# SR-01 — Constitución y leyes fundamentales del universo

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.1  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5  
**Dependencias:** Ninguna. Este documento establece la autoridad normativa de los documentos posteriores.

## Control de versiones

- **v1.0:** Constitución inicial: existencia, identidad, causalidad, vida, muerte, memoria, inteligencia, evolución, sociedades, economía, progresión, mundo híbrido y gobernanza.
- **v1.1:** Incorpora las decisiones expresas del usuario: reencarnación mixta; muerte condicionalmente reversible; tiempo global persistente. Añade como principio que los habitantes pueden investigar las leyes de su propia realidad.

---

# 0. Propósito y autoridad

Esta constitución define las condiciones fundamentales que todos los sistemas deben respetar: simulación, inteligencia, memoria, evolución, combate, criaturas, objetos, economía, sociedades, narrativa, generación de contenido, sincronización y persistencia.

No define todavía cada fenómeno del universo. Establece qué condiciones debe cumplir cualquier fenómeno que se incorpore después. Las leyes físicas, químicas, biológicas y mágicas se especificarán en documentos especializados, pero no podrán contradecir los principios constitucionales.

### 0.1. Lenguaje normativo

- **DEBE:** obligación para todos los sistemas pertinentes.
- **NO DEBE:** comportamiento prohibido.
- **PUEDE:** comportamiento permitido si cumple las demás leyes.
- **CONDICIONADO:** comportamiento permitido solo al cumplirse condiciones identificables.
- **PENDIENTE:** decisión que debe definirse antes de implementar el dominio correspondiente.

### 0.2. Jerarquía de autoridad

Ante una contradicción prevalece este orden:

1. Constitución del universo.
2. Leyes especializadas aplicables al dominio.
3. Estado objetivo y acontecimientos confirmados.
4. Contratos y permisos de los sistemas.
5. Capacidades, conocimientos y decisiones de las entidades.
6. Objetivos narrativos y conveniencias de presentación.
7. Animaciones, efectos y representación del cliente.

Una animación no modifica la realidad. Una misión no inventa historia pasada. Una propuesta generativa no se vuelve un hecho sin validación.

# PARTE I — NATURALEZA DE LA REALIDAD

## 1. Ley de existencia

Todo aquello que exista dentro del universo debe poder representarse como entidad, fenómeno, recurso, lugar, relación o acontecimiento. No todo tiene que estar vivo, ser inteligente o tener forma física.

Las categorías incluyen, sin limitarse a ellas:

- Individuos: jugadores, NPC, monstruos y otras criaturas.
- Especies, linajes y poblaciones.
- Objetos, armas, herramientas y materiales.
- Construcciones, ciudades, territorios y ecosistemas.
- Facciones, gremios, familias y comunidades.
- Habilidades, técnicas y conocimientos.
- Fenómenos naturales, mágicos o sobrenaturales.
- Acontecimientos, descubrimientos y procesos históricos.

Toda entidad persistente DEBE tener identidad lógica, separada de su apariencia visual.

## 2. Ley de identidad y continuidad

Cada entidad persistente tendrá una identidad única dentro del ámbito de autoridad definido. Su identidad no depende de nombre, apariencia, modelo 3D, cuerpo, ubicación, nivel o inventario.

La identidad deberá permitir relacionar origen, trayectoria, relaciones, transformaciones, posesiones, capacidades, genealogía y acontecimientos.

### 2.1. Transformación sin pérdida automática de identidad

Una entidad puede conservar su identidad después de cambiar de apariencia, anatomía, capacidades, afiliación, profesión, nombre o ubicación. La continuidad se determina por las reglas de identidad del tipo de entidad.

### 2.2. Creación de nuevas identidades

El nacimiento, fabricación, construcción o aparición de una nueva entidad genera una identidad nueva, vinculada a su procedencia cuando corresponda.

### 2.3. Copias

Una réplica, clon, reconstrucción o copia de recuerdos no hereda automáticamente la identidad del original. Compartir información no equivale a compartir existencia.

## 3. Ley del estado objetivo

El universo mantiene un estado objetivo independiente de las creencias de sus habitantes. Deben distinguirse:

- **Hecho:** acontecimiento que ocurrió realmente.
- **Observación:** información que una entidad percibió.
- **Recuerdo:** representación conservada de una experiencia o información.
- **Interpretación:** explicación construida por una entidad.
- **Creencia:** afirmación que una entidad considera cierta.
- **Hipótesis:** explicación aún no confirmada.
- **Rumor:** información transmitida con fiabilidad variable.
- **Predicción:** posibilidad futura, no hecho consumado.

Un NPC solo puede conocer información que haya percibido, investigado, deducido a partir de evidencias accesibles o recibido por transmisión válida. El mundo puede conocer el estado objetivo sin revelar ese conocimiento a sus habitantes.

## 4. Ley de causalidad

Todo cambio relevante debe tener causa o mecanismo que lo haga posible. Un resultado puede ser inesperado, raro o desconocido para los habitantes, pero debe ser compatible con las leyes del universo o identificarse como una anomalía pendiente de explicación.

### 4.1. Cadenas causales

Un acontecimiento puede producir consecuencias inmediatas, individuales, sociales, económicas, ecológicas, regionales e históricas. Las consecuencias pueden aparecer mucho después del acontecimiento original.

### 4.2. Consecuencias pendientes

Un acontecimiento no termina necesariamente con su efecto inmediato. Robar un objeto puede iniciar una cadena de decisiones: esconderlo, usarlo, venderlo, perderlo, entregarlo o transformarlo. Las consecuencias pertinentes no desaparecen porque el jugador abandone la zona.

### 4.3. Aleatoriedad condicionada

La aleatoriedad puede seleccionar entre resultados posibles, pero no sustituye las condiciones que hacen posible el resultado. Las probabilidades pueden depender de contexto, capacidades, historia individual, entorno, recursos, motivaciones, relaciones y acontecimientos previos.

## 5. Ley de continuidad temporal

El universo posee tiempo propio y no depende de los fotogramas ni de la presencia del jugador. Las entidades pueden actuar, descansar, viajar, aprender, envejecer, reproducirse, morir y producir consecuencias sin ser observadas.

Se distinguen escalas de resolución:

- Inmediata: combate, impactos y acciones de respuesta rápida.
- Cotidiana: rutinas, actividades, relaciones y viajes.
- Ecológica: poblaciones, recursos, migraciones y generaciones.
- Histórica: sociedades, acontecimientos regionales y procesos prolongados.

La simulación puede resumir procesos de baja relevancia, pero debe conservar sus invariantes, causas y resultados. Reducir precisión no equivale a congelar la existencia.

# PARTE II — VIDA, MUERTE E INTELIGENCIA

## 6. Ley de vida

La vida es un proceso organizado de continuidad, mantenimiento y transformación de una entidad biológica o de otra naturaleza definida por las reglas del universo. Estar vivo no implica ser inteligente, tener lenguaje, cultura o emociones humanas.

Cada tipo de organismo podrá tener anatomía, estado fisiológico, necesidades, sentidos, reservas, lesiones, edad, adaptaciones, rasgos hereditarios y limitaciones propios. No se impondrá un único modelo biológico a todas las especies.

## 7. Ley de muerte — muerte condicionalmente reversible

La muerte es la terminación de una determinada continuidad vital. Deben distinguirse daño, incapacidad, inconsciencia, agonía, muerte, descomposición o desaparición corporal y persistencia de identidad, historia o legado.

**Decisión aprobada v1.1:** la muerte puede revertirse, pero solo bajo condiciones extraordinarias, mecanismos definidos y consecuencias relevantes. No existirá una resurrección universal, gratuita ni automática.

El sistema diferenciará como mínimo:

1. **Reanimación:** el cuerpo vuelve a funcionar, sin garantizar que recupere la identidad anterior.
2. **Resurrección:** se intenta restaurar la continuidad de la entidad fallecida.
3. **Reencarnación:** comienza una nueva existencia que puede conservar componentes de la anterior.

La reversión podrá depender de naturaleza de la entidad, tiempo transcurrido, integridad de los elementos necesarios, recursos, conocimientos, mecanismos disponibles y leyes metafísicas. La muerte conserva consecuencias aun cuando un mecanismo excepcional permita revertirla.

## 8. Ley de reencarnación — continuidad mixta

**Decisión aprobada v1.1:** la reencarnación podrá conservar componentes de la existencia anterior en proporciones variables. Estos componentes pueden incluir identidad esencial, fragmentos de memoria, capacidades, predisposiciones, conocimientos, tendencias emocionales o vínculos residuales cuando exista un mecanismo válido.

No se garantiza que todos sobrevivan juntos. Una entidad puede conservar continuidad esencial sin recuerdos conscientes; otra puede tener recuerdos fragmentarios, capacidades heredadas o reacciones emocionales sin conservar la personalidad anterior.

Reencarnar no equivale a reiniciar estadísticas ni a resucitar automáticamente. La nueva vida tendrá trayectoria propia. La continuidad podrá ser confirmada, probable, parcial, desconocida o solo aparente. Los habitantes podrán investigar indicios, pero no conocerán automáticamente la verdad metafísica.

## 9. Ley de inteligencia y agencia

La inteligencia es multidimensional. No se reduce a un único número. Debe contemplar percepción, atención, reconocimiento, memoria, aprendizaje, razonamiento, planificación, anticipación, resolución de problemas, comunicación, creatividad, adaptación y autonomía.

La arquitectura será híbrida:

1. Simulación cognitiva estructurada.
2. Planificación y evaluación de acciones.
3. Aprendizaje mediante experiencias.
4. Modelos generativos opcionales para proponer hipótesis, planes, explicaciones o diálogos.

Una entidad solo puede actuar si posee información, capacidad, recursos, oportunidad, tiempo y condiciones compatibles. Imaginar una acción no otorga capacidad para ejecutarla. Las propuestas generativas no modifican el mundo sin validación.

## 10. Ley de memoria

La memoria no es una copia infalible de la realidad. Puede ser incompleta, selectiva, distorsionada o contradictoria. Se distinguen memorias sensorial, episódica, semántica, procedimental, emocional, social, espacial y prospectiva.

La memoria privada pertenece a un individuo; la memoria colectiva, a grupos, sociedades, familias o especies. La información privada solo se difunde por mecanismos válidos de comunicación, observación, enseñanza, publicación, comercio o investigación.

Olvidar no elimina el acontecimiento histórico. El sistema separará hecho, percepción original, recuerdo actual e interpretación posterior. Los recuerdos relevantes conservarán fuente y grado de confianza.

# PARTE III — EVOLUCIÓN, APRENDIZAJE Y TRANSFORMACIÓN

## 11. Ley universal de evolución

Todas las especies y entidades podrán evolucionar si su naturaleza, capacidades y circunstancias lo permiten. No habrá árboles evolutivos cerrados que determinen anticipadamente todas las formas posibles.

La evolución puede afectar anatomía, fisiología, percepción, resistencia, inteligencia, conducta, adaptaciones, capacidades especiales, organización social, cultura, reproducción y relación con otras especies.

La evolución no es siempre positiva. Puede tener costes, vulnerabilidades, necesidades nuevas, pérdidas de capacidades o dificultades de adaptación. Una entidad excepcional necesita una trayectoria y mecanismos compatibles con sus características.

## 12. Ley de aprendizaje

Aprender es modificar conocimientos, procedimientos o modelos de interpretación mediante información y experiencia. Puede depender de atención, capacidad, repetición, enseñanza, práctica, recursos, comprensión, retroalimentación y contexto.

El aprendizaje estratégico permite modificar decisiones después de observar resultados. Una criatura puede dejar de atacar frontalmente a escudados y buscar ángulos, objetivos separados o rutas alternativas, siempre que haya podido observar y aprender esas tácticas.

## 13. Ley de descubrimiento

Los habitantes pueden formular hipótesis, experimentar, fracasar, conservar resultados y descubrir técnicas, recetas, materiales, fenómenos o leyes. El descubrimiento no es exclusivo del jugador.

El conocimiento nuevo no aparece automáticamente en todas las entidades: necesita transmisión. Los descubrimientos conservarán procedencia, evidencias, grado de certeza y posibles errores.

## 14. Ley de transformación de materiales y objetos

Los objetos tienen identidad, composición, estado, procedencia y propiedades. Pueden deteriorarse, repararse, transformarse, combinarse, dividirse o destruirse mediante procesos válidos.

La fabricación depende de materiales, cantidades, herramientas, técnica, conocimiento, habilidad, tiempo y condiciones pertinentes. No toda combinación produce un objeto funcional. La fabricación, reparación y consumo modifican recursos verificables.

Dos objetos de la misma categoría pueden tener historias y propiedades diferentes. La singularidad puede provenir de composición, geometría, método, transformaciones e historia, no solo de color o estadísticas.

# PARTE IV — SOCIEDADES, ECOLOGÍA Y NARRATIVA

## 15. Ley de ecología

Las criaturas no existen solo para combatir con el jugador. Pueden alimentarse, reproducirse, descansar, desplazarse, competir, protegerse, migrar, ocupar territorios y responder a cambios ambientales.

Las poblaciones se ven afectadas por recursos, depredación, enfermedades, competencia, reproducción, migración, presión de otras especies, actividad de aventureros y fenómenos extraordinarios. La reducción de una especie puede afectar a otras. El equilibrio no exige que todos los encuentros sean apropiados para el jugador.

## 16. Ley de sociedad y relaciones

Entidades humanas y no humanas pueden formar comunidades, jerarquías, culturas, organizaciones, alianzas y conflictos, según sus capacidades y circunstancias.

Las relaciones no son simples indicadores binarios. Pueden incluir confianza, respeto, rivalidad, deuda, lealtad, dependencia, temor, admiración, desconfianza, amor, resentimiento, gratitud, interés y obligación. La relación puede ser asimétrica: dos individuos no tienen por qué interpretar igual el vínculo.

Las decisiones individuales pueden alterar reputación, información, alianzas, comercio y memoria colectiva.

## 17. Ley de economía y propiedad

Dinero, materiales, productos, armas, territorios y servicios tienen procedencia y cantidad verificables. Se distingue propiedad, posesión física, custodia, préstamo, deuda, robo, abandono, recompensa y herencia.

Los precios y la disponibilidad pueden variar por oferta, demanda, producción, escasez, transporte, conflictos, riesgos y descubrimientos. Los recursos no aparecen ilimitadamente por conveniencia narrativa.

## 18. Ley de narrativa emergente

La narrativa detecta, organiza y presenta acontecimientos reales; no tiene autoridad para falsificar la realidad. Las historias pueden surgir de relaciones, pérdidas, descubrimientos, conflictos, migraciones, rivalidades, deudas, secretos, accidentes y decisiones.

Las misiones pueden tener múltiples resultados, incluso fracaso, abandono, resolución por NPC o consecuencias inesperadas. No todo acontecimiento importante debe estar disponible para el jugador ni esperar su intervención.

## 19. Autonomía epistemológica

**Decisión aprobada:** los habitantes pueden investigar las leyes de su propia realidad. Un investigador puede estudiar magia, biología, materiales, causalidad o fenómenos; una civilización puede desarrollar teorías; una criatura inteligente puede investigar sus capacidades.

Pueden descubrir verdades, sostener hipótesis incompletas, equivocarse, ocultar conocimientos o mantener dogmas falsos. El sistema conserva el estado objetivo, pero no concede omnisciencia a sus habitantes. Investigar no otorga privilegios para romper las leyes.

# PARTE V — JUGADORES, PROGRESIÓN Y COMBATE

## 20. Ley de progresión

La progresión distinguirá atributos, dominio, experiencia y nivel o categoría evolutiva. No todo crecimiento depende de la misma cifra.

Los ascensos importantes requieren méritos, acontecimientos o transformaciones significativas, no solo acumular experiencia ordinaria. Las diferencias de poder entre niveles pueden ser grandes. NPC y monstruos también pueden progresar, aunque no todos utilicen la misma escala.

## 21. Ley de combate y consecuencias físicas

El combate debe respetar distancia, dirección, posición, velocidad, equilibrio, fuerza, técnica, arma, defensa, resistencia, fatiga, terreno, percepción y reacción. Evasión no equivale a invulnerabilidad. Bloqueo, parada, cobertura y resistencia son resultados diferentes.

Las animaciones representan acciones autorizadas, no sustituyen la resolución lógica. El cliente puede predecir visualmente, pero el dominio autorizado confirma consecuencias compartidas.

# PARTE VI — MUNDO HÍBRIDO Y PERSISTENCIA

## 22. Ley de mundo compartido y experiencias individuales

El universo tiene un mundo global compartido y experiencias individuales. Ambos respetan las mismas leyes. El mundo global contiene reglas, economía compartida, facciones, historia, descubrimientos difundidos y acontecimientos comunes. Las experiencias individuales contienen recuerdos, relaciones, encuentros, misiones y consecuencias particulares.

Los acontecimientos individuales pueden influir en lo global si existe un mecanismo válido de promoción, difusión o impacto causal.

## 23. Ley de tiempo global persistente

**Decisión aprobada v1.1:** el mundo global continúa evolucionando aunque el jugador no esté conectado. NPC, monstruos, poblaciones, recursos, organizaciones y acontecimientos no esperan al jugador.

La simulación puede utilizar distintos niveles de precisión y resumir procesos secundarios, pero no debe congelar la existencia ni inventar teletransportes narrativos. Los resultados resumidos deben ser compatibles con capacidades, recursos, tiempos y causas.

El modo offline individual puede calcular tiempo transcurrido localmente al regresar. Un único mundo compartido entre dispositivos desconectados requiere reconciliación posterior o una autoridad online; no debe fingirse sincronización inexistente.

## 24. Ley de persistencia histórica

Los acontecimientos importantes deben conservarse con identidad, participantes, tiempo, causa, ámbito, autoridad, procedencia y consecuencias. No es necesario registrar cada movimiento trivial para siempre, pero sí preservar información suficiente para reconstruir los estados y resultados relevantes.

# PARTE VII — INTEGRIDAD Y GOBERNANZA

## 25. Ley de validación universal

Ningún sistema modifica un estado persistente sin validaciones pertinentes. Deben comprobarse existencia, capacidad, condiciones, recursos, autoridad, reglas del dominio, causalidad y consecuencias.

## 26. Ley de procedencia

Toda entidad, conocimiento, objeto y acontecimiento relevante debe poder indicar origen, creador, materiales, método, fuente, transmisión, transformaciones y evidencias cuando corresponda.

## 27. Ley contra contradicciones

El sistema detectará objetos duplicados, conocimientos imposibles, habilidades sin adquisición, comercio sin recursos, individuos muertos que actúan como vivos, identidades duplicadas y conflictos de sincronización.

No borrará automáticamente un resultado extraño. Primero distinguirá error, percepción incompleta, falsificación, conflicto de sincronización o fenómeno extraordinario legítimo. La rareza no constituye por sí sola una contradicción.

## 28. Ley de seguridad e integridad competitiva

El cliente no confirma unilateralmente operaciones que afectan al mundo compartido: inventarios, comercio, PvP, recompensas, propiedad, progresión confirmada y eventos globales. La autoridad correspondiente valida dichas operaciones.

# PARTE VIII — PRINCIPIOS INMUTABLES

## 29. Independencia del jugador

El mundo sigue existiendo aunque el jugador no participe en sus acontecimientos.

## 30. Información limitada

Cada entidad conoce aquello que pudo percibir, aprender, deducir o recibir legítimamente.

## 31. Consecuencias

Las acciones importantes pueden producir efectos duraderos aunque el jugador no los observe.

## 32. Diversidad

Individuos de una misma especie pueden diferenciarse por historia, herencia, experiencia, entorno, aprendizaje y evolución.

## 33. Descubrimiento

El universo permite resultados emergentes compatibles con sus reglas, sin necesidad de prediseñar individualmente cada resultado.

## 34. Singularidad histórica

Individuos y objetos pueden desarrollar historias irrepetibles aun cuando compartan plantilla o apariencia.

## 35. Coherencia sobre conveniencia

No se rompe la consistencia del mundo para facilitar una misión, asegurar una recompensa o evitar una consecuencia.

## 36. Evolución abierta

Se permiten desarrollos emergentes, pero cada resultado necesita mecanismo, condiciones y límites.

## 37. Separación entre realidad y representación

La lógica de una entidad y su representación visual son independientes. El modelo 3D no define identidad, inteligencia, historia ni capacidades.

# PARTE IX — CRITERIOS DE CUMPLIMIENTO

La constitución no se considera implementada porque existan variables con sus nombres. Debe superar pruebas repetibles:

1. Un NPC no conoce hechos que no pudo conocer.
2. Una muerte detiene la actividad vital, pero conserva historia.
3. Las consecuencias de una muerte afectan relaciones pertinentes.
4. Las transformaciones tienen condiciones y procedencia.
5. El aprendizaje modifica decisiones a partir de experiencias disponibles.
6. La desaparición de un depredador produce consecuencias ecológicas coherentes.
7. Los recursos económicos tienen fuente verificable.
8. La fabricación explica materiales y proceso.
9. Las misiones se vinculan con acontecimientos y entidades reales.
10. Las ramas personales no contradicen arbitrariamente el canon global.
11. La sincronización usa autoridad y causalidad, no solo hora de llegada.
12. Individuos equivalentes pueden desarrollar trayectorias distintas.
13. Los acontecimientos relevantes sobreviven a cambios de sesión.
14. Las hipótesis de habitantes no se confunden con la realidad objetiva.
15. La reencarnación y la reversión de la muerte conservan las distinciones definidas.

# PARTE X — DECISIONES RESERVADAS

Quedan pendientes leyes especializadas sobre: metafísica de conciencia y alma; mecanismos concretos de reencarnación y resurrección; sistema mágico; biología y reproducción; requisitos exactos de progresión; promoción entre mundo personal y global; muerte del jugador; escalas temporales; capacidades cognitivas; economía y geografía.

Estas decisiones deben desarrollarse en documentos especializados y no improvisarse dentro del código de un sistema aislado.

# DECLARACIÓN FUNDACIONAL

Este universo no será una colección de escenarios, personajes y enemigos que esperan a que alguien los active. Será una realidad simulada con entidades que poseen identidad, capacidades, necesidades, historia, relaciones y posibilidades de transformación.

Los individuos podrán equivocarse, aprender, adaptarse, fracasar, prosperar, desaparecer y, bajo condiciones, regresar de formas diferentes. Los acontecimientos tendrán causas y consecuencias. Los conocimientos tendrán procedencia. Los objetos podrán tener genealogía. Las sociedades podrán cambiar. Los ecosistemas podrán responder. Las historias podrán surgir sin haber sido escritas previamente.

**La primera obligación del Sistema Rector no será crear acontecimientos interesantes. Será conservar una realidad coherente en la que acontecimientos interesantes puedan ocurrir.**

# REGISTRO MAESTRO DE ESTADO, APROBACIONES E INTEGRACIÓN

**Proyecto:** World Laboratory / Sistema Reactor  
**Fecha de corte documental:** 20 de noviembre de 2026  
**Estado:** SR-01 a SR-15 principales figuran como documentos oficiales aprobados; SR-15 incluye además un bloque técnico complementario de 44 secciones, identificado por separado.

Este registro es administrativo. El contenido normativo completo está en los documentos individuales. En caso de conflicto prevalece la jerarquía normativa de SR-01 y la autoridad definida por los SR; este índice no crea reglas nuevas.

| Código | Versión | Estado | Alcance / reserva importante |
|---|---:|---|---|
| SR-01 | 1.1 | Aprobada | Constitución y leyes fundamentales; incluye las enmiendas de reencarnación mixta, muerte condicionalmente reversible y tiempo global persistente. |
| SR-02 | 1.0 | Aprobada | Arquitectura interna del Sistema Rector. |
| SR-03 | 1.0 | Aprobada | Identidad, inteligencia, memoria, aprendizaje y evolución. |
| SR-04 | 1.0 | Aprobada | Mundo híbrido, causalidad, persistencia y funcionamiento offline. |
| SR-05 | 1.0 | Aprobada | Creation Engine, entidades, organismos, materiales, objetos y representación. |
| SR-06 | 1.0 | Aprobada | World Laboratory, Simulation Kernel, scheduler y observación. |
| SR-07 | 1.0 | Aprobada | Leyes naturales, arcanas y de interacción; dioses y mecánicas divinas siguen sin definición. |
| SR-08 | 1.0 | Aprobada | Biología, fisiología, reproducción, herencia, monstruos, salud y ecología. |
| SR-09 | 1.0 | Aprobada | Combate, daño, curación, clases, aprendizaje y adaptación táctica. |
| SR-09 Anexo A | 1.0 | Aprobado | Veyrath y 72 hechizos de referencia para pisos 1–5; formulación mediante palabras completas ordenadas en oraciones; balance sujeto a calibración. |
| SR-10 | 0.1 | Aprobada | Economía, comercio, recursos, botín y fabricación. UM es unidad de cuenta de trabajo; MC/MP/MO son rótulos heredados provisionales, no canónicos. |
| SR-11 | 0.1 | Aprobada | Geografía, asentamientos y Mazmorra; dimensiones, nombres propios y planos exactos sujetos a calibración donde así se indica. |
| SR-12 | 0.1 | Aprobada | Progresión, atributos, experiencia, clases y maestría. |
| SR-13 | 0.1 | Aprobada | Sociedad, cultura, instituciones y Arcana como fundamento civilizatorio no divino. |
| SR-14 | 0.1 | Aprobada | Historia fundacional y emergente; campaña inicial de referencia: El Eco de Vhaloren. |
| SR-15 principal | 1.0 | Aprobado | Arquitectura técnica, ejecución, Android, simulación y validación; mantiene 88 secciones numeradas 1–88. |
| SR-15-B complemento | Fuente v0.1; bloque complementario | Incorporado como material técnico complementario por instrucción del autor | Mantiene 44 secciones numeradas localmente 1–44; no sustituye ni modifica silenciosamente SR-15 v1.0 y no se presenta como una aprobación independiente del cuerpo principal. |

## Actas y evidencias de aprobación registradas

- **SR-01 a SR-07:** se conservan como paquete fundacional aprobado; las copias oficiales incorporan metadatos editoriales de estado coherentes. SR-01 v1.1 incluye las tres decisiones consolidadas: reencarnación mixta, muerte condicionalmente reversible y tiempo global persistente.
- **SR-08 v1.0:** aprobación expresa y posterior consolidación con las respuestas del autor; se mantiene la separación de responsabilidades biológicas/ecológicas y de combate.
- **SR-09 v1.0 y Anexo A:** aprobación expresa del marco de combate y del anexo. La formulación de hechizos usa palabras léxicas completas ordenadas como oraciones, no secuencias cortas de sílabas. Los parámetros de balance siguen calibrables donde el texto lo indica.
- **SR-10 v0.1:** aprobación con valores numéricos y nombres regionales sujetos a calibración. El usuario indicó que MC/MP/MO no deben tratarse como nombres canónicos definitivos; UM se conserva como etiqueta neutral de trabajo.
- **SR-11 v0.1:** aprobación expresa; dimensiones, nombres propios, planos exactos y distribuciones permanecen sujetos a calibración donde se indica.
- **SR-12 v0.1:** aprobación delegada y confirmada; se entregó como aprobado sin dudas bloqueantes.
- **SR-13 v0.1:** aprobación delegada y confirmada bajo autorización para completar la propuesta sin esperar otra revisión si no había dudas bloqueantes.
- **SR-14 v0.1:** aprobación expresa del autor el 20-11-2026. El Eco de Vhaloren se conserva como campaña inicial de referencia; los nombres que el cuerpo marca como provisionales mantienen ese carácter.
- **SR-15 principal v1.0:** aprobado para incorporarse al paquete oficial. Su acta se refiere al cuerpo de 88 secciones y no declara que el software esté implementado o validado.
- **SR-15-B:** su inclusión como bloque complementario de 44 secciones fue solicitada expresamente al consolidar los dos paquetes. Se conserva diferenciado y subordinado; su incorporación no debe confundirse con una nueva aprobación integral de cada posible diferencia o baseline.

## Cómo interpretar «aprobado»

«Aprobado» significa que las reglas estructurales y decisiones incluidas en el documento forman parte del canon normativo en el alcance que el propio texto declara. No significa que todos los nombres, planos, fórmulas numéricas, costes, curvas o máximos se hayan fijado. Las etiquetas CALIBRACIÓN, RESERVADO, PENDIENTE, BASELINE TÉCNICO y NO VERIFICADO mantienen exactamente el alcance abierto que declaran. No rellenar esos huecos por inferencia.

## Reglas de lectura de SR-15

1. Leer SR-15 principal v1.0 completo: 88 secciones, numeración 1–88.
2. Leer después SR-15-B completo: 44 secciones, numeración local 1–44.
3. No fusionar las numeraciones ni eliminar duplicaciones aparentes de temas: parte de la finalidad es añadir concreción.
4. Si una cláusula del complemento contradice SR-01 a SR-14 o al cuerpo principal de SR-15, registrar el conflicto con las dos referencias exactas y esperar resolución.
5. Distinguir siempre entre normativa aprobada, complemento incorporado, decisión de implementación, calibración y característica realmente implementada.

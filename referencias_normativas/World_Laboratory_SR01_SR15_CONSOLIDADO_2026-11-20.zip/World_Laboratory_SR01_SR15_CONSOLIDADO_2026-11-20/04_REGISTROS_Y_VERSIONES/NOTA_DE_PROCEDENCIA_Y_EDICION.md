# NOTA DE EDICIÓN, PROCEDENCIA Y CRITERIO DE CONSOLIDACIÓN

Este paquete se compiló el 20-11-2026 a partir de los dos ZIP aportados por el autor. El paquete `World_Laboratory_Sistema_Reactor_SR01_SR15_OFICIAL_2026-11-20.zip` se utilizó como base por contener las ediciones más completas/recientes de los documentos normativos principales y las actas de aprobación más actuales. El paquete `World_Laboratory_SR01_SR15_Paquete_Oficial_2026-11-20.zip` se utilizó como fuente complementaria, en particular para el segundo bloque técnico de SR-15 y para preservar detalles adicionales de continuidad.

## Selección de SR-01 a SR-14

- SR-01 a SR-07: se conservaron las versiones del paquete Sistema Reactor, que incluyen la declaración editorial coherente con su estado oficial. Las diferencias sustantivas entre copias son mínimas o se limitan a control de estado, salvo las precisiones indicadas más abajo.
- SR-08: las dos copias comparadas son idénticas; se conservó la del paquete Sistema Reactor.
- SR-09: se conservó la edición del paquete Sistema Reactor, que explicita mejor la aprobación del autor y mantiene las precisiones de reconocimiento de clases y cierre normativo.
- SR-09 Anexo A: se conservó la edición del paquete Sistema Reactor, que explicita la aprobación y la revisión lingüística solicitada: fórmulas compuestas por palabras completas y ordenadas como oraciones. Se mantienen los 72 hechizos y los valores calibrables donde el documento los identifica.
- SR-10: se conservó la edición del paquete Sistema Reactor, que incluye la nota explícita sobre UM y el carácter provisional/no canónico de las abreviaturas MC/MP/MO, además de precisar el estado de los valores de referencia.
- SR-11, SR-12 y SR-13: las copias de ambos paquetes son idénticas; se conservaron las del paquete Sistema Reactor.
- SR-14: se conservó la edición del paquete Sistema Reactor, con sus declaraciones explícitas de aprobación y el tratamiento más preciso de nombres de trabajo y campaña de referencia.

## Integración de SR-15

- El SR-15 principal v1.0 del paquete Sistema Reactor se conserva íntegro, con sus **88 secciones numeradas 1–88**. No se redujo ni se reestructuró.
- El SR-15 v0.1 del segundo paquete aporta **44 secciones diferentes**. Se conservan completas como `SR-15-B`, con numeración local 1–44 y con el texto técnico de sus secciones preservado. Solo se ajustó el encabezado y el control documental para que su condición en este paquete quede clara: complemento subordinado, no reemplazo ni nueva versión principal aprobada.
- El conjunto SR-15 se lee como cuerpo principal de 88 secciones seguido del bloque complementario de 44 secciones. No se mezclan ni renumeran los bloques. Los conflictos se deben señalar, nunca resolver por inferencia.

## Material explicativo adicional

Se conserva la Guía Maestra del paquete Sistema Reactor y también una referencia complementaria de continuidad procedente del segundo paquete. Esta segunda referencia queda identificada como no normativa y de procedencia histórica; cualquier estado o versión antigua mencionado en ella cede ante los SR individuales y el registro actualizado.

Los cuerpos normativos fuente se preservan completos salvo las aclaraciones expresas de control documental del bloque SR-15-B. Las propuestas históricas y los compendios antiguos no se incluyen como autoridades paralelas. Se generó un compendio completo nuevo a partir de las fuentes seleccionadas en este paquete y se regeneró el manifiesto SHA-256.

# SR-05 — Creation Engine
## Arquitectura de creación de entidades, organismos, materiales, objetos y representaciones

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5  
**Dependencias:** SR-01 a SR-04.

# PARTE I — PRINCIPIOS FUNDAMENTALES

## 1. Propósito

El Creation Engine crea, transforma, registra y valida las entidades que pueden existir en el universo: especies, individuos, organismos, anatomías, materiales, recursos, objetos, armas, herramientas, armaduras, habilidades, estructuras, recursos ambientales y assets audiovisuales.

No es solo un generador visual. Establece cómo algo aparece en la realidad, qué condiciones cumple y qué capacidades posee.

## 2. Separación entre existencia y representación

Una entidad lógica puede existir antes de tener modelo 3D. La especie puede estar definida por anatomía, necesidades, metabolismo, capacidades, sentidos, ecología y evolución aunque el asset visual todavía no se haya producido.

El modelo no define por sí mismo las capacidades. Alas visuales no garantizan vuelo; una espada enorme no tiene masa arbitraria; un objeto luminoso no es automáticamente mágico. La representación debe corresponder a tamaño, anatomía, materiales, estado, daños y transformaciones lógicas.

## 3. Definición, plantilla, individuo y representación

- **Definición:** describe una clase, especie, estructura o tipo.
- **Plantilla:** configura una creación reutilizable.
- **Individuo:** entidad concreta con identidad e historia.
- **Variante:** diferencia compatible con definición existente.
- **Representación:** recursos que muestran al individuo.

Miles de criaturas pueden compartir plantilla sin compartir identidad, memoria ni trayectoria.

## 4. Procedencia

Toda entidad importante conserva origen, creador o progenitores, método, materiales, herramientas, conocimientos requeridos y transformaciones. La procedencia se integra con Chronicle.

# PARTE II — ARQUITECTURA

## 5. Subsistemas

1. **Creation Core:** coordina creación y dependencias.
2. **Ontology Registry:** define categorías y relaciones posibles.
3. **Blueprint Engine:** administra definiciones y plantillas.
4. **Entity Generation Engine:** crea individuos y entidades concretas.
5. **Anatomy & Morphology Engine:** construye y valida anatomías.
6. **Material & Object Engine:** propiedades, materiales, objetos y fabricación.
7. **Capability Engine:** valida capacidades y requisitos de acción.
8. **Evolution Interface:** conecta con Evolution Engine.
9. **Asset Factory:** produce o asigna recursos visuales.
10. **Creation Validator:** comprueba coherencia física, biológica, material, causal y funcional.

Los subsistemas son responsabilidades lógicas, no servidores obligatoriamente separados.

# PARTE III — ESPECIES Y ORGANISMOS

## 6. Species Blueprint

Cada especie tendrá definición independiente de sus individuos. La ficha puede incluir taxonomía, familia o linaje, especies relacionadas, origen, distribución, estado poblacional, anatomía, fisiología, ecología, cognición y capacidades.

### 6.1. Anatomía

Incluye plan corporal, simetría, tamaño habitual, regiones, extremidades, órganos, sistemas internos, articulaciones, sensores y estructuras locomotoras. No se obliga a utilizar cuerpo humano.

### 6.2. Fisiología

Incluye metabolismo, alimentación, respiración cuando corresponda, circulación, regulación térmica, recuperación, resistencia, energía, ciclo vital y condiciones ambientales.

### 6.3. Ecología

Incluye hábitat, territorio, alimentos, depredadores, competidores, relaciones, reproducción, migración y adaptaciones.

### 6.4. Cognición

La especie puede definir predisposiciones y rangos habituales de percepción, memoria, aprendizaje, planificación y comunicación, pero sus individuos pueden diferir y evolucionar.

### 6.5. Capacidades

Posibles capacidades: vuelo, excavación, natación, veneno, camuflaje, regeneración, sentidos especiales, manipulación, comunicación o capacidades mágicas. La posibilidad de especie no significa que todos los individuos la posean.

## 7. Anatomía funcional

La anatomía se representa mediante regiones, órganos, sistemas, soportes, articulaciones, elementos de movimiento, sensores y puntos de interacción. El plan corporal puede ser bípedo, cuadrúpedo, multipodal, serpentino, volador, acuático, segmentado, radial o alternativo.

### 7.1. Articulaciones

Cada articulación declara ejes, rango, restricciones, estabilidad, carga y relación con otras estructuras. La animación no puede doblar miembros de forma incompatible.

### 7.2. Accionamiento

Músculos, tendones y otros mecanismos biológicos, o mecanismos equivalentes no biológicos, explican movimiento y fuerza.

### 7.3. Órganos y sensores

Los organismos pueden utilizar sistemas respiratorio, circulatorio, digestivo, nervioso, sensorial, musculoesquelético, excretor, reproductor, protector o energético según su naturaleza. Los sentidos pueden detectar luz, movimiento, sonido, vibración, químicos, temperatura o fenómenos especiales.

## 8. Validación anatómica

Comprobar soporte, peso, movilidad, estabilidad, articulaciones, órganos, energía, percepción, ambiente y reproducción cuando corresponda. Las especies mágicas o sobrenaturales pueden usar mecanismos distintos, pero deben declararlos; la excepción necesita explicación.

# PARTE IV — HERENCIA Y VARIACIÓN

## 9. Genotipo y fenotipo

El genotipo/configuración hereditaria es información transmisible según mecanismo reproductivo. Fenotipo es la expresión resultante de herencia y circunstancias. No todos los rasgos son heredables.

Rasgos heredables posibles: tamaño potencial, estructura corporal, pigmentación, sensores, metabolismo, predisposiciones cognitivas, resistencia, adaptaciones y predisposición mágica si se define.

Rasgos adquiridos: lesión, cicatriz, técnica aprendida, hábito, modificación corporal o experiencia. No se heredan automáticamente sin mecanismo específico.

## 10. Creación de individuo

El proceso determina origen, identidad, especie/estructura, herencia, variaciones, anatomía, fisiología, capacidades, perfil cognitivo, necesidades, motivaciones, relaciones y procedencia; valida la entidad y asigna/genera su representación.

## 11. Nacimiento y reproducción

Debe respetar compatibilidad, recursos, estado de progenitores, tiempo de desarrollo, supervivencia, entorno, herencia y variación. Nacimiento crea identidad nueva y relación genealógica.

# PARTE V — VARIANTES Y EXCEPCIONALIDAD

## 12. Niveles de individuo

- **Ordinario:** plantilla y anatomía compartidas; variaciones menores de edad, tamaño, color, estado, memoria y personalidad.
- **Especializado:** diferencias anatómicas o capacidades significativas; puede requerir variante de modelo, rigging o animación.
- **Excepcional:** trayectoria, anatomía, inteligencia, capacidades, apariencia o historia singulares; puede requerir recursos visuales específicos.

La singularidad lógica e histórica no siempre exige un modelo exclusivo.

## 13. Generación reproducible

La creación importante conserva semilla, versión de definición, parámetros, reglas, procedencia y resultado validado. Una actualización de generador no altera silenciosamente entidades históricas.

## 14. Evolución de formas

Las propuestas del Evolution Engine pasan por evaluación de viabilidad, compatibilidad, cambio hereditario/adquirido, procedencia, representación y validación funcional. Una estructura nueva necesita función, costes y consecuencias, no solo cambio visual.

# PARTE VI — MATERIALES Y RECURSOS

## 15. Definición de material

Un material tiene identidad o definición, composición, propiedades, estado y procedencia. No se limita a una etiqueta estética.

## 16. Propiedades

Según naturaleza: densidad, masa, dureza, tenacidad, elasticidad, fragilidad, conductividad térmica/eléctrica, capacidad calorífica, resistencia térmica, punto de fusión, combustibilidad, reactividad, corrosión, toxicidad, porosidad, resistencia al impacto, presión y absorción.

No todo material necesita todos los campos. Las propiedades derivan de composición y proceso.

## 17. Composición y microestructura

Puede incluir componentes, proporciones, estructura interna, impurezas, tratamientos y condiciones de producción. Materiales visualmente iguales pueden tener propiedades distintas; un material puede cambiar por tratamientos válidos.

## 18. Interacción de materiales

Las interacciones se basan en composición, conductividad, aislamiento, temperatura, humedad, densidad, estructura y reacciones físicas/químicas. La magia futura utilizará estas propiedades cuando corresponda. No se decidirá eficacia únicamente por etiquetas elementales.

## 19. Recursos ambientales

La disponibilidad depende de geología, biología, clima, procesos naturales, actividad mágica, historia, extracción y regeneración. Un mineral no aparece en cualquier región sin explicación.

# PARTE VII — OBJETOS Y FABRICACIÓN

## 20. Objeto lógico

Un objeto persistente puede incluir categoría, función, componentes, materiales, masa, geometría, dimensiones, propiedades, estado, durabilidad, restricciones, procedencia, fabricante, propietarios y transformaciones.

## 21. Armas

Una espada, hacha, daga, arma de asta o herramienta se define por componentes, material, geometría, masa, distribución de masa, equilibrio, rigidez, flexibilidad, ergonomía, filo, punta, penetración, corte y resistencia.

El combate usa propiedades pertinentes; la categoría visual no basta.

## 22. Fabricación

La fabricación considera materiales y cantidades, herramientas, método, habilidad, conocimiento, tiempo, temperatura, presión y condiciones. El resultado responde al proceso real.

Las recetas pueden ser conocidas, incompletas, heredadas, descubiertas, experimentales, erróneas o secretas. La experimentación puede tener éxito, éxito parcial, defecto, propiedades imprevistas, deterioro de materiales o fallo. Todos los resultados tienen procedencia.

## 23. Genealogía de objetos

Un objeto puede conservar historia de fabricante, materiales, región, reparaciones, refuerzos, encantamientos, batallas y propietarios. Si una transformación destruye y reconstruye completamente el objeto puede generarse identidad nueva vinculada genealógicamente.

## 24. Singularidad

Puede surgir de composición, geometría, fabricación, tratamientos, propiedades, historia y transformaciones. No se reduce a color, nombre o daño.

# PARTE VIII — CAPACIDADES Y HABILIDADES

## 25. Capacidad lógica

Una capacidad es posibilidad funcional derivada de anatomía, fisiología, conocimiento, aprendizaje, herramientas, materiales, tecnología, magia o transformación. No es una animación ni un botón.

## 26. Definición de acción

Una acción declara requisitos, condiciones, recursos, tiempo, movimiento, efectos, restricciones, interrupciones, resultados, fallos, consecuencias y recuperación. La entidad solo la ejecuta si posee capacidades y condiciones.

## 27. Técnicas aprendidas

Se distinguen conocer, poder ejecutar, ejecutar correctamente, dominar, modificar, enseñar e inventar variantes. Habilidades nuevas deben tener requisitos comprobables y procedencia.

## 28. Integración mágica

El Creation Engine puede representar capacidades y efectos mágicos definidos en documento especializado. La magia podrá alterar materiales, organismos, estructuras y fenómenos solo bajo reglas coherentes y validación causal.

# PARTE IX — ASSET FACTORY

## 29. Separación de lógica y asset

Asset Factory recibe entidad lógica y asigna o produce recursos. Se reutilizan assets cuando sea válido; no cada individuo necesita geometría exclusiva.

## 30. Tipos de recurso

Modelos, mallas, materiales, texturas, esqueletos, rigging, blend shapes, animaciones, VFX, sonidos, iconos, colisionadores y LOD.

## 31. Estrategias

1. Reutilización de recursos compatibles.
2. Variación procedural de parámetros.
3. Construcción modular con componentes validados.
4. Creación especializada para entidades excepcionales.

## 32. Pipeline visual

Recibir definición; escoger representación; seleccionar plantilla; ajustar geometría; asignar materiales; producir texturas; crear/adaptar esqueleto y rig; asignar animaciones; preparar colisionadores y LOD; probar compatibilidad y rendimiento; versionar y publicar.

## 33. Rigging y animación

Rigging debe corresponder con articulaciones y restricciones lógicas. Alas, colas, dedos y miembros requieren esqueletos compatibles. Las animaciones representan acciones autorizadas, no determinan el resultado del combate.

## 34. Validación visual

Comprobar geometría, escala, materiales, rig, animaciones, colisionadores, rendimiento, LOD y compatibilidad Android. Un asset atractivo pero deformado o incapaz de representar acciones requeridas no es válido.

## 35. Biblioteca de assets

Cada recurso registra ID, versión, categoría, compatibilidad, dependencias, procedencia/licencia, rendimiento, entidades compatibles y estado de validación. La reutilización es principio obligatorio.

# PARTE X — ESTRUCTURAS Y AMBIENTE

## 36. Estructuras

Edificios y construcciones tienen materiales, componentes, funciones, estado, resistencia, accesos, habitaciones, dependencias, propietarios y modificaciones. Destrucción lógica y visual deben corresponder.

## 37. Creación ambiental

Vegetación, minerales, cuevas, geología, agua, fuentes de recursos y fenómenos se distribuyen según reglas del entorno. El asset visual y la existencia lógica del recurso son separables.

## 38. Biomas

Un bioma representa clima, temperatura, humedad, geografía, recursos, especies, población y procesos naturales, no solo paleta visual. Las variaciones deben conservar identidad ecológica.

# PARTE XI — OFFLINE-FIRST Y COSTE

## 39. Independencia de servicios externos

El núcleo lógico de Creation Engine debe funcionar offline. Creación por reglas, validación, variaciones, materiales, fabricación, persistencia y generación procedural básica no requieren llamadas a API.

## 40. Capacidades locales y online

Locales prioritarias: creación lógica, variación procedural, validación anatómica, fabricación, propiedades, procedencia, simulación poblacional y persistencia.

Opcionales online: modelos generativos remotos, generación visual externa, descarga de recursos, respaldo o sincronización multijugador.

Ninguna capacidad online opcional es indispensable para la continuidad de un mundo individual.

## 41. Inteligencia local

No ejecutar modelos generativos para cada movimiento o decisión. La mayoría de las operaciones utiliza reglas, planificadores, algoritmos reproducibles, memoria estructurada y procedimientos. Un modelo local opcional puede apoyar tareas complejas; su ausencia no paraliza el mundo.

## 42. Desarrollo frente a runtime

Durante desarrollo se pueden usar herramientas de modelado y rigging exigentes. Durante juego se prefieren plantillas, parámetros, combinaciones validadas, variaciones ligeras y assets precompilados. No se generarán modelos 3D complejos continuamente en el teléfono.

## 43. Mundo individual offline

La autoridad local conserva entidades, historias, inventarios, acontecimientos, estados y tiempo. El tiempo transcurrido se calcula al volver a abrir. Dos dispositivos desconectados no comparten un único canon sin reconciliación.

## 44. Presupuesto

Priorizar software libre o controlado, reutilización, automatización, simulación jerárquica, assets compartidos, almacenamiento eficiente y uso selectivo de modelos. El sistema debe poder avanzar con un desarrollador individual y recursos modestos.

# PARTE XII — PRUEBAS Y CIERRE

## 45. Pruebas

1. Crear especie funcional.
2. Crear individuos distintos.
3. Generar anatomía nueva y validarla.
4. Representar lesión lógica y visual.
5. Reproducir con genealogía.
6. Transmitir rasgos compatibles.
7. Evolucionar con función y procedencia.
8. Definir material con composición.
9. Fabricar objeto experimental.
10. Crear objeto singular con genealogía.
11. Crear capacidad con requisitos.
12. Reutilizar asset para individuos diferentes.
13. Representar individuo excepcional.
14. Cambiar apariencia sin cambiar identidad.
15. Crear offline.
16. Perder asset y mantener entidad lógica.
17. Rechazar anatomía incompatible.

## 46. Criterios de cierre

Deben existir identidad lógica separada, definiciones/plantillas, anatomía funcional, variación, herencia, materiales funcionales, objetos con procedencia, fabricación, capacidades validadas, Asset Factory y funcionamiento local. La entidad debe poder existir sin modelo 3D.

# Declaración fundacional

El universo no dependerá de un catálogo cerrado. Las especies tendrán estructuras y posibilidades; los individuos desarrollarán diferencias e historias; los materiales tendrán propiedades; los objetos tendrán procedencia; las capacidades tendrán requisitos; las transformaciones tendrán causas. La representación muestra lo que existe, no decide arbitrariamente lo que puede hacer.

**No crearemos únicamente personajes para llenar un mundo. Construiremos las reglas que permitan que el mundo produzca sus propios habitantes, objetos, estructuras e historias.**

# REGISTRO DE DECISIONES CANÓNICAS Y RESTRICCIONES NO NEGOCIABLES

Este registro facilita la navegación entre normas; los SR citados contienen la regla completa y prevalecen.

## Identidad del producto

- RPG y World Laboratory para Android.
- Universo autónomo y persistente con entidades que actúan sin necesidad del jugador.
- World Laboratory inicia y observa un mundo sin jugador; el juego permite incorporarse a esa misma realidad mediante un personaje participante.
- Mundo individual offline en el dispositivo; no se afirma un canon compartido entre dispositivos desconectados.
- Estilo semi-realista estilizado, escena 3D real, presentación 2.5D y cámara isométrica ortográfica.
- Godot 4.7.2 Standard y GDScript como base aprobada inicial.

## Tiempo, mundo y persistencia

- El tiempo global persiste y el mundo avanza durante la ausencia.
- Catch-up al reabrir, con simulación multiescala y controles de anomalía de reloj.
- La identidad de una entidad no depende del modelo, escena o apariencia.
- La descarga visual de un sector no destruye su estado.
- El observatorio es pasivo por defecto; intervención administrativa se separa y audita.

## Jugador, muerte y combate

- El jugador es participante, no centro ontológico del universo.
- Sin respawn ordinario; muerte en perfil Hardcore y consecuencias persistentes.
- Perfil de dificultad protegido puede existir como conjunto separado de reglas.
- HP y MP son representaciones cuantificables útiles, pero no sustituyen anatomía, fisiología y mecanismos arcanos.
- Combate en tiempo real continuo, lesiones localizadas, sangrado, amputación, primeros auxilios, curación y rehabilitación.
- Cualquier espacio físicamente válido puede ser campo de batalla.

## Seres, monstruos y ecología

- Gólems y no-muertos son entidades activas no biológicas, no objetos inertes.
- La Mazmorra genera monstruos; no se afirma que sea necesariamente el único mecanismo.
- Solo los monstruos pueden reproducirse entre especies de monstruos según compatibilidad; la reproducción puede generar especies emergentes.
- Los monstruos no envejecen por senescencia y fortalecen su capacidad cuanto más tiempo sobreviven conforme a SR-08.
- Los pisos tienen identidad propia y se agrupan por bloques de bioma; los grupos pueden compartir rasgos sin volver idénticos todos los pisos.
- Cada piso puede tener especies, poblaciones, recursos y jefe; no todo jefe debe esperar al jugador.

## Arcana y Veyrath

- La Trama carece de voluntad; la Arcana no es una deidad ni concede favores por devoción.
- La Arcana tiene un papel civilizatorio central: infraestructura, conocimiento, cultura, oficio y filosofía.
- La existencia y mecánicas de los dioses permanecen sin definir.
- Veyrath es la lengua arcana original aprobada.
- La magia formulada usa oraciones de palabras completas y ordenadas, no secuencias de sílabas.
- Anexo A contiene 72 hechizos de referencia para pisos 1–5; aprender palabras no equivale a dominar fórmulas.
- Autocompletado no elimina tiempo de cántico, coste ni riesgo de interrupción.

## Economía

- Moneda de cuenta UM en el documento económico; abreviaturas MC/MP/MO son provisionales y no canónicas.
- Economía causal, inventarios finitos, propiedad, transacciones y procedencia.
- Cristales/materiales de monstruos como botín principal de Mazmorra; no se construye la recompensa central sobre cofres o cajas rompibles.

## Geografía y narrativa

- Reino, ciudad, muro, bosque, torre y Mazmorra forman un territorio continuo en la ficción.
- La muralla separa reino y bosque; no se desarrolla contenido jugable fuera de ella en la primera fase, salvo futuras aprobaciones.
- La torre es monumental; el interior de la Mazmorra puede exceder el tamaño exterior y usar topología espacial arcana.
- Piso 1 tiene estética de mina antigua, roca natural, ruinas, pilares y minerales visibles; al menos 12 habitaciones diferenciadas en el objetivo de diseño.
- Zona segura por piso: normalmente sin spawn espontáneo, pero no es inviolable.
- Historia fundacional escrita + historia emergente. Primera campaña de referencia: El Eco de Vhaloren.
- Misiones y tutoriales manuales están permitidos; sus resultados no están garantizados por guion.

## Prohibiciones arquitectónicas

- Un LLM no tiene autoridad directa para modificar estado objetivo.
- No se depende de API pagada para acciones rutinarias.
- No se crea un segundo simulador separado para Observatorio.
- No se confunde animación o VFX con resultado lógico.
- No se finge que el mundo es autónomo usando solo rutinas visuales, guiones fijos o diálogos.
- No se declara implementado/validado sin código, pruebas y evidencia.
- No se reescribe una regla aprobada para acomodar una limitación de código; se propone cambio formal o rediseño técnico compatible.


## SR-15: especificación técnica de dos bloques

- El cuerpo principal SR-15 v1.0 conserva 88 secciones numeradas 1–88.
- SR-15-B conserva 44 secciones complementarias con numeración local 1–44, procedentes del segundo paquete.
- Ambos bloques se leen en conjunto para mayor concreción, sin fusionar sus numeraciones.
- SR-15-B no sustituye ni altera silenciosamente SR-15 v1.0 ni las normas SR-01 a SR-14. Toda contradicción debe señalarse con sus referencias exactas y quedar pendiente de resolución explícita.

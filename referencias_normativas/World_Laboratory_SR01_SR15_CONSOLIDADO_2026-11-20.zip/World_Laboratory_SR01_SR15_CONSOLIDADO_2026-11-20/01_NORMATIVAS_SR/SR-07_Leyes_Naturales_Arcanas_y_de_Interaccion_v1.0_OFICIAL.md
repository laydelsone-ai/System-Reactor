# SR-07 — LEYES NATURALES, ARCANAS Y DE INTERACCIÓN

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0 · **Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR · **Ámbito:** fases 0–5 · **Dependencias:** SR-01 a SR-06.

> Nota de integridad: este archivo consolida la especificación SR-07 redactada en la conversación del 19-11-2026. Es una especificación de diseño; no representa código implementado ni parámetros físicos ya calibrados. Los valores, ecuaciones y gramática arcana detallada quedan para diseño técnico posterior.

## PREÁMBULO — UNA REALIDAD, DOS DOMINIOS Y SUS INTERACCIONES

El universo posee leyes naturales y arcanas que coexisten. La magia no es una licencia para ignorar causalidad, propiedades materiales o consecuencias. Puede introducir mecanismos sobrenaturales, transformar condiciones y producir fenómenos imposibles por medios naturales, pero cada operación debe tener fuente, condiciones, límites y resultados validados. El nivel de simulación puede ser aproximado, pero no arbitrario.

Se distinguen: (1) dominio natural: materia, energía, movimiento, fuerzas, química, temperatura, presión, luz, sonido y biología; (2) dominio arcano: Trama, flujo/energía arcana, Resonancias y formulaciones; (3) dominio de interacción: reglas que determinan cómo ambos dominios se afectan.

## PARTE I — LEYES GENERALES

### 1. Coexistencia natural y arcana
La materia conserva sus propiedades salvo que un mecanismo válido las modifique. La magia puede generar o alterar fenómenos, pero sus efectos sobre el entorno deben respetar las reglas aplicables, excepto cuando la propia operación arcana defina explícitamente una interacción distinta. Un fuego mágico no implica que cualquier superficie arda; una descarga no implica que todo metal sea automáticamente vulnerable.

### 2. Consistencia
Bajo condiciones equivalentes, las operaciones deben producir resultados comparables. Las diferencias deben poder explicarse mediante variables pertinentes: potencia, precisión, materiales, ambiente, ejecución, Resonancia, capacidades, interferencias o estado del objetivo. No se alteran las leyes por conveniencia narrativa.

### 3. Causalidad
Todo cambio persistente tiene una causa o mecanismo. Las causas se registran antes de confirmar los efectos. Una anomalía desconocida puede ser real sin que los habitantes la comprendan; el motor debe conservar condiciones causales verificables y distinguir anomalía de error técnico.

### 4. Conservación y fuentes
Materia y energía no aparecen gratuitamente mediante procesos naturales. Las operaciones arcanas que creen, transfieran o transformen materia/energía deben declarar el mecanismo, fuente, coste, conversión o excepción arcana correspondiente. No se usa la conservación para prohibir fantasía; se usa para dar estructura a sus posibilidades.

## PARTE II — LEYES NATURALES FUNCIONALES

### 5. Espacio y geometría
Entidades y fenómenos poseen posición, orientación, dimensiones, volumen, distancia y trayectoria. Geometría, pendiente, altura, obstáculos, superficies y capacidades determinan transitabilidad. La apariencia visual no decide por sí sola si una superficie puede recorrerse.

### 6. Tiempo
Las acciones físicas requieren tiempo. El tiempo del mundo es independiente de FPS. La simulación puede usar resolución inmediata, táctica, cotidiana, ecológica e histórica; reducir precisión no puede borrar continuidad ni consecuencias.

### 7. Masa, volumen e inercia
Masa y dimensiones influyen en movimiento, colisiones, fuerza, equilibrio y ocupación espacial. El movimiento cambia mediante fuerzas, impulso, aceleración, fricción y resistencia del medio; no hay desplazamientos instantáneos sin mecanismo.

### 8. Fuerzas, gravedad y movimiento
La gravedad actúa según reglas regionales definidas. Fuerzas producen aceleración, deformación, presión, desplazamiento, rotación, ruptura o vibración. Anomalías naturales o arcanas requieren definición y registro.

### 9. Colisiones y daño
Distinguir contacto, rozamiento, impacto, penetración, corte, compresión, deformación, rebote y rotura. El resultado depende de geometría, masa, velocidad, rigidez, elasticidad, material, ángulo y protección. El daño puede ser localizado: cortes, contusiones, fracturas, lesiones internas, quemaduras, daños sensoriales y pérdida funcional. No se exige simular tejido microscópico si no aporta valor jugable.

### 10. Materiales y deformación
Los materiales pueden deformarse, recuperar forma, sufrir daño acumulativo o romperse. Propiedades como dureza, tenacidad, elasticidad, fragilidad, conductividad y resistencia proceden de composición, microestructura y tratamiento, no solo de etiquetas estéticas.

### 11. Fricción y superficies
La fricción afecta agarre, deslizamiento, estabilidad, desgaste y calentamiento. Hielo, barro, arena, roca y otras superficies modifican locomoción de forma coherente con el cuerpo y equipo.

### 12. Presión y fluidos
Gases y líquidos ejercen presión. Los fluidos tienen volumen, densidad, viscosidad, presión, caudal, temperatura, estado y respuesta a gravedad/obstáculos. Se permiten aproximaciones computacionales, pero las consecuencias lógicas deben ser consistentes.

### 13. Gases y atmósfera
Composición, presión, temperatura, densidad y difusión pueden afectar respiración, combustión, toxicidad, explosiones y propagación. Cada especie puede tener requisitos respiratorios propios.

### 14. Temperatura y transferencia térmica
Calor se transfiere por conducción, convección, radiación o mecanismos arcanos. Los cambios térmicos pueden causar dilatación, contracción, quemaduras, congelación, evaporación, fusión, fragilización y cambios metabólicos.

### 15. Estados de la materia
Sólido, líquido, gas y plasma/estados adicionales cuando sean relevantes. Cambios de estado dependen de condiciones y energía; una transformación mágica debe declarar cómo las produce.

### 16. Luz y radiación
Emisión, reflexión, absorción, refracción, dispersión, sombras, intensidad y propagación. Distinguir luz visible, calor y otros efectos: iluminar no implica necesariamente quemar.

### 17. Sonido y vibración
Frecuencia, intensidad, distancia, obstáculos, materiales y medio afectan propagación. Los sentidos varían por especie. Vibraciones pueden causar efectos físicos si intensidad y condiciones lo justifican. La formulación verbal puede depender de fonética, secuencia, ritmo e integridad.

### 18. Electricidad y magnetismo
Carga, potencial, conductividad, resistencia, aislamiento, geometría, medio y continuidad determinan trayectorias y efectos. Descargas pueden generar calor, contracciones, daños orgánicos, alteraciones sensoriales o incendios. El metal no es una debilidad universal: su papel depende de circuito, aislamiento y contacto.

### 19. Química
Composición, concentración, reactividad, temperatura, presión, catalizadores y velocidad determinan reacciones. Resultados posibles: calor, gases, precipitados, corrosión, combustión, toxicidad y cambios materiales. Se usan modelos apropiados a la escala, no simulación molecular exhaustiva permanente.

### 20. Combustión y fuego
La combustión natural depende de combustible, oxidante, temperatura, mezcla, superficie y condiciones. Diferenciar llama, calor, humo, brasas, gases y radiación térmica. El contacto visual de una partícula no basta para incendiar un material: se evalúa composición y estado. Fuego mágico puede tener otro mecanismo, pero sus consecuencias se definen.

### 21. Corrosión y degradación
Exposición a sustancias y condiciones puede cambiar composición, superficie, resistencia, integridad y función. El deterioro lento puede agregarse en simulación regional conservando resultados.

## PARTE III — LEYES ARCANAS

### 22. La Trama
La Trama es la estructura arcana fundamental propuesta para explicar la posibilidad de interacciones arcanas. No es una deidad, conciencia universal ni voluntad que premie o seleccione individuos. Está presente en la realidad, aunque concentración, manifestación, accesibilidad y comportamiento pueden variar. Los habitantes pueden investigarla sin que sus teorías sean automáticamente ciertas.

### 23. Flujo arcano
Se distingue la Trama como estructura y el flujo arcano como manifestación utilizable. Puede encontrarse en ambiente, concentraciones naturales, materiales, estructuras preparadas, organismos compatibles u objetos capaces de almacenarlo. Su disponibilidad varía por región y condiciones.

### 24. Reservas personales y externas
Algunas entidades pueden almacenar o canalizar flujo según naturaleza, anatomía, predisposición, entrenamiento y experiencia. Objetos y estructuras pueden almacenar flujo si materiales y construcción lo permiten: cristales, recipientes, sellos, artefactos y materiales conductores arcanos. Toda reserva tiene límites.

### 25. Energía arcana y coste
Registrar flujo disponible, energía almacenada, utilizada, transferida, transformada, disipada y residual. Costes pueden depender de magnitud, duración, distancia, complejidad, precisión, resistencia del objetivo, ambiente, estabilidad, materia afectada y naturaleza de la transformación. No se impone una única fórmula universal.

### 26. Recuperación y sobrecarga
Recuperación posible por reposo, ambiente, procesos biológicos, concentración, absorción, objetos o fenómenos específicos; no todas las fuentes sirven a todas las entidades. Exceso puede causar fatiga, pérdida de precisión, interrupción, daño fisiológico, alteración perceptiva, inestabilidad o lesiones duraderas. Consecuencia depende del organismo y operación.

### 27. Resonancias
Las Resonancias son patrones/principios arcanos con los que entidades y fenómenos pueden establecer afinidad. No son dioses, bendiciones ni clases rígidas ni se limitan a elementos. Ejemplos de categorías iniciales de investigación: Persistencia, Transformación, Umbral, Reciprocidad, Retorno, Desvío y Testimonio; no son taxonomía definitiva.

### 28. Afinidad
Una afinidad puede depender de herencia, naturaleza, anatomía, cognición, experiencias, entrenamiento, exposición y transformaciones. No concede automáticamente hechizos. Puede existir sin que el individuo la conozca; una misma afinidad puede producir aplicaciones distintas en individuos diferentes.

## PARTE IV — APRENDIZAJE Y CONOCIMIENTO MÁGICO

### 29. Magia aprendible
La magia se aprende por estudio, grimorios, investigación, enseñanza, observación, experimentación, práctica y tradición. No es un catálogo de habilidades otorgadas automáticamente. Ritmo de aprendizaje depende de capacidades y circunstancias.

### 30. Predisposición y herencia
Características heredables pueden facilitar afinidad, percepción, canalización, estabilidad, eficiencia o aprendizaje. No determinan el destino: alguien sin predisposición puede progresar mediante estudio si es viable; alguien predispuesto puede fracasar por falta de comprensión, práctica o compatibilidad.

### 31. Clases y especializaciones
Clases mágicas pueden surgir de predisposición, formación, práctica y especialización; no necesariamente son categorías biológicas inmutables. Linajes pueden mostrar tendencias sin obligar a sus descendientes a seguirlas.

### 32. Grimorios
Pueden contener formulaciones, símbolos, procedimientos, explicaciones, advertencias, variaciones, experimentos, errores y teorías. Leer no garantiza comprender ni ejecutar. Pueden ser incompletos, erróneos, fragmentarios, secretos o personales. El soporte físico y el conocimiento lógico son entidades distintas: destruir un libro no borra copias ni recuerdos, pero puede perder conocimiento irreemplazable.

## PARTE V — LENGUA Y ENCANTAMIENTO

### 33. Ley de expresión
Las operaciones que requieran formulación se expresan verbalmente o por escritura. La formulación puede integrar palabras, sílabas, pronunciación, ritmo, secuencia, gramática, símbolos, geometría u otros componentes definidos. No se reduce a pulsar un botón de habilidad.

### 34. Lengua arcana
Puede existir una lengua original interna del juego con fonética, morfología, sintaxis, semántica, marcadores funcionales, intensidad, objetivo, condiciones y relaciones entre operaciones. No será un conjunto decorativo de palabras. Conocer palabras no equivale a comprender ni dominar una fórmula.

### 35. Traducción
La interfaz puede mostrar traducción española para que el jugador entienda el encantamiento. La traducción informativa no cambia automáticamente el idioma que pronuncia el personaje. Una formulación traducida puede ser menos precisa/eficiente por pérdida de estructura: más coste, tiempo, menor precisión, complejidad limitada o inestabilidad. Estudio lingüístico puede reducir penalizaciones; no se impone que traducir sea inútil.

### 36. Encantamiento verbal y escrito
La ejecución verbal valida formulación, orden, integridad, tiempo, pronunciación cuando corresponda, concentración y canalización. La escritura puede aprender, conservar, preparar, almacenar patrones, crear sellos y objetos; una inscripción no activa magia sin estructura y fuente de energía válidas.

### 37. Encantamientos en movimiento
Algunas fórmulas pueden ejecutarse caminando/corriendo según complejidad, longitud, concentración, coordinación, estabilidad, dominio, energía y entorno. El movimiento puede aumentar coste, tiempo, errores, interrupciones o reducir precisión/potencia; no todos los encantamientos móviles son débiles.

### 38. Encantamientos estacionarios
Algunos requieren inmovilidad, postura o preparación para alcanzar estabilidad, complejidad, potencia, precisión, eficiencia y control superiores. La inmovilidad debe responder a una necesidad real de la operación, no ser una restricción arbitraria. La preparación puede exponer al lanzador a interrupciones.

### 39. Interrupción y fallo
Impacto, dolor, pérdida de concentración, incapacidad, alteración sensorial, interferencia o error pueden interrumpir. Según etapa y fórmula, el resultado puede ser cancelación, pérdida de energía, efecto incompleto o liberación inestable; no toda interrupción explota. Fallos derivan de formulación, recursos, compatibilidad, condiciones, resistencia o desconocimiento y también producen conocimiento.

## PARTE VI — HECHIZOS Y FENÓMENOS

### 40. Hechizo como operación
Cada hechizo declara los componentes pertinentes: formulación, propósito, principio, fuente, objetivo, alcance, manifestación, duración, intensidad, condiciones, restricciones, efectos secundarios, interrupciones y terminación. No todos requieren todos los campos.

### 41. Objetivo, alcance y duración
Objetivos posibles: usuario, individuo, objeto, superficie, volumen, área, estructura, fenómeno o región. Alcance depende de energía, precisión, Resonancia, medio, obstáculos, conocimiento, visión, anclajes y estabilidad. Efectos pueden ser instantáneos, breves, sostenidos, persistentes, condicionales o vinculados a objeto/región. Persistencia necesita mantenimiento, almacenamiento o anclaje.

### 42. Intensidad y control
Poder no equivale solo a daño o energía. Importan precisión, forma, densidad, distribución, duración, concentración, interacción y eficiencia. Efecto pequeño y preciso puede superar a uno enorme mal dirigido.

### 43. Clasificación abierta
Puede haber fenómenos de fuego, agua, aire, tierra, hielo, electricidad, luz, oscuridad, sonido, presión, gravedad, movimiento, percepción, protección, transformación, vínculo, sellado, regeneración, desplazamiento, espacio, memoria y otros. La lista organiza conocimiento; no garantiza que cualquier efecto sea posible.

### 44. No hay tabla elemental universal
No se codifica «fuego vence viento» o «agua vence metal» como regla fija. El resultado depende de composición, temperatura, conductividad, aislamiento, presión, volumen, trayectoria, estado y formulación.

### 45. Ejemplos de interacción
- Viento puede alimentar o apagar combustión, dispersar llama, transportar calor/humo o modificar trayectoria según intensidad y dirección.
- Electricidad en metal depende de continuidad, resistencia, aislamiento, potencial y contacto; armadura no es automáticamente vulnerable.
- Agua sobre metal puede conducir electricidad, enfriar o facilitar corrosión según composición y estado.
- Hielo afecta organismos según fisiología, temperatura y exposición; especies adaptadas al frío responden distinto.
- Dos hechizos pueden reforzarse, disiparse, desviarse, interferir, combinarse o transformarse según sus mecanismos, no solo sus etiquetas.

## PARTE VII — INDIVIDUOS, RELIGIÓN Y SOCIEDAD

### 46. Manifestación personal
Una Resonancia puede manifestarse de formas diferentes. Afinidad con Persistencia podría facilitar mantener estados o resistir interrupciones, pero no hace indestructible a su portador. Retorno no permite revertir cualquier muerte; Umbral no permite viajar arbitrariamente a cualquier lugar. Todo principio se traduce a operaciones limitadas, requisitos y costes.

### 47. Investigación personal y social
Individuos y culturas pueden descubrir, clasificar o interpretar mal Resonancias y fenómenos. La misma realidad puede recibir nombres diferentes. El sistema distingue hechos objetivos, hipótesis y creencias.

### 48. Religión y creencias
NPC pueden ser creyentes, ateos, fundar iglesias, religiones, cultos o instituciones espirituales. La creencia influye en personalidad, motivaciones, relaciones, costumbres, arquitectura, educación, conflictos, interpretación y memoria colectiva. La adoración, oración o pertenencia religiosa no concede por sí sola poderes ni bendiciones. Una institución religiosa puede descubrir hechos mediante investigación, pero autoridad social no convierte su doctrina en verdad objetiva.

### 49. Deidades no definidas
La existencia, naturaleza y origen de dioses quedan expresamente reservados para la historia/cosmología futura. SR-07 no presupone que existan ni que no existan. No se implementa bendición divina ni poder por adoración mientras no se apruebe una ley nueva con mecanismo verificable.

## PARTE VIII — VALIDACIÓN, PRESENTACIÓN Y ESCALA

### 50. Coste multidimensional
Intervienen energía, tiempo, complejidad, alcance, precisión, preparación, estabilidad, compatibilidad, concentración, conocimiento, ambiente y resistencia. Efectos pequeños pueden ser complejos; efectos grandes pueden ser sencillos si su mecanismo lo permite.

### 51. Resistencia y contramedidas
Resistencia térmica, eléctrica, química, estructural, biológica y arcana depende de propiedades reales. Contramedidas incluyen movimiento, cobertura, materiales, interrupción, barreras, sellos, contrafórmulas, dispersión, interferencia y preparación; deben responder al mecanismo del fenómeno.

### 52. Lógica antes que VFX
El motor lógico calcula fuente, forma, trayectoria, intensidad, área, duración, interacción y consecuencias. El motor visual recibe resultados y los representa. Partículas no son autoridad de daño. Fuego puede mostrar núcleo, llama, humo, brasas, ondas de calor, iluminación y superficies afectadas; electricidad arcos y ramificaciones; agua volumen, flujo y salpicaduras; viento polvo, hojas, telas y humo. Luz, sonido y marcas persistentes corresponden al fenómeno lógico.

### 53. Persistencia ambiental
Pueden quedar quemaduras, humo, agua, hielo, roturas, vegetación dañada, residuos y marcas. Su permanencia depende de leyes y procesos. El nivel de detalle puede simplificarse sin perder estados relevantes.

### 54. Simulación jerárquica
Combate cercano exige precisión alta; regiones lejanas pueden usar modelos agregados. Cambiar de resolución no puede borrar incendio, daño, posición o consecuencias incompatibles. Se conserva continuidad causal entre escalas.

### 55. Cliente y rendimiento
Android representa mundo, controles, animación, audio, interfaz y predicción local; no tiene que simular toda la población. La autoridad lógica se mantiene en núcleo local del mundo offline o autoridad compartida en modo online. VFX se optimiza sin alterar resultados.

## PARTE IX — INVESTIGACIÓN, GOBERNANZA Y PRUEBAS

### 56. Investigación natural y arcana
Habitantes pueden estudiar materiales, reacciones, temperatura, presión, electricidad, anatomía, Trama, flujo, Resonancias, formulaciones e interacciones. Ciclo: observación, pregunta, hipótesis, experimento, recursos, ejecución, registro, comparación, repetición, teoría provisional y transmisión.

### 57. Estados del conocimiento
Resultados pueden ser confirmados, probables, parciales, no concluyentes, refutados, falsos o incomprendidos. Procedencia y evidencias se conservan. Un error cultural no altera la realidad.

### 58. Creación de hechizos
Puede surgir de modificar fórmulas, combinar procedimientos, investigar Resonancias, experimentar, estudiar grimorios o descubrir variantes. No toda combinación funciona. Nueva operación pasa validación de requisitos, coste, fuente, efecto, riesgo y reproducibilidad.

### 59. Validación universal
Antes de persistir una operación se verifican fuente, energía, materiales, capacidad, formulación, condiciones, objetivo, alcance, duración, consecuencias, compatibilidad y procedencia. No hay resultados extraordinarios gratuitos ni cambios persistentes sin autorización de dominio.

### 60. Anomalías
Un fenómeno desconocido no es automáticamente un error. Clasificar como regla conocida, interacción rara, nueva posibilidad, anomalía, fallo técnico o acontecimiento sin explicación suficiente. No eliminar lo extraordinario por ser raro.

### 61. Versionado
Las leyes tienen versión. Cambios no reescriben automáticamente historia confirmada. Migraciones consideran estado, procedencia, reglas antiguas/nuevas y consecuencias.

### 62. Pruebas obligatorias
Impacto; material frágil; combustión; viento/fuego; electricidad/conductividad; agua/metal; calor prolongado; presión; encantamiento móvil y estacionario; interrupción; traducción; grimorio incompleto; herencia; Resonancia sin poder automático; sobrecarga; hechizo persistente; combinación de fenómenos; religión sin bendición; descubrimiento reproducible; consistencia entre simulación cercana y resumida.

## CRITERIOS DE CIERRE

SR-07 estará listo para implementación cuando existan modelos funcionales de materia/energía/movimiento/materiales; Trama, flujo y Resonancias con límites; aprendizaje mágico y grimorios; formulación verbal/escrita; movimiento frente a quietud; interacción natural/arcana; lógica de hechizos separada de VFX; investigación con procedencia; simulación multiescala y pruebas reproducibles.

## DECISIONES RESERVADAS

Origen último de Trama; taxonomía completa de Resonancias; gramática arcana formal; catálogo inicial de hechizos; almacenamiento arcano; límites de fenómenos espaciales; relación magia-muerte/reencarnación; alquimia; transformaciones biológicas arcanas; artefactos; fenómenos regionales; cosmología y posible existencia de deidades.

## DECLARACIÓN FUNDACIONAL

La magia no romperá las leyes de este mundo: será una de las razones por las que esas leyes son más amplias de lo que sus habitantes imaginan. La física y la química determinan interacciones; la magia introduce mecanismos adicionales con condiciones y costes. Los habitantes pueden conocer, malinterpretar o descubrir esas reglas, pero ningún relato, animación o conveniencia narrativa puede sustituirlas.

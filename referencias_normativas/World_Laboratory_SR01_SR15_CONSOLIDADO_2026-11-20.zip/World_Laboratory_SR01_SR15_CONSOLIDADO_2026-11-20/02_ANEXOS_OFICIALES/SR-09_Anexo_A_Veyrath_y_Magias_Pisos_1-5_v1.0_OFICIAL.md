# ANEXO A DE SR-09 — LENGUA ARCANA VEYRATH Y CATÁLOGO DE MAGIA
## Parámetros de referencia y 72 hechizos para los pisos 1–5

**Código:** SR-09 — Anexo A (compendio subordinado)  
**Versión:** 1.0 — edición oficial aprobada  
**Estado:** ANEXO OFICIAL — APROBADO EXPRESAMENTE POR EL AUTOR EL 2026-11-20. El catálogo contiene 72 hechizos de referencia para los pisos 1–5; sus parámetros de balance siguen sujetos a calibración.  
**Ámbito:** lengua arcana, aprendizaje, formulación, casteo, balance y catálogo de referencia para los pisos 1–5.  
**Autoridad:** SR-07 y SR-09 prevalecen en caso de conflicto. Este anexo desarrolla vocabulario, fórmulas y valores iniciales; no modifica las leyes superiores.  
**Alcance de contenido:** repertorio inicial de 72 hechizos, gramática oracional, vocabulario léxico completo y parámetros de prueba para aprendizaje, adaptación, casteo, balance y curación.

---

## 0. Criterio de diseño

**Nota de aprobación:** el autor aprobó SR-09 v1.0 y su Anexo A el 2026-11-20. La revisión lingüística solicitada sustituyó secuencias cortas parecidas a sílabas por oraciones compuestas de palabras léxicas completas. Esta edición oficial conserva los 72 efectos y su balance de referencia, y fija la gramática y el vocabulario de Veyrath para la primera fase. Los valores numéricos de balance permanecen como parámetros de referencia sujetos a calibración.

La magia debe ser una disciplina poderosa, flexible y valiosa, pero no una versión superior de la reacción física del guerrero. El guerrero puede reaccionar, desplazarse, bloquear y atacar con una inmediatez que el mago no posee mientras formula y ejecuta un cántico. El mago, a cambio, aporta alcance, daño concentrado, control del terreno, defensa preventiva, información, alteración del entorno, apoyo y curación.

La diferencia no se resolverá haciendo que los hechizos sean débiles sin más. Se resolverá haciendo que **el tiempo, la exposición y el riesgo de interrumpir el cántico sean el precio de efectos más amplios, precisos o especializados**. Un hechizo bien lanzado debe justificar el tiempo que el grupo protegió al mago. Un hechizo mal elegido, interrumpido o ejecutado tarde puede no producir ningún beneficio.

La curación será especialmente importante porque el combate tiene consecuencias corporales y la muerte ordinaria no permite reaparecer. Un sanador no convierte al grupo en invulnerable: evita que heridas tratables se vuelvan irreversibles, detiene hemorragias, estabiliza, reduce secuelas y permite continuar. No puede devolver la vida a quien ya murió ni reconstruir instantáneamente cualquier parte del cuerpo.

Los 72 hechizos siguientes forman el **catálogo de referencia de la primera fase (pisos 1–5)**. Cada uno se expresa ahora como una oración Veyrath de nueve palabras con marco gramatical explícito; las fórmulas no son listas de sílabas ni abreviaturas. Eso no significa que cada personaje conozca los 72 al comenzar. El acceso individual depende de aprendizaje, enseñanza, grimorios, descubrimientos, compatibilidad, práctica y recursos. El catálogo tampoco impide descubrir variantes nuevas mediante las reglas de investigación de SR-07.

## 1. Decisiones de alcance aprobadas

1. La lengua arcana original será **Veyrath**. Es la lengua de formulación de referencia del Sistema Reactor.
2. Veyrath tendrá una gramática fundamental común. En esta primera etapa no habrá otros idiomas arcanos completos. Más adelante podrán surgir dialectos, escrituras históricas, variantes regionales o lenguas derivadas, pero serán desarrollos posteriores y no reemplazarán el idioma palabra.
3. El español de la interfaz será una traducción de comprensión. El personaje debe conocer y ejecutar la fórmula Veyrath para obtener la máxima fidelidad.
4. La selección manual de palabras representa el conocimiento consciente del personaje. El autocompletado solo aparece para fórmulas que ya comprende y domina; reproduce el cántico, pero no elimina su duración ni sus riesgos.
5. Los hechizos ofensivos de objetivo único tendrán, como referencia inicial, un efecto comparable a aproximadamente **1.3–2.6 impactos básicos exitosos de un combatiente físico equivalente**, según el piso y la complejidad. La ventaja del mago será el alcance, la forma de impacto, el control y la posibilidad de afectar varios objetivos; su desventaja será el tiempo de ejecución, el gasto arcano y la vulnerabilidad durante el cántico.
6. Los hechizos de área harán menos daño por objetivo que los de objetivo único. Su valor aumenta con el número de objetivos, la posición y el entorno.
7. La curación no será una barra de HP que borra lesiones. Se resolverán por separado el daño general, la hemorragia, el trauma, las fracturas, las lesiones de órganos y las secuelas.
8. En los pisos 1–5 no habrá un hechizo ordinario de resurrección ni regeneración instantánea de miembros. La resurrección queda sujeta a SR-01 y a condiciones extraordinarias; no se incluye como habilidad aprendible de esta fase.

Estas ocho decisiones generales quedan aprobadas como dirección de diseño. Las cifras siguen siendo valores iniciales de prueba y podrán calibrarse mediante simulación, sin alterar los principios aprobados.

---

# PARTE I — LENGUA ARCANA VEYRATH

## 2. Naturaleza de Veyrath

Veyrath es una lengua arcana construida para expresar operaciones completas sobre la Trama. **Los hechizos no se forman con sílabas sueltas ni con secuencias abreviadas de sílabas: se pronuncian como oraciones completas, compuestas por palabras independientes con significado propio.** Cada palabra puede aprenderse y reconocerse por separado, pero dominar una palabra no equivale a dominar la oración ni la operación mágica.

La lengua no crea energía por sí misma. Una oración válida describe y organiza una operación; el resultado requiere fuente de flujo, compatibilidad, conocimiento, canalización, objetivo alcanzable y condiciones adecuadas. Memorizar sonidos sin comprender su función permite como mucho una ejecución inestable y limitada.

Veyrath es fonético-funcional: importan la elección de palabras, su orden, la pronunciación, la intención operacional, el ritmo y la canalización. Una grabación no sustituye la ejecución de una persona, porque la operación necesita una fuente y un patrón de canalización compatibles.

## 3. Sonidos, escritura y vocabulario

### 3.1 Sonidos y transliteración

La transliteración inicial usa vocales a, e, i, o, u; consonantes k, t, d, g, m, n, r, l, s, z, v, h, sh y th. `sh` y `th` representan sonidos individuales. La acentuación ordinaria cae en la penúltima sílaba de cada palabra léxica, salvo indicación de un maestro o dialecto. Las palabras se escriben separadas y no se fusionan en una cadena de sílabas.

La primera versión usa alfabeto latino para facilitar la lectura. La escritura gráfica original podrá diseñarse después sin alterar el vocabulario ni la gramática hablada.

### 3.2 Estructura de una oración mágica

La forma canónica inicial tiene nueve posiciones funcionales:

`Ena Aethar [OPERACIÓN] [DOMINIO] [FORMA] Varen [OBJETIVO] [CONDICIÓN] Thalen.`

1. **Ena** — «Yo invoco / inicio la formulación». Identifica al lanzador como ejecutor de la oración.
2. **Aethar** — «a través del flujo arcano». Declara el medio operacional, no una fuente ilimitada.
3. **Palabra de operación** — qué hace la magia: proyectar, fijar, guiar, reparar, etc.
4. **Palabra de dominio** — sobre qué fenómeno o materia actúa.
5. **Palabra de forma** — qué patrón físico/arcano adopta el efecto.
6. **Varen** — «dirigido hacia / aplicado sobre». Introduce el complemento objetivo.
7. **Palabra de objetivo** — lanzador, aliado, hostil, objeto, área o superficie.
8. **Palabra de condición** — intensidad, duración, precisión, anclaje o extensión.
9. **Thalen** — cierre gramatical: «que la operación quede definida». No añade potencia gratuita; cierra y estabiliza la instrucción.

Las nueve posiciones son la forma de referencia del catálogo de 72 hechizos. Las futuras fórmulas avanzadas podrán requerir cláusulas adicionales —fuente, límite, condición de activación, trayectoria, excepción o duración— y por tanto oraciones más largas. No se permite añadir palabras decorativas sin función.

### 3.3 Léxico de operaciones

| Palabra Veyrath | Significado funcional |
|---|---|
| Varesh | proyectar, liberar o emitir |
| Auneth | unir, fijar o sujetar |
| Selvar | guiar, desviar o conducir |
| Eshara | mantener o sostener |
| Mireth | reparar o restaurar parcialmente |
| Kordain | separar, cortar o fragmentar |
| Thesira | revelar o hacer perceptible |
| Dasev | soltar, dispersar o deshacer una unión |
| Khalem | reforzar, endurecer o estabilizar |
| Nemeira | velar, ocultar o atenuar |
| Tavren | transferir o conducir entre puntos |
| Shevara | moldear o alterar una forma |

### 3.4 Léxico de dominios

| Palabra Veyrath | Dominio expresado |
|---|---|
| Aethar | flujo arcano y conducción de la Trama |
| Orath | calor, combustión y fuego |
| Iskalen | agua, humedad y líquidos |
| Varelin | aire, viento y gases |
| Durneth | tierra, roca, polvo y minerales |
| Seloria | luz y radiación visible |
| Vumareth | sombra y reducción de luz |
| Narethis | tejido vivo, vitalidad y reparación biológica |
| Kelvane | nervios, sensación, coordinación y dolor |
| Vethorin | fuerza, presión, impulso y tensión |
| Sonareth | sonido y vibración |
| Sairen | percepción, atención y lectura de señales |
| Zareth | electricidad y carga eléctrica |
| Rhemora | temperatura y gradientes térmicos |
| Thiraven | estructura, unión y cohesión material |

### 3.5 Léxico de formas

| Palabra Veyrath | Forma operacional |
|---|---|
| Kethar | proyectil compacto |
| Raveth | onda, cono o descarga extendida |
| Kardelis | barrera o plano de contención |
| Limerath | línea estrecha o corte lineal |
| Meliora | campo o área definida |
| Veskar | hilo, corriente o flujo estrecho |
| Dorveth | cúpula, envoltura o caparazón |
| Rilaven | punto, marca o anclaje preciso |
| Thamorin | pulso radial desde un centro |
| Senvara | red o patrón de varios puntos relacionados |

### 3.6 Léxico de objetivos y relaciones

| Palabra Veyrath | Significado |
|---|---|
| Mirevan | el propio lanzador |
| Aeloran | un aliado identificado |
| Irkalen | un objetivo hostil identificado |
| Ilvaren | un objeto o estructura no viva |
| Arameth | un área o volumen definido |
| Sulvaren | una superficie o punto del entorno |
| Varen | relación direccional: «hacia / sobre» |

### 3.7 Léxico de condiciones

| Palabra Veyrath | Matiz |
|---|---|
| Nerai | breve, una sola descarga |
| Torevan | sostenido mientras haya mantenimiento |
| Keshara | preciso y concentrado |
| Marovar | extendido o de mayor cobertura |
| Thularek | anclado a un lugar, objeto o marca |
| Vaelis | intensidad contenida o baja |
| Rokharen | impulso más fuerte, con mayor coste o inestabilidad |
| Naimora | discreto, de baja señal observable |

### 3.8 Palabras de marco y cierre

| Palabra | Función |
|---|---|
| Ena | declara al lanzador como ejecutor |
| Aethar | declara el medio de flujo arcano |
| Varen | introduce el objetivo de la operación |
| Thalen | cierra la oración y confirma su estructura |

Las palabras de marco aparecen en muchas fórmulas porque cumplen una función gramatical, no porque sean relleno. Las palabras de contenido cambian según el efecto. En la siguiente etapa se diseñarán variantes de fuente, límites y cláusulas condicionales para cánticos de mayor complejidad.

## 4. Reglas de combinación y errores

1. El orden de la oración importa. Cambiar operación, dominio, forma u objetivo altera el efecto o invalida la fórmula.
2. Una palabra desconocida no se vuelve conocida por aparecer en un grimorio que el personaje no comprende.
3. Sustituir una palabra puede producir otra operación, una ejecución incompleta o un fallo.
4. Omitir una palabra estructural puede invalidar la oración; omitir una condición puede producir un efecto menos preciso, menos estable o distinto.
5. Una oración no puede ordenar un resultado físicamente imposible sin mecanismo arcano, fuente y coste válidos.
6. Una traducción puede servir como ayuda conceptual, pero no reemplaza la estructura Veyrath ni garantiza el mismo resultado.
7. El pánico no cambia la gramática objetiva: puede afectar la selección, memoria de trabajo, pronunciación, ritmo o concentración del personaje.
8. El aprendizaje se registra en dos escalas: conocimiento de cada palabra y dominio de cada oración/hechizo. La segunda nunca se deduce automáticamente de la primera.

## 6. Penalización por formular en español

Parámetros iniciales aprobados de penalización relativa respecto de la misma fórmula ejecutada correctamente en Veyrath:

| Dominio de la fórmula | Penalización de ejecución en español |
|---|---:|
| Traducción literal sin comprender la estructura | 30% de pérdida de eficacia global |
| Traducción comprendida y practicada | 15% de pérdida |
| Dominio lingüístico alto y traducción adaptada | 5% de pérdida |
| Veyrath correctamente dominado | Sin penalización lingüística |

La pérdida global se reparte según la naturaleza del hechizo: puede traducirse en más coste, más tiempo, menos precisión, menos potencia, menor duración o más inestabilidad. No se aplican todas las penalizaciones simultáneamente ni se reduce siempre el daño de la misma manera. Las cifras son valores de prueba y se pueden ajustar tras las primeras simulaciones.

## 7. Aprendizaje de Veyrath y acceso a hechizos

Se proponen cinco estados de conocimiento por palabra o fórmula:

1. **Oída/vista:** el personaje ha tenido exposición, pero no puede ejecutarla de forma fiable.
2. **Reconocida:** identifica la palabra y su significado aproximado.
3. **Comprendida:** entiende la función y su relación con otras palabras.
4. **Ejecutable:** puede construir y probar la fórmula, con errores posibles.
5. **Dominada:** puede ejecutarla de forma fiable y, tras práctica suficiente, habilitar autocompletado.

Los grimorios y maestros permiten adquirir información, no dominio instantáneo. El personaje aprende palabras individuales, relaciones gramaticales y oraciones completas como conocimientos distintos. Reconocer las nueve palabras de un hechizo no implica poder formularlo: debe comprender el orden, la función, la pronunciación y la canalización de la oración. El jugador verá únicamente palabras adquiridas legítimamente. Las desconocidas aparecerán como signos ilegibles o términos no comprendidos, no como botones mágicos disponibles. El autocompletado exige dominio de la oración completa, no solo de sus palabras.

---

# PARTE II — PARÁMETROS QUE PROPONGO CERRAR PARA LA PRIMERA PRUEBA

## 8. Fórmula inicial de aprendizaje

Propongo mantener la capacidad general de aprendizaje y aptitudes por dominio separadas. Una criatura puede aprender rápido en combate y lentamente una lengua, o al revés.

### 8.1 Índice de aprendizaje efectivo

Todos los componentes se expresan inicialmente en una escala de 0 a 100:

`LE = 0.35C + 0.25A + 0.15K + 0.10I + 0.15F`

Donde:

- `C`: capacidad general de aprendizaje del individuo.
- `A`: aptitud específica del dominio (magia, idioma, combate, medicina, fabricación, etc.).
- `K`: conocimientos previos relevantes.
- `I`: calidad de instrucción, maestro, libro, demostración o material.
- `F`: calidad de práctica, atención, retroalimentación y corrección de errores.

`LE` no es inteligencia total ni garantiza éxito. Es un estimador del rendimiento de aprendizaje en una actividad concreta.

### 8.2 Velocidad de progreso

`Progreso por sesión = Base de la actividad × (0.5 + LE/100) × Atención × Práctica × Dificultad`

Modificadores recomendados:

- Atención: 0.0–1.0. Distracción, miedo o agotamiento reducen el valor.
- Práctica: 0.5–1.25. Práctica variada y deliberada vale más que repetir sin corregir.
- Dificultad: 0.5–1.5. Depende de la complejidad, prerrequisitos y compatibilidad.
- La calidad de instrucción ya está incluida en `I`; no se debe volver a multiplicar por ella.

El resultado se acumula en progreso de conocimiento o dominio, no en una barra genérica que convierte cualquier repetición en maestría.

### 8.3 Etapas de dominio

| Progreso de dominio | Estado orientativo | Qué permite |
|---:|---|---|
| 0–19 | Familiarización | Reconocer elementos, errores frecuentes |
| 20–39 | Comprensión inicial | Explicar principios y requisitos básicos |
| 40–59 | Ejecución básica | Ejecutar con tiempo, riesgo de error y supervisión cuando proceda |
| 60–79 | Competencia | Uso fiable en condiciones conocidas |
| 80–94 | Dominio | Adaptación, eficiencia y variaciones limitadas |
| 95–100 | Dominio experto | Innovación fundamentada y transferencia a problemas nuevos |

El talento puede acelerar el proceso, pero no saltarse experiencias, prerrequisitos o información ausente.

### 8.4 Aprendizaje de oraciones Veyrath

Cada hechizo posee progreso separado para: (a) reconocimiento de palabras; (b) comprensión sintáctica; (c) memoria de la oración completa; (d) ejecución/canalización; y (e) dominio práctico bajo presión. Una fórmula de nueve palabras exige aprender como mínimo el léxico, el orden y la relación entre sus cláusulas. Las repeticiones idénticas sin retroalimentación aportan rendimientos decrecientes. Una práctica variada —cambiar objetivo, distancia o situación sin alterar la fórmula— consolida mejor la comprensión.

La longitud por sí sola no debe ser el único coste de aprendizaje: una oración larga con estructura familiar puede ser más sencilla que una corta con una operación nueva. Las fórmulas avanzadas de pisos posteriores podrán contener 12–20 palabras y cláusulas condicionales; no se desbloquean por nivel automáticamente, sino por conocimientos y experiencia.

## 9. Reglas iniciales para adaptación táctica

Una criatura no adapta su estrategia por «haber visto» una acción una sola vez ni accede a los pensamientos del jugador.

### 9.1 Evidencia táctica

Cada observación útil genera evidencia según calidad: visibilidad, distancia, atención, repetición, contexto, memoria y claridad de la causa/consecuencia.

| Evidencia acumulada de un patrón | Interpretación posible |
|---:|---|
| 0–2 puntos | Sin conclusión estable; puede reaccionar al evento concreto |
| 3–5 puntos | Hipótesis: intenta una respuesta de prueba, con posibilidad alta de equivocarse |
| 6–9 puntos | Adaptación funcional: contramedida parcial en circunstancias similares |
| 10 o más | Patrón confirmado: respuesta consistente, si tiene medios físicos o mágicos para ejecutarla |

### 9.2 Qué cuenta como evidencia

- Una observación clara y directa puede aportar 1–2 puntos.
- Una observación parcial, lejana o confusa puede aportar 0.25–0.75 puntos.
- Ver al jugador repetir la misma conducta en oportunidades distintas vale más que contemplar una secuencia continua que no permite inferir intención.
- Para adaptación funcional se recomienda exigir al menos tres oportunidades distinguibles. Para confirmación, al menos cinco oportunidades distribuidas en dos encuentros o contextos, salvo que el patrón sea extremadamente obvio.
- La capacidad de aprendizaje y las aptitudes tácticas aumentan la calidad de la inferencia y reducen errores; no eliminan la necesidad de exposición.

### 9.3 Ejemplo: castigar una esquiva repetida

Si un jugador esquiva repetidamente hacia el mismo lado y ataca siempre al terminar el movimiento, un monstruo puede primero notar la dirección (hipótesis), después lanzar un ataque retardado hacia ese espacio (prueba), y finalmente sincronizar una persecución o golpe con la recuperación de la esquiva (adaptación funcional). No conoce el botón pulsado ni la animación interna del juego: aprende el movimiento observable.

El jugador puede romper el patrón variando dirección, ritmo, distancia, pausa, defensa o tipo de contraataque. El monstruo tendrá que observar esas nuevas conductas para adaptarse de nuevo.

### 9.4 Adaptación individual y colectiva

La adaptación es individual por defecto. Solo se transmite a aliados si existe comunicación, señal visible, imitación, entrenamiento compartido o experiencia directa. No se comparte automáticamente una memoria invisible entre todos los monstruos de la especie.

## 10. Reglas iniciales de casteo y coste

### 10.1 Tiempo de formulación

Fórmula inicial aprobada de tiempo base:

`T = 0.8 + (0.22 × N) + (0.35 × C) + (0.75 × P)` segundos

- `N`: cantidad total de palabras pronunciadas (incluidas las palabras gramaticales). En el catálogo inicial N=9; las fórmulas avanzadas podrán superar esa longitud. El coeficiente 0.22 representa una ejecución practicada; un aprendiz tardará más por pausas, vacilaciones y errores.
- `C`: complejidad operacional, de 1 a 5.
- `P`: exigencia postural: 0 si puede ejecutarse en movimiento; 1 si requiere estabilidad parcial; 2 si exige postura o preparación.

El resultado es un tiempo base, no una animación rígida. Puede aumentar por heridas, miedo, fatiga, interferencia, mala pronunciación, flujo insuficiente o entorno desfavorable. El dominio puede reducir errores y pequeños retrasos, pero no convertir el cántico en instantáneo.

### 10.2 Coste arcano

Para balance inicial se utilizará el porcentaje de la reserva arcana funcional del individuo, no un valor MP fijo idéntico para todas las especies. La interfaz puede mostrarlo como MP cuando esa entidad tenga una reserva compatible.

- Hechizo menor: 2–4% de la reserva máxima.
- Hechizo ofensivo/control estándar: 4–7%.
- Defensa o curación relevante: 5–10%.
- Efecto de área, sostenido o de alta complejidad: 8–14%.
- Mantenimiento: coste periódico de referencia, inicialmente entre 1–3% cada 10 segundos según magnitud; el valor exacto se calibra por hechizo y condiciones de ejecución.

La eficiencia, la fuente ambiental, la Resonancia y el entrenamiento pueden alterar el coste. No debe ser posible encadenar hechizos sin límite solo porque el número visual de MP sea alto: también cuentan fatiga, estabilidad, recuperación y tolerancia corporal.

### 10.3 Interrupción

- Antes de iniciar canalización: no hay coste significativo, salvo preparación especial.
- Durante formulación temprana: puede perderse una fracción pequeña del coste.
- Durante canalización: puede perderse una parte importante o toda la energía comprometida.
- En liberación: el efecto puede salir incompleto, desviarse, debilitarse o disiparse.
- La explosión o lesión del lanzador no será una consecuencia automática. Solo ocurrirá si el mecanismo del hechizo y las condiciones físicas lo justifican.

## 11. Balance entre guerrero y mago

### 11.1 Unidad de comparación

Para las pruebas se define `U` como un impacto básico exitoso de un combatiente físico de capacidad equivalente contra el mismo tipo de objetivo. No es una unidad universal de daño permanente; sirve para comparar resultados en combate.

### 11.2 Referencias por diseño

- Hechizo de objetivo único, 2.5–4.5 s de casteo: aproximadamente 1.3–2.1 U.
- Hechizo de objetivo único del tramo alto de pisos 4–5, 4–6 s: aproximadamente 2.0–2.6 U, con mayor coste o requisito.
- Hechizo de área: aproximadamente 0.7–1.1 U por objetivo alcanzado, con pérdida de potencia en bordes o impactos parciales.
- Hechizo de control: daño bajo o nulo; su valor se mide por segundos de ventaja, separación, interrupción o reducción de precisión enemiga.
- Hechizo defensivo: evita o reduce daño futuro, pero exige anticipación, posición o mantenimiento.
- Curación: no debe superar sin coste el daño entrante sostenido del grupo. Su valor es mantener a alguien vivo, controlar una lesión y reducir secuelas, no borrar el peligro del encuentro.

### 11.3 Por qué el mago sigue siendo valioso

El mago puede herir a distancia, alcanzar grupos, cambiar superficies, levantar barreras, negar rutas, iluminar, detectar amenazas, controlar movimientos, interrumpir cánticos rivales y resolver situaciones que un arma no resuelve con rapidez. El guerrero protege el tiempo que requiere la ejecución y aprovecha aperturas inmediatas. Ninguno reemplaza al otro en todos los contextos.

## 12. Curación, heridas graves y muerte

### 12.1 Principio

La curación se aplica a una lesión concreta y a un organismo compatible. Debe declarar qué tejidos, funciones o estados corrige y qué no puede corregir.

### 12.2 Escala inicial de referencia de lesiones

| Grado | Estado | Papel habitual del sanador |
|---|---|---|
| I | Daño menor, corte superficial, contusión | Cierre, alivio, recuperación más rápida |
| II | Herida importante, esguince, fractura simple | Tratamiento dirigido, inmovilización, reparación parcial |
| III | Hemorragia importante, trauma profundo, shock, lesión funcional grave | Estabilización urgente, control de sangrado, atención prolongada |
| IV | Daño catastrófico de estructura vital o destrucción incompatible con la vida | Puede ser muerte instantánea; curación ordinaria no es válida |

### 12.3 Muerte instantánea

La pérdida de HP no es por sí sola la única condición de muerte. La muerte instantánea se puede producir cuando una lesión destruye una estructura vital de forma incompatible con la continuidad del organismo, teniendo en cuenta anatomía, especie, fuerza, ángulo, arma, protección y mecanismo del daño. Un corte superficial en la cabeza no significa automáticamente muerte; una destrucción suficiente del cerebro, tronco vital u otra estructura equivalente sí puede hacerlo.

Un hechizo curativo ordinario no puede aplicarse a un muerto. La estabilización debe ocurrir antes de que se cumplan las condiciones de muerte irreversible. Cualquier excepción posterior se rige por SR-01 y no forma parte del catálogo ordinario de pisos 1–5.

### 12.4 Límites de la fase

- No hay regeneración instantánea de brazos, piernas, manos u órganos completos.
- Cerrar una herida no equivale a restaurar la función perdida.
- Reimplante, cirugía, prótesis y reconstrucción artificial siguen siendo vías posibles, según SR-09.
- Una curación fallida puede dejar cicatrices, pérdida de movilidad, infección, dolor, daño residual o necesidad de rehabilitación.
- El sanador puede ser decisivo sin poder evitar toda muerte: necesita tiempo, protección, alcance, energía y oportunidad de actuar.

---

# PARTE III — CATÁLOGO DE 72 HECHIZOS DE LOS PISOS 1–5

## 13. Convenciones del catálogo

- `P1` a `P5`: piso o tramo en el que se propone que el hechizo pueda descubrirse, enseñarse o encontrarse por primera vez. No obliga a que cada jugador lo obtenga en ese piso.
- `T`: casteo aproximado en condiciones favorables, usando dominio suficiente. El cántico sigue ocurriendo aunque se use autocompletado.
- `Coste`: porcentaje inicial sugerido de reserva arcana máxima funcional.
- `U`: impacto básico físico exitoso de referencia contra un objetivo comparable.
- Los efectos están sujetos a cobertura, resistencia, anatomía, entorno, precisión, armadura, especie, interrupciones y leyes de SR-07/SR-08.
- Los hechizos no son habilidades instantáneas ni garantizan impacto.

## 14. Ofensiva directa — 12 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 1 | Brasa dirigida | `Ena Aethar Varesh Orath Kethar Varen Irkalen Nerai Thalen.` | 1 | 2.8 s / 4% | Proyectil pequeño de fuego; 1.3–1.5 U. Puede quemar material inflamable si las condiciones lo permiten. |
| 2 | Aguja de escarcha | `Ena Aethar Varesh Iskalen Kethar Varen Irkalen Keshara Thalen.` | 1 | 3.2 s / 4% | Punta de agua congelada; 1.4 U y ralentización breve si impacta una zona expuesta. No congela automáticamente a un enemigo entero. |
| 3 | Dardo de presión | `Ena Aethar Varesh Vethorin Kethar Varen Irkalen Nerai Thalen.` | 1 | 2.7 s / 4% | Impacto invisible de presión; 1.3 U y pequeño desplazamiento si el peso y la resistencia lo permiten. |
| 4 | Corte de viento | `Ena Aethar Kordain Varelin Limerath Varen Irkalen Keshara Thalen.` | 1 | 3.4 s / 5% | Lámina estrecha de aire; 1.4–1.6 U. Puede producir cortes en zonas sin protección adecuada. |
| 5 | Piedra impulsada | `Ena Aethar Varesh Durneth Kethar Varen Irkalen Rokharen Thalen.` | 2 | 3.8 s / 6% | Acelera una masa mineral pequeña o forma un fragmento del entorno; 1.6–1.8 U, más lenta y visible. |
| 6 | Chispa de arco | `Ena Aethar Varesh Zareth Kethar Varen Irkalen Nerai Thalen.` | 2 | 3.1 s / 5% | Descarga eléctrica breve; 1.4 U, puede alterar músculos o mecanismos sensibles. La conductividad del entorno importa. |
| 7 | Látigo incandescente | `Ena Aethar Varesh Orath Veskar Varen Irkalen Torevan Thalen.` | 2 | 4.2 s / 7% | Corriente de fuego dirigida que puede rozar un objetivo o zona; 1.5–1.8 U y riesgo de ignición secundaria. |
| 8 | Pulso resonante | `Ena Aethar Varesh Sonareth Thamorin Varen Irkalen Rokharen Thalen.` | 3 | 4.0 s / 7% | Golpe sónico concentrado; 1.5 U, puede desorientar o interrumpir una acción si el objetivo es vulnerable al sonido. |
| 9 | Lanza de vapor | `Ena Aethar Varesh Rhemora Raveth Varen Irkalen Marovar Thalen.` | 3 | 4.3 s / 7% | Descarga caliente de vapor; 1.5–1.8 U en corto alcance, menor penetración y visibilidad limitada por vapor. |
| 10 | Dardo de luz | `Ena Aethar Varesh Seloria Kethar Varen Irkalen Keshara Thalen.` | 3 | 3.4 s / 6% | Proyectil luminoso preciso; 1.5 U. Reduce eficacia contra superficies muy reflectantes o barreras adecuadas. |
| 11 | Aguja umbría | `Ena Aethar Varesh Vumareth Kethar Varen Irkalen Keshara Thalen.` | 4 | 4.0 s / 7% | Proyectil oscuro de baja señal visual; 1.7–1.9 U. No atraviesa automáticamente armaduras ni vuelve intangible al proyectil. |
| 12 | Ruptura de suelo | `Ena Aethar Shevara Durneth Thamorin Varen Sulvaren Rokharen Thalen.` | 5 | 5.5 s / 10% | Estallido localizado del suelo; 2.0–2.3 U a quien esté sobre el punto y alteración del terreno. Requiere superficie compatible y es muy telegráfico. |

## 15. Control, interrupción y restricción — 8 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 13 | Tobillo de barro | `Ena Aethar Auneth Durneth Veskar Varen Irkalen Torevan Thalen.` | 1 | 3.4 s / 5% | Adhiere barro o tierra húmeda a los pies; reduce movilidad durante 1–2 s si el suelo lo permite. |
| 14 | Empuje lateral | `Ena Aethar Selvar Varelin Raveth Varen Irkalen Nerai Thalen.` | 1 | 2.8 s / 4% | Desvía o desequilibra un objetivo pequeño; no derriba automáticamente criaturas pesadas. |
| 15 | Nudo de escarcha | `Ena Aethar Auneth Iskalen Rilaven Varen Irkalen Torevan Thalen.` | 2 | 3.8 s / 6% | Congela una zona pequeña de articulación o superficie; limita movimiento, con efecto reducido en enemigos resistentes al frío. |
| 16 | Red de hilo arcano | `Ena Aethar Auneth Aethar Senvara Varen Irkalen Torevan Thalen.` | 2 | 4.5 s / 7% | Red de filamentos que entorpece a un objetivo; puede romperse mediante fuerza, corte o interferencia. |
| 17 | Velo de silencio | `Ena Aethar Nemeira Sonareth Meliora Varen Arameth Torevan Thalen.` | 3 | 4.6 s / 7% | Reduce la propagación de sonido en un área pequeña; dificulta comunicación y cánticos audibles, no elimina vibraciones físicas. |
| 18 | Tirón de sombra | `Ena Aethar Selvar Vumareth Veskar Varen Irkalen Nerai Thalen.` | 3 | 3.8 s / 6% | Tira brevemente de una extremidad o sombra proyectada si hay anclaje; no controla por completo el cuerpo ni la voluntad. |
| 19 | Campo de fricción | `Ena Aethar Shevara Varelin Meliora Varen Sulvaren Torevan Thalen.` | 4 | 4.8 s / 8% | Aumenta o reduce fricción en una superficie pequeña; puede dificultar una carga o causar resbalones. |
| 20 | Sello de detención | `Ena Aethar Auneth Vethorin Rilaven Varen Irkalen Thularek Thalen.` | 5 | 5.2 s / 9% | Marca un punto de anclaje que frena brevemente a un objetivo al cruzarlo; visible y evitable si se detecta. |

## 16. Defensa y protección — 8 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 21 | Lámina de aire | `Ena Aethar Khalem Varelin Kardelis Varen Mirevan Nerai Thalen.` | 1 | 2.8 s / 4% | Desvía parcialmente un proyectil ligero o reduce un impacto frontal; no es un escudo omnidireccional. |
| 22 | Piel de polvo | `Ena Aethar Khalem Durneth Dorveth Varen Mirevan Torevan Thalen.` | 1 | 4.0 s / 6% | Capa mineral ligera que reduce abrasión y cortes superficiales; añade peso y no detiene golpes potentes. |
| 23 | Velo térmico | `Ena Aethar Khalem Rhemora Dorveth Varen Aeloran Torevan Thalen.` | 2 | 4.1 s / 6% | Reduce cambios térmicos moderados sobre un aliado; no concede inmunidad al fuego o al frío extremo. |
| 24 | Guardia de pulso | `Ena Aethar Khalem Vethorin Kardelis Varen Aeloran Nerai Thalen.` | 2 | 3.7 s / 6% | Capa de fuerza que amortigua un impacto; su eficacia cae si recibe varios golpes seguidos. |
| 25 | Refugio de luz | `Ena Aethar Varesh Seloria Kardelis Varen Arameth Torevan Thalen.` | 3 | 4.8 s / 8% | Barrera luminosa pequeña que bloquea parcialmente visión y ataques ligeros; puede ser atravesada o rota. |
| 26 | Desvío de trayectoria | `Ena Aethar Selvar Aethar Kardelis Varen Aeloran Nerai Thalen.` | 3 | 4.0 s / 7% | Altera ligeramente el ángulo de un proyectil dirigido a un aliado marcado. Requiere anticipación y línea de efecto. |
| 27 | Cáscara de cohesión | `Ena Aethar Khalem Thiraven Dorveth Varen Mirevan Torevan Thalen.` | 4 | 4.7 s / 8% | Refuerza temporalmente la cohesión externa de armadura, escudo u objeto; no repara grietas internas ni vuelve irrompible el equipo. |
| 28 | Barrera de umbral | `Ena Aethar Khalem Aethar Kardelis Varen Sulvaren Thularek Thalen.` | 5 | 5.8 s / 10% | Barrera fija y estrecha en un umbral o pasillo; eficaz contra avance y proyectiles modestos, con duración y superficie limitadas. |

## 17. Curación, primeros auxilios arcanos y estabilización — 10 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 29 | Cese de sangre | `Ena Aethar Auneth Narethis Veskar Varen Aeloran Keshara Thalen.` | 1 | 3.8 s / 5% | Reduce o detiene una hemorragia externa moderada al favorecer la coagulación local. No sustituye extracción de objetos ni cirugía. |
| 30 | Cierre superficial | `Ena Aethar Mireth Narethis Limerath Varen Aeloran Keshara Thalen.` | 1 | 4.0 s / 5% | Cierra cortes menores y ayuda a reparar tejido superficial; no cura infección ni daño profundo. |
| 31 | Alivio del dolor | `Ena Aethar Selvar Kelvane Meliora Varen Aeloran Vaelis Thalen.` | 1 | 3.0 s / 3% | Reduce dolor durante poco tiempo; no elimina la lesión y puede ocultar señales de empeoramiento. |
| 32 | Estabilizar pulso | `Ena Aethar Eshara Narethis Rilaven Varen Aeloran Torevan Thalen.` | 2 | 4.8 s / 7% | Ayuda a mantener funciones fisiológicas inestables durante una ventana corta; útil ante shock, pero no revive a un muerto. |
| 33 | Limpieza de toxina leve | `Ena Aethar Dasev Narethis Veskar Varen Aeloran Keshara Thalen.` | 2 | 5.0 s / 7% | Ayuda a neutralizar o expulsar una toxina simple ya identificada; no sirve contra todos los venenos y puede requerir diagnóstico. |
| 34 | Alineación ósea | `Ena Aethar Selvar Thiraven Rilaven Varen Aeloran Keshara Thalen.` | 3 | 5.8 s / 8% | Facilita colocar una fractura simple en posición correcta; requiere inmovilización posterior y no reconstruye hueso destruido. |
| 35 | Reparación profunda | `Ena Aethar Mireth Narethis Veskar Varen Aeloran Torevan Thalen.` | 3 | 6.2 s / 9% | Recupera parte del tejido dañado y puede devolver aproximadamente 15–25% de HP en una lesión compatible; no cierra por sí sola heridas catastróficas. |
| 36 | Purga de infección inicial | `Ena Aethar Dasev Narethis Meliora Varen Aeloran Keshara Thalen.` | 4 | 6.0 s / 9% | Reduce una infección localizada temprana si el sanador la identifica; no elimina parásitos complejos ni sustituye tratamiento prolongado. |
| 37 | Reconstrucción de tejido | `Ena Aethar Mireth Narethis Dorveth Varen Aeloran Rokharen Thalen.` | 4 | 7.2 s / 11% | Cura una lesión grave no instantáneamente mortal y puede recuperar 25–35% de HP o función parcial. Requiere inmovilidad y protección del grupo. |
| 38 | Anclaje vital | `Ena Aethar Eshara Narethis Kardelis Varen Aeloran Torevan Thalen.` | 5 | 7.5 s / 12% | Mantiene estable a un aliado en estado crítico y frena el deterioro durante una ventana limitada. No revierte muerte irreversible ni reconstruye órganos destruidos. |

**Regla especial para sanadores:** los hechizos 29, 32, 35, 37 y 38 pueden ser decisivos incluso cuando su daño directo es cero. El grupo debe proteger el cántico; el sanador debe elegir si estabiliza, trata la causa, reduce secuelas o reserva energía para una segunda emergencia. Un guerrero puede impedir que la herida ocurra; un sanador puede impedir que una herida sobrevivible termine en muerte.

## 18. Apoyo, mejoras y coordinación — 8 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 39 | Mano firme | `Ena Aethar Khalem Kelvane Rilaven Varen Aeloran Torevan Thalen.` | 1 | 3.2 s / 4% | Mejora temporalmente precisión motora fina; útil para arqueros, cirujanos o artesanos bajo presión. |
| 40 | Paso ligero | `Ena Aethar Khalem Varelin Meliora Varen Aeloran Nerai Thalen.` | 1 | 3.4 s / 4% | Reduce la resistencia del aire y facilita un desplazamiento corto; no aumenta reflejos ni permite teletransportarse. |
| 41 | Aliento compartido | `Ena Aethar Tavren Narethis Veskar Varen Aeloran Torevan Thalen.` | 2 | 4.5 s / 6% | Ayuda a repartir una parte de la carga respiratoria/fatiga entre lanzador y aliado compatible; el coste y el cansancio no desaparecen. |
| 42 | Marca de presa | `Ena Aethar Auneth Sairen Rilaven Varen Irkalen Thularek Thalen.` | 2 | 3.8 s / 5% | Marca un objetivo visible para mejorar coordinación y seguimiento; la marca no revela al enemigo a través de paredes. |
| 43 | Foco sereno | `Ena Aethar Khalem Kelvane Meliora Varen Aeloran Vaelis Thalen.` | 3 | 4.0 s / 6% | Ayuda a sostener concentración y reduce interferencias leves; no inmuniza al miedo ni impide interrupciones físicas. |
| 44 | Reserva templada | `Ena Aethar Eshara Aethar Dorveth Varen Mirevan Torevan Thalen.` | 3 | 5.0 s / 8% | Conserva flujo arcano en una envoltura temporal para usarlo después; no crea energía y tiene un límite de almacenamiento. |
| 45 | Enlace de señales | `Ena Aethar Tavren Sonareth Veskar Varen Aeloran Torevan Thalen.` | 4 | 4.8 s / 7% | Permite transmitir una señal breve entre aliados vinculados a corta distancia; obstáculos y ruido pueden degradarla. |
| 46 | Ritmo de grupo | `Ena Aethar Khalem Sairen Meliora Varen Arameth Torevan Thalen.` | 5 | 6.0 s / 10% | Facilita que un grupo coordinado perciba señales comunes y sincronice maniobras; no comparte pensamientos ni concede habilidades. |

## 19. Percepción, rastreo e investigación — 6 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 47 | Oído de piedra | `Ena Aethar Thesira Sonareth Meliora Varen Sulvaren Torevan Thalen.` | 1 | 3.8 s / 5% | Amplifica vibraciones transmitidas por una superficie; puede detectar pasos cercanos si el entorno no está demasiado ruidoso. |
| 48 | Rastro térmico | `Ena Aethar Thesira Rhemora Limerath Varen Arameth Nerai Thalen.` | 2 | 4.2 s / 6% | Revela diferencias térmicas recientes en un corredor o superficie; no identifica automáticamente quién pasó. |
| 49 | Lectura de flujo | `Ena Aethar Thesira Aethar Meliora Varen Arameth Keshara Thalen.` | 2 | 4.8 s / 6% | Detecta concentraciones o perturbaciones del flujo arcano; no identifica por sí sola el hechizo o la intención que las produjo. |
| 50 | Eco de cámara | `Ena Aethar Varesh Sonareth Meliora Varen Arameth Vaelis Thalen.` | 3 | 4.5 s / 7% | Emite una señal tenue y lee su retorno para estimar espacios y obstáculos; puede revelar la posición del lanzador. |
| 51 | Rastreo de huella | `Ena Aethar Thesira Sairen Limerath Varen Sulvaren Keshara Thalen.` | 4 | 5.0 s / 7% | Resalta rastros físicos recientes (pisadas, fricción, residuos) si siguen presentes; no reconstruye el pasado completo. |
| 52 | Aviso direccional | `Ena Aethar Thesira Sairen Thamorin Varen Mirevan Nerai Thalen.` | 5 | 5.2 s / 8% | Produce una alerta direccional ante una alteración cercana detectada; puede generar falsos positivos y no predice el futuro. |

## 20. Movimiento, acceso y supervivencia — 5 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 53 | Caída amortiguada | `Ena Aethar Selvar Varelin Dorveth Varen Mirevan Nerai Thalen.` | 1 | 3.0 s / 4% | Reduce el impacto de una caída moderada si se activa a tiempo; no salva de cualquier altura. |
| 54 | Salto asistido | `Ena Aethar Varesh Vethorin Meliora Varen Mirevan Nerai Thalen.` | 2 | 3.4 s / 5% | Añade impulso a un salto; no permite volar y puede lesionar si el aterrizaje es inadecuado. |
| 55 | Agarre de superficie | `Ena Aethar Auneth Thiraven Veskar Varen Mirevan Torevan Thalen.` | 3 | 4.3 s / 6% | Aumenta la adherencia de manos y pies a una superficie compatible; no funciona en todas las texturas ni bajo cargas ilimitadas. |
| 56 | Tirón de cuerda | `Ena Aethar Selvar Vethorin Veskar Varen Ilvaren Nerai Thalen.` | 4 | 4.4 s / 7% | Tira de una cuerda, herramienta u objeto ligero hacia un punto; no arrastra grandes criaturas. |
| 57 | Paso de corriente | `Ena Aethar Selvar Varelin Limerath Varen Mirevan Nerai Thalen.` | 5 | 4.8 s / 8% | Desplazamiento corto impulsado por aire en una dirección; no es teletransporte y puede ser bloqueado por obstáculos. |

## 21. Entorno, utilidad y manipulación — 8 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 58 | Luz flotante | `Ena Aethar Varesh Seloria Rilaven Varen Arameth Torevan Thalen.` | 1 | 2.8 s / 3% | Crea una luz pequeña que sigue o permanece sobre un punto; ilumina, pero también puede delatar al grupo. |
| 59 | Encender yesca | `Ena Aethar Varesh Orath Rilaven Varen Ilvaren Nerai Thalen.` | 1 | 2.2 s / 2% | Enciende material seco y combustible de poco volumen; no crea combustible ni incendia cualquier material. |
| 60 | Apagar llama | `Ena Aethar Dasev Orath Raveth Varen Sulvaren Nerai Thalen.` | 1 | 2.8 s / 3% | Reduce o extingue una llama pequeña al retirar calor/oxígeno de forma arcana; fuegos mayores requieren más recursos. |
| 61 | Purificar agua simple | `Ena Aethar Dasev Iskalen Meliora Varen Ilvaren Keshara Thalen.` | 2 | 4.0 s / 5% | Reduce sedimentos y contaminantes simples en poco volumen; no garantiza potabilidad frente a cualquier veneno o patógeno. |
| 62 | Niebla baja | `Ena Aethar Varesh Iskalen Meliora Varen Arameth Torevan Thalen.` | 2 | 4.2 s / 6% | Forma niebla ligera en un espacio pequeño; reduce visibilidad de ambos bandos y depende de humedad/temperatura. |
| 63 | Moldear grava | `Ena Aethar Shevara Durneth Veskar Varen Sulvaren Keshara Thalen.` | 3 | 4.4 s / 6% | Reacomoda una pequeña cantidad de grava o tierra suelta; no crea roca ni excava instantáneamente una galería. |
| 64 | Secado rápido | `Ena Aethar Selvar Rhemora Meliora Varen Ilvaren Nerai Thalen.` | 3 | 3.8 s / 4% | Extrae humedad superficial de ropa, cuerda o material pequeño; no seca grandes volúmenes sin coste superior. |
| 65 | Reparación menor | `Ena Aethar Mireth Thiraven Limerath Varen Ilvaren Keshara Thalen.` | 5 | 6.0 s / 9% | Repara una grieta o unión pequeña en material compatible; no reconstruye armas destruidas ni sustituye la forja. |

## 22. Ilusión, sonido y ocultación — 5 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 66 | Susurro distante | `Ena Aethar Tavren Sonareth Veskar Varen Aeloran Naimora Thalen.` | 2 | 3.8 s / 4% | Envía un susurro breve a un aliado identificado dentro de alcance limitado; puede ser interferido. |
| 67 | Eco falso | `Ena Aethar Nemeira Sonareth Rilaven Varen Arameth Naimora Thalen.` | 3 | 4.0 s / 5% | Genera un sonido localizado para desviar atención; no crea una criatura ni engaña automáticamente a sentidos sobrenaturales. |
| 68 | Silueta velada | `Ena Aethar Nemeira Vumareth Dorveth Varen Mirevan Torevan Thalen.` | 4 | 5.2 s / 8% | Reduce contraste y silueta del lanzador en un fondo adecuado; no lo vuelve invisible ni elimina sonido, olor o huellas. |
| 69 | Rostro borroso | `Ena Aethar Nemeira Seloria Meliora Varen Mirevan Vaelis Thalen.` | 4 | 4.8 s / 7% | Distorsiona detalles visuales de la cara a distancia; no cambia rasgos físicos ni engaña una inspección cercana. |
| 70 | Doble destello | `Ena Aethar Varesh Seloria Thamorin Varen Arameth Nerai Thalen.` | 5 | 4.4 s / 7% | Crea destellos breves en uno o dos puntos para confundir la orientación; puede afectar también a aliados si no se advierte. |

## 23. Sellos, marcas y preparación — 2 hechizos

| # | Hechizo | Veyrath | P | T / coste | Efecto de referencia |
|---:|---|---|---:|---|---|
| 71 | Sello de alarma | `Ena Aethar Auneth Sairen Rilaven Varen Sulvaren Thularek Thalen.` | 2 | 4.5 s / 6% | Marca una puerta, objeto o paso y emite una señal al detectar una perturbación definida; no distingue automáticamente aliados de enemigos. |
| 72 | Anclaje de reserva | `Ena Aethar Auneth Aethar Rilaven Varen Ilvaren Thularek Thalen.` | 5 | 6.5 s / 10% | Inscribe un punto donde almacenar una cantidad pequeña de flujo para una operación posterior; requiere material compatible, preparación y tiempo de carga. |

---

# PARTE IV — PROGRESIÓN DE LOS PISOS 1–5

## 24. Distribución de disponibilidad

La distribución indica el primer tramo razonable de descubrimiento o enseñanza. No es una lista rígida de contenido que aparece automáticamente al cruzar una puerta.

| Piso | Enfoque mágico | Hechizos cuyo descubrimiento inicial se recomienda |
|---:|---|---|
| 1 | Fundamentos de supervivencia y canalización | 1–4, 13–14, 21–22, 29–31, 39–40, 47, 53, 58–60 |
| 2 | Control básico, curación y utilidad | 5–7, 15–16, 23–24, 32–33, 41–42, 48–49, 54, 61–62, 66, 71 |
| 3 | Coordinación, percepción y especialización | 8–10, 17–18, 25–26, 34–36, 43–44, 50, 55, 63–64, 67 |
| 4 | Técnicas precisas y defensa especializada | 11, 19, 27, 37, 45, 51, 56, 68–69 |
| 5 | Técnicas de riesgo elevado y preparación | 12, 20, 28, 38, 46, 52, 57, 65, 70, 72 |

Algunos hechizos simples pueden aparecer en grimorios antiguos fuera del piso previsto, pero eso no significa que el personaje pueda ejecutarlos sin los prerrequisitos. Los pisos definen progresión de acceso y dificultad, no una frontera metafísica que prohíbe descubrir antes una palabra.

## 25. Roles mágicos dentro de un grupo

- **Mago ofensivo:** castiga enemigos desde distancia, explota debilidades físicas/químicas/térmicas del entorno y produce daño concentrado o de área. Requiere protección y oportunidad.
- **Controlador:** modifica rutas, ralentiza, separa, distrae o interrumpe. Puede aportar más valor que el daño directo si evita que el enemigo alcance al grupo.
- **Defensor arcano:** anticipa ataques, levanta coberturas, desvía proyectiles y refuerza equipo. No reemplaza la armadura ni el bloqueo del guerrero.
- **Sanador:** detiene hemorragias, estabiliza, trata lesiones y reduce secuelas. Su prioridad no siempre es recuperar HP: puede necesitar controlar la causa de la lesión antes de reparar tejido.
- **Apoyo:** coordina, marca objetivos, mejora precisión, comunica señales y facilita maniobras.
- **Explorador arcano:** ilumina, percibe flujo, rastrea señales y lee espacios. La información obtenida sigue siendo parcial y puede interpretarse mal.
- **Artesano/inscriptor:** usa sellos, reparaciones y preparación fuera del choque inmediato. Sus operaciones requieren materiales, tiempo y conocimiento.

Las clases predisponen y facilitan el aprendizaje, pero no bloquean que un guerrero aprenda curación básica o que un mago aprenda a usar una espada.

## 26. Ejemplo de una situación donde el sanador resulta esencial

Un grupo de cuatro entra en combate. El guerrero recibe un corte profundo en el costado y queda con hemorragia de grado III. El atacante sigue activo.

1. El guerrero puede reaccionar y defenderse de inmediato; el sanador no puede curar de forma instantánea.
2. El sanador necesita que otro miembro cree una ventana segura y decide entre aplicar **Cese de sangre** (hechizo 29) o **Estabilizar pulso** (32), según la causa inmediata.
3. Si la hemorragia externa continúa, curar HP antes de controlarla desperdicia energía y no resuelve el peligro.
4. Una vez estabilizado, puede ejecutar **Reparación profunda** (35) o recibir tratamiento convencional.
5. Si el golpe hubiese destruido instantáneamente una estructura vital y causado muerte irreversible, ninguno de estos hechizos serviría. La oportunidad de actuar y la decisión correcta importan.

Esto hace que el sanador sea necesario sin convertirlo en un botón de resurrección ni hacer que el guerrero sea prescindible.

---

# PARTE V — INTERFAZ Y EJECUCIÓN PARA EL SISTEMA REACTOR

## 27. Interfaz de formulación

1. El jugador abre el panel de formulación. No se pausa el mundo ni el combate.
2. La interfaz muestra palabras Veyrath conocidas, agrupadas por su función gramatical: operación, dominio, forma, objetivo y condición.
3. El jugador selecciona las unidades en orden. La interfaz puede mostrar traducción contextual en español, pero valida la gramática Veyrath.
4. Mientras el personaje formula, el mundo sigue avanzando. El usuario puede estar expuesto a ataques, movimiento, miedo, ruido e interrupciones.
5. Al completar una secuencia válida, empieza la ejecución/canalización conforme al tiempo calculado.
6. El usuario puede cancelar, pero se pierde el tiempo y, según fase, una parte del flujo comprometido.
7. Al dominar una fórmula, aparece la opción de autocompletado. Esta opción introduce directamente la secuencia aprendida, no un lanzamiento instantáneo.

## 28. Autocompletado y criterios de dominio aprobados

Condiciones de desbloqueo por hechizo:

- Dominio de fórmula recomendado igual o superior a 75/100.
- Al menos cuatro ejecuciones correctas en condiciones distinguibles, distribuidas en un mínimo de dos sesiones de práctica o encuentros.
- Comprensión funcional de operadores, dominio y objetivo.
- El umbral puede subir para fórmulas de gran complejidad; el talento puede reducir la práctica necesaria, pero no eliminar comprensión ni experiencia.

Efectos del autocompletado:

- Reduce errores de selección manual.
- No reduce el coste base de forma gratuita.
- No elimina pronunciación, ritmo, canalización ni tiempo de cántico.
- No impide interrupciones por impacto, dolor, pánico, agotamiento o pérdida de concentración.
- No permite usar un hechizo que el personaje no haya aprendido.

## 29. Pánico y formulación

El pánico puede perturbar atención, memoria de trabajo, selección y ejecución. La representación visual de palabras que se desplazan o reordenan se usará solo como recurso probabilístico y graduado, no como molestia constante.

Parámetros iniciales aprobados:

- Ansiedad leve: solo una pequeña posibilidad de retraso o selección equivocada en fórmulas complejas.
- Miedo intenso: mayor coste de concentración, riesgo de perder una unidad o romper el ritmo.
- Pánico severo: puede desordenar visualmente opciones, forzar pausas involuntarias o interrumpir la fórmula.
- El dominio alto y la resiliencia emocional reducen la probabilidad y la duración del efecto, pero no garantizan inmunidad.
- El pánico no modifica el vocabulario aprendido ni cambia la gramática verdadera de Veyrath.

## 30. Datos mínimos que cada hechizo debe exponer al motor

- Identificador único y nombre mostrado.
- Fórmula Veyrath y versión lingüística.
- palabras requeridas y prerrequisitos de conocimiento.
- Operador, dominio, forma y objetivo.
- Tiempo de formulación, canalización y liberación.
- Coste, fuente, mantenimiento y recuperación.
- Alcance, trayectoria, área y precisión.
- Potencia esperada y tipo de interacción física/biológica/arcana.
- Duración, condiciones de terminación y resistencias relevantes.
- Vulnerabilidades ante interrupción.
- Efectos secundarios, fallos posibles y residuos.
- Compatibilidad anatómica y límites médicos, cuando corresponda.
- Requisitos de postura, movimiento, materiales, entorno o anclaje.
- Nivel de dominio y disponibilidad de autocompletado.

El motor lógico resuelve el efecto. La animación y los efectos visuales muestran lo sucedido, pero no determinan por sí solos daño, curación, alcance o éxito.

---

# PARTE VI — PRUEBAS DE ACEPTACIÓN

## 31. Pruebas mínimas para validar los valores de referencia

1. **Guerrero frente a mago:** comparar daño total, daño recibido, interrupciones y utilidad durante 30 segundos. El mago no debe superar al guerrero en reacción inmediata; debe aportar valor cuando puede completar su fórmula.
2. **Casteo interrumpido:** impacto recibido en 25%, 60% y 90% de la ejecución. Verificar pérdida de flujo y que no haya explosión automática.
3. **Grupo con sanador:** simular una hemorragia de grado III. Verificar que el grupo necesita crear una ventana de protección y que la curación cambia la probabilidad de supervivencia sin garantizarla.
4. **Muerte instantánea:** destruir una estructura vital. Comprobar que los hechizos ordinarios no resucitan al individuo.
5. **Traducción:** comparar la misma fórmula en español, traducción comprendida y Veyrath dominado. Verificar que existe una diferencia visible, sin volver inútil la traducción.
6. **Aprendizaje:** dos personajes con distinta capacidad y aptitud aprenden la misma palabra Veyrath bajo condiciones idénticas; el más apto progresa más deprisa, pero ambos necesitan exposición y práctica.
7. **Adaptación:** un monstruo observa una esquiva repetida y desarrolla primero una hipótesis, luego una contramedida imperfecta y finalmente una adaptación consistente.
8. **Contraadaptación:** el jugador cambia de patrón y el monstruo no debe anticiparlo hasta reunir evidencia nueva.
9. **Pánico:** probar miedo leve, intenso y severo. La interferencia debe ser probabilística y no alterar las palabras conocidas.
10. **Autocompletado:** una fórmula dominada se selecciona automáticamente, pero conserva el tiempo de cántico, el coste y la vulnerabilidad.
11. **Hechizos de área:** medir potencia por objetivo al alcanzar uno, dos, tres o más objetivos; evitar que el área sea siempre mejor que el hechizo concentrado.
12. **Curación:** comparar detener hemorragia, estabilizar pulso y restaurar tejido. El orden correcto debe importar.
13. **Ambiente:** probar fuego, agua, electricidad, viento y materiales diferentes sin ventajas elementales automáticas.
14. **Uso del léxico:** sustituir una palabra por otra y omitir condiciones. El motor debe producir un resultado coherente con la gramática y no tratar palabras como claves intercambiables.
15. **Magia de utilidad:** comprobar que iluminar, detectar, reparar, ocultar o manipular terreno puede resolver problemas sin producir daño directo.

## 32. Parámetros de calibración que no bloquean la aprobación

Los siguientes valores quedan establecidos como referencias iniciales de balance y podrán calibrarse con pruebas reproducibles. Su ajuste no podrá convertir los hechizos en instantáneos, borrar la diferencia entre aprender palabras y dominar oraciones, eliminar costes ni hacer que la magia sustituya universalmente al combate físico.

- HP absolutos, daño por especie y escalas de reserva arcana se determinan en las fichas de entidades y no se fijan con una cifra global.
- Resistencias de criaturas, materiales y condiciones ambientales se definen en sus fichas y en SR-07.
- Recuperación fisiológica, regeneración de flujo y costes específicos pueden variar por especie, Resonancia, entrenamiento y entorno.
- Las curvas de aprendizaje pueden ajustarse sin saltarse exposición, comprensión, prerrequisitos ni práctica real.
- Alcance, precisión, duración e interrupción de cada hechizo se conservan en sus fichas de catálogo y se calibran por ensayo.
- La disponibilidad por piso es una expectativa de descubrimiento, no una aparición garantizada ni una barrera absoluta contra conocimientos anteriores.

## 33. Resolución de diseño y control de integración

La edición aprobada establece como referencia: Veyrath como lengua arcana original; oraciones de palabras independientes y ordenadas; gramática operacional compartida; 72 hechizos iniciales distribuidos entre pisos 1–5; aprendizaje separado de palabras y oraciones; autocompletado solo para fórmulas dominadas; casteo no instantáneo e interrumpible; costes medidos sobre la reserva funcional de cada entidad; y balance en el que el mago aporta alcance, control, protección, información y curación, mientras el combatiente físico conserva ventaja de reacción inmediata.

Los 72 efectos del catálogo se conservan. Cada fórmula inicial tiene nueve palabras completas, no abreviaturas ni sílabas sueltas. Las futuras oraciones avanzadas podrán incorporar 12–20 palabras y cláusulas adicionales si su operación lo exige.

**Estado:** Anexo A de SR-09, versión 1.0 oficial aprobada por el autor. Se mantiene subordinado a SR-07 y SR-09.

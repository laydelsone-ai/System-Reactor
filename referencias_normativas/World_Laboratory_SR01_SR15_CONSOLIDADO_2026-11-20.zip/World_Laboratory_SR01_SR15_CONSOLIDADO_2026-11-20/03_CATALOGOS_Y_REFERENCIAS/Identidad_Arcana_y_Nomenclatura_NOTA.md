# NOTA COMPLEMENTARIA — IDENTIDAD CIVILIZATORIA Y NOMENCLATURA

SR-13 establece que la Arcana será uno de los ejes de identidad del universo. El nombre se utiliza como término civilizatorio amplio y no reemplaza Trama, flujo, Resonancias ni Veyrath.

Los nombres de instituciones, tradiciones, corrientes filosóficas, órdenes, cargos y prácticas deben nacer de las culturas que los usan. No se crearán nombres aleatorios ni se repetirá la misma terminación para todas las organizaciones. Las familias fonéticas deben distinguirse por región, lengua, época, oficio y tradición.

Los ejemplos funcionales del SR-13 (casas de estudio, custodias de fuentes, observatorios, colegios de formulación, etc.) son tipos de institución, no nombres canónicos. Los nombres propios se desarrollarán en fichas culturales y atlas posteriores.

Veyrath conserva su identidad como lengua arcana de formulación. No se reutilizará como nombre genérico de la civilización, religión o especie. Los nombres aprobados no se sustituirán por semejanza estética sin control de versiones.

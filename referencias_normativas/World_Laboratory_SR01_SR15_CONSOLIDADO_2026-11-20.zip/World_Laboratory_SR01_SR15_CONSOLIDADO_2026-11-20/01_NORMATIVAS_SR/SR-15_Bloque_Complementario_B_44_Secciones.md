# WORLD LABORATORY / SISTEMA REACTOR
# SR-15 — BLOQUE COMPLEMENTARIO B: ESPECIFICACIÓN TÉCNICA EN 44 SECCIONES

**Identificador del bloque:** SR-15-B (complemento documental; numeración local 1–44).  
**Fuente de origen:** SR-15 — ARQUITECTURA TÉCNICA, SIMULACIÓN AUTÓNOMA Y EJECUCIÓN DEL SISTEMA RECTOR; versión fuente 0.1, incluida en el segundo paquete aportado.  
**Fecha de integración en este paquete:** 20 de noviembre de 2026.  
**Estado:** MATERIAL TÉCNICO COMPLEMENTARIO INCORPORADO POR INSTRUCCIÓN DEL AUTOR. No sustituye ni modifica silenciosamente SR-15 v1.0 (88 secciones), ni constituye una aprobación independiente de una nueva versión del cuerpo principal.  
**Autoridad:** subordinado a SR-01 y compatible con SR-02 a SR-15 v1.0.  
**Uso:** desarrollar con mayor detalle los contratos técnicos, dominios, decisiones de producto, ejecución y validación descritos en SR-15 v1.0.

> **Regla de lectura y conflicto:** este bloque conserva sus 44 secciones con la numeración local original 1–44. El SR-15 principal conserva intactas sus 88 secciones 1–88. Ambos bloques se leen en conjunto, pero sus numeraciones no se mezclan. Las reglas del SR-15 v1.0 y de SR-01 a SR-14 prevalecen. Si una cláusula de este complemento parece contradecir una norma superior o el cuerpo principal, no se debe elegir ni fusionar por inferencia: se debe señalar la sección exacta, explicar el conflicto y proponer una resolución para aprobación.

> **Declaración de alcance:** SR-15 convierte las reglas ya aprobadas de SR-01 a SR-14 en contratos técnicos verificables. No reemplaza ninguna norma de dominio, no modifica las leyes del universo y no afirma que la implementación esté terminada. Esta versión incorpora y consolida la especificación técnica WLA-TECH-001 v0.1.0 como antecedente de diseño; los supuestos técnicos que no sean leyes aprobadas se identifican como baseline o decisiones de implementación sujetas a prueba.

## CONTROL DEL BLOQUE COMPLEMENTARIO

| Campo | Valor |
|---|---|
| Código | SR-15-B — complemento de 44 secciones |
| Fuente histórica | SR-15 v0.1 del segundo paquete aportado |
| Clasificación en este paquete | Especificación técnica complementaria |
| Estado de aprobación | Su inclusión como material complementario fue solicitada por el autor; no reemplaza ni reabre la aprobación de SR-15 v1.0 |
| Autoridad superior | SR-01; SR-15 v1.0 para la arquitectura técnica principal |
| Numeración | Local 1–44; separada de las secciones 1–88 del SR-15 principal |

### Convenciones

- **DEBE / NO DEBE:** requisito normativo obligatorio.
- **PUEDE:** posibilidad permitida, no garantía.
- **BASELINE TÉCNICO:** decisión actual de implementación que puede revisarse con pruebas, sin alterar contratos normativos.
- **CALIBRACIÓN:** valor cuantitativo ajustable después de pruebas reproducibles.
- **RESERVADO:** detalle que se desarrollará en catálogos, contenido o una norma subordinada.
- **NO VERIFICADO:** implementación o comportamiento que aún no tiene pruebas suficientes.


# PARTE I — PROPÓSITO, AUTORIDAD Y PRINCIPIOS

## 1. Propósito

SR-15 define cómo se ejecuta técnicamente el universo diseñado en SR-01 a SR-14. Establece una arquitectura que permita que entidades persistentes perciban, interpreten, recuerden, desarrollen objetivos, planifiquen, actúen, sufran resultados y produzcan acontecimientos sin depender de la presencia del jugador ni de un modelo generativo externo.

El primer producto de validación es el **World Laboratory**: una instancia del mundo que puede inicializarse sin jugador humano, avanzar durante tiempo simulado, mantener población, recursos, ecosistemas, sociedades y conflictos, y permitir que un observador inspeccione los acontecimientos. El laboratorio no es un segundo simulador desechable. Sus contratos lógicos, reglas de tiempo, identidad, comandos, validación, eventos y persistencia deberán poder servir al RPG final.

El producto posterior incorpora al jugador como participante controlado por una persona, sin convertirlo en el centro ontológico ni detener la vida de los demás habitantes. El jugador es una entidad más dentro del mismo mundo y queda sujeto a las mismas leyes, costes, información limitada y consecuencias.

## 2. Autoridad normativa y separación de responsabilidades

SR-15 está subordinada a SR-01 y desarrolla técnicamente SR-02 a SR-14. En caso de conflicto:

1. SR-01 conserva autoridad constitucional y define lo que puede existir y las leyes superiores.
2. SR-02 define la arquitectura de autoridad, comandos, validación y coordinación.
3. SR-03 define identidad, cognición, memoria, aprendizaje y evolución individual.
4. SR-04 define realidad única, causalidad, canon, crónicas, instancias y persistencia.
5. SR-05 define creación de entidades, especies, objetos, materiales y representaciones.
6. SR-06 define el World Laboratory, simulación, observación y experimentación.
7. SR-07 define las leyes naturales, arcanas y de interacción.
8. SR-08 define biología, fisiología, salud, reproducción, herencia y ecología.
9. SR-09 y su Anexo A definen combate, lesiones, curación, táctica, formulación y Veyrath.
10. SR-10 define economía, propiedad, intercambio, fabricación, recursos y recompensas.
11. SR-11 define geografía, asentamientos, torre, Mazmorra, pisos y espacio.
12. SR-12 define progresión, atributos, aprendizaje, habilidades, clases y maestría.
13. SR-13 define sociedad, cultura, instituciones, creencias y Arcana.
14. SR-14 define historia fundacional, motivaciones narrativas, misiones manuales, arcos y narrativa emergente.
15. SR-15 define la arquitectura técnica que ejecuta esas reglas; no puede reinterpretarlas ni anularlas.

Si una regla de software parece contradecir una regla del universo, el comportamiento de software es el que debe corregirse. No se cambia el canon para acomodar una limitación de código sin una enmienda aprobada.

## 3. Principios técnicos obligatorios

1. **Realidad única:** el World Laboratory y el RPG consultan y modifican el mismo modelo de mundo lógico; no mantienen simulaciones paralelas que se contradigan.
2. **Autoridad de dominio:** cada cambio persistente debe ser confirmado por el dominio que tiene competencia para resolverlo.
3. **Agente no omnipotente:** un agente propone acciones con información, memoria, capacidades y recursos limitados.
4. **Causalidad antes que narrativa:** el motor resuelve lo que ocurrió; el Narrative Engine organiza oportunidades e interpretaciones, pero no inventa resultados.
5. **Persistencia verificable:** los cambios relevantes se registran con identidad, tiempo, causa, procedencia y versión.
6. **Representación no es realidad:** cámara, animación, VFX, UI y modelos no crean daño, propiedad, identidad, memoria ni resultados.
7. **Autonomía sin LLM obligatorio:** necesidades, rutinas, supervivencia, navegación, acción, memoria, comercio, ecología y planificación básica deben funcionar sin servicios generativos.
8. **Simulación multiescala:** no se procesa a todos los individuos con máxima resolución en cada frame; se conserva una cronología causal con niveles de detalle adecuados.
9. **Offline-first individual:** la primera instancia Android puede operar sin red, con autoridad local y persistencia local.
10. **No prometer sincronización global offline:** un mundo compartido entre dispositivos necesita autoridad común y reconciliación; no se simula esa garantía con dos copias desconectadas.
11. **Rendimiento medido:** máximos de población, detalle y duración de catch-up se aprueban con benchmarks, no mediante números arbitrarios.
12. **Desarrollo por pruebas:** una demo que abre o una simulación que corre una vez no acredita autonomía, integridad ni estabilidad.

# PARTE II — ARQUITECTURA GENERAL

## 4. Arquitectura lógica del Sistema Rector

La arquitectura se divide en dominios funcionales. No implica microservicios ni procesos separados en la primera versión. En Android pueden vivir dentro de un único proceso modular; la separación define autoridad y contratos, no distribución física obligatoria.

### 4.1 Componentes principales

| Componente | Responsabilidad | Prohibición principal |
|---|---|---|
| System Core / Kernel | Coordinar versiones, comandos, tiempo, transacciones y ciclo de ejecución | Decidir vidas y resultados de forma arbitraria |
| Entity Registry | Identidades, episodios de vida, cuerpos, vínculos y referencias estables | Usar nombre o modelo visual como identidad |
| World Model | Estado objetivo actual y consultas de dominios | Convertirse en memoria omnisciente de cada agente |
| Cognitive Engine | Percepción limitada, evaluación, motivación, selección y planificación | Escribir directamente el estado persistente |
| Memory Engine | Recuerdos, conocimientos, creencias, confianza y procedencia | Reescribir hechos objetivos |
| Evolution Engine | Aprendizaje, dominio, adaptación y transformación | Conceder capacidades por deseo o escena |
| Command Processor | Validar y ejecutar comandos tipados | Confiar en una intención sin validar |
| Domain Resolvers | Resolver movimiento, combate, economía, biología, sociedad, Arcana, etc. | Resolver fuera de su autoridad |
| Causal Engine | Dependencias, efectos diferidos y consecuencias | Crear consecuencias sin condición ni causa |
| Narrative Engine | Arcos, misiones, oportunidades, pistas y presentación narrativa | Garantizar finales o forzar aceptación |
| Social Engine | Relaciones, grupos, instituciones y prácticas sociales | Repartir conocimiento automáticamente |
| Ecology Engine | Poblaciones, redes tróficas, migración y recursos naturales | Depender de la cámara o jugador |
| Creation Engine | Definiciones, plantillas, individuos, materiales, objetos y assets | Confundir asset con existencia |
| Chronicle Engine | Eventos confirmados, historial, snapshots y auditoría | Borrar o sobrescribir hechos silenciosamente |
| Scheduler | Priorizar tareas, eventos y niveles de resolución | Usar la cercanía a la cámara como medida de existencia |
| Persistence Layer | Diario, snapshots, migraciones, backups y recuperación | Guardar solo lo que actualmente está renderizado |
| Observatory | Consulta y presentación pasiva del mundo | Intervenir de forma oculta en decisiones |
| Presentation Client | Vista 2.5D/3D, interacción, animación, audio y UI | Ser autoridad de reglas o consecuencias |

### 4.2 Topología lógica

```text
Android / World Laboratory / RPG Client
                 │
        consultas / órdenes de UI
                 ▼
         System Core / Kernel
          ├── Scheduler / World Clock
          ├── Entity Registry / World Model
          ├── Cognitive Engine ── Memory / Evolution
          ├── Command Processor
          │      └── Domain Resolvers
          │          ├── Movement / Physics
          │          ├── Combat / Healing
          │          ├── Biology / Ecology
          │          ├── Economy / Crafting
          │          ├── Society / Institutions
          │          ├── Arcana / Veyrath
          │          ├── Creation / Materials
          │          └── Narrative / Missions
          ├── Causal Engine / Chronicle
          └── Persistence / Snapshots / Recovery
                 ▲
          Observatory (read-only by default)
```

## 5. Modularidad y dependencias

Los módulos DEBEN comunicarse mediante contratos de dominio estables; NO DEBEN acceder arbitrariamente a estructuras internas de otros módulos. Los dominios pueden consultar información publicada y enviar comandos a la autoridad competente. Las dependencias deben formar un grafo acíclico de responsabilidades o usar mensajes/eventos cuando una dependencia directa produciría un ciclo.

Un módulo puede proponer una operación que afecte varios dominios, pero cada dominio resuelve su parte y el Kernel coordina una transacción o saga con estados explícitos. Un fallo parcial debe dejar un estado recuperable y trazable; no se oculta como éxito completo.

En la primera versión, simplicidad de despliegue prevalece sobre microservicios. Una separación lógica correcta permite extraer procesos posteriormente sin reescribir la semántica.

# PARTE III — IDENTIDAD, ESTADO Y CONTRATOS

## 6. Identidad y representación de entidades

La identidad lógica se mantiene separada de nombre visible, apariencia, modelo, especie, plantilla, cuerpo actual y sesión. Debe ser posible que un individuo cambie de cuerpo, nombre, apariencia, condición vital o representación sin crear automáticamente una identidad nueva, y que dos individuos visualmente idénticos sigan siendo personas distintas.

### 6.1 Identificadores mínimos

- `entity_id`: instancia lógica actual dentro del mundo.
- `universal_identity_id`: identidad persistente conforme a SR-01/SR-03.
- `life_episode_id`: episodio vital o encarnación.
- `body_id`: cuerpo concreto, cuando corresponda.
- `cognitive_profile_id`: perfil cognitivo.
- `social_identity_id`: identidad social o registro de una comunidad.
- `species_definition_id`: definición de especie, cuando exista.
- `template_id`: plantilla de creación, no identidad.
- `asset_key`: referencia opcional de representación visual.
- `state_version`: versión monotónica del estado relevante.

Los campos exactos pueden ampliarse, pero sus semánticas no pueden colapsarse. Un `asset_key` ausente o sin resolver no invalida una entidad. La pérdida de un modelo no destruye a la criatura; el cambio de modelo no crea otro individuo.

## 7. Estado del mundo y separación de capas

El sistema distingue:

1. **Estado objetivo:** lo que ocurrió o existe según los dominios competentes.
2. **Percepción:** lo que un agente pudo observar mediante sus sentidos, instrumentos o comunicaciones.
3. **Conocimiento:** lo que el agente aprendió o recibió.
4. **Creencia / hipótesis:** lo que el agente interpreta, incluido lo falso o incierto.
5. **Difusión:** lo que se comunicó a otros.
6. **Presentación:** lo que la interfaz elige mostrar al usuario.

No se puede modificar el estado objetivo porque un NPC crea algo, porque un jugador lea un rumor o porque un diálogo lo diga. Los hechos pueden ser secretos aunque estén confirmados; los rumores pueden estar difundidos sin probar su contenido.

## 8. Contratos de datos y versionado

Todo contrato persistente DEBE declarar su versión de esquema y permitir migración explícita. Los identificadores son estables; los nombres de campos, enumeraciones y unidades deben documentarse. Las referencias a entidades y objetos se resuelven por ID, no por texto visible.

### 8.1 Esqueleto ilustrativo de entidad

```json
{
  "entity_id": "ent_...",
  "universal_identity_id": "uid_...",
  "life_episode_id": "life_...",
  "body_id": "body_...",
  "cognitive_profile_id": "cog_...",
  "social_identity_id": "social_...",
  "species_definition_id": "species_...",
  "template_id": "template_...",
  "scope": "world_local",
  "asset_key": "characters/placeholder_humanoid",
  "state_version": 1,
  "schema_version": 1
}
```

Este esquema es una forma de referencia, no una obligación de usar literalmente esos nombres en el lenguaje de implementación. La separación semántica sí es obligatoria.

### 8.2 Unidades y formatos

Las unidades de distancia, tiempo, masa, volumen, energía, dinero y reservas deben declararse por campo o tipo. No se mezclan metros con celdas, segundos con frames ni valores enteros con unidades de UI sin conversión explícita. Fechas del mundo se almacenan mediante `world_tick` y calendario del mundo; UTC local se usa solo como referencia externa para estimar tiempo de ausencia en modo offline.

# PARTE IV — AGENTES AUTÓNOMOS

## 9. Perfil de agente

Un agente es una entidad con capacidades de percepción, procesamiento y acción. No se presume que todos los seres vivos tengan cognición humana. El modelo se adapta a la especie, edad, anatomía, desarrollo, cultura, experiencia y limitaciones individuales.

Un perfil de agente puede contener, cuando proceda:

- necesidades fisiológicas o funcionales;
- objetivos y motivaciones con prioridad, intensidad y horizonte temporal;
- rasgos de personalidad como tendencias probabilísticas, no como frases de diálogo;
- emociones y estados de estrés que afectan atención, memoria y selección;
- capacidades sensoriales, cognitivas, físicas, sociales y arcanas;
- conocimientos, creencias e hipótesis con fuente y confianza;
- recuerdos episódicos, semánticos, procedimentales, espaciales, emocionales, sociales y prospectivos;
- relaciones asimétricas y compromisos;
- recursos, inventario, propiedad y obligaciones;
- planes activos, condiciones de reevaluación y límites de coste computacional.

## 10. Ciclo de decisión autónoma

El ciclo normativo de decisión es:

1. **Percepción:** recoger observaciones disponibles desde sentidos, entorno, instrumentos y comunicaciones.
2. **Filtrado:** aplicar alcance sensorial, atención, ruido, visibilidad, distancia, obstáculos, estado físico y contexto.
3. **Interpretación:** conectar observaciones con conocimientos y recuerdos; producir creencias con incertidumbre.
4. **Evaluación:** actualizar necesidades, riesgos, motivaciones, relaciones, obligaciones y oportunidades.
5. **Generación de objetivos:** identificar objetivos posibles de acuerdo con capacidades y circunstancias.
6. **Planificación:** producir uno o varios planes viables, con costes, duración, riesgos, recursos y dependencias.
7. **Selección:** escoger una intención según prioridades individuales, urgencia, preferencias, incertidumbre y compromisos.
8. **Emisión de comando:** transformar la intención en un comando tipado con precondiciones observadas.
9. **Validación:** el dominio competente comprueba autoridad, capacidades, recursos, distancia, estado, permisos y versión.
10. **Resolución:** se calcula el resultado según las reglas del dominio.
11. **Confirmación y evento:** se registra el resultado real; una acción rechazada no se registra como éxito.
12. **Aprendizaje y memoria:** se actualizan conocimientos, recuerdos y dominio únicamente por información y experiencia adquiridas.
13. **Replanificación:** los resultados pueden cancelar, modificar o reemplazar planes.

No todos los agentes ejecutan cada paso con igual complejidad o frecuencia. Una criatura sencilla puede usar respuestas reactivas; un individuo complejo puede combinar planificación jerárquica y deliberación. La simplificación no puede concederle capacidades que no posee.

## 11. Arquitectura cognitiva offline

La primera implementación debe combinar técnicas ligeras y verificables según la necesidad:

- máquinas de estado o comportamientos reactivos para respuestas inmediatas;
- Utility AI o prioridades para comparar necesidades y objetivos;
- GOAP para encontrar secuencias de acciones según precondiciones y efectos;
- HTN o planes jerárquicos para actividades prolongadas;
- memoria estructurada y consultas por relevancia;
- aprendizaje incremental acotado por experiencia y retroalimentación;
- comunicación limitada por canal, idioma, capacidad, distancia y tiempo.

No es obligatorio usar todas estas técnicas en cada agente. La elección es un asunto de implementación y benchmark. Ningún método puede sustituir los límites de SR-03, SR-08, SR-12 y la información disponible.

## 12. Modelos generativos y LLM

Los modelos generativos son opcionales, intercambiables y fuera de la ruta crítica del núcleo. Pueden ayudar a redactar diálogo, proponer formulaciones, resumir recuerdos, sugerir hipótesis, elaborar candidatos de plan o presentar información. Sus salidas deben ser datos no confiables hasta que se validen.

Un LLM NO DEBE:

- escribir directamente el estado objetivo o los archivos de guardado;
- adjudicar propiedad, dinero, materiales, heridas, muertes o victorias;
- decidir que una acción físicamente imposible tuvo éxito;
- añadir una habilidad, recuerdo o conocimiento sin evento de adquisición válido;
- conceder a un agente información que nunca percibió ni recibió;
- crear un resultado de misión, un jefe, un objeto o un NPC para resolver una escena;
- ser llamado obligatoriamente en cada tick o por cada habitante.

Si no hay red, proveedor, cuota o modelo, el mundo debe mantener supervivencia, tiempo, movimiento, actividad, economía básica, persistencia, validación y simulación principal. La indisponibilidad generativa afecta solo las funciones opcionales que realmente la utilicen.

## 13. Trazas de decisión

Las decisiones relevantes deben poder auditarse mediante datos estructurados, sin guardar razonamiento privado textual. La traza contiene, según necesidad:

- `decision_id`, `agent_id`, `world_tick`;
- observaciones usadas y su procedencia;
- creencias/recuerdos pertinentes;
- motivaciones/objetivos que compitieron;
- alternativas consideradas o descartadas, si se instrumentan;
- acción seleccionada y comando emitido;
- validación y dominio ejecutor;
- resultado, `event_id` y actualizaciones de aprendizaje.

La traza debe explicar qué variables estructuradas influyeron, no fabricar una racionalización posterior. Su granularidad puede ajustarse por rendimiento, pero las pruebas de autonomía deben poder habilitar trazas detalladas.

# PARTE V — COMANDOS, DOMINIOS Y CAUSALIDAD

## 14. Comandos tipados y autoridad de escritura

Todo cambio persistente se realiza mediante comando tipado o proceso de dominio explícito. Un agente formula una intención; no muta el estado directamente. Un comando debe incluir, según corresponda:

- identificador único e idempotente;
- actor y objetivos afectados;
- dominio y tipo de acción;
- alcance del mundo o instancia;
- precondiciones conocidas;
- recursos requeridos y ofrecidos;
- versión del estado observada;
- referencia de decisión, interacción o proceso originador;
- instante de creación en tiempo del mundo.

El procesador competente comprueba identidad, autorización, capacidades, anatomía, estado, alcance, distancia, recursos, inventario, propiedad, condiciones ambientales, tiempo y versión. Las comprobaciones específicas dependen del dominio.

## 15. Validación, concurrencia e idempotencia

La validación ocurre antes de mutar el estado. Si falla, se registra rechazo o resultado fallido según la política del dominio; no se consumen recursos a medias salvo que exista coste de intento aprobado por la norma de ese dominio.

Los comandos que compiten por bienes únicos, recursos limitados, plazas, rutas exclusivas, propiedad o espacio deben resolverse con serialización, bloqueos lógicos o transacciones. Nunca puede ocurrir que dos compradores adquieran simultáneamente el mismo objeto único o que dos expediciones retiren el mismo componente del mismo lugar.

Repetir el mismo `command_id` no debe duplicar sus efectos. La recuperación tras cierre inesperado debe conservar esa propiedad. Un resultado parcial de operación multietapa necesita un estado explícito de compensación, reintento o fallo.

## 16. Dominios de resolución

Cada dominio es autoridad de los hechos de su competencia:

- Movimiento y entorno: posición, colisión, ruta, obstáculos, fuerzas relevantes y tránsito.
- Biología: fisiología, hambre, enfermedad, reproducción, muerte, regeneración y estado corporal.
- Combate: impactos, lesiones, defensa, incapacitación, curación táctica y consecuencias.
- Arcana: operación, fuente, coste, objetivo, alcance, duración, estabilidad e interrupciones.
- Economía: bienes, inventario, propiedad, transferencia, pagos, deuda, fabricación y reparación.
- Sociedad: relaciones, instituciones, acuerdos, reputación, ley, comunicación y conflicto.
- Geografía: regiones, localizaciones, accesibilidad, conexiones y estado del espacio.
- Progresión: adquisición, aprendizaje, dominio, experiencia, clase y evolución individual.
- Narrativa: arcos, contratos, objetivos, condiciones, pistas y representación de acontecimientos confirmados.

La resolución integrada puede requerir varios dominios. Ejemplo: al derrotar a un monstruo, combate confirma muerte o incapacitación; biología determina si el cuerpo conserva tejidos; Creation/Materials determina qué material puede extraerse; economía y propiedad determinan quién adquiere lo extraído; Chronicle conserva los hechos; Narrative puede presentar una oportunidad de misión. El relato no puede saltarse ninguno de esos pasos.

## 17. Causalidad y eventos

Un evento persistente debe conservar, según proceda:

- `event_id`, tipo y versión de esquema;
- `world_tick` y fecha de calendario;
- ubicación o región;
- actores, participantes y entidades afectadas;
- estado previo y posterior relevante;
- causa, comando o proceso originador;
- dominio que confirmó el resultado;
- evidencia y procedencia;
- versión de reglas, definiciones y generadores;
- consecuencias pendientes y dependencias;
- visibilidad, difusión y ámbito.

Un evento propuesto no equivale a un evento confirmado. Un rumor difundido no cambia el estado objetivo. La ausencia de información no se interpreta como prueba de que algo no ocurrió.

# PARTE VI — TIEMPO Y SIMULACIÓN MULTIESCALA

## 18. Reloj del mundo

`world_tick` es la cronología interna autoritativa. El calendario del mundo convierte ticks en días, estaciones, años y horas según la configuración de escenario. La escala entre tiempo real y tiempo del mundo es configurable y no debe codificarse en cada dominio.

La primera configuración técnica descrita por WLA-TECH-001 utilizaba como punto de partida un segundo real por segundo del mundo. Esto es un parámetro inicial de prueba, no una obligación universal. Los escenarios de simulación acelerada pueden aplicar otra escala documentada.

## 19. Scheduler y niveles de resolución

El Scheduler procesa tareas y eventos programados, no cada agente en cada frame. La escala de resolución se adapta a la precisión necesaria y al impacto causal:

| Nivel | Ejemplos | Resolución |
|---|---|---|
| Interacción | combate cercano, impactos, esquiva, operación arcana activa | alta y de corta duración |
| Actividad | trabajo, rutinas, expediciones, conversación, viajes | evaluaciones programadas |
| Ecología/población | reproducción, migración, oferta de recursos, población agregada | lotes con conservación de consecuencias |
| Historia | evolución social, cambios de organización, generaciones, transformaciones regionales | procesos de largo plazo |

La cámara, el foco narrativo y la presencia del jugador no determinan si una entidad existe ni si sus procesos continúan. Pueden influir en qué se representa y en el presupuesto de detalle, pero no congelar arbitrariamente el mundo.

## 20. Priorización de trabajo

La prioridad se basa en urgencia, riesgo, severidad, impacto causal, compromisos, entidades afectadas, consecuencias pendientes, precisión requerida y recursos disponibles. Una amenaza inmediata o una lesión crítica puede exigir resolución fina; una transacción distante con vencimiento puede procesarse como tarea de actividad; la reproducción de una población puede procesarse agregadamente si se conservan resultados relevantes.

El paso de un nivel de detalle a otro no puede teletransportar entidades, borrar heridas, duplicar objetos, cambiar ganadores o cancelar decisiones confirmadas retroactivamente.

## 21. Mundo offline, catch-up y pausa

Al guardar y cerrar la aplicación, se conserva el estado y la última referencia temporal. Al reabrir, el sistema estima el tiempo ausente, calcula el intervalo pendiente y ejecuta catch-up mediante tareas del Scheduler. No simula cada frame perdido.

La aplicación debe ofrecer una política explícita de pausa. Cuando el usuario pausa el mundo, el intervalo de pausa no debe acumular catch-up. Cuando se cierra sin pausar, el mundo continúa y se procesa el tiempo de ausencia al reabrir.

En una instalación offline individual, el reloj local del dispositivo no es una autoridad inviolable. La aplicación puede detectar retrocesos o inconsistencias y registrar anomalías, pero no puede garantizar que un usuario no altere deliberadamente la hora del dispositivo tras apagarlo. La interfaz no debe prometer protección antimanipulación absoluta sin una autoridad externa.

# PARTE VII — PERSISTENCIA Y RECUPERACIÓN

## 22. Persistencia local

La primera implementación usa persistencia local versionada. Como baseline técnico, se adopta:

- snapshots del estado materializado;
- diario append-only de eventos persistentes (por ejemplo, NDJSON o un formato equivalente validado);
- checkpoints periódicos y al pausar/cerrar;
- copia de seguridad de un snapshot válido anterior;
- secuencias de ID y semilla de generación guardadas;
- versiones de esquema, reglas, escenario y generadores.

No se guardan todos los frames. Se guardan los cambios persistentes y hechos relevantes. La estructura física de almacenamiento puede cambiar si las pruebas muestran necesidad de SQLite u otra base local; los contratos lógicos y las garantías de recuperación no cambian.

## 23. Recuperación tras cierre inesperado

Proceso mínimo:

1. localizar el snapshot vigente;
2. validarlo y, si está corrupto, intentar el backup;
3. comprobar versión de esquema y aplicar solo migraciones explícitas;
4. cargar eventos posteriores al cursor del snapshot;
5. descartar eventos incompletos o inválidos de forma segura y dejar diagnóstico;
6. aplicar solo proyecciones de eventos con recuperación implementada;
7. aplicar idempotencia para evitar dobles consumos o transferencias;
8. restaurar `world_tick`, secuencias de IDs, seeds y tareas pendientes;
9. calcular catch-up desde el último checkpoint válido;
10. guardar un nuevo checkpoint tras completar la recuperación.

No se permite reescribir el historial para ajustarlo al nuevo código. Si una versión antigua no puede migrarse con seguridad, la aplicación debe conservar el archivo original, informar el problema y usar backup o procedimiento de reparación; no debe borrar silenciosamente un mundo del usuario.

## 24. Migraciones y compatibilidad hacia atrás

Cada cambio de esquema debe incluir:

- versión de origen y destino;
- transformación determinista o justificación de no determinismo;
- validación previa y posterior;
- estrategia de backup;
- tratamiento de campos desconocidos;
- impacto en eventos y snapshots;
- pruebas sobre copias de mundos reales o fixtures.

Un cambio de balance no debe exigir modificar identidad o historia, salvo que cambie explícitamente su semántica. Cambiar una regla de forma incompatible requiere nueva versión y nota de migración. No se alteran eventos pasados para hacer que parezca que siempre se utilizó la regla nueva.

# PARTE VIII — WORLD LABORATORY, OBSERVATORIO Y EXPERIMENTACIÓN

## 25. World Laboratory: ejecución sin jugador

El laboratorio debe poder inicializar y hacer avanzar un mundo sin jugador humano. La ausencia de jugador no puede impedir:

- necesidades, rutinas, trabajo y descanso;
- exploración y expediciones;
- movimiento, combate, huida, tratamiento y muerte;
- reproducción, alimentación, migración y cambios ecológicos;
- comercio, fabricación, reparación, custodia, deuda y escasez;
- relaciones, comunicación, aprendizaje, rivalidad y cooperación;
- investigación, hipótesis, descubrimientos y fracasos;
- misiones originadas por objetivos manuales o hechos emergentes;
- consecuencias y memoria histórica.

El laboratorio debe poder avanzar periodos prolongados (por ejemplo, 1, 7, 30 y 100 días simulados) y permitir inspeccionar resultados. La duración de cada test y sus criterios cuantitativos se registran; no se declara autonomía solo porque aparezca un evento aleatorio.

## 26. Observatory / God View

El Observatory es una vista de consulta sobre el mismo World Model y Chronicle. Por defecto es pasivo y no aparece en el mundo, no genera agentes, no altera probabilidades y no toma decisiones por ellos.

Funciones requeridas:

- mapa/escena navegable con regiones y entidades visibles;
- reloj del mundo, velocidad de simulación y estado de pausa;
- cronología filtrable por tiempo, evento, entidad, región, organización y severidad;
- apertura de un evento con actores, causas, consecuencias, estado previo/posterior y procedencia;
- acción para centrar cámara en la ubicación del evento, si existe;
- seguimiento de NPC, monstruos, expediciones, grupos u organizaciones;
- inspección de identidad, cuerpo, estado, capacidades, memoria/conocimiento autorizados, relaciones, objetivos, inventario e historial;
- separación visual entre estado objetivo y lo que el agente cree;
- métricas de población, muertes, nacimientos, expediciones, recursos, economía, conflictos, descubrimientos y errores.

La UI debe indicar cuándo un dato es desconocido, estimado, resumido, secreto o no reconstruible. No mostrará como hecho una inferencia del observador.

## 27. Replay, cronología y ramas experimentales

Cada reconstrucción histórica declara su fidelidad: exacta, detallada, resumida o no reconstruible. El sistema no presenta animaciones reconstruidas como grabación exacta si solo conserva eventos agregados.

Las ramas experimentales trabajan sobre copia/snapshot y deben tener namespace, seed, configuración y origen diferenciados. Una rama no modifica el canon ni las partidas oficiales a menos que exista una operación de promoción explícita, validada y auditada.

La intervención administrativa se encuentra desactivada en observación ordinaria. Si se habilita para pruebas, debe mostrar que se trata de intervención y registrar usuario, instante, motivo, estado anterior, cambio y rama afectada.

# PARTE IX — INTEGRACIÓN CON LOS SISTEMAS DEL UNIVERSO

## 28. Integración física, biológica y arcana

SR-15 no implementa una simulación universal de toda la física o química. Debe integrar modelos por dominio y escala, calibrados y suficientemente precisos para las interacciones relevantes del juego. La simplificación debe declararse; no puede producir arbitrariedad ni violar las consecuencias esenciales.

La primera implementación verificable debe priorizar, como mínimo:

1. espacio 3D y coordenadas coherentes;
2. distancia, movimiento, colisión y obstáculos básicos;
3. propiedades esenciales de masa, volumen y material cuando afecten al resultado;
4. daño e integridad corporal básicos;
5. fuentes y consumo de recursos;
6. contrato de operación arcana con fuente, coste, objetivo, alcance, duración, condiciones e interrupción.

No se introduce una tabla elemental universal. La Trama no tiene voluntad propia. Las operaciones arcanas dependen de las reglas, fuentes, Resonancias, capacidades y condiciones. La religión no concede poderes automáticos.

## 29. Integración con SR-08 y SR-09

El runtime biológico debe mantener anatomía, fisiología, nutrición, salud, enfermedad, reproducción, herencia y ecología. El combate se resuelve en tiempo real continuo y no se subordina al FPS de presentación. HP no reemplaza lesiones localizadas; curar HP no regenera por sí solo órganos ni extremidades.

Los eventos críticos —lesión, hemorragia, amputación, tratamiento, muerte, reanimación, resurrección extraordinaria o reencarnación— pasan por los dominios competentes y respetan SR-01, SR-03, SR-08 y SR-09. La animación de un ataque no confirma impacto; solo el resultado del dominio de combate lo hace.

## 30. Integración con economía, progresión y sociedad

El motor económico consulta inventarios, propiedad, financiación y disponibilidad reales. No crea dinero, materiales, tiendas infinitas ni recompensas. La progresión deriva de aprendizajes y experiencias válidas; no se otorgan estadísticas o habilidades solo por nivel, clase o guion. Las instituciones, leyes, cultura y reputación cambian por hechos y acuerdos confirmados.

Los contratos de misión, recompensas y pagos deben tener emisor, motivo, capacidad, fondos, objetivo, condiciones, vencimiento y consecuencias de acuerdo con SR-10, SR-13 y SR-14. El Narrative Engine no puede inventar un pagador ni declarar cumplido un objetivo sin evidencia.

## 31. Integración narrativa con SR-14

El motor narrativo organiza cinco capas: historia fundacional, escenario inicial, arco principal, crónica personal y narrativa emergente. La historia autoral puede establecer antecedentes, instituciones, misterios, personajes, tutoriales, misiones manuales y condiciones de campaña. No puede garantizar resultados causales.

Las misiones manuales definen contrato y condiciones; las misiones emergentes se originan en necesidades, eventos y consecuencias. Un NPC o monstruo puede actuar sobre un objetivo antes que el jugador. Un arco puede caducar, fracasar, cambiar de objetivo o resolverse sin el jugador.

La campaña inicial de referencia **El Eco de Vhaloren** y sus detalles fijos/variables se rigen por SR-14. SR-15 no debe inventar el destino de la expedición desaparecida, ubicación actual de los tres componentes, función exacta de Vhaloren, victoria del jugador o rescate completo. Los nombres de trabajo Nareth, Orrun y Khael continúan sujetos a la nomenclatura que SR-14 declara provisional.

# PARTE X — REPRESENTACIÓN Y CLIENTE ANDROID

## 32. Separación entre simulación y presentación

El núcleo puede avanzar sin cargar una escena 3D. La escena visual consulta el estado y emite comandos de usuario; no es la base de datos del mundo. Un individuo puede persistir sin modelo o animación disponible.

Los sistemas de animación, VFX, audio, UI, cámara, partículas y modelos interpretan resultados ya confirmados. La capa visual puede interpolar movimiento y presentar efectos, pero no determina si una flecha impactó, si un hechizo fue interrumpido, si una herida es letal o si un objeto cambió de dueño.

## 33. Plataforma técnica y baseline de implementación

### 33.1 Decisiones de producto

- Plataforma de destino inicial: Android.
- Primera app de laboratorio: completamente offline en la operación principal.
- Persistencia: local en el dispositivo.
- Presentación: escena 3D con cámara ortográfica inclinada para aspecto 2.5D isométrico.
- Representación: modelos 3D y assets preparados/validados; GLB/glTF es el formato preferente de intercambio si no hay incompatibilidad.
- Distribución fuente: repositorio y ZIP para facilitar trabajo y revisión.
- Compilación de prueba: GitHub Actions produce un APK Debug descargable como artefacto.
- La base de datos/servidor remoto no es obligatorio en la primera versión.

### 33.2 Motor y toolchain

La especificación técnica previa WLA-TECH-001 v0.1.0 fijó como baseline **Godot 4.7.2 Standard con GDScript**, renderizador Compatibility inicial y comparación posterior con Mobile en el dispositivo de referencia. SR-15 adopta ese baseline como punto de partida para continuidad del proyecto, sujeto a verificación de estabilidad y compatibilidad de plugins/exportación justo antes de cada entrega. No se autoriza migrar a Unity, Unreal u otro motor por preferencia de una IA sin una justificación comparativa y aprobación del autor.

La exportación Android debe fijar versiones compatibles de Godot, plantillas, JDK, Android SDK, Build Tools, NDK y CMake en el workflow. No se deben copiar versiones antiguas de herramientas sin verificarlas contra la versión de Godot usada. El APK de CI es de depuración; la firma de release debe usar un keystore privado fuera del repositorio, por ejemplo mediante secretos protegidos de CI.

### 33.3 World Lab frente a RPG jugable

- En el **World Laboratory**, no se requiere un jugador humano: los personajes denominados player-agents del escenario de prueba también son agentes autónomos para observar la simulación.
- En el **RPG final**, una persona controla un avatar/jugador que participa en el mismo mundo; los NPC, monstruos, facciones y procesos continúan siendo autónomos.
- No confundir un laboratorio sin jugador humano con una decisión de eliminar al jugador de la versión final.

### 33.4 Alcance de escena y recursos

El mundo se divide en regiones/sectores con identidad lógica estable. La presentación carga modelos y detalles próximos y libera o agrupa los demás; el núcleo conserva sus estados. Assets no deben generarse como geometría compleja en runtime móvil. La generación procedural de individuos y objetos debe partir de definiciones, parámetros y combinaciones validadas.

# PARTE XI — RENDIMIENTO Y ESCALABILIDAD

## 34. Escala grande sin simular cada cosa en cada frame

El objetivo de mundo es amplio y persistente. El desempeño se consigue con agendas de actualización, colas de tareas, resolución por relevancia causal, agregación temporal/ecológica, consultas indexadas, instanciación visual selectiva y niveles de detalle. No se fija un máximo definitivo de entidades antes de medir.

La prueba debe separar al menos:

- entidades lógicas existentes;
- agentes con evaluación cognitiva activa;
- eventos pendientes;
- entidades físicas cercanas en resolución fina;
- modelos 3D renderizados;
- población representada en forma agregada.

No se permite confundir «no renderizado» con «no simulado» ni «agregado» con «borrado». Los agregados deben preservar recursos, identidades singulares, eventos importantes, capacidad de reconstrucción declarada y causalidad relevante.

## 35. Métricas obligatorias

Registrar en benchmarks:

- tiempo de CPU por segundo/minuto/día simulado;
- decisiones de agente por segundo;
- comandos confirmados/rechazados por segundo;
- eventos generados y procesados;
- tamaño del event log y snapshots;
- duración del catch-up para intervalos definidos;
- RAM pico y promedio;
- almacenamiento y tamaño de partidas;
- tiempo de carga y recuperación;
- FPS de presentación, latencia de controles y stutter;
- consumo de batería y temperatura cuando se mida en dispositivo.

El dispositivo de referencia comunicado en el proyecto es un Xiaomi Note 12 con 6+6 GB de RAM. Debe utilizarse como perfil de prueba, no como límite arquitectónico del mundo ni como garantía de rendimiento. Los resultados en otros dispositivos deben registrarse por modelo y configuración.

# PARTE XII — PRUEBAS Y CRITERIOS DE ACEPTACIÓN

## 36. Test harness y reproducibilidad

Las simulaciones de prueba deben poder ejecutarse sin UI y con tiempo acelerado. Cada test conserva seed, versiones, escenario, comandos externos y configuración. Cuando el comportamiento sea determinista, misma seed, versiones y secuencia deben producir el mismo resultado. Cuando existan procesos deliberadamente probabilísticos o no deterministas, sus fuentes de azar y rangos deben registrarse para que la prueba pueda reproducirse o analizarse.

Los tests no se limitan a escenarios escritos para mostrar éxito. Deben incluir perturbaciones, ausencia de agentes, recursos agotados, rutas bloqueadas, información falsa, pérdida de módulos, cierre inesperado y eventos que no estaban previstos como casos narrativos.

## 37. Pruebas obligatorias de arquitectura y autonomía

1. **Sin jugador:** desactivar/remover al jugador humano y demostrar que el mundo continúa.
2. **Sin narrativa:** desactivar Narrative Engine y demostrar que rutinas, supervivencia, economía y ecología básicas siguen funcionando.
3. **Sin LLM:** desconectar todo proveedor generativo y demostrar operación de la ruta crítica.
4. **Información limitada:** dos agentes con experiencias y relaciones distintas reaccionan de manera distinta al mismo evento sin recibir conocimiento global.
5. **Capacidades reales:** retirar una capacidad o recurso y comprobar que acciones dependientes se rechazan.
6. **Causalidad:** cambiar una condición significativa produce un resultado causal diferente y trazable.
7. **No misión:** quitar una misión authored no detiene necesidades reales ni impide que otros agentes generen objetivos.
8. **Evento y procedencia:** un evento abre su tiempo, lugar, actores, causa, evidencia y resultado.
9. **Propiedad concurrente:** dos agentes intentan adquirir el mismo bien único; solo una operación concluye.
10. **Economía:** ausencia de stock, falta de fondos y escasez producen consecuencias sin crear bienes o dinero.
11. **Ecología:** migración, depredación, reproducción y pérdida de recursos afectan poblaciones conforme a SR-08.
12. **Aprendizaje:** agente solo aprende aquello que percibe, practica, investiga o recibe por canal válido.
13. **Combate:** daño localizado, hemorragia y tratamiento respetan anatomía y mecanismo, no solo HP.
14. **Arcana:** lanzamiento respeta fuente, coste, conocimiento, secuencia de Veyrath, duración e interrupciones.
15. **Narrativa:** misión manual puede fracasar, caducar o resolverse por un NPC sin resultado forzado.
16. **Catch-up:** cerrar sin pausar hace avanzar el mundo según política temporal; cerrar en pausa no acumula intervalo.
17. **Retroceso temporal:** hora del dispositivo hacia atrás no produce tiempo negativo y registra anomalía.
18. **Idempotencia:** repetir un comando no duplica consumo, pago, movimiento ni resultado.
19. **Recuperación:** cierre en mitad de operación restaura un estado válido o informa fallo sin corrupción silenciosa.
20. **Migración:** mundo de una versión anterior se migra mediante transformación explícita y testeada.
21. **Entidad sin asset:** individuo permanece lógico si su modelo falta o no carga.
22. **Replay:** se informa fidelidad real y no se inventa animación como registro exacto.
23. **Rama:** experimento no contamina canon o partida principal.
24. **Escala:** benchmarks separados a 100, 500 y 1.000 entidades lógicas, además de carga progresiva; no significan metas de población de producción.
25. **Prueba prolongada:** ejecutar escenarios de 1, 7, 30 y 100 días simulados con seguimiento de continuidad, errores y rendimiento.

## 38. Criterios de cierre de SR-15

SR-15 se considera implementada solo cuando:

- el núcleo coordina dominios mediante comandos tipados y validadores;
- las entidades conservan identidad estable y datos separados de assets;
- reloj, scheduler y catch-up operan sin depender del render;
- agentes autónomos completan ciclos de percepción, decisión, acción y memoria;
- las reglas críticas funcionan sin LLM ni red;
- eventos y trazas permiten explicar causas y consecuencias;
- persistencia y recuperación superan pruebas de cierre inesperado;
- Observatory observa el mismo estado del mundo y no usa un simulador paralelo;
- benchmarks Android demuestran una carga objetivo aceptable y reproducible;
- las pruebas de regresión de SR-01 a SR-14 continúan pasando.

Un scaffold que exporta un APK, muestra proxies 3D o mueve entidades no satisface por sí solo estos criterios.

# PARTE XIII — HITOS DE IMPLEMENTACIÓN

## 39. Secuencia de trabajo recomendada

Los hitos siguientes ordenan la implementación. No son nuevas fases normativas ni autorizan ampliar el alcance más allá de las fases 0–5.

| Hito | Entrega verificable | No se considera terminado hasta |
|---|---|---|
| WLA-0A | Proyecto Android abre, ejecuta y exporta APK Debug | CI repetible, instalación y arranque en dispositivo |
| WLA-0B | Kernel, reloj, comandos, eventos, snapshots y recuperación mínima | Idempotencia, cierres abruptos, migraciones y pruebas locales |
| WLA-1A | Perfil de agente, percepción, motivaciones, objetivos, memoria y Decision Trace | Agentes toman decisiones distintas por causa y conocimiento |
| WLA-1B | Scheduler multiescala y catch-up | 1/7/30/100 días simulados, sin saltos causales silenciosos |
| WLA-2A | Región de observación 2.5D, entidades y mapa | Observatorio consulta la misma realidad del Kernel |
| WLA-2B | Necesidades, economía, ecología, expediciones y narrativas | Simulación sin jugador produce eventos auditables sin guion obligatorio |
| WLA-3 | Pruebas prolongadas, replay, ramas y regresión | Métricas, recuperación y autonomía verificadas |
| RPG-1 | Incorporación del avatar humano al mundo ya validado | Controles, UI, combate e integración no duplican el núcleo |
| RPG-2 | Contenido inicial de ciudad y pisos 1–5 | Los catálogos cumplen SR-08 a SR-14 y su generación está validada |

**Regla de alcance:** la visión de largo plazo contempla una Mazmorra extensa (referencia de 100 pisos). La primera gran versión de contenido acordada por el usuario se dirige a pisos 1–5. La validación técnica debe comenzar con un escenario pequeño (por ejemplo, ciudad esquemática y un piso representativo) y ampliarse progresivamente; ello es una secuencia de implementación, no una reducción de la meta aprobada.

## 40. Orden de prioridad inmediato

1. Consolidar y verificar el repositorio técnico de Godot y el pipeline Android.
2. Completar WLA-0A y WLA-0B con pruebas automatizadas.
3. Implementar contratos de identidad, evento, comando, causalidad y persistencia.
4. Implementar agentes de prueba no dependientes de LLM.
5. Ejecutar simulaciones aceleradas y auditar causalidad.
6. Implementar Observatory/God View.
7. Añadir gradualmente ciudad, economía, ecología, Mazmorra y contenido.
8. Incorporar el avatar/jugador humano después de validar el mundo sin jugador.

# PARTE XIV — RESTRICCIONES, RIESGOS Y CONTROL DE CAMBIOS

## 41. Restricciones duras

La implementación NO DEBE:

- programar individualmente cada historia, muerte, victoria o reacción para aparentar autonomía;
- depender de que el jugador esté presente para simular rutinas y procesos principales;
- crear un segundo mundo simplificado solo para el God View;
- permitir a LLMs o UI escribir estados sin validación de dominio;
- exigir una API pagada para cada acción cotidiana;
- afirmar que una instalación offline individual constituye un universo compartido global;
- convertir inteligencia en una cifra única o un guion rígido universal;
- tratar nivel/clase como paquetes automáticos de poderes;
- conceder bendiciones por religión o inventar dioses activos;
- generar inventarios, recompensas, dinero, monstruos o materiales sin procedencia;
- crear geometría compleja en runtime Android sin validación;
- convertir modelos, animaciones o VFX en autoridad de la realidad;
- eliminar o reescribir silenciosamente partidas, eventos o memoria histórica;
- ampliar a fases, sistemas o plataformas no autorizadas por conveniencia.

## 42. Riesgos reconocidos

1. **Escala móvil:** el número máximo de entidades y detalle depende de benchmarks.
2. **Catch-up local:** la hora del dispositivo puede manipularse; no existe autoridad inviolable offline después de reinicio.
3. **Autonomía real:** debe demostrarse con pruebas, no se deduce de tener un sistema de agentes.
4. **Física y Arcana:** SR-07 exige modelos que se desarrollarán por capas, no una simulación universal perfecta.
5. **Datos de largo plazo:** diarios y snapshots crecerán; compacción/almacenamiento embebido pueden requerirse.
6. **Replay:** parte de la historia antigua puede ser resumida; la fidelidad debe declararse.
7. **Generación procedural:** debe validarse por anatomía, materiales, navegación y coherencia lógica.
8. **Complejidad del proyecto:** mantener un único desarrollador requiere entregas pequeñas, automatización y prioridades.

## 43. Política de compatibilidad y cambios

- SR-15 no autoriza cambiar SR-01 a SR-14.
- Las decisiones de usuario aprobadas no se cambian silenciosamente.
- Un cambio de implementación se registra con motivo, alcance, documentos afectados, contratos, datos guardados y pruebas de regresión.
- Una mejora técnica interna puede cambiar algoritmo o almacenamiento si mantiene contratos, semántica y compatibilidad.
- Un cambio de reglas del universo requiere enmienda normativa, versión, impacto y aprobación del autor.
- Si una IA detecta contradicción, debe documentar las cláusulas exactas y proponer opciones; no elegir arbitrariamente una reinterpretación.
- Una función no implementada se marca como pendiente/no verificada; nunca se presenta como completada.

## 44. Declaración final

El Sistema Rector no existe para escribir de antemano lo que cada habitante hará. Existe para conservar las leyes, estados, capacidades, límites, causas, decisiones y consecuencias que permiten que los habitantes produzcan un mundo coherente. El World Laboratory debe demostrar esa autonomía antes de que el juego dependa de ella. El cliente Android será una forma de observar y participar en esa realidad, no la autoridad que la inventa.

**Cierre del bloque SR-15-B: 44 secciones complementarias preservadas como especificación técnica subordinada.**

# REFERENCIA DE CONTINUIDAD COMPLEMENTARIA — FUENTE DEL SEGUNDO PAQUETE

**Clasificación:** referencia explicativa complementaria; no es una normativa ni sustituye la Guía Maestra actual o los SR individuales.  
**Procedencia:** `DOCUMENTO_MAESTRO_DE_CONTINUIDAD.md` del paquete `World_Laboratory_SR01_SR15_Paquete_Oficial_2026-11-20.zip`.  
**Uso:** conservar detalles descriptivos adicionales que pueden ayudar a interpretar la visión y el alcance del proyecto.  
**Regla de autoridad:** cuando esta referencia mencione estados/versiones anteriores, especialmente SR-15 v0.1, prevalecen los documentos normativos individuales y el registro actualizado de este paquete. Para SR-15 se utiliza el bloque principal v1.0 de 88 secciones y, después, el complemento B de 44 secciones. No resolver contradicciones mediante inferencias.

---

# WORLD LABORATORY / SISTEMA REACTOR
# DOCUMENTO MAESTRO DE CONTINUIDAD Y DIRECCIÓN DEL PROYECTO

**Versión:** 1.0 — paquete oficial SR-01 a SR-15  
**Fecha de corte:** 20 de noviembre de 2026  
**Idioma de trabajo y documentación:** español  
**Propósito:** preservar la visión, todas las decisiones, la jerarquía normativa, los límites, la arquitectura, el alcance, el estado real y las instrucciones de colaboración para que cualquier IA, desarrollador o colaborador pueda continuar el proyecto sin reinterpretarlo, reducirlo ni inventar contenido.

> **IMPORTANTE:** este documento NO sustituye ni resume los quince SR. Es la guía de continuidad que los conecta, explica la intención global, establece cómo leerlos y evita que sus detalles se pierdan al transferir el proyecto. Las normas oficiales completas están en `01_NORMATIVAS_OFICIALES/`. Deben consultarse en su totalidad cuando una tarea afecte su dominio.

---

# 0. MANDATO PARA CUALQUIER IA QUE RECIBA ESTE PAQUETE

## 0.1 Orden de lectura obligatorio

1. Lee este documento completo.
2. Lee `02_REGISTRO_Y_CONTROL/REGISTRO_OFICIAL_SR01_SR15.md` para conocer versiones, aprobaciones y estados.
3. Lee el README del paquete.
4. Lee los quince documentos normativos completos, SR-01 a SR-15, en orden. Lee también el Anexo A de SR-09 — Veyrath, que forma parte del paquete normativo de combate y magia.
5. Antes de cambiar o programar algo, consulta los SR del dominio y sus dependencias.
6. Revisa los archivos técnicos existentes que el usuario comparta en la conversación actual antes de afirmar que el proyecto se encuentra en un estado determinado.

No basta con leer un resumen, el README, las primeras páginas de cada documento o la norma más reciente. Los detalles de cada dominio son obligatorios para comprender el proyecto.

## 0.2 Instrucciones de conducta

- Trabaja en español salvo solicitud expresa en otro idioma.
- Sé honesto, técnico, crítico y proactivo. No asientas por cortesía; evalúa la viabilidad y señala riesgos.
- No disminuyas la ambición del proyecto para hacerlo parecer fácil. Divide el trabajo en etapas sin cambiar la visión final.
- El usuario es un desarrollador individual y está aprendiendo desarrollo de videojuegos. Explica decisiones técnicas con claridad, sin asumir experiencia avanzada ni tratarlo con condescendencia.
- Evita preguntas repetidas. La información ya aprobada está en los SR y en esta guía. Pregunta solo ante un bloqueo real que no pueda resolverse con una recomendación explícita y reversible.
- No escribas código antes de comprender la arquitectura, los contratos, el alcance y las pruebas de aceptación de la tarea.
- Propón mejoras concretas y di si son recomendación, supuesto técnico, calibración o decisión que requiere aprobación.
- No declares algo «hecho», «funcional», «autónomo», «optimizado», «seguro» o «probado» sin evidencia verificable.
- No inventes resultados de pruebas, builds, cifras, versiones instaladas, funcionamiento de IA, contenido aprobado ni características del repositorio.
- Cuando entregues código, incluye cambios, archivos afectados, dependencias, comandos de compilación/prueba, resultados reales, limitaciones y pasos de rollback cuando proceda.
- Conserva los documentos fuente, versiones, hashes, CHANGELOG y registro de decisiones. Nunca sobrescribas la única copia de un documento o partida.

## 0.3 Prohibición de desviación e invención

Ninguna IA puede añadir por su cuenta una nueva ley, clase de entidad, mecanismo mágico, dios activo, sistema de resurrección, jefe obligatorio, personaje protegido, mapa canónico, moneda, recurso, fórmula, atributo, piso, final narrativo o función de producto y tratarlo como aprobado.

Una IA puede presentar una recomendación o un experimento, pero debe etiquetarlo expresamente y mantenerlo fuera del canon hasta aprobación. No puede disfrazar contenido manual como emergente, ni presentar una hipótesis, rumor, ejemplo, placeholder o parámetro de prueba como hecho aprobado.

Si detecta ambigüedad o contradicción:

1. cita los dos documentos y apartados exactos;
2. explica qué comportamiento o decisión queda en conflicto;
3. identifica qué autoridad tiene cada norma;
4. propone una solución compatible y sus consecuencias;
5. no modifica el canon hasta la aprobación del autor cuando la solución afecte una decisión aprobada.

No uses fuentes externas, opiniones de otras IA o patrones de juegos conocidos para reemplazar el canon del proyecto. Pueden servir como investigación técnica o inspiración comparativa, nunca como autoridad sobre el universo.

---

# 1. IDENTIDAD DEL PROYECTO

## 1.1 Nombre de trabajo

**World Laboratory / Sistema Reactor** es el nombre de trabajo del proyecto técnico y de su arquitectura de simulación. El producto final es un RPG Android construido sobre un universo autónomo y persistente. «World Laboratory» no significa que el objetivo sea solo un simulador de escritorio; es la primera fase de validación del mundo antes de incorporar al jugador humano.

## 1.2 Visión del producto final

Construir un RPG de mundo abierto para Android, con presentación 2.5D isométrica mediante escena 3D, estética anime estilizada y combate en tiempo real. El mundo debe existir antes, durante y después de la presencia del jugador. Sus habitantes deben poder percibir, recordar, aprender, planificar, investigar, formar relaciones, trabajar, producir, comerciar, viajar, luchar, huir, morir, reproducirse, evolucionar, crear organizaciones y transformar su entorno.

La diferencia fundamental con un RPG tradicional de NPC guionizados no es que haya más líneas de diálogo, sino que las entidades operan dentro de un mundo con estados, recursos, capacidades, necesidades, información limitada, motivaciones, memoria, reglas y consecuencias. Las historias deben resultar de ese funcionamiento, aunque pueda existir una historia fundacional escrita por los autores.

El producto no debe convertirse en una sucesión de escenas guionizadas que esperan a que el usuario active botones. La historia ofrece dirección; la simulación decide lo que realmente ocurre.

## 1.3 Inspiraciones y originalidad

DanMachi sirve como referencia parcial para la idea de aventureros, gremio, mazmorra, progresión y diferencias importantes de poder. Sword Art Online / Aincrad sirve como referencia parcial para la idea de un mundo sistémico con pisos y continuidad. Estas referencias no son canon ni autorizan copiar personajes, nombres, diseños, mapas, mecánicas protegidas, diálogos, escenas o propiedad intelectual.

El mundo, cosmología, nombres, entidades, historia, reglas, hechizos, instituciones, apariencia y experiencia deben desarrollarse con identidad original. La guía de nomenclatura y las normas aprobadas prevalecen sobre una referencia externa.

---

# 2. PRODUCTOS Y MODOS: NO CONFUNDIRLOS

## 2.1 World Laboratory / God Simulator

El primer gran producto de validación ejecuta el mundo sin jugador humano. NPC, monstruos, facciones, fauna, flora, recursos, expediciones e instituciones actúan por sí mismos. El usuario observa la realidad mediante un Observatory/God View pasivo que permite inspeccionar cronología, personajes, acontecimientos, lugares, decisiones y consecuencias.

El World Laboratory debe avanzar durante periodos simulados prolongados. El objetivo es descubrir si las reglas producen una realidad coherente, no mostrar una demo preparada para el usuario.

## 2.2 RPG Android

El RPG posterior incorpora al jugador humano como participante controlado por una persona. El jugador no se convierte en el centro del universo ni en un elegido por defecto. Los demás agentes, instituciones, monstruos y procesos siguen funcionando mientras juega.

El núcleo del mundo, autoridad, causalidad, identidad, eventos y persistencia se comparte conceptualmente con el World Laboratory. No se crea un mundo nuevo con reglas distintas para el juego.

## 2.3 Instancia individual offline y mundo compartido

La primera experiencia aprobada puede ser individual, local y completamente offline. El dispositivo instalado es autoridad de su propio mundo. Guardado, catch-up, progreso e historia son locales.

Un mundo compartido entre varios dispositivos o usuarios es otro problema: necesita una autoridad común, sincronización y reconciliación de conflictos. No debe prometerse multijugador global, PvP sincronizado o canon común entre dispositivos desconectados sin diseñar esa infraestructura y recibir autorización. No es requisito de la primera versión offline.

---

# 3. PLATAFORMA, ARTE Y FORMA DE EJECUCIÓN

## 3.1 Plataforma y dispositivo de referencia

La plataforma objetivo es Android. El dispositivo comunicado como referencia de prueba es un Xiaomi Note 12 con 6+6 GB de RAM. Es un perfil de benchmark, no el límite de la arquitectura ni una garantía de rendimiento.

El código fuente se mantiene en repositorio GitHub y puede compartirse mediante ZIP. La compilación Android de depuración debe poder automatizarse mediante GitHub Actions, produciendo un APK Debug como artefacto descargable. Las credenciales de firma Release no deben incluirse en ZIP ni en el repositorio; se guardan en secretos protegidos cuando proceda.

## 3.2 Motor técnico de continuidad

La especificación WLA-TECH-001 v0.1.0 anterior a SR-15 fijó Godot 4.7.2 Standard, GDScript y renderizador Compatibility como baseline. SR-15 lo adopta para la continuidad inicial, sujeto a verificación técnica al comenzar cada implementación. Una IA no puede migrar a Unity, Unreal u otro motor por preferencia personal. Una propuesta de cambio exige comparación técnica, coste, impacto en código y datos, ventajas demostrables y autorización del autor.

## 3.3 Cámara y representación

La visualización buscada es 2.5D isométrica realizada con escena 3D. La altura, profundidad, colisiones, distancia, movimiento, anatomía y geometría deben permanecer coherentes aunque la cámara presente una composición estilizada.

Los modelos 3D representan entidades lógicas; no son la entidad. Un individuo debe conservar su identidad si su asset no carga. Animaciones y VFX ilustran eventos confirmados; no determinan por sí solos el daño ni el resultado físico o arcano.

El formato de intercambio preferente para modelos es GLB/glTF siempre que el asset sea válido y compatible. Rigging, animaciones, materiales, LOD y colisiones deben validarse. No se generará geometría compleja de forma ilimitada dentro del teléfono durante la partida; los assets de runtime deben prepararse, probarse y empaquetarse.

---

# 4. ESCALA Y ALCANCE DEL UNIVERSO

## 4.1 Escala de largo plazo

La visión de largo plazo contempla un reino y una Mazmorra extensos. La Mazmorra tiene una aspiración de aproximadamente 100 pisos como escala global deseada, pero no es una obligación de construir los cien pisos en la primera versión. El mundo puede crecer en regiones, asentamientos, biomas, pisos, rutas y culturas a medida que las herramientas lo permitan.

## 4.2 Alcance de la primera versión de contenido

La primera versión de contenido acordada por el usuario cubre la ciudad inicial y los pisos 1–5 de la Mazmorra. La arquitectura técnica se valida primero con un vertical slice reducido: una región, agentes de prueba, sistemas básicos y un piso representativo. Después se incorporan los demás pisos 1–5 mediante los mismos contratos y herramientas.

Esta secuencia de implementación no cambia el alcance de contenido acordado. Tampoco obliga a diseñar desde el principio los cien pisos finales.

## 4.3 Fases 0–5

El proyecto se mantiene dentro de las fases acordadas:

- **Fase 0 — Arquitectura y constitución:** leyes, identidad, causalidad, autoridad, contratos y persistencia.
- **Fase 1 — Laboratorio y dirección técnica/artística:** prototipo de simulación, pruebas de inteligencia, biblioteca de assets y pruebas Android.
- **Fase 2 — Ciudad principal:** construcción, NPC, rutinas, memoria, gremios/facciones, economía y relaciones.
- **Fase 3 — Mazmorra inicial:** pisos, biomas, especies, ecología, combate, monstruos inteligentes, territorios y recursos.
- **Fase 4 — Sistema Rector operativo:** inteligencia híbrida, memoria, aprendizaje, evolución, reencarnación, causalidad, historias emergentes y mundo híbrido.
- **Fase 5 — Creation Engine y economía avanzada:** materiales, fabricación experimental, armas, criaturas, apariencias procedurales, habilidades, genealogía y comercio.

No expandir a nuevas fases, servicios online obligatorios o plataformas adicionales sin decisión expresa del autor.

---

# 5. LEYES FUNDAMENTALES QUE NO SE PUEDEN OLVIDAR

Los siguientes puntos son recordatorios de integración. La redacción completa y autoritativa está en el SR citado; este apartado no los reduce ni los sustituye.

## 5.1 Realidad, causalidad y continuidad — SR-01 / SR-04

Existe una realidad objetiva compartida. Los hechos tienen causas y consecuencias. Los agentes pueden ignorar hechos objetivos, equivocarse o creer cosas falsas. Canon global, crónica personal e instancia/sesión son capas relacionadas de una misma realidad; no mundos contradictorios.

El mundo continúa sin jugador. Tiempo, eventos, procesos y consecuencias persisten. La reencarnación aprobada es mixta: puede conservar elementos variables de identidad, recuerdos, predisposiciones o capacidades bajo condiciones, pero no garantiza continuidad total ni transfiere automáticamente el cuerpo anterior.

La muerte es condicionalmente reversible solo mediante mecanismos extraordinarios y con consecuencias. No existe respawn ordinario gratuito y universal. La distinción entre reanimación, resurrección y reencarnación es obligatoria.

## 5.2 Autoridad de los dominios — SR-02

El Sistema Rector no es una única IA que decide todo. Es una arquitectura de motores especializados. Los agentes solicitan acciones; los dominios competentes validan y resuelven; eventos confirmados registran resultados. El Narrative Engine no puede escribir la realidad por encima del dominio físico, biológico, económico, social o arcano.

## 5.3 Identidad, inteligencia y memoria — SR-03

La inteligencia no se reduce a dos estadísticas ni es idéntica en todas las especies. Percepción, atención, memoria, razonamiento, planificación, aprendizaje, creatividad y comunicación pueden variar. Los agentes tienen conocimientos y creencias con procedencia; no son omniscientes. La memoria no es lo mismo que la realidad objetiva.

## 5.4 Mundo híbrido — SR-04

El mundo puede tener canon global persistente y experiencias personales distintas. Las crónicas personales recuerdan hechos y perspectivas de cada personaje sin crear duplicados contradictorios del mismo acontecimiento global. La visibilidad de un hecho no equivale a su existencia.

## 5.5 Creation Engine — SR-05

Definición, plantilla, individuo, variante y representación son entidades distintas. Individuos pueden compartir plantillas sin compartir identidad. Objetos y materiales conservan propiedades, procedencia y genealogía. Un asset gráfico no crea entidad lógica ni capacidad.

## 5.6 World Laboratory — SR-06

La simulación debe funcionar sin jugador humano. El observatorio ve el estado real del mismo kernel y es pasivo por defecto. El replay declara su fidelidad. Las ramas experimentales no contaminan el canon. El catch-up y las resoluciones de detalle deben preservar causalidad.

## 5.7 Leyes naturales y Arcana — SR-07 / SR-13

Física y Arcana coexisten bajo leyes, condiciones, fuentes, costes, límites y consecuencias. La magia no es licencia para ignorar las reglas del mundo. La Trama carece de voluntad propia. La Arcana es un término civilizatorio para fenómenos, conocimiento y aplicaciones relacionados con Trama, flujo y Resonancias; no es una deidad ni un ser que responda a plegarias.

La existencia y naturaleza última de dioses permanece sin resolver. Los habitantes pueden tener religiones, cultos, iglesias, filosofías o ateísmo, pero la fe por sí sola no concede poderes o bendiciones automáticas.

## 5.8 Biología y ecología — SR-08

Los seres vivos y monstruos deben tener anatomía, fisiología, necesidades, salud, alimentación, reproducción, herencia y respuestas ecológicas según su naturaleza. Los monstruos no son simples plantillas de combate. Pueden aprender, migrar, reproducirse, adquirir rasgos y evolucionar si existen mecanismos y circunstancias.

## 5.9 Combate y magia — SR-09 + Anexo A

El combate es continuo y en tiempo real, no por turnos obligatorios. HP y estados anatómicos son dimensiones distintas. Lesiones, hemorragias, pérdida de extremidades, recuperación y muerte son reales conforme a SR-01, SR-08 y SR-09. El modo Hardcore es la referencia canónica: no hay respawn ordinario. Cualquier perfil alternativo debe ser separado y no alterar mundos Hardcore.

Guerreros, magos y sanadores tienen funciones con ventajas y costes. La magia no debe ser instantánea ni sustituir universalmente la reacción física. Los hechizos se formulan en Veyrath con palabras completas ordenadas como oraciones, no como sílabas breves. Las palabras se aprenden por separado y dominar un hechizo requiere comprender/practicar la frase completa. El autocompletado no elimina tiempo, coste ni posibilidad de interrupción.

## 5.10 Economía y propiedad — SR-10

Dinero, bienes, materiales, stock, propiedad, custodia, deuda y recompensas tienen origen y registro. Comerciantes pueden quedarse sin stock; los precios dependen del contexto. La Mazmorra se recompensa principalmente mediante cristales y materiales obtenidos de monstruos; no usar cofres/cajas rompibles como fuente arbitraria de riqueza.

## 5.11 Geografía — SR-11

El reino inicial contempla una ciudad principal, muralla, bosque fronterizo y una torre monumental como acceso a una Mazmorra con volumen interior extraordinario. La región es amplia y conectada. La ciudad y el espacio subterráneo deben tener identidad propia. Los pisos 1–5 comparten un carácter inicial de mina/ruinas subterráneas, pero no deben ser copias idénticas. El piso 1 debe diferenciar más de doce tipos de salas, según el documento normativo. Cada sala, ruta y zona se conserva como espacio navegable con conexiones reales.

La zona segura es limitada y normalmente protegida; no significa invulnerabilidad absoluta. Un monstruo puede entrar si una causa válida lo lleva allí.

## 5.12 Progresión — SR-12

Progresión multidimensional: atributos, estado, conocimiento, habilidad, maestría, experiencia, nivel, clase y evolución son dimensiones distintas. Subir de nivel no regala automáticamente atributos, hechizos, equipo o habilidades. NPC y monstruos progresan por experiencias reales; no escalan artificialmente para igualar al jugador. Las clases son abiertas, no excluyentes y no garantizan poderes.

## 5.13 Sociedad — SR-13

Sociedades, leyes, culturas, familias, instituciones, profesiones, religiones y organizaciones son plurales y autónomas. Las relaciones son personales y pueden cambiar. Las instituciones tienen recursos, motivos, autoridad y límites. La Arcana puede influir en infraestructura, medicina, educación, economía, política y cultura, pero sus aplicaciones requieren fuentes, dispositivos, materiales, costes y mantenimiento.

## 5.14 Narrativa — SR-14

La historia fundacional puede ser escrita; los resultados son abiertos. El jugador llega a un mundo con historia, motivos, objetivos, instituciones y conflictos, no a un escenario vacío. Las misiones manuales son permitidas para tutoriales y arcos. Los eventos emergentes nacen de hechos reales. El jugador no es elegido por defecto ni tiene garantizada la victoria o la supervivencia de NPC.

---

# 6. MUNDO Y PREMISA NARRATIVA INICIAL

## 6.1 Campaña de inicio: El Eco de Vhaloren

La campaña inicial de referencia aprobada en SR-14 es **El Eco de Vhaloren**. Un instrumento de observación arcana de la ciudad registra tres pulsos procedentes de una cámara antigua del quinto piso. La señal es un hecho dentro del escenario, pero su interpretación no está resuelta. Una expedición anterior desapareció tras investigar ruinas y estructuras relacionadas. Sus registros parciales mencionan una estructura o mecanismo denominado provisionalmente Vhaloren y tres componentes de alineación: Nareth, Orrun y Khael.

El gremio, investigadores arcanos, autoridades, comerciantes y otros grupos reaccionan desde sus propios intereses. El jugador puede aceptar la investigación, pero no es el único agente que puede actuar sobre el objetivo. Otros exploradores pueden localizar componentes, descubrir evidencia, fracasar, morir, cambiar de objetivo o resolver una etapa antes del jugador.

## 6.2 Fijos y variables

Como hechos iniciales de la campaña se conservan la señal, los tres pulsos registrados, las ruinas/mecanismo Vhaloren y la existencia histórica de una expedición desaparecida. Se mantienen abiertos: la función exacta de Vhaloren, supervivencia y destino de la expedición, localización y posesión de los componentes, monstruo excepcional, desenlace, rescate y consecuencias institucionales.

No revelar ni fijar ahora el origen último de la Mazmorra, el creador de Vhaloren, si existe una conciencia, el origen de las ruinas, la verdad final sobre dioses o contenidos de pisos posteriores. No inventar un jefe invulnerable como requisito del final.

## 6.3 Motivación y origen del personaje

El jugador no comienza como elegido. Puede empezar con biografías y motivaciones diversas: aprendizaje, oficio, guardia, asistencia médica, minería, investigación, deuda, apoyo a familiares, promesa, protección, búsqueda de alguien, prestigio, curiosidad o ambición. Las habilidades iniciales deben tener procedencia en entrenamiento, trabajo, educación, maestro, experiencia o práctica. Seleccionar una motivación no concede clase ni poder.

## 6.4 Tutorial

Un tutorial puede ser manual y diseñado para enseñar controles, inventario, equipo, desplazamiento, práctica, combate, magia básica, observación, retirada, primeros auxilios, entrega de evidencia y recompensa. Debe estar integrado en el mundo mediante instructor, compañero, gremio u otra fuente plausible. Puede ser obligatorio, guiado, abreviado o saltarse. Saltarlo no concede habilidades que el personaje no haya adquirido.

---

# 7. INTELIGENCIA, INDIVIDUALIDAD Y VIDA AUTÓNOMA

## 7.1 No son actores esperando al jugador

Los NPC tienen identidad, necesidades, horarios/planes, relaciones, compromisos, intereses, conocimiento limitado, memoria, riesgos y metas. Algunos pueden ser sencillos; otros más complejos. No se impone una psicología humana a animales o monstruos, y no todas las entidades requieren un LLM.

## 7.2 Ejemplos de comportamiento esperado (no eventos obligatorios)

- Un aventurero puede recordar a un compañero perdido y buscarlo por afecto, deuda, culpa o deber.
- Otro puede negarse a arriesgar su vida, denunciar una expedición, esconderse, vender información o aceptar una recompensa.
- Un monstruo puede aprender a evitar armas observadas, migrar por escasez, robar objetos, ocultar materiales o explotar un territorio si su cognición y capacidades se lo permiten.
- Un depredador que desaparece puede modificar una red ecológica; una migración puede crear nuevos encuentros.
- Un investigador puede formular una hipótesis, gastar recursos, fracasar y cambiar de método.
- Un comerciante puede subir precios, cerrar, quebrar o cambiar de ubicación si las condiciones lo justifican.
- Un acontecimiento extraño puede dar lugar a miedo, compasión, rumor, investigación, protección, explotación o indiferencia según los agentes implicados.

Estos son ejemplos para evaluar la generalidad de los mecanismos, no escenas que deban aparecer forzosamente en cada partida.

## 7.3 Memoria y conocimiento

Cada agente recuerda lo que percibió, experimentó, investigó o recibió por un canal válido. Puede olvidar, tergiversar, malinterpretar o conservar recuerdos parciales. La memoria no vuelve verdadero un rumor. Un NPC no conoce los objetivos secretos del jugador ni la campaña completa automáticamente.

## 7.4 Investigación y descubrimiento

Agentes con recursos, motivación, método y capacidades pueden investigar. La investigación consume tiempo, materiales, información, instalaciones y esfuerzo. Puede fracasar. Los descubrimientos se basan en evidencia y procedencia; no son revelaciones del LLM que pasan a ser canon por escribirlas.

---

# 8. CONTENIDO, PROCEDURALIDAD Y AUTORÍA

## 8.1 Qué se diseña manualmente

Se permite crear mapas, plantillas, anatomías base, especies iniciales, materiales, catálogos, instituciones, nombres, historia, tutoriales, personajes iniciales, misiones especiales y arcos de campaña. Ese contenido es authored y debe etiquetarse como tal.

## 8.2 Qué debe surgir de la simulación

Se esperan resultados emergentes para expediciones, combates, muertes, victorias, huidas, relaciones, matrimonios, nacimientos, robos, comercio, crisis, aprendizaje, evolución, descubrimientos, conflictos, cultos, migraciones y desenlaces. El motor implementa mecanismos generales; no escribe cada historia concreta.

## 8.3 Proceduralidad con validación

Los individuos, materiales, armas y objetos pueden surgir de combinaciones y variaciones, pero no todo resultado aleatorio es válido. Debe pasar validación de anatomía, fisiología, materiales, masa, estructura, navegación, capacidades y procedencia. Una apariencia no concede capacidades. Una criatura con alas no puede volar solo porque tenga alas visuales; requiere anatomía y capacidad funcional según sus reglas.

## 8.4 Catálogos subordinados

Las normas establecen el marco. Los catálogos de especies, monstruos, animales, plantas, habitaciones, NPC, armas, armaduras, objetos, materiales, profesiones, hechizos, estructuras y localizaciones se elaboran como contenido versionado subordinado. Deben respetar el SR correspondiente y marcar cada dato como oficial, calibración, placeholder o pendiente.

---

# 9. ARQUITECTURA DEL SOFTWARE: CÓMO DEBE PENSARSE

## 9.1 El mundo es el núcleo; la cámara es un cliente

La simulación no puede depender de que una escena esté cargada. Los agentes, recursos, estados, eventos y relojes existen en el modelo lógico. El cliente Android consulta regiones y presenta entidades próximas. El Observatory consulta la misma realidad. No hay una simulación de juego y otra simulación para el observador.

## 9.2 Autoridad y comandos

El agente emite intención y comando, no mutación arbitraria. El dominio valida capacidades, estado, recursos, permisos y precondiciones. El sistema confirma evento. Los IDs de comando son idempotentes. Las operaciones que compiten por recursos únicos se serializan o usan transacciones.

## 9.3 Scheduler

El mundo no actualiza cada individuo a cada frame. El Scheduler agenda y prioriza tareas. Combate y movimiento de proximidad pueden requerir resolución fina; actividades tienen evaluaciones programadas; poblaciones y ecología pueden usar procesos agregados; historia y sociedades pueden avanzar por procesos de largo plazo. Los cambios de detalle no borran identidad ni causalidad.

## 9.4 Persistencia

La instancia offline conserva snapshots y diario de eventos. Al abrir, valida el último snapshot, restaura eventos posteriores de forma idempotente, calcula catch-up y genera nuevo checkpoint. Si hay corrupción debe usar backup, registrar diagnóstico y evitar pérdida silenciosa. Las migraciones de partida son explícitas.

## 9.5 Observatorio

El Observatory es pasivo por defecto. Permite ver hora, región, población, eventos, entidades y trazas. Debe poder seleccionar un evento y localizar su tiempo y lugar. Replay declara fidelidad. Las ramas experimentales no contaminan partidas oficiales.

---

# 10. RUTA TÉCNICA Y CRITERIOS DE HECHO

## 10.1 Orden obligatorio recomendado

1. Verificar el estado del proyecto Godot y workflow Android actual; no asumir que un ZIP anterior corresponde al último repositorio.
2. Completar WLA-0A: abrir, ejecutar, exportar e instalar APK Debug con CI repetible.
3. Completar WLA-0B: kernel, reloj, entidades, comandos, eventos, snapshot, backup, recuperación e idempotencia.
4. Construir agentes simples offline con necesidades, percepción, objetivos, planificación y memoria.
5. Añadir Scheduler y catch-up. Ejecutar días simulados sin UI y sin jugador.
6. Crear Chronicle y Observatory mínimo para inspeccionar causalidad.
7. Añadir movimiento, navegación y espacio representativo.
8. Añadir economía, biología, ecología, sociedad, combate y Arcana por capas.
9. Añadir ciudad y pisos 1–5 como contenido validado.
10. Incorporar jugador humano y controles del RPG una vez validado el mundo sin jugador.

## 10.2 No declarar terminado por una demo

Un APK que abre no demuestra que el mundo simule. Un personaje que camina no demuestra autonomía. Un combate animado no demuestra daño causal. Un NPC que cambia una línea de diálogo no demuestra memoria. Un evento aleatorio no demuestra narrativa emergente.

La aceptación requiere pruebas repetibles: ausencia de jugador, ausencia de LLM, persistencia, recuperación, catch-up, causalidad, memoria limitada, dos individuos reaccionando de forma diferente, economía sin duplicación, ecología con consecuencias y pruebas prolongadas.

## 10.3 Pruebas de referencia

Ejecutar 1, 7, 30 y 100 días simulados. Incluir expediciones, desapariciones, muertes, comercio, escasez, fabricación, investigación, aprendizaje, migración, reproducción, cambios sociales, errores, cierres inesperados y reapertura. Usar seeds, versiones y logs para reproducibilidad.

Probar 100, 500 y 1.000 entidades lógicas como benchmarks iniciales, sin convertir esos números en límites de producción ni promesas de rendimiento. Separar población lógica de agentes activos y modelos renderizados.

---

# 11. ESTADO DEL PROYECTO AL CIERRE DE ESTE PAQUETE

## 11.1 Estado normativo

SR-01 a SR-15 quedan registrados como documentos normativos oficiales aprobados dentro de este paquete. SR-09 incluye su Anexo A — Veyrath. El registro documental normaliza algunos encabezados que en copias fuente antiguas conservaban la etiqueta «propuesta» aunque el contenido había sido aceptado en la secuencia de trabajo.

La aprobación de una norma no significa que todos sus sistemas estén implementados. Significa que su marco de diseño es oficial y que futuras implementaciones deben respetarlo.

## 11.2 Estado de implementación

El proyecto cuenta con antecedentes técnicos, especificación de Godot/Android, archivos de workflow, un `project.godot`, un scaffold/prototipo y paquetes de diagnóstico/continuidad. No se afirma que estos elementos implementen el universo completo, que los NPC sean ya autónomos o que los hitos WLA estén cerrados.

En particular, la especificación WLA-TECH-001 v0.1.0 describía un scaffold con entidades placeholder y un baseline de persistencia inicial. Ese antecedente es punto de partida, no certificación de funcionamiento total. La IA que continúe debe inspeccionar el repositorio que el usuario proporcione y comparar archivos, commits, workflows y pruebas antes de informar el estado real.

## 11.3 Estado artístico

No hay biblioteca de assets final cerrada para el RPG. Los modelos de prueba y experiencias de herramientas 3D de otros proyectos no se deben tratar como pipeline aprobado para este juego. El usuario desea representación 3D y calidad anime estilizada, pero la dirección artística y pipeline final deben evolucionar con pruebas y presupuesto.

## 11.4 Estado de contenido

La campaña inicial está definida en su estructura por SR-14. Las fichas definitivas de especies, monstruos, NPC, salas, pisos, objetos, economía y topología exacta aún necesitan creación y validación como catálogos subordinados. Los nombres marcados como provisionales no se convierten en canon irrevocable.

---

# 12. GLOSARIO DE TÉRMINOS DEL PROYECTO

- **Sistema Reactor / System Core:** autoridad técnica que coordina comandos, versiones, tiempo y validación, conforme SR-02/SR-15.
- **World Model:** estado objetivo consultable del mundo.
- **Agent / agente:** entidad con percepción y capacidad de acción, limitada por SR-03.
- **NPC:** habitante del mundo no controlado por el jugador humano.
- **Player-agent:** entidad autónoma utilizada como agente dentro del World Laboratory; no equivale a eliminar al jugador humano del RPG final.
- **World Laboratory:** entorno de simulación y validación sin jugador humano.
- **Observatory / God View:** interfaz pasiva de observación y consulta.
- **World Canon:** hechos objetivos compartidos.
- **Personal Chronicle:** recuerdos, relaciones y perspectiva personal.
- **Instance / Session:** contexto particular de expedición, misión o sesión sin crear una realidad global contradictoria.
- **Event:** hecho confirmado o estado de evento con causa, lugar, tiempo y procedencia.
- **Command:** petición tipada de acción que debe validar el dominio competente.
- **Decision Trace:** registro estructurado de datos que influyeron en una decisión; no razonamiento privado textual.
- **Catch-up:** procesamiento del tiempo del mundo transcurrido mientras la aplicación estuvo cerrada y no pausada.
- **Hardcore:** perfil canónico de dificultad con muerte permanente por defecto y sin respawn ordinario.
- **Perfil Protegido:** reglas alternativas separadas, nunca mezcladas con mundos Hardcore.
- **Trama:** fundamento de las operaciones arcanas definido por SR-07; no tiene voluntad propia.
- **Resonancias:** fenómenos/patrones arcanos sujetos a SR-07.
- **Arcana:** campo civilizatorio de conocimientos y aplicaciones relacionadas con Trama, flujo y Resonancias; no una deidad.
- **Veyrath:** lengua arcana cuyas formulaciones se estructuran en palabras completas y oraciones ordenadas según SR-09 Anexo A.
- **Mazmorra:** espacio subterráneo de la torre de acceso según SR-11.
- **Crystal / cristal monstruoso:** recurso obtenido si los mecanismos biológicos y económicos lo permiten; no una recompensa automática de interfaz.
- **Authenticated offline world:** no existe autoridad remota para autenticar la hora o sincronizar otros dispositivos; la instancia individual mantiene su propio mundo local.

---

# 13. REGLAS DE CONTINUIDAD PARA FUTURAS ENTREGAS

Cada nueva entrega debe incluir:

1. nombre y versión exactos del artefacto;
2. qué SR y apartados afecta;
3. decisiones ya aprobadas que conserva;
4. supuestos nuevos separados de las decisiones;
5. archivos modificados y hashes cuando sea útil;
6. tests ejecutados y resultados reales;
7. limitaciones y asuntos pendientes;
8. guía de uso y siguiente paso;
9. indicación explícita de si un cambio altera guardados o contratos.

No generar un SR nuevo si el dominio ya está cubierto. Los documentos subordinados, catálogos, ADRs, tech notes y pruebas no deben recibir un número SR para aparentar progreso. Las propuestas nuevas deben estar claramente separadas y nunca reemplazar el paquete oficial hasta su aprobación.

---

# 14. MENSAJE DE INICIO PARA OTRA IA

«Este ZIP contiene el paquete oficial de continuidad de World Laboratory / Sistema Reactor, con SR-01 a SR-15 y su guía completa de dirección. Trabaja en español. Lee primero `00_LEER_PRIMERO/INSTRUCCIONES_PARA_IA.md`, luego `03_GUIA_DE_CONTINUIDAD/DOCUMENTO_MAESTRO_DE_CONTINUIDAD.md`, el registro oficial y después los quince SR completos, incluido SR-09 Anexo A — Veyrath.

No resumas los SR para sustituirlos ni inventes contenido. Las normas aprobadas son la autoridad sobre el mundo. No cambies decisiones, no agregues sistemas ni amplíes fases sin aprobación expresa. Distingue siempre canon aprobado, calibración, reservado, placeholder, hipótesis y propuesta. No presentes código, autonomía, pruebas, APK ni rendimiento como existentes sin evidencia.

La visión es un RPG Android de mundo abierto, 2.5D isométrico/3D estilizado, con combate continuo y un universo persistente y autónomo. El primer producto técnico es el World Laboratory offline-first sin jugador humano; debe validar el mismo núcleo lógico que usará el RPG final, donde después se incorporará un jugador humano. NPC y monstruos deben poder vivir, decidir, aprender, relacionarse, investigar, comerciar, migrar, luchar, morir y generar consecuencias sin depender del jugador ni de LLMs por entidad.

La primera versión de contenido apunta a la ciudad y los pisos 1–5 de la Mazmorra; los cien pisos son una aspiración de largo plazo. La campaña inicial es El Eco de Vhaloren con sus hechos fijos y resultados abiertos según SR-14. Empieza por revisar el estado real del repositorio y el hito técnico pendiente; no reinicies el proyecto ni cambies el motor por preferencia. Propón un plan concreto, compatible con SR-15, con contratos, pruebas y entregables verificables.»


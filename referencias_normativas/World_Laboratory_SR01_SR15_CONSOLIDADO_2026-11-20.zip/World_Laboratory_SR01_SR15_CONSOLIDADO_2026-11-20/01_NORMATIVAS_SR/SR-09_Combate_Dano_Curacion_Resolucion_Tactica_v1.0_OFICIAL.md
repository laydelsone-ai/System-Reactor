# SR-09 — COMBATE, DAÑO, CURACIÓN Y RESOLUCIÓN TÁCTICA

**Versión:** 1.0 — edición normativa aprobada  
**Estado:** NORMATIVA OFICIAL — APROBADA EXPRESAMENTE POR EL AUTOR EL 2026-11-20.  
**Fecha de consolidación:** 2026-11-20.  

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Borrador parcial | Marco inicial de combate, daño, curación y resolución táctica. |
| 0.2 | Borrador ampliado | Incorpora decisiones del autor sobre HP/MP, lesiones, aprendizaje, clases, magia, estados emocionales y adaptación. |
| 1.0 | Edición oficial aprobada | Cierra reglas estructurales, incorpora valores iniciales de referencia y distingue normativa de parámetros calibrables. |

**Dependencias:** SR-01 a SR-08.  
**Ámbito:** Combates entre entidades biológicas y activas no biológicas, consecuencias físicas y arcanas, asistencia, curación, incapacitación, muerte, recuperación, aprendizaje de combate, adaptación táctica, estados emocionales y clases.

**Registro de consolidación 1.0:** conserva las decisiones expresas del autor y transforma en reglas de referencia las recomendaciones necesarias para completar el sistema: escalas iniciales de aprendizaje y resiliencia emocional, valoración del impacto emocional, evidencia de adaptación táctica, perfil de dificultad protegido, sistema de clases no excluyente y enlace formal con el Anexo A de Veyrath. Los valores numéricos declarados como iniciales son parámetros de prueba sujetos a calibración, no constantes universales de todas las especies.

---

# 0. PROPÓSITO, AUTORIDAD Y LÍMITES

## 0.1. Propósito

SR-09 define cómo se producen, resuelven y registran los enfrentamientos dentro del universo. El combate no se reducirá a restar puntos de vida hasta que una barra llegue a cero. Deberá considerar, según corresponda, posición, movimiento, anatomía, zonas corporales, armas, armaduras, fuerza, técnica, velocidad, percepción, equilibrio, fatiga, lesiones, recursos, terreno, entorno, capacidades y decisiones de los combatientes.

El sistema combinará estadísticas cuantificables —como HP y, cuando corresponda, MP— con estados físicos localizados y consecuencias fisiológicas reales dentro de las reglas del universo.

El combate deberá poder ocurrir en cualquier lugar donde existan condiciones para un enfrentamiento: calles, viviendas, tabernas, caminos, bosques, corredores, túneles, cámaras, salas, escaleras, puentes, zonas abiertas y cualquier otro espacio válido. No se requerirán arenas o salas especiales para habilitarlo.

## 0.2. Autoridad normativa

SR-09 desarrolla la Ley de combate y consecuencias físicas de SR-01 §21. Debe respetar:

- SR-01: existencia, identidad, causalidad, muerte condicionalmente reversible, reencarnación mixta, agencia, progresión, consecuencias y persistencia.
- SR-02: autoridad de dominio, validación, comandos, concurrencia y registro de acontecimientos.
- SR-03: identidad corporal, cognición, memoria, aprendizaje, dominio, experiencia y reencarnación.
- SR-04: realidad objetiva, crónicas, causalidad, eventos y persistencia.
- SR-05: anatomía, capacidades, objetos, materiales y representación.
- SR-06: resolución temporal, simulación, autonomía y observabilidad.
- SR-07: movimiento, fuerzas, colisiones, daño, materiales, energía arcana, costes, recuperación, resistencias y contramedidas.
- SR-08: fisiología, anatomía, lesiones, mantenimiento, salud, enfermedades, regeneración y entidades activas no biológicas.
- Anexo A de SR-09: lengua arcana Veyrath y catálogo de 72 hechizos para los pisos 1–5. El anexo desarrolla la ejecución práctica, pero SR-07 conserva autoridad sobre Trama, flujo, costes, fuentes, resistencias y causalidad arcana.

SR-09 no podrá convertir las animaciones, las barras visuales, las clases, los niveles o las decisiones narrativas en autoridad física.

## 0.3. Lenguaje normativo

- **DEBE:** requisito obligatorio.
- **NO DEBE:** prohibición.
- **PUEDE:** posibilidad permitida, no garantizada.
- **CALIBRACIÓN:** valor de prueba que puede ajustarse con experimentos sin cambiar la regla estructural.
- **RESERVADO:** contenido específico de una especie, arma, técnica, hechizo o material que se definirá en su ficha o catálogo subordinado.

## 0.4. Alcance y exclusiones

Este documento define el marco normativo de combate y recuperación. Los valores universales que pueden fijarse ya quedan recogidos como referencias iniciales en esta versión. Las estadísticas propias de cada especie, el catálogo de armas, las fichas individuales de hechizos y los perfiles detallados de clases se desarrollarán en documentos subordinados. Esos datos no podrán contradecir las reglas de este documento ni las normas superiores.

---

# PARTE I — PRINCIPIOS DEL COMBATE

## 1. El combate como proceso causal

### 1.1. No es una comparación aislada de estadísticas

Un enfrentamiento es una secuencia causal de percepciones, intenciones, movimientos, acciones, contactos, defensas, impactos, lesiones, decisiones y consecuencias.

Una entidad más poderosa no tiene garantizada la victoria en toda circunstancia. La diferencia de capacidad puede ser enorme, pero la posición, sorpresa, preparación, número, terreno, información, equipo, compatibilidad de capacidades y errores pueden influir en el resultado.

### 1.2. Las acciones no garantizan resultados

Atacar, bloquear, esquivar, apuntar, lanzar un hechizo o intentar escapar son acciones intentadas o ejecutadas por un combatiente. El resultado depende de las condiciones reales y de la resolución del sistema competente.

Una animación de impacto no demuestra que haya ocurrido daño. El sistema lógico determina contacto, penetración, absorción, deformación, lesión y consecuencias; la presentación visual representa el resultado confirmado.

### 1.3. Cualquier lugar puede convertirse en campo de batalla

No existe una categoría de habitación que sea la única válida para combatir. Un corredor estrecho puede limitar el uso de armas largas, impedir rodear a un enemigo o favorecer emboscadas. Una cámara amplia puede permitir maniobras y ataques de área, pero no garantiza ventajas. El entorno es parte de la resolución táctica.

### 1.4. Persistencia de las consecuencias

Daño, heridas, equipo roto, agotamiento, pérdida de recursos, muerte, destrucción ambiental y cambios de relación pueden persistir después del combate. Terminar un enfrentamiento no restaura automáticamente el estado anterior.

## 2. Combatientes y tipos de entidad

### 2.1. Organismos biológicos

Humanos, animales, monstruos y demás organismos se rigen por su anatomía, fisiología, sentidos, necesidades, capacidades y vulnerabilidades definidas por SR-08.

### 2.2. Entidades activas no biológicas

Gólems, no-muertos y otras entidades activas no biológicas podrán combatir y sufrir daños, pero sus estados no deberán traducirse automáticamente a heridas, sangre, dolor, órganos o fisiología biológica. Sus estructuras, fuentes de actividad, puntos funcionales, mecanismos de degradación y condiciones de desactivación dependerán de su naturaleza.

### 2.3. Entidades heterogéneas

Los sistemas de combate deberán poder resolver enfrentamientos entre anatomías, materiales, fisiologías, reservas y mecanismos muy distintos. No se supondrá que todas las entidades utilizan HP, MP, sangre, dolor, fatiga o estados biológicos de la misma manera.

---

# PARTE II — ESTADOS CUANTIFICABLES Y CONDICIÓN FÍSICA

## 3. HP — puntos de vida

### 3.1. Función de HP

HP será una magnitud numérica útil para resumir parte de la capacidad de una entidad para continuar soportando un enfrentamiento. Su función exacta deberá convivir con el modelo de daños localizados.

HP NO DEBE ser la única representación del cuerpo ni una garantía de que todas las lesiones pueden ignorarse mientras quede un valor positivo. Un combatiente puede conservar HP y haber perdido una mano, un brazo, la visión de un ojo, la movilidad de una pierna o sufrir una hemorragia peligrosa.

### 3.2. Relación entre HP y daño localizado

El sistema deberá mantener la diferencia entre:

- daño o desgaste general representado en HP;
- daño localizado en una zona corporal;
- lesión funcional que limita una acción;
- alteración fisiológica sistémica;
- estado crítico o incapacidad;
- muerte.

Un mismo ataque puede reducir HP y producir una lesión localizada, solo una de esas consecuencias, o ninguna, según la energía transferida, la zona, la protección y el resultado físico.

### 3.3. HP no equivale a integridad anatómica

La restauración de HP no reconstruye automáticamente tejidos, órganos ni extremidades. La pérdida de una extremidad puede coexistir con HP restante. Una herida puede seguir causando consecuencias aunque una parte del daño general se haya recuperado.

### 3.4. HP = 0: resultado dependiente de daño y entidad

HP = 0 NO significa necesariamente muerte instantánea para toda entidad. Significa que la reserva representada por HP ha alcanzado su umbral de agotamiento. El resultado posterior DEBE determinarse mediante el estado anatómico/fisiológico o estructural, el tipo y localización del daño, la continuidad de funciones vitales, la naturaleza de la entidad y las posibilidades reales de intervención.

Según el caso, HP = 0 puede producir:

- incapacidad o pérdida de consciencia;
- estado crítico o agonizante;
- colapso de funciones vitales;
- muerte inmediata;
- un estado equivalente específico para una entidad no biológica.

Una lesión catastrófica puede matar aunque queden HP. A la inversa, una entidad puede alcanzar HP = 0 y permanecer recuperable durante un intervalo si conserva las funciones necesarias y existe una intervención viable. No habrá un periodo de gracia universal: dependerá del mecanismo del daño y del organismo o estructura.

HP debe seguir siendo cuantificable y útil para la interfaz, pero nunca anulará una lesión letal, una amputación, una hemorragia o un fallo estructural confirmado.

## 4. MP y recursos arcanos

### 4.1. MP cuantificable

MP PUEDE representarse numéricamente como reserva personal disponible para operaciones arcanas, cuando la naturaleza de la entidad y su fisiología/estructura lo permitan.

### 4.2. Representación numérica común, mecanismos internos diferentes

MP podrá mostrarse mediante una interfaz numérica común para las entidades que tengan una reserva o capacidad arcana pertinente. La escala visual común no implica que todas las entidades almacenen, produzcan, recuperen o canalicen energía mediante el mismo órgano o mecanismo.

Cuando una entidad no posea reserva arcana utilizable, MP podrá figurar como no aplicable, ausente o cero según el contrato de interfaz; no se le inventará una reserva ficticia. Las reservas internas, fuentes, costes y límites continúan obedeciendo SR-07 §§23–26.

### 4.3. MP no es dominio mágico

Tener MP suficiente no garantiza conocer, comprender, formular, controlar ni ejecutar una operación mágica. Deben respetarse conocimiento, vocabulario arcano, gramática, comprensión, práctica, afinidad, concentración, preparación, compatibilidad, alcance, estabilidad y demás condiciones de SR-03 y SR-07.

### 4.4. Agotamiento y sobrecarga

El agotamiento arcano puede producir efectos distintos según organismo, estructura, reserva y operación: fatiga, pérdida de precisión, interrupción, daño fisiológico, alteración perceptiva, inestabilidad o lesiones duraderas. No se asumirá un efecto universal.

## 5. Atributos y capacidades de combate

El sistema PUEDE utilizar atributos cuantificables para representar capacidades generales, pero no deberá reducir toda la resolución a una sola cifra. Los atributos describen tendencias y capacidades; no sustituyen la anatomía, la experiencia, el conocimiento, el equipo ni las condiciones reales.

Entre las dimensiones posibles están:

- fuerza, potencia y control muscular;
- velocidad, aceleración, reacción y coordinación;
- precisión, equilibrio, estabilidad y movilidad;
- resistencia física, tolerancia al esfuerzo y recuperación;
- percepción, atención, concentración y control motor;
- técnica, dominio, experiencia y conocimiento táctico;
- capacidad de defensa, control del arma y lectura del adversario;
- reserva física y capacidad de canalización arcana;
- **capacidad de aprendizaje** y aptitudes de aprendizaje por dominio;
- **resiliencia emocional**, también denominada provisionalmente tolerancia al impacto emocional.

### 5.1. Capacidad de aprendizaje

La capacidad de aprendizaje es una dimensión cuantificable del perfil cognitivo, compatible con la inteligencia multidimensional de SR-01 y SR-03. No es una estadística única de inteligencia ni garantiza que el individuo aprenda cualquier cosa.

Influye en la rapidez y eficiencia con que una entidad puede adquirir, comprender, retener, corregir, transferir y aplicar conocimientos o patrones, siempre que disponga de percepción, atención, experiencia, instrucción, práctica, retroalimentación y tiempo suficientes.

La capacidad general podrá coexistir con aptitudes específicas: aprendizaje marcial, mágico, lingüístico, artesanal, sensorial, social, táctico u otros dominios. Dos entidades con la misma capacidad general pueden progresar de manera distinta en disciplinas diferentes.

La aptitud de aprendizaje no reemplaza el conocimiento ni el dominio práctico. Observar un hechizo, una maniobra o una técnica no garantiza comprenderla; comprenderla no garantiza poder ejecutarla; ejecutarla una vez no equivale a dominarla.

Esta dimensión se aplica a jugadores, NPC y monstruos. Una especie, un individuo o un monstruo élite puede aprender más rápido que otro, pero el resultado también depende de su inteligencia pertinente, sentidos, memoria, experiencia, oportunidades y límites biológicos/estructurales.

**Escala de referencia:** la capacidad general y cada aptitud de dominio se expresan de 0 a 100 cuando sean aplicables. Para estimar el aprendizaje de una actividad se adopta el Índice de Aprendizaje Efectivo del Anexo A: `LE = 0.35C + 0.25A + 0.15K + 0.10I + 0.15F`. Sus componentes representan capacidad individual, aptitud del dominio, conocimientos previos, calidad de instrucción y calidad de práctica/retroalimentación. El índice orienta la progresión; no concede información, experiencia ni dominio ausentes.

### 5.2. Resiliencia emocional

Se adopta el nombre **Resiliencia emocional (RE)** para la dimensión que representa la capacidad de soportar, procesar y recuperar estabilidad funcional ante presión, miedo, pérdida, trauma, sorpresa y acontecimientos emocionalmente intensos. Se expresa en una escala de referencia de 0 a 100 cuando sea pertinente. No significa inmunidad emocional, ausencia de miedo ni incapacidad para sufrir consecuencias psicológicas.

La resiliencia emocional no significa ausencia de emociones, indiferencia ni inmunidad al pánico. Modifica la probabilidad, intensidad, duración o recuperación de determinadas respuestas, junto con personalidad, vínculos, experiencia, interpretación, preparación y circunstancias.

No elimina automáticamente el duelo, el miedo, la memoria dolorosa ni las consecuencias psicológicas. Tampoco convierte a una entidad en incapaz de sentir.

### 5.3. Aprendizaje, clase y predisposición

Las clases y especializaciones pueden predisponer a aprender con mayor facilidad los conocimientos relacionados con su ámbito, sin bloquear aprendizajes externos. La predisposición puede influir en la eficiencia de aprendizaje, no conceder conocimiento, técnica o dominio automáticos. Véanse §§18–19.

### 5.4. Atributos no universales

No todas las entidades necesitan los mismos atributos. Un gólem puede tener integridad estructural y estabilidad de núcleo en lugar de resistencia fisiológica; un monstruo sin sistema nervioso humano puede tener procesamiento sensorial distinto; una entidad sin capacidad arcana no necesita MP. Los campos inaplicables deben declararse como tales.

---

# PARTE III — DAÑO FÍSICO Y LESIONES LOCALIZADAS

## 6. Modelo anatómico de daño

### 6.1. Zonas corporales

Los organismos deberán poder tener zonas anatómicas relevantes para su especie. Una ficha de especie puede definir, entre otras, cabeza, cuello, torso, abdomen, espalda, brazos, manos, piernas, pies, alas, cola, órganos y estructuras especializadas.

No se impondrá una anatomía humanoide a todas las entidades. Una criatura puede tener varios miembros, caparazón, múltiples cabezas, órganos distribuidos, cuerpos segmentados o anatomía no convencional.

### 6.2. Localización y consecuencias

El daño localizado deberá poder afectar:

- integridad del tejido o estructura;
- movilidad y capacidad de desplazamiento;
- agarre y manipulación;
- percepción y sentidos;
- equilibrio y coordinación;
- respiración y circulación, cuando existan;
- canalización o regulación arcana, cuando existan;
- capacidad de atacar, defenderse o ejecutar técnicas;
- mantenimiento y supervivencia.

Una lesión no debe imponer efectos que la anatomía del objetivo no pueda sufrir.

### 6.3. Armadura y protección localizada

La armadura y el equipo protector actúan sobre las zonas que realmente cubren, según diseño, ajuste, material, grosor, integridad, movilidad y forma de impacto. Un casco no protege automáticamente el torso; un peto no cubre necesariamente axilas, articulaciones o extremidades; los huecos y uniones pueden dejar zonas vulnerables.

La protección debe evaluarse en relación con la trayectoria, ángulo, energía, tipo de daño, material del arma/fenómeno y propiedades de la armadura. Puede detener, reducir, desviar o distribuir un impacto sin garantizar inmunidad. La armadura puede deformarse, agrietarse, perforarse, romperse, desplazarse o perder eficacia conforme a SR-07.

La interfaz PUEDE resumir el estado de protección mediante estadísticas agregadas o indicadores sencillos, pero el sistema lógico DEBE conservar la cobertura y condición por zona. Una cifra global no puede borrar la localización del impacto ni afirmar que una región está protegida cuando no lo está.

Los escudos y otras protecciones móviles dependen de orientación, posición, tiempo de reacción, técnica, capacidad y posibilidad real de interponerlos entre el ataque y el objetivo.

## 7. Tipos de daño

El sistema deberá poder distinguir, cuando sean pertinentes:

- corte;
- perforación o penetración;
- impacto y contusión;
- compresión y aplastamiento;
- fractura y dislocación;
- desgarro;
- quemadura y daño térmico;
- congelación o daño por frío;
- daño químico, corrosivo o tóxico;
- daño eléctrico;
- presión y onda de choque;
- daño acústico o vibratorio;
- daño arcano;
- daño interno u orgánico;
- destrucción estructural en entidades no biológicas.

La etiqueta de daño por sí sola no determina el resultado. Deben evaluarse propiedades del atacante, arma o fenómeno; trayectoria; punto de impacto; material; protección; ángulo; energía; resistencia y vulnerabilidad específica.

## 8. Heridas, incapacidad y efectos progresivos

### 8.1. Estados de lesión

El sistema podrá registrar lesiones leves, moderadas, graves, críticas e incompatibles con la continuidad vital, pero las categorías y sus umbrales deberán definirse con criterios funcionales. La gravedad no debe inferirse exclusivamente del aspecto visual.

### 8.2. Efectos funcionales

Las lesiones pueden reducir o impedir acciones concretas. Por ejemplo:

- lesión de una mano: limita agarre, manipulación o uso de determinadas armas;
- lesión de un brazo: limita defensa, carga, equilibrio o técnicas bimanuales;
- lesión de una pierna: afecta movilidad, carrera, salto o estabilidad;
- lesión ocular: altera visión, profundidad o puntería;
- lesión auditiva: altera localización de sonidos y comunicación;
- lesión torácica o respiratoria: limita esfuerzo y resistencia si la entidad depende de esa función.

Los ejemplos son ilustrativos; los efectos dependen de anatomía y severidad.

### 8.3. Dolor, shock y pérdida de función

El dolor y el shock PUEDEN influir en concentración, coordinación, percepción, conducta y capacidad de continuar. No deben convertirse en simples penalizaciones cosméticas. Las entidades que no experimentan dolor biológico podrán tener señales de fallo, pérdida de estabilidad o mecanismos equivalentes.

### 8.4. Estados alterados, buffs y debuffs

El sistema DEBE permitir estados temporales, persistentes o condicionales que modifiquen capacidades, atributos, percepción, conducta, fisiología, recursos o ejecución de acciones. En la interfaz podrán agruparse como **buffs** (efectos beneficiosos), **debuffs** (efectos perjudiciales) y estados neutros/mixtos; estas etiquetas de interfaz no sustituyen la descripción causal del efecto.

Los estados pueden originarse por magia, lesiones, enfermedades, venenos, fatiga, falta de sueño, hambre, sed, temperatura, exposición ambiental, combate prolongado, miedo, estrés, relaciones, habilidades, sustancias, equipos u otros procesos válidos.

Cada instancia de estado deberá poder declarar, según corresponda: causa y procedencia, objetivo, intensidad, duración o condición de terminación, frecuencia de actualización, variables afectadas, acumulación o exclusión con otros estados, resistencia, inmunidad, tratamiento, disipación y consecuencias de terminar.

Los estados no deben aplicarse solo porque la animación o el nombre de una habilidad lo indique. Requieren una causa, condiciones y validación. La misma etiqueta puede tener distinta intensidad o efectos en especies diferentes.

Ejemplos no exhaustivos: sangrado, envenenamiento, quemadura, congelación, agotamiento, desorientación, mareo, dolor intenso, shock, silencio, pérdida de concentración, miedo, pánico, calma, protección, aceleración, fortalecimiento, debilitamiento, bloqueo arcano y aumento temporal de percepción.

### 8.5. Impacto emocional de acontecimientos

Se establece el **Impacto Emocional del Acontecimiento (IEA)** como una valoración contextual de la magnitud emocional potencial de un hecho. La escala de referencia es 0–10 y se registra en el evento, no como una emoción idéntica impuesta a todos los testigos.

| IEA | Categoría de referencia | Ejemplo de magnitud |
|---:|---|---|
| 0 | Nulo | Hecho sin relevancia emocional apreciable |
| 1–2 | Leve | Sorpresa, contratiempo o amenaza menor |
| 3–4 | Moderado | Peligro serio, pérdida limitada o fracaso importante |
| 5–6 | Alto | Lesión grave, amenaza mortal o pérdida significativa |
| 7–8 | Severo | Muerte de persona cercana, desastre local o peligro extremo |
| 9–10 | Catastrófico | Múltiples muertes presenciadas, destrucción vital o amenaza existencial |

La respuesta individual utiliza además una **Exposición Individual (EI)** de 0 a 1 y una **Relevancia Personal (RP)** de 0.5 a 1.5. Como referencia de cálculo: `Impacto Personal = limitar(IEA × EI × RP, 0, 10)`. Esta magnitud no equivale automáticamente a pánico ni a trauma: se combina con RE, personalidad, vínculos, experiencia, apoyo, interpretación y estado físico.

El IEA del acontecimiento no equivale automáticamente al impacto vivido por cada individuo. Exposición, percepción, relación con las personas afectadas, interpretación, experiencia previa, personalidad, memoria, importancia del evento y conocimiento adquirido modifican la respuesta individual. La escala y fórmula son un marco de valoración, no un diagnóstico psicológico ni una orden narrativa.

Ejemplo de referencia: si un grupo de ocho aventureros sufre un enfrentamiento en el que un monstruo acaba con siete y el octavo presencia la muerte de sus siete compañeros, el acontecimiento puede recibir IEA 10 en la escala de referencia. No significa que todos los individuos expuestos deban sufrir la misma respuesta ni que el superviviente entre automáticamente en pánico. La respuesta dependerá de su Resiliencia emocional, vínculos, experiencia, estado físico, interpretación y otras circunstancias.

### 8.6. Pánico y otros estados emocionales

El pánico es una posible respuesta, no un resultado obligatorio de todo acontecimiento de alto impacto. Puede producir huida, bloqueo, errores de coordinación, visión atencional estrecha, dificultades para concentrarse, decisiones impulsivas, interrupción de acciones o incapacidad temporal para continuar una tarea compleja.

En operaciones mágicas que requieren seleccionar palabras en orden, el pánico PUEDE provocar, de manera probabilística, confusión de secuencia, dificultad para seleccionar el término correcto, desplazamiento o reordenamiento visual de las opciones de palabras en la interfaz, errores de selección o interrupción del cántico. Esto no cambia la gramática real del hechizo ni borra las palabras conocidas: representa una interferencia temporal en la atención, memoria de trabajo o ejecución.

No todo individuo en pánico fallará un hechizo. La probabilidad depende de intensidad del estado, resiliencia emocional, concentración, dominio del hechizo, longitud/complicación del cántico, experiencia, apoyo recibido y condiciones del momento. Un NPC experimentará una interferencia cognitiva equivalente sin necesitar la interfaz gráfica del jugador.
## 9. Sangrado y pérdida de fluidos

### 9.1. Sangrado como proceso progresivo

Una herida que dañe vasos o estructuras equivalentes puede causar pérdida progresiva de sangre o fluido funcional. La consecuencia depende de tipo de lesión, localización, magnitud, fisiología, coagulación y atención recibida.

### 9.2. Relación con HP

El sangrado PUEDE reducir HP progresivamente si esa es la representación elegida para la entidad. También deberá conservar su propio estado de hemorragia, porque detener la pérdida no equivale a restaurar automáticamente el fluido perdido ni reparar la lesión.

### 9.3. Estados de hemorragia

El contrato deberá permitir registrar ubicación, intensidad, tasa estimada, duración, fuente, tratamiento aplicado y progresión. Se adopta una clasificación funcional de cuatro grados: **I leve**, controlable con medidas sencillas; **II significativa**, requiere intervención correcta y vigilancia; **III grave**, amenaza la continuidad funcional y exige estabilización urgente; **IV crítica**, puede causar colapso rápido o muerte si no se controla de inmediato.

El grado no se asigna por una cantidad universal de sangre: depende de anatomía, especie, volumen circulante o fluido funcional, tasa de pérdida, localización, estado previo y capacidad de compensación. HP puede reflejar parte del deterioro, pero la hemorragia conserva su propio estado para evitar que una barra agregada oculte la causa. Los coeficientes por especie se calibrarán en sus fichas.

### 9.4. Entidades no biológicas

Una entidad no biológica no sangra salvo que su diseño funcional incluya un fluido o mecanismo análogo. La pérdida de energía, fluido arcano, material estructural o presión deberá modelarse según su naturaleza, sin llamarla automáticamente hemorragia biológica.

## 10. Pérdida de extremidades y partes corporales

### 10.1. Posibilidad real de pérdida

Las extremidades y partes corporales podrán sufrir amputación, destrucción o pérdida funcional cuando la geometría, fuerza, instrumento, resistencia y circunstancias lo permitan.

La pérdida de una extremidad puede producir hemorragia, shock, dolor, pérdida de función, reducción de movilidad y otras consecuencias compatibles con la fisiología de la especie.

### 10.2. No depende exclusivamente de HP

La pérdida de un brazo, pierna, mano, ala, cola u otra estructura puede ocurrir aunque la entidad conserve HP. No se requiere que HP llegue a cero para que una lesión localizada grave ocurra.

### 10.3. Persistencia

Una extremidad perdida no reaparece por descansar, terminar el combate, subir de nivel ni recuperar HP. Su recuperación requiere un mecanismo válido de curación, regeneración, reconstrucción o reemplazo.

### 10.4. Relevancia de la anatomía

La pérdida de una estructura debe afectar las funciones que dependían de ella. El impacto concreto variará por especie, anatomía, entrenamiento, adaptación y mecanismos alternativos.

---

# PARTE IV — MUERTE, HARDCORE Y CONTINUIDAD

## 11. Regla ordinaria: sin respawn

### 11.1. Ausencia de respawn automático y modo hardcore

El modo ordinario y de referencia del universo será **hardcore desde el inicio**. Una entidad derrotada o muerta no reaparece automáticamente en un punto de aparición, posada, gremio, hogar, entrada de mazmorra ni lugar equivalente.

No existe un reinicio automático del individuo tras la muerte. No se restauran automáticamente HP, inventario, equipo, heridas, ubicación ni progreso individual.

### 11.2. Variantes de dificultad separadas

PUEDE existir un **Perfil Protegido** (modo accesible) como variante separada del modo Hardcore. Se recomienda elegirlo al crear el mundo y mantenerlo fijo para esa línea de mundo; cambiar el perfil exige crear una ramificación o copia explícita, no una alteración retroactiva silenciosa.

En Perfil Protegido, un resultado que sería mortal pero que deje una posibilidad causal de recuperación puede convertirse en **incapacitación crítica con extracción o rescate asistido**. El personaje pierde tiempo, posición, recursos y puede sufrir heridas, secuelas, pérdida o daño de equipo y consecuencias sociales. No obtiene una victoria, curación gratuita ni inmunidad al daño. Si la entidad es completamente destruida o el mecanismo hace imposible toda continuidad, la regla superior de SR-01 prevalece.

El Perfil Protegido es una regla de accesibilidad y no la experiencia canónica del universo. No se mezcla con partidas Hardcore ni se presenta como si los mismos acontecimientos hubieran ocurrido bajo idénticas reglas.


### 11.3. La muerte como consecuencia persistente

La muerte debe detener la continuidad vital correspondiente conforme a SR-01 §7. La identidad y la historia no se borran. El cuerpo, los objetos, las relaciones, las crónicas y los efectos derivados permanecen sujetos a causalidad y persistencia.

### 11.4. Reversión extraordinaria no equivale a respawn

SR-01 §7 permite muerte condicionalmente reversible bajo condiciones extraordinarias, mecanismos definidos y consecuencias relevantes. Esto no constituye respawn ordinario, ni garantiza que el individuo vuelva, ni elimina el coste histórico y causal de la muerte.

Resurrección, reanimación y reencarnación se mantienen diferenciadas conforme a SR-01 §§7–8. La reencarnación puede producir una nueva existencia con continuidad parcial; no equivale a volver al combate con la misma vida restaurada.

## 12. Daño letal y lesiones en la cabeza

### 12.1. Lesiones vitales

El daño que destruya estructuras indispensables para la continuidad vital puede causar muerte inmediata o en un plazo muy breve, según anatomía, mecanismo y posibilidad real de intervención.

### 12.2. Cabeza y sistema nervioso

En organismos cuya continuidad vital dependa de estructuras nerviosas centrales, la destrucción catastrófica de esas estructuras podrá ser inmediatamente mortal. La lesión debe resolverse conforme a anatomía y causalidad, no por una etiqueta visual genérica.

### 12.3. Resolución de lesiones en la cabeza

Una lesión en la cabeza no es mortal por el simple hecho de estar localizada allí. Su resultado depende de fuerza, arma o mecanismo, velocidad, ángulo, profundidad, trayectoria, protección, estructura anatómica alcanzada y estado previo.

Un corte que alcance o destruya estructuras indispensables para la continuidad vital puede ser mortal aunque queden HP. Una lesión superficial no produce muerte automática. Ciertas lesiones catastróficas de estructuras vitales se consideran letales por su mecanismo, no por una etiqueta genérica de «golpe en la cabeza».

### 12.4. Otros organismos y entidades

No todas las entidades tienen cabeza ni un sistema nervioso central equivalente. Sus puntos o condiciones de destrucción vital deberán definirse por especie o arquitectura. No se impondrá una debilidad humanoide universal.

## 13. Incapacitación, agonía y estados críticos

El sistema deberá diferenciar al menos:

- ileso o funcional;
- lesionado;
- incapacitado parcialmente;
- incapacitado;
- crítico;
- agonizante o en fallo vital, cuando aplique;
- muerto;
- reanimado o resucitado, si un mecanismo válido ocurre;
- reencarnado, si se inicia una nueva existencia.

Estos estados no serán una única barra ni necesariamente una secuencia universal. La progresión dependerá del tipo de entidad y del evento causal.

La relación entre HP = 0, incapacitación, estado crítico y muerte se resuelve conforme a §3.4: depende del daño, la entidad y la continuidad de sus funciones vitales/estructurales.

---

# PARTE V — PRIMEROS AUXILIOS, ESTABILIZACIÓN Y CURACIÓN

## 14. Principio de tratamiento por capas

La recuperación deberá distinguir al menos:

1. detener o reducir una causa de deterioro;
2. estabilizar funciones vitales;
3. tratar la lesión;
4. recuperar tejidos o estructuras;
5. rehabilitar funciones;
6. restaurar, regenerar o reemplazar una parte perdida, cuando sea posible.

Una intervención puede resolver una capa sin resolver las demás. Detener el sangrado no reconstruye una extremidad. Restaurar HP no elimina automáticamente una fractura. Cerrar una herida no garantiza recuperar movilidad o sensibilidad.

## 15. Primeros auxilios y material médico

### 15.1. Existencia de objetos médicos

El mundo podrá contener y producir botiquines, vendas, gasas, apósitos, torniquetes, férulas, herramientas médicas, antisépticos, medicamentos y otros consumibles o instrumentos compatibles con el nivel tecnológico y cultural correspondiente.

Los objetos tendrán composición, disponibilidad, usos, limitaciones, conservación, caducidad cuando proceda y procedencia. No serán consumibles mágicos universales.

### 15.2. Primeros auxilios

Los primeros auxilios permiten responder a ciertos problemas inmediatos: controlar una hemorragia, proteger una herida, inmovilizar una estructura, asistir la respiración si el mecanismo del mundo lo contempla, reducir contaminación o estabilizar una entidad.

La eficacia dependerá del procedimiento, conocimiento, herramientas, tiempo, entorno, anatomía y gravedad. Un botiquín no garantiza salvar a cualquier herido.

### 15.3. Torniquetes

El torniquete podrá emplearse como herramienta de control de determinadas hemorragias en extremidades o estructuras equivalentes, siempre que la anatomía y el tipo de lesión lo permitan.

Su uso tendrá condiciones, eficacia, duración, riesgos y necesidad de atención posterior. No será una solución universal para hemorragias internas, lesiones del torso, cuello, órganos u otras anatomías incompatibles.

El nivel de detalle médico y los parámetros temporales concretos quedan para desarrollo posterior; la disponibilidad general de primeros auxilios básicos y la necesidad de formación avanzada ya están decididas.

### 15.4. Acceso a primeros auxilios

Todos los individuos que tengan capacidades físicas y cognitivas pertinentes PUEDE aprender y aplicar primeros auxilios básicos. No se exige pertenecer a una clase Sanador o Support para intentar una intervención elemental.

Los procedimientos avanzados, el diagnóstico complejo, la cirugía, el tratamiento especializado y las operaciones arcanas de curación requieren conocimientos, formación, práctica, instrumentos y capacidades apropiadas. La falta de formación puede reducir la precisión, eficacia o seguridad, y puede causar errores o complicaciones.

La clase o especialización aumenta la predisposición y oportunidades de aprendizaje en su ámbito, pero no concede exclusividad absoluta sobre las acciones.

## 16. Curación biológica y mágica

### 16.1. Curación no universal

La curación deberá resolver una lesión mediante un mecanismo que sea compatible con el organismo, el tipo de daño y las leyes de SR-07. La energía arcana no sustituye automáticamente la fisiología ni elimina las condiciones de fuente, coste, reserva, alcance, precisión, compatibilidad y resistencia.

### 16.2. Recuperación de HP

Una operación de curación puede recuperar HP sin resolver todas las lesiones localizadas. Del mismo modo, una lesión localizada puede ser tratada sin restaurar por completo HP, resistencia o reservas.

### 16.3. Regeneración y restauración de extremidades

Se permite que técnicas curativas de gran capacidad restauren una extremidad perdida, incluido un brazo, cuando el nivel de poder y el mecanismo lo permitan. Esta capacidad no será común ni automática.

La restauración de una extremidad es un proceso distinto de recuperar HP. Deberá considerar la cantidad de tejido o estructura a reconstruir, compatibilidad anatómica, estado del paciente, fuente y coste, tiempo, precisión, estabilidad, conocimiento y posibles secuelas.

### 16.4. Cirugía, reimplantación, prótesis y reconstrucción artificial

La recuperación de una parte perdida no depende exclusivamente de la magia. Según la especie, tecnología, conocimientos y recursos disponibles, pueden existir:

- reimplantación de una parte conservada y viable;
- cirugía reconstructiva;
- regeneración biológica natural;
- restauración o regeneración arcana;
- prótesis mecánicas, materiales o biológicas;
- reconstrucción artificial de una estructura funcional;
- combinación de varios métodos.

Una prótesis o reconstrucción artificial no equivale automáticamente a recuperar la anatomía original. Puede restituir algunas funciones, ofrecer otras capacidades, tener limitaciones, requerir mantenimiento o necesitar adaptación y entrenamiento. Su integración debe respetar SR-05 y las leyes materiales/arcanas de SR-07.

### 16.5. Límites y consecuencias

Una curación poderosa no debe ignorar gratuitamente las leyes de SR-07. Podrá requerir grandes reservas, materiales, condiciones, preparación, compatibilidad, tiempo o conocimiento. La técnica puede fallar, ser incompleta o dejar consecuencias si las condiciones no se cumplen. La velocidad y resultado de una curación avanzada dependerán del hechizo, lesión, anatomía, estado del objetivo y habilidad real del sanador; no existe una duración universal.

### 16.6. Curación de entidades no biológicas

Gólems, no-muertos y otras entidades activas no biológicas pueden repararse o restaurarse mediante mecanismos compatibles con sus estructuras, fuentes de actividad y naturaleza. No se les impondrá tejido, sangre ni fisiología biológica sin fundamento.

## 17. Rehabilitación y secuelas

La recuperación puede requerir reposo, nutrición, terapia, readaptación, entrenamiento, prótesis, aprendizaje de técnicas alternativas o tiempo. Las secuelas pueden ser temporales, persistentes o permanentes.

El hecho de que una lesión se cure no implica que el individuo recupere de inmediato su anterior dominio práctico. SR-03 conserva autoridad sobre aprendizaje, memoria procedimental y dominio; SR-08 sobre las restricciones fisiológicas que persistan.

---

# PARTE VI — CLASES, ROLES Y SOPORTE

## 18. Clases, especializaciones y profesiones

### 18.1. Función de una clase

Las clases representan orientaciones de formación, práctica, predisposición, especialización o función social/táctica. No son permisos exclusivos ni sustituyen anatomía, inteligencia, conocimiento, entrenamiento o dominio.

Una clase puede aumentar la predisposición y eficiencia para aprender conocimientos y capacidades relacionados con su ámbito. No entrega automáticamente el conocimiento ni prohíbe aprender fuera de él. Un Guerrero puede aprender alquimia; un Herrero puede aprender magia; un Mago puede desarrollar técnicas de espada; un Ladrón puede especializarse en medicina de campo.

### 18.2. Aprendizaje y predisposición de clase

La influencia de la clase actúa como una predisposición, no como un bloqueo. Puede afectar facilidad de comprensión, velocidad de aprendizaje, eficiencia de práctica, reconocimiento de patrones o acceso a métodos de instrucción específicos. Por ejemplo, una clase orientada a la magia puede facilitar el estudio de formulaciones arcanas, mientras que una clase de Herrero puede facilitar el aprendizaje de metalurgia, forja y tratamiento de materiales. El efecto debe combinarse con capacidad de aprendizaje individual, aptitudes por dominio, experiencia, enseñanza, práctica, atención, memoria y retroalimentación.

La pertenencia a una clase no garantiza aptitud ni éxito. Un individuo puede tener una clase relacionada con algo en lo que sea mediocre, o aprender una disciplina externa con gran dominio gracias a sus capacidades y esfuerzo.

### 18.3. Clases múltiples, híbridas y evolución

Un individuo PUEDE desarrollar varias clases, especializaciones o perfiles profesionales y combinarlos en una identidad de capacidades. Las combinaciones pueden producir perfiles híbridos no enumerados de antemano. No existe un límite universal de clases ni una ranura que impida estudiar otra disciplina.

**Regla de reconocimiento aprobada:** una clase se reconoce por evidencia acumulada de aprendizaje, práctica, conocimientos, desempeño y continuidad de actividad, no por elegir un nombre ni alcanzar un nivel global. Puede existir una autoidentificación, una clasificación del gremio/academia y una clasificación interna del sistema; pueden diferir sin alterar las capacidades reales. La interfaz puede destacar una o dos orientaciones principales para facilitar lectura, pero eso no limita las demás. Una clase no concede automáticamente técnicas, estadísticas, magia ni equipamiento.

### 18.4. Catálogo inicial abierto de clases

El siguiente catálogo sirve como punto de partida y no es exhaustivo ni obligatorio. Los nombres describen perfiles de aprendizaje y práctica; no garantizan poderes, estadísticas ni habilidades concretas.

**Combate cuerpo a cuerpo y primera línea:** Guerrero, Caballero, Espadachín, Duelista, Guardián, Defensor, Lancero, Luchador, Monje de combate, Berserker, Espadachín mágico, Portador de escudo, Soldado, Gladiador.

**Combate a distancia:** Arquero, Tirador, Francotirador, Ballestero, Cazador, Lanzador, Hostigador.

**Sigilo, infiltración y precisión:** Ladrón, Pícaro, Asesino, Explorador, Infiltrador, Espía, Trampero, Rastreador.

**Magia y artes arcanas:** Mago, Brujo, Hechicero, Elementalista, Mago de viento, Mago de fuego, Mago de agua, Mago de tierra, Ilusionista, Invocador, Encantador, Sellador, Mago de barreras, Mago de apoyo, Mago de combate, Investigador arcano.

**Sanación y soporte:** Sanador, Curandero, Médico de campo, Support, Auxiliar táctico, Protector, Especialista en barreras, Buffer, Disipador, Coordinador, Logístico, Bardo de apoyo. Estos nombres no autorizan bendiciones divinas ni poderes por adoración; cualquier operación arcana debe obedecer SR-07.

**Fabricación y artesanía:** Herrero, Armero, Forjador de armas, Forjador de armaduras, Alquimista, Encantador de objetos, Grabador de sellos, Artesano rúnico, Carpintero, Curtidor, Peletero, Sastre, Ingeniero, Constructor, Cocinero, Herborista, Joyero, Reparador.

**Exploración y recursos:** Minero, Recolector, Naturalista, Cartógrafo, Guía, Explorador de mazmorras, Superviviente, Rastreador, Trampero, Prospector.

**Conocimiento, comercio y sociedad:** Comerciante, Negociador, Erudito, Investigador, Escriba, Bibliotecario, Estratega, Diplomático, Administrador, Maestro, Traductor, Tasador.

El catálogo podrá ampliarse mediante clases nuevas, combinaciones y especializaciones emergentes. Una clase no se crea simplemente por asignarle un nombre: debe corresponder a un conjunto reconocible de prácticas, conocimientos, predisposiciones o funciones.

## 19. Sanador y Support

### 19.1. Sanador

El Sanador se orienta al diagnóstico, tratamiento, estabilización y/o curación biológica o arcana según sus conocimientos y capacidades. No se presupone que todo Sanador pueda regenerar extremidades, resucitar o tratar toda patología.

### 19.2. Support

Support es un perfil híbrido de apoyo al grupo y no un simple personaje que carga objetos. Puede especializarse en una combinación de:

- logística, carga, inventario y distribución de suministros;
- preparación y administración de botiquines;
- primeros auxilios y control de hemorragias;
- estabilización y evacuación de heridos;
- asistencia táctica, cobertura y coordinación;
- análisis del entorno y preparación de rutas;
- apoyo mágico, protección, barreras, restauración parcial o mejora de aliados, si tiene conocimiento y capacidad;
- observación del enemigo y transmisión de información útil;
- administración de consumibles y recursos durante enfrentamientos.

No todos los Support tienen que dominar todas estas áreas. Pueden existir especializaciones logísticas, médicas, tácticas, arcanas o mixtas.

### 19.3. No dependencia obligatoria de una clase

Un grupo puede viajar sin Sanador o Support. La ausencia de esos roles no detendrá la simulación ni hará imposible toda recuperación; implicará que el grupo deberá asumir limitaciones, riesgos y alternativas compatibles con sus recursos y conocimientos.

Todos pueden aprender primeros auxilios básicos. La clase Support/Sanador mejora predisposición y dominio en sus ámbitos, pero no monopoliza ayuda elemental.

### 19.4. Aprendizaje y especialización

Cualquier individuo con capacidad y acceso a enseñanza puede aprender primeros auxilios u otras técnicas. La especialización proporciona ventajas según dominio, equipo y experiencia, no un monopolio absoluto de una acción básica.

---

# PARTE VII — RESOLUCIÓN TÁCTICA Y CONDUCTA

## 20. Combate en tiempo real continuo

El combate se desarrolla en **tiempo real continuo**, no por turnos. Los combatientes pueden moverse, observar, atacar, defender, esquivar, preparar formulaciones, interrumpir y cambiar de intención mientras el enfrentamiento continúa.

El motor puede evaluar decisiones y condiciones en intervalos internos o eventos discretos para mantener rendimiento y consistencia, pero la experiencia temporal del combate no se divide en turnos obligatorios. Las acciones físicas requieren duración, trayectoria, aceleración, preparación y recuperación según SR-07.

La simulación debe ser independiente de FPS. Variar la frecuencia de renderizado no puede alterar arbitrariamente el resultado físico. Las ventanas de recuperación, retrasos entre acciones, tiempos de animación y cast deben corresponder al modelo lógico.

### 20.1. Variables del enfrentamiento

La resolución podrá considerar:

- distancia, alcance, posición, orientación y ángulo;
- velocidad, aceleración, reacción, iniciativa situacional y tiempo de recuperación;
- visibilidad, percepción, atención, concentración y sorpresa;
- trayectoria y geometría del ataque;
- masa, impulso, fuerza, potencia, técnica y dominio;
- arma, armadura, material, estado y cobertura del equipo;
- zona anatómica alcanzada;
- lesión previa, fatiga, dolor, sangrado, shock y estabilidad;
- suelo, pendiente, obstáculos, iluminación, sonido, clima y espacio disponible;
- número de participantes, apoyo, formación y coordinación;
- información disponible, experiencia, aprendizaje, miedo, motivaciones y objetivos;
- reservas físicas y arcanas, formulación, concentración y condiciones de ejecución.

No todas las variables deben recalcularse en cada fotograma. Sin embargo, las condiciones relevantes deben actualizarse a tiempo para que el sistema no ignore un esquive, una interrupción, una pérdida de equilibrio o una acción que cambie el enfrentamiento.

## 21. Tipos de acción

El sistema podrá representar acciones como atacar, bloquear, parar, esquivar, desplazarse, retroceder, perseguir, apuntar, cubrir, proteger a otra entidad, interrumpir, canalizar, lanzar, asistir, estabilizar, retirarse, rendirse, negociar o cambiar de objetivo.

La lista es abierta. Una acción requiere capacidades, recursos, tiempo, información y condiciones compatibles.

## 22. Entorno y espacio de combate

### 22.1. Cualquier espacio válido

Todo espacio transitable o utilizable podrá convertirse en zona de combate. Los pasillos estrechos, puertas, habitaciones pequeñas, calles, escaleras, puentes, bosques y cámaras de mazmorra no quedan excluidos.

### 22.2. Restricciones geométricas

La anchura, altura, longitud, obstáculos, visibilidad, material y estabilidad del espacio pueden impedir o limitar determinadas armas, movimientos, formaciones y técnicas.

### 22.3. Consecuencias ambientales

El combate puede alterar el entorno: romper, deformar, incendiar, desplazar, bloquear, contaminar, inundar o marcar superficies, cuando la física y las capacidades lo permitan. Los cambios relevantes serán persistentes conforme a SR-07 y SR-04.

## 23. IA, aprendizaje y adaptación de combatientes

Los NPC, monstruos y jugadores deben poder aprender del combate dentro de sus capacidades. El aprendizaje forma parte de la inteligencia multidimensional de SR-01/SR-03 y no se limita a subir una estadística o desbloquear una habilidad.

### 23.1. Aprendizaje de patrones del adversario

Un combatiente puede observar y registrar patrones de otro individuo, por ejemplo:

- frecuencia, dirección, distancia y momento de sus esquives;
- intervalo entre esquives y acciones posteriores;
- tendencia a bloquear, parar, retroceder, contraatacar o perseguir;
- preferencias de arma, postura, alcance y combinación de ataques;
- objetivos anatómicos que suele buscar;
- hábitos de preparación, interrupción o cancelación de hechizos;
- palabras, fórmulas o familias de hechizos que emplea con frecuencia;
- respuesta ante presión, heridas, pérdida de aliados o escasez de recursos;
- rutas de retirada, patrones de movimiento y uso del terreno.

La observación debe tener una fuente real: percepción propia, experiencia directa, comunicación fiable, registro consultado u otro canal válido. El combatiente no conoce patrones que nunca haya podido observar o inferir.

**Modelo de evidencia de referencia:** cada patrón recibe evidencia acumulada ponderada por claridad. Una observación directa y clara aporta 1–2 puntos; una observación parcial o confusa, 0.25–0.75. La escala inicial se interpreta así: 0–2, sin conclusión estable; 3–5, hipótesis que justifica una prueba imperfecta; 6–9, adaptación funcional parcial; 10 o más, patrón confirmado en circunstancias comparables. Para declarar adaptación funcional se recomiendan al menos tres oportunidades distinguibles; para confirmación, cinco oportunidades distribuidas en dos encuentros o contextos, salvo evidencia excepcionalmente clara. La capacidad de aprendizaje mejora la calidad de inferencia, pero no elimina la necesidad de observar. Evidencia contradictoria reduce la confianza y puede invalidar una adaptación.

### 23.2. Adaptación táctica progresiva

Cuando dispone de observaciones suficientes y capacidad de aprendizaje pertinente, una entidad PUEDE ajustar su comportamiento para explotar hábitos observados. Por ejemplo, un monstruo que observe que un aventurero esquiva repetidamente en la misma dirección y queda expuesto al terminar el movimiento puede retrasar su ataque, preparar un segundo ataque o cubrir la trayectoria de salida.

Otros ejemplos posibles:

- contra un bloqueador recurrente, cambiar ángulo, usar fintas, ataques de agarre o presión sobre recursos;
- contra un arquero que mantiene distancia, buscar cobertura, interrumpir línea de visión o forzar terreno cerrado;
- contra un combatiente que siempre contraataca después de bloquear, retrasar el siguiente golpe o provocar una respuesta prematura;
- contra un usuario de magia que repite un cántico largo, aumentar presión, intentar interrumpir o aprovechar el tiempo de preparación;
- contra un objetivo que usa repetidamente una misma ruta de escape, anticipar puntos de paso cuando exista información suficiente;
- contra una formación que protege siempre al mismo integrante, crear distracciones o cambiar el objetivo si la percepción y capacidad táctica lo permiten.

La adaptación no es instantánea ni omnisciente. Requiere observación, interpretación, memoria, aprendizaje y oportunidad de ejecutar una respuesta. Puede ser incorrecta, tardía o contraproducente. Un patrón puede cambiar, y el adversario puede modificar su estilo para contrarrestar la adaptación.

### 23.3. Diferencias individuales y monstruos élite/inteligentes

La capacidad de aprendizaje y las aptitudes específicas determinan en parte la rapidez con la que un monstruo o individuo reconoce patrones y modifica su estrategia. Algunos monstruos pueden aprender mucho más rápido que otros; esa diferencia puede ser un rasgo destacado de élites o criaturas inteligentes.

No todo monstruo élite tiene que ser inteligente del mismo modo, ni toda criatura inteligente tiene que ser físicamente poderosa. El sistema debe mantener separados fuerza, antigüedad, aprendizaje, memoria, percepción, razonamiento y experiencia.

Un monstruo común puede reaccionar por instinto o aprender un hábito simple. Un monstruo excepcional puede reconocer rutinas complejas, preparar contramedidas, recordar enfrentamientos anteriores y variar estrategias con mayor rapidez, si su perfil lo permite.

### 23.4. Aprendizaje recíproco del jugador

Los jugadores también pueden observar enemigos, reconocer patrones, aprender debilidades, ajustar tiempos y desarrollar contramedidas. El aprendizaje del jugador debe derivarse de práctica, atención, conocimiento y experiencia del personaje; no únicamente de que la persona detrás de la pantalla haya visto una animación.

La interfaz puede facilitar la comprensión, pero no conceder conocimiento al personaje sin una fuente válida. La progresión puede incluir conocimiento explícito, memoria procedimental, dominio y reconocimiento de patrones.

### 23.5. Conducta autónoma

Los NPC y monstruos deberán decidir y actuar según su información, capacidades, memoria, objetivos, personalidad, relaciones, entrenamiento, fisiología y circunstancias.

Podrán elegir combatir, evitar, acechar, retirarse, pedir ayuda, proteger a otros, rendirse, negociar, perseguir, cambiar de objetivo o aprovechar el terreno cuando resulte coherente con su perfil y conocimiento.

No habrá una obligación universal de luchar hasta morir. La conducta depende del individuo o especie. Un monstruo no necesita conocer el nivel del jugador ni el estado global del mundo; actúa con la información que pueda adquirir.

Los resultados de un combate no se escribirán por adelantado. El motor narrativo no impondrá victorias, derrotas, rescates ni muertes para obtener una historia conveniente.

---

# PARTE VIII — MUERTE, RESURRECCIÓN Y REENCARNACIÓN EN EL CONTEXTO DEL COMBATE

## 24. Sin reaparición ordinaria

La muerte no activa un respawn automático. El lugar de muerte, estado del cuerpo, inventario, equipo, testigos, consecuencias sociales e históricas permanecen sujetos a los sistemas correspondientes.

La muerte ordinaria de un monstruo termina la continuidad de ese individuo. Si la Mazmorra genera posteriormente otro monstruo de la misma especie o tipo, será una entidad distinta, con nueva identidad y trayectoria. La generación de un nuevo monstruo no resucita ni reconstruye al anterior. Cualquier posible reversión extraordinaria o reencarnación deberá cumplir por separado SR-01 §§7–8 y un mecanismo expresamente definido; no se presume por el mero hecho de que la Mazmorra vuelva a generar esa especie.

## 25. Resurrección extraordinaria

La posibilidad de reversión prevista por SR-01 no implica que cualquier Sanador pueda resucitar a cualquier persona. El mecanismo debe definirse, conocerse o descubrirse dentro del mundo, cumplir condiciones y producir consecuencias. Su disponibilidad puede ser extremadamente rara.

## 26. Reencarnación y memoria de combate

Una futura reencarnación podrá conservar, de forma total o parcial, recuerdos procedimentales, estilos de combate, reconocimiento de patrones, conocimientos tácticos y experiencias de enfrentamientos conforme a SR-01 §8 y SR-03 §§4, 17–24.

La experiencia pasada puede dar ventaja, pero no transfiere automáticamente el cuerpo, fuerza, velocidad, reservas, equipo o dominio físico anterior. El nuevo individuo deberá adaptarse a su nueva anatomía y condiciones.

---

# PARTE IX — EVENTOS, PROCEDENCIA Y DATOS

## 27. Registro causal del combate

Todo cambio persistente provocado por combate deberá registrar, según corresponda:

- entidades participantes y sus identidades;
- momento y ubicación;
- contexto y condiciones relevantes;
- acciones y comandos;
- atacante, objetivo y medio empleado;
- zona afectada y tipo de daño;
- HP y recursos antes/después cuando se apliquen;
- lesiones, sangrado, incapacitación y efectos;
- defensas, protecciones, cobertura y condición de armadura/equipo por zona, además de resistencias y contramedidas;
- estados activos, buffs/debuffs y cambios de atributos;
- impacto emocional del acontecimiento y respuestas individuales pertinentes;
- patrones observados, inferencias de conducta y adaptaciones tácticas relevantes;
- formulación de hechizos, palabras seleccionadas, orden, idioma, resultado e interrupciones;
- tratamiento y recuperación;
- resultado confirmado y consecuencias posteriores;
- procedencia, autoridad y relaciones causales.

El registro no necesita almacenar cada fotograma. Debe conservar la información necesaria para reconstruir el resultado lógico y su cadena causal con un nivel de fidelidad declarado.

## 28. Separación entre lógica y representación

El daño se calcula en el sistema lógico. Efectos visuales, animaciones, indicadores HP/MP, sonidos, sangre, partículas y mensajes son representaciones del estado confirmado.

La barra de HP no sustituye la inspección de heridas. Un efecto visual de corte no prueba amputación. La animación de un hechizo no prueba que su efecto haya sido ejecutado.

## 29. Contratos mínimos

El modelo lógico deberá poder representar, cuando aplique:

- HP actual/máximo o equivalente, con definición de su significado;
- MP/reserva arcana actual/máxima o equivalente, si existe;
- estado general de combate;
- anatomía y zonas corporales;
- integridad/función de cada zona relevante;
- heridas y tipo de daño;
- hemorragia o pérdida de fluido funcional;
- dolor, shock, fatiga y estados fisiológicos;
- pérdida o destrucción de extremidades;
- defensas, armadura, resistencia e inmunidad;
- acciones, comandos, objetivos y decisiones;
- capacidad de aprendizaje, aptitudes por dominio, resiliencia emocional y memoria de combate cuando apliquen;
- clases, especializaciones, predisposiciones de aprendizaje y dominio por disciplina;
- vocabulario mágico conocido, fórmulas aprendidas, orden sintáctico, nivel de dominio y estado de autocompletado;
- patrones tácticos observados y modelos de comportamiento del adversario;
- tratamientos, herramientas, recursos y resultados;
- estados de muerte, reanimación, resurrección o reencarnación cuando procedan;
- causa, procedencia, cronología y eventos relacionados.

No todas las entidades usarán todos los campos. Los campos inaplicables deberán ser explícitamente no aplicables, no valores ficticios.

---

# PARTE X — PRUEBAS OBLIGATORIAS Y CRITERIOS DE CUMPLIMIENTO

## 30. Experimentos fundamentales

1. Un combatiente conserva HP, pero pierde un brazo: el sistema registra hemorragia y pérdida funcional sin declarar automáticamente que el brazo sigue presente.
2. Un botiquín o tratamiento adecuado reduce una hemorragia: se registra qué efecto detuvo y qué lesiones permanecen.
3. Un tratamiento insuficiente no elimina una herida crítica por conveniencia.
4. Un torniquete no resuelve una hemorragia incompatible con su aplicación.
5. Una curación de HP no reconstruye automáticamente una extremidad.
6. Una técnica curativa avanzada puede restaurar una extremidad si cumple sus condiciones, costes y mecanismo.
7. Una lesión catastrófica de estructuras vitales puede causar muerte aunque queden HP, si la regla de daño letal se cumple.
8. HP = 0 produce el resultado que se apruebe en SR-09 y no se contradice con SR-01.
9. La muerte no genera respawn automático.
10. Una resurrección excepcional requiere condiciones verificadas y no se confunde con respawn.
11. Una entidad no biológica no recibe hemorragia o heridas biológicas que no correspondan a su naturaleza.
12. Un arma larga puede quedar limitada en un corredor estrecho; el mismo combatiente puede maniobrar de otra forma en una cámara amplia.
13. Una entidad decide retirarse o rendirse si sus condiciones, conocimiento y motivaciones conducen a ello; no queda obligada a luchar hasta morir.
14. La pérdida de una extremidad modifica las acciones posibles y puede modificar decisiones futuras.
15. El modelo visual no puede confirmar consecuencias que el sistema lógico no haya validado.
16. La misma situación, con las mismas reglas y entradas deterministas, produce un resultado reproducible.
17. HP = 0 puede llevar a resultados diferentes según daño y entidad, sin contradicción con las lesiones letales.
18. Dos entidades con diferente anatomía reciben consecuencias distintas ante el mismo mecanismo de daño cuando su estructura lo justifica.
19. Una armadura protege zonas cubiertas y puede dejar otras expuestas; la interfaz resume sin borrar la localización.
20. Un individuo con formación básica puede intentar primeros auxilios; una intervención avanzada exige formación y condiciones.
21. Una prótesis recupera determinadas funciones sin declararse idéntica a una extremidad biológica original.
22. Un Support puede aportar logística, primeros auxilios y apoyo táctico/mágico según su dominio, sin que el grupo dependa obligatoriamente de esa clase.
23. El modo fácil, si está activado, conserva un perfil de reglas separado y no modifica una partida hardcore.
24. El combate avanza en tiempo real continuo y el resultado no cambia por variar el FPS de presentación.
25. Un combatiente con observación y aprendizaje suficientes identifica un patrón repetido y puede adaptar su táctica; otro sin información suficiente no puede anticiparlo mágicamente.
26. El adversario puede contrarrestar una adaptación posterior si observa el nuevo patrón del combatiente.
27. El aprendizaje de un hechizo depende de capacidad, aptitud arcana/lingüística, estudio, práctica, comprensión y retroalimentación; no aparece por clase o nivel automáticamente.
28. El sistema de magia presenta solo palabras y estructuras conocidas o disponibles para el personaje en la interfaz de formulación.
29. Alterar el orden de palabras de una fórmula puede producir fallo, interrupción o resultado distinto conforme a la gramática validada.
30. Una formulación española recibe la reducción de eficacia definida por las reglas de traducción; la interfaz puede explicar su significado sin cambiar la lengua pronunciada.
31. El autocompletado solo aparece después de suficiente uso correcto y dominio de la fórmula; no elimina el tiempo de cántico ni el coste.
32. La duración de casteo responde, entre otros factores, a longitud y complejidad de la formulación; no se reduce a una espera fija arbitraria.
33. El pánico no desordena siempre las palabras ni fuerza siempre un fallo; su interferencia es probabilística y depende de resiliencia, concentración, dominio e intensidad.
34. Un acontecimiento emocionalmente intenso puede producir respuestas diferentes en dos supervivientes; el IEA del hecho no sustituye la experiencia individual.
35. Un jugador y un NPC pueden adquirir y aplicar aprendizaje táctico; la interfaz no concede conocimiento sin adquisición válida.
36. La reencarnación puede conservar recuerdos procedimentales o estilos de combate si el mecanismo de continuidad lo permite, sin transferir automáticamente el cuerpo o dominio físico anterior.

## 31. Criterios de conformidad normativa

El diseño de SR-09 v1.0 se considera completo para aprobación cuando mantiene, como mínimo, estas condiciones:

- HP nunca sustituye la anatomía, la integridad localizada ni las condiciones letales.
- HP = 0 conduce a un estado definido por el daño y la naturaleza de la entidad; no activa una muerte universal automática.
- Una lesión catastrófica puede ser mortal aunque queden HP.
- Armadura, daño, heridas y consecuencias se resuelven por zona y mecanismo real.
- Sangrado, incapacidad, estados críticos, tratamiento y secuelas conservan su propia procedencia.
- La recuperación de HP no reconstruye por sí sola tejidos, órganos o extremidades.
- La muerte ordinaria no genera respawn en el modo Hardcore; toda excepción depende de SR-01.
- El Perfil Protegido constituye un conjunto separado de reglas y no modifica partidas Hardcore.
- MP es una representación común de interfaz, no una fisiología universal.
- El combate es continuo, en tiempo real e independiente de FPS de presentación.
- Jugadores, NPC y monstruos pueden aprender según información y capacidades reales; no conocen datos que nunca adquirieron.
- Adaptación táctica requiere evidencia, memoria, inferencia y capacidad de ejecutar una contramedida.
- La formulación mágica respeta Veyrath, la secuencia de palabras, tiempo, costes e interrupciones definidos por SR-07 y el Anexo A.
- IEA describe el acontecimiento; la vivencia y respuesta se calculan individualmente, sin imponer pánico o trauma.
- Las clases son orientaciones de aprendizaje y práctica, no bloqueos ni paquetes de poderes automáticos.
- Lógica, causalidad y representación visual permanecen separadas.

## 32. Registro de decisiones incorporadas

Las siguientes reglas provienen de decisiones expresas del autor ya comunicadas y quedan consolidadas en SR-09:

1. HP = 0 depende del tipo de daño y entidad.
2. La letalidad de una lesión craneal depende de fuerza, arma, ángulo, trayectoria, protección y anatomía.
3. La recuperación puede usar cirugía, prótesis, reimplantación, reconstrucción biológica o arcana compatible.
4. Todos pueden aprender primeros auxilios básicos; las intervenciones avanzadas requieren formación.
5. Support combina logística, primeros auxilios, asistencia táctica y soporte mágico según especialización.
6. MP tendrá una representación numérica común, con mecanismos internos diferentes.
7. Puede existir un perfil de dificultad separado que reduzca la muerte permanente.
8. El combate es en tiempo real continuo.
9. La curación avanzada depende del mecanismo, la lesión y la capacidad real del sanador.
10. La resurrección extraordinaria permanece sujeta a SR-01.
11. Un monstruo muerto no reaparece como el mismo individuo; una generación posterior es una identidad distinta.
12. La armadura protege zonas concretas y puede resumirse en interfaz sin perder su cobertura real.
13. La capacidad de aprendizaje se aplica a jugadores, NPC y monstruos.
14. Monstruos y jugadores aprenden patrones y pueden adaptar tácticas cuando existe evidencia.
15. Los hechizos se expresan mediante palabras ordenadas en oraciones; no por sílabas sueltas.
16. El uso de español en lugar de Veyrath tiene una pérdida de eficacia graduada.
17. El autocompletado requiere comprensión y dominio de una fórmula y conserva el tiempo de casteo.
18. Los buffs, debuffs y estados alterados tienen causas, duración y condiciones.
19. Se incorporan IEA y Resiliencia emocional; el pánico es probabilístico.
20. Clases de combate, magia, sigilo, soporte, fabricación, exploración y profesiones son abiertas y no excluyentes.

## 33. Criterios de cierre incorporados y aprobados en v1.0

Los siguientes criterios y parámetros iniciales forman parte de la edición aprobada v1.0. Son referencias normativas de partida; los valores expresamente identificados como calibrables pueden ajustarse mediante pruebas sin reabrir la estructura normativa:

1. **Escalas de aprendizaje:** capacidad general y aptitud por dominio de 0 a 100; se calcula el Índice de Aprendizaje Efectivo mediante la fórmula incorporada en §5.1 y el Anexo A.
2. **Dominio:** etapas de familiarización, comprensión, ejecución básica, competencia, dominio y dominio experto; los umbrales de referencia son 0–19, 20–39, 40–59, 60–79, 80–94 y 95–100.
3. **Resiliencia emocional:** nombre definitivo del atributo, escala 0–100, sin inmunidad emocional.
4. **Impacto emocional:** IEA de 0–10 con categorías descriptivas; impacto personal ajustado por exposición y relevancia individual.
5. **Adaptación:** evidencia ponderada por claridad; hipótesis desde 3 puntos, adaptación parcial desde 6 y patrón confirmado desde 10, con oportunidades de observación diferenciadas.
6. **Perfil de dificultad:** Hardcore es el modo canónico. Perfil Protegido es una variante del mundo elegida al crearlo, con rescate/recuperación asistidos cuando la causalidad permite continuidad y con consecuencias persistentes.
7. **Clases:** no hay una única ranura de clase ni un máximo universal; los nombres se reconocen por práctica, conocimientos y trayectoria, y no conceden habilidades automáticamente.
8. **Magia:** el Anexo A de SR-09 es la especificación subordinada del catálogo Veyrath de 72 hechizos para pisos 1–5; SR-07 conserva autoridad superior.

## 34. Parámetros de calibración y datos reservados

Los siguientes elementos se ajustarán mediante pruebas, fichas de especie, armas, hechizos y datos del mundo. No impiden aprobar la estructura normativa de SR-09:

- HP máximos, reserva física, resistencia y umbrales específicos por especie o entidad.
- Coeficientes de daño y velocidad de deterioro por arma, material, ataque y localización.
- Tasa de hemorragia y compensación fisiológica por especie.
- Duración de estados críticos, agonía y ventanas de intervención según lesión y entidad.
- Tiempo, coste, calidad, riesgo y secuelas de cirugía, prótesis, regeneración y reconstrucción por tecnología y cultura.
- Curvas exactas de recuperación fisiológica y arcana.
- Probabilidad numérica de pánico, duración de estados emocionales y secuelas individuales.
- Coeficientes de retención, olvido y transferencia de aprendizaje táctico.
- Resistencia, alcance y compatibilidad de cada hechizo, material y criatura.
- Reglas institucionales específicas de adquisición de títulos, rangos, certificaciones y reconocimiento de clases.

Cada parámetro deberá tener unidad, ámbito, procedencia, versión y prueba asociada. No se utilizarán valores genéricos sin declarar su alcance ni resultados narrativos forzados para ocultar un mecanismo ausente.

---

# PARTE XII — DECLARACIÓN NORMATIVA Y CONTROL DE CAMBIOS

Esta es la edición oficial SR-09 v1.0, aprobada expresamente por el autor el 2026-11-20. Los principios, responsabilidades y reglas estructurales están cerrados; los valores que siguen abiertos se identifican expresamente como parámetros de calibración o datos propios de entidades y catálogos.

SR-09 no altera SR-01 a SR-08. En particular:

- la muerte extraordinariamente reversible, la resurrección y la reencarnación mantienen las distinciones de SR-01 §§7–8;
- el aprendizaje, memoria, inteligencia multidimensional y continuidad mixta respetan SR-03;
- la formulación verbal/escrita, lengua arcana, traducción, interrupción, fuentes y costes respetan SR-07 §§24–39;
- anatomía, fisiología, lesiones, estados biológicos, monstruos y entidades activas no biológicas respetan SR-08;
- las clases no convierten una predisposición de aprendizaje en una capacidad automática ni en una restricción absoluta.

Toda mecánica nueva deberá conservar causalidad, procedencia y validación. Un resultado visual no prueba un resultado lógico; un botón de interfaz no reemplaza el conocimiento, las palabras, el tiempo, los costes ni la ejecución del personaje.

La finalidad de SR-09 es un combate en tiempo real donde HP y MP sean útiles, pero no oculten el cuerpo ni el funcionamiento de la magia; donde lesiones, miedo, aprendizaje y preparación cambien las decisiones; donde monstruos y jugadores puedan adaptarse; donde curar implique mecanismos y recursos; y donde la muerte conserve consecuencias persistentes, sin respawn ordinario.

**Declaración de estado:** SR-09 v1.0 fue aprobada expresamente por el autor el 2026-11-20. Los parámetros declarados como CALIBRACIÓN o RESERVADO permanecen sujetos a las pruebas y desarrollos subordinados previstos en el documento.


# ANEXO A — FORMULACIÓN MÁGICA, CÁNTICOS Y AUTOCOMPLETADO

Este anexo establece el contrato de combate para formular magia. El vocabulario, la gramática Veyrath, el aprendizaje detallado, los tiempos base, costes de referencia y el catálogo de 72 hechizos de los pisos 1–5 se desarrollan en el documento subordinado **SR-09 — Anexo A: Lengua arcana Veyrath y catálogo de magia, versión 1.0 oficial aprobada**. Si hubiera divergencia, prevalecen SR-07 y el cuerpo normativo de SR-09.

## A.1. Hechizos como oraciones de palabras completas

Los hechizos iniciales se formulan como oraciones construidas con palabras independientes, cada una con función y significado. No son combinaciones de sílabas ni abreviaturas. El catálogo de pisos 1–5 utiliza nueve palabras por fórmula como estructura de referencia. Las operaciones de mayor complejidad podrán requerir oraciones más largas y cláusulas adicionales.

## A.2. Conocimiento y construcción consciente

El personaje debe adquirir palabras, comprender sus funciones, aprender la gramática y dominar cada oración. Conocer todas las palabras aisladas no equivale a conocer cualquier hechizo. El jugador solo puede seleccionar palabras conocidas legítimamente; un grimorio o maestro transmite información, no dominio instantáneo. El orden gramatical es obligatorio y una alteración puede invalidar, debilitar o transformar la operación solo cuando la nueva secuencia tenga un significado válido.

## A.3. Traducción y lengua original

Veyrath es la lengua arcana de referencia. La interfaz puede traducir al español para comprensión, pero la traducción visible no cambia el idioma que formula el personaje. Los valores iniciales de pérdida de eficacia frente a Veyrath son: 30% para traducción literal no comprendida; 15% para traducción comprendida y practicada; 5% para dominio lingüístico alto y traducción adaptada; 0% de penalización lingüística para Veyrath correctamente dominado. La pérdida se manifiesta según el hechizo —coste, tiempo, precisión, potencia, alcance, duración o estabilidad— sin acumular todas las penalizaciones a la vez. Son valores iniciales calibrables.

## A.4. Aprendizaje y etapas de dominio

El aprendizaje utiliza una escala de 0 a 100 y el Índice de Aprendizaje Efectivo: `LE = 0.35C + 0.25A + 0.15K + 0.10I + 0.15F`. Las etapas de referencia son: 0–19 familiarización; 20–39 comprensión inicial; 40–59 ejecución básica; 60–79 competencia; 80–94 dominio; 95–100 dominio experto. El progreso requiere exposición válida, comprensión, práctica, retroalimentación y prerrequisitos. Repetición mecánica sin corrección produce rendimientos decrecientes.

## A.5. Autocompletado

El autocompletado se habilita por fórmula concreta, no por nivel global. Como umbral inicial se recomienda dominio igual o superior a 75/100, al menos cuatro ejecuciones correctas en condiciones distinguibles y práctica distribuida en un mínimo de dos sesiones o encuentros. La complejidad puede elevar el umbral. Autocompletar inserta una oración ya dominada, pero el personaje sigue pronunciándola/canalizándola, consume recursos y conserva el tiempo de casteo y la posibilidad de interrupción.

## A.6. Tiempo de casteo y costes de referencia

El tiempo base se estima mediante `T = 0.8 + (0.22 × N) + (0.35 × C) + (0.75 × P)` segundos. `N` es el número de palabras; `C` es la complejidad operacional (1–5); `P` es la exigencia postural (0–2). Heridas, fatiga, miedo, concentración, pronunciación, flujo y entorno pueden aumentar el tiempo; el dominio reduce vacilaciones y errores, pero no vuelve instantáneo el hechizo.

Costes iniciales sobre la reserva arcana funcional del individuo: hechizo menor 2–4%; ofensivo/control estándar 4–7%; defensa o curación relevante 5–10%; área, sostenido o alta complejidad 8–14%; mantenimiento 1–3% cada diez segundos, según magnitud. La reserva puede aparecer como MP en interfaz, sin imponer mecanismos internos idénticos.

## A.7. Interrupción y pánico

La interrupción se resuelve según la fase: antes de canalizar puede no haber coste significativo; durante formulación temprana se pierde una fracción pequeña; durante canalización puede perderse una parte importante o toda la energía comprometida; durante liberación el efecto puede salir incompleto, desviarse, debilitarse o disiparse. La explosión o lesión del lanzador nunca es automática: requiere un mecanismo.

El pánico puede perturbar atención, memoria de trabajo, selección, pronunciación, ritmo y concentración. En una formulación manual, la interfaz puede mostrar desplazamiento o reordenamiento de opciones como representación probabilística, nunca como cambio de la gramática objetiva ni pérdida de palabras aprendidas. El autocompletado reduce errores de selección, pero no elimina interrupciones ni pérdida de concentración. NPC y monstruos usan las mismas reglas cognitivas sin necesitar la interfaz del jugador.

## A.8. Contrato mínimo de un hechizo

Cada hechizo debe declarar identificador, nombre, versión lingüística, oración Veyrath, palabras requeridas, prerrequisitos, operador, dominio, forma, objetivo, tiempo, complejidad, postura, coste, fuente, mantenimiento, alcance, trayectoria, área, precisión, potencia, tipo de interacción, duración, resistencias, interrupciones, fallos posibles, condiciones anatómicas y requisitos de entorno/material.

## A.9. Pruebas mínimas

1. Solo se muestran palabras conocidas legítimamente.
2. La oración válida y ordenada se valida; una oración alterada se resuelve según gramática y semántica, no al azar.
3. Una traducción española aplica la pérdida de eficacia correspondiente; la ayuda de interfaz no modifica el idioma de ejecución.
4. El autocompletado exige dominio de esa oración y conserva tiempo, coste y vulnerabilidad.
5. Pánico e interrupciones afectan probabilísticamente la ejecución.
6. NPC y monstruos necesitan conocimiento adquirido para usar la fórmula.
7. Ningún hechizo anula la causalidad, anatomía, coste o límites de SR-07 y SR-08.


# GLOSARIO NORMATIVO DE SR-09 v1.0

- **HP:** reserva cuantificable de supervivencia/continuidad funcional cuyo agotamiento no sustituye el análisis anatómico ni determina por sí solo la muerte universal.
- **MP:** representación numérica común de recursos arcanos cuando corresponda; los mecanismos internos pueden diferir.
- **Capacidad de aprendizaje:** dimensión individual que influye en adquirir, comprender, retener, transferir y aplicar conocimientos; no concede dominio automático.
- **Resiliencia emocional:** dimensión individual (0–100 cuando aplica) que modula la capacidad de procesar impacto emocional y mantener/recuperar estabilidad funcional; no equivale a inmunidad emocional.
- **IEA:** Impacto Emocional del Acontecimiento, medida del peso emocional potencial del hecho; su efecto real es individualizado.
- **Estado alterado:** condición con fuente y reglas que modifica capacidades, funciones, percepciones, recursos o conducta.
- **Adaptación táctica:** modificación de la estrategia de un combatiente basada en patrones observados e inferidos del adversario.
- **Autocompletado:** asistencia de interfaz para insertar una oración concreta que el personaje ya conoce y domina; no equivale a hechizo instantáneo.
- **Clase:** perfil de predisposición, aprendizaje, formación o función; no es bloqueo absoluto ni concesión automática de habilidades.

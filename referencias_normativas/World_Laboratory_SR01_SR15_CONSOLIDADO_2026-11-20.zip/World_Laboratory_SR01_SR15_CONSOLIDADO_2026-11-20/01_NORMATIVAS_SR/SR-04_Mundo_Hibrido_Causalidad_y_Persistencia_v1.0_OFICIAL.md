# SR-04 — Mundo híbrido, causalidad y persistencia

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5  
**Dependencias:** SR-01, SR-02 y SR-03.

# PARTE I — CONSTITUCIÓN DEL MUNDO HÍBRIDO

## 1. Ley de realidad única

El universo posee una historia objetiva compartida. Los jugadores pueden experimentar encuentros, misiones, relaciones y descubrimientos diferentes, pero esas experiencias deben coexistir con una realidad global coherente. No se crean copias contradictorias de una entidad global solo para satisfacer historias diferentes.

El jugador es un participante del mundo. No puede detener el tiempo global, duplicar individuos u objetos compartidos, deshacer hechos confirmados ni modificar entidades sin autoridad.

## 2. Historias diferentes, realidad común

Dos jugadores pueden conocer una misma región en momentos diferentes. Uno puede haberla explorado; otro puede ignorarla. La región ya existía; lo que cambia es su conocimiento. El primero puede conservar un descubrimiento privado hasta comunicarlo.

Un acontecimiento global único no puede tener resultados incompatibles. Una historia alternativa o simulación debe identificarse como representación, rama experimental o instancia con identidad diferenciada.

## 3. Tres capas fundamentales

### 3.1. World Canon

Estado objetivo compartido: geografía, regiones, ciudades, mazmorra, poblaciones, entidades globales, acontecimientos, organizaciones, economía, recursos, descubrimientos difundidos, ambiente y reglas.

### 3.2. Personal Chronicle

Trayectoria de un jugador o entidad: recuerdos, relaciones privadas, decisiones, descubrimientos no compartidos, misiones personales, consecuencias individuales y experiencias.

### 3.3. Instance / Session

Contexto de ejecución de expedición, desafío, batalla, misión personal, encuentro, simulación o experiencia temporal. Puede tener persistencia según el tipo, pero no modifica automáticamente el canon global.

Son capas de una misma realidad, no tres mundos desconectados.

# PARTE II — ALCANCE Y AUTORIDAD

## 4. Clasificación de acontecimientos

- **Global:** afecta al universo compartido.
- **Regional:** afecta a zona, población o territorio.
- **Comunitario:** afecta a una sociedad u organización.
- **Grupal:** afecta a participantes de una expedición.
- **Individual:** afecta a la trayectoria de una entidad.
- **Efímero:** presentación temporal sin cambio duradero.

El alcance no es igual a importancia. Un hecho individual puede ser vital para una persona; un hecho regional puede terminar alterando el mundo.

## 5. Alcance y visibilidad

El alcance determina dónde tiene consecuencias un evento. La visibilidad determina quién lo conoce. Un asesinato puede ser un hecho global y permanecer secreto; la población puede creer que el gobernante sigue vivo. Deben separarse hecho, testigos, sospechas, rumores y creencias.

La visibilidad podrá ser privada, para participantes, grupo/familia, organización, región, pública o restringida. La información puede filtrarse, olvidarse o difundirse por mecanismos válidos.

## 6. Ámbito de entidades

### 6.1. Globales

Identidad compartida en todo el universo: gobernante, criatura única, personaje histórico o NPC importante.

### 6.2. Poblacionales

Individuos pertenecientes a población compartida. Cada uno tiene identidad propia aunque comparta plantilla con otros.

### 6.3. De instancia

Entidades cuya existencia pertenece a una instancia o conjunto de instancias relacionadas.

### 6.4. Personales

Entidades vinculadas a una historia individual o propietario definido. No se duplican entre jugadores.

### 6.5. Plantillas y arquetipos

Definiciones reutilizables, no individuos vivos.

## 7. Entidad canónica y representación contextual

Una entidad global puede representarse en escenas, interfaces o recuerdos sin estar físicamente presente en todos esos lugares. Una proyección no es una identidad nueva y no puede duplicar vida, inventario, propiedad, autoridad o recursos.

Un individuo físico global solo tiene una ubicación coherente en cada momento de la cronología. Si una misión requiere una variante independiente, debe utilizar otra identidad de instancia o personal.

## 8. Política de unicidad

Se distinguen único global, único regional, único de instancia, único personal y arquetipo. La clasificación se determina antes de crear una entidad importante. Una criatura excepcional puede ser única global; un guardián de reto puede ser único de instancia.

# PARTE III — ESPACIOS Y SESIONES

## 9. Tipos de espacio

- Espacios abiertos compartidos.
- Espacios de encuentro controlado.
- Espacios de grupo.
- Espacios personales.
- Espacios de simulación.

La geografía puede ser compartida aunque algunos encuentros o interiores utilicen instancias. La mazmorra puede mezclar grandes zonas abiertas, rutas alternativas, cámaras de grupo y encuentros particulares.

## 10. Poblaciones dentro de instancias

Toda criatura mostrada debe clasificarse como individuo global existente, proyección de entidad existente, entidad temporal de encuentro o individuo de población de instancia. Una entidad temporal no genera automáticamente descendencia global. Una entidad global conserva identidad e historia al entrar en un contexto de instancia.

# PARTE IV — CRÓNICAS E INFORMACIÓN

## 11. World Chronicle

Registra acontecimientos objetivos: nacimiento, muerte, desaparición, reencarnación, transformación, descubrimiento, cambio territorial, conflicto, alianza, construcción, destrucción, fabricación, comercio y cambio ecológico. No requiere registrar cada movimiento visual, pero conserva hechos necesarios para reconstrucción y consecuencias.

## 12. Personal Chronicle

Registra vivencias, personas conocidas, relaciones, objetivos, decisiones, pérdidas, descubrimientos, conocimientos, errores y promesas. No se confunde con la verdad objetiva: un aventurero puede recordar un ataque sin conocer su causa real.

## 13. Descubrimiento, creación y difusión

Descubrir una región es adquirir conocimiento de algo que ya existía. Crear una técnica o fabricar un objeto produce algo nuevo. Divulgar es transmitir conocimiento. Son operaciones separadas.

Un descubrimiento mágico puede pertenecer primero al investigador; si se escribe en un grimorio y se comparte, empieza su difusión. La disponibilidad pública no concede dominio automático.

## 14. NPC globales y relaciones diferentes

Un NPC global mantiene una identidad y una memoria coherentes, pero puede tener relaciones distintas con cada jugador: confianza, deuda, desconfianza o secreto. No conoce automáticamente conversaciones privadas que no presenció ni recibió.

Las conversaciones pueden modificar una relación particular; un cambio objetivo como su muerte afecta a todos los ámbitos relacionados.

# PARTE V — CAUSALIDAD ENTRE CAPAS

## 15. Causalidad compartida

Los acontecimientos personales, regionales y globales se conectan mediante causas y consecuencias válidas. Un evento personal puede tener efecto global; uno global puede generar muchas experiencias personales; una instancia puede permanecer aislada.

## 16. Tipos de evento

- **Objetivo:** modifica realidad (muerte, robo, fabricación, destrucción, desplazamiento, propiedad, evolución).
- **Epistemológico:** modifica conocimiento (descubrimiento, aprendizaje, rumor, lectura, hipótesis).
- **Narrativo:** organiza una oportunidad basada en hechos (rescate, investigación, conflicto).
- **De representación:** modifica presentación visual (animación, efecto, reproducción).

Solo los objetivos y otros cambios de dominio autorizados alteran estado objetivo. Los eventos narrativos no falsifican hechos.

## 17. Promoción de eventos personales

Un acontecimiento personal puede adquirir consecuencias compartidas si su naturaleza lo exige.

### 17.1. Promoción automática

Se utiliza cuando la acción modifica directamente una entidad o recurso global y supera validación: muerte de entidad única, destrucción de estructura compartida, transferencia de objeto global.

### 17.2. Promoción por difusión

El conocimiento privado se transmite por publicación, enseñanza, grimorio, comercio, conversación o investigación.

### 17.3. Promoción por impacto

Un evento personal provoca consecuencias fuera de su instancia, por ejemplo un incendio que alcanza estructura compartida.

### 17.4. Aislamiento

Conversación privada, entrenamiento personal o conflicto de entidades personales puede permanecer en su crónica.

## 18. Procedimiento de promoción

1. Registrar hecho o solicitud.
2. Identificar participantes y afectados.
3. Determinar ámbito.
4. Comprobar autoridad.
5. Verificar causalidad.
6. Comprobar conflictos.
7. Validar recursos y consecuencias.
8. Confirmar operación.
9. Registrar en Chronicle.
10. Notificar motores afectados.

Descubrir, divulgar y modificar son operaciones separadas.

# PARTE VI — SINCRONIZACIÓN

## 19. Autoridad global

El servidor o autoridad local del mundo individual controla operaciones del canon. El cliente puede mostrar, solicitar, predecir y guardar datos autorizados, pero no confirma por sí solo cambios globales.

## 20. Reconciliación causal

No basta con el orden de llegada o marca temporal. Se consideran identidad, ámbito, versiones de estado, antecedentes causales, recursos, propiedad, autoridad y conflictos.

### 20.1. Protocolo

1. Comprobar duplicación de solicitud.
2. Identificar ámbito.
3. Identificar entidades.
4. Comprobar versiones y precondiciones.
5. Verificar antecedentes requeridos.
6. Validar capacidad, recursos y propiedad.
7. Detectar operaciones incompatibles.
8. Resolver según reglas del dominio.
9. Confirmar, aislar, compensar o rechazar.
10. Registrar el resultado.

### 20.2. Operaciones repetidas

Una petición repetida no produce varias recompensas o efectos. Cada operación persistente tiene identificador idempotente.

### 20.3. Operaciones compatibles

Dos jugadores pueden descubrir independientemente la misma ruta: existe un único lugar, pero dos registros personales de descubrimiento.

### 20.4. Operaciones incompatibles

Dos jugadores que intentan adquirir un objeto único no pueden recibirlo ambos salvo mecanismo explícito de división/copia. La transferencia se resuelve atómicamente.

### 20.5. Operaciones inválidas

Una acción que depende de un hecho no confirmado puede quedar provisional, aislada o rechazada. No se convierte silenciosamente en hecho global.

## 21. Concurrencia y transacciones

Las operaciones con recursos, propiedad, salud, identidad o estado exclusivo se resuelven de forma controlada. Las operaciones inseparables se confirman como unidad: compra = cobro + transferencia + inventario + registro. Una desconexión no debe dejar estados parciales sin compensación explícita.

# PARTE VII — TIEMPO GLOBAL PERSISTENTE

## 22. Cronología única

El universo posee cronología objetiva. Instancias históricas, simulaciones y reproducciones deben indicar su relación temporal y no convertirse en acontecimientos reales adicionales.

## 23. Tiempo durante la ausencia

El mundo sigue evolucionando durante la desconexión: poblaciones, economía, territorios, organizaciones, NPC, monstruos y procesos ambientales. La precisión puede variar, pero la continuidad causal permanece.

## 24. Niveles de resolución

- Inmediato: combate y acciones rápidas.
- Actividad: rutinas, viajes, trabajo y conversaciones.
- Población: nacimiento, migración, recursos y supervivencia.
- Histórico: sociedades, conflictos y generaciones.

Los niveles comparten una cronología; no son relojes independientes.

## 25. Simulación resumida

Una expedición de varios días puede procesarse mediante etapas agregadas si se respetan recursos, capacidades, riesgos, tiempos y acontecimientos posibles. Al consultar el resultado, el sistema reconstruye la secuencia relevante sin inventar movimientos incompatibles.

## 26. Ausencia y justicia

La persistencia no es castigo arbitrario por desconexión. Las pérdidas pueden ocurrir si existen causas, exposición al riesgo y consecuencias coherentes; no se crean derrotas solo para penalizar ausencia.

## 27. Recuperación temporal

Tras una interrupción del servidor, el sistema recupera estado y eventos confirmados, calcula procesos pendientes según autoridad y conserva orden causal, identidad, recursos y consecuencias. El ritmo exacto del tiempo del mundo se define en especificación posterior.

# PARTE VIII — FUNCIONAMIENTO OFFLINE

## 28. Autoridad local

Un mundo individual offline puede tener su propia autoridad local y guardar estado, crónicas, recursos y acontecimientos en el dispositivo o equipo que lo ejecuta. Dos dispositivos desconectados no pueden mantener una única realidad coordinada sin reconciliación posterior.

## 29. Estado provisional

Una actividad local puede guardar eventos provisionales dentro de su ámbito. No se declaran globales hasta validación.

## 30. Sincronización posterior

Al reconectar se comprueban posibilidad, recursos, continuidad de entidades, cronología, duplicaciones, conflictos y causalidad. Las operaciones incompatibles no se sobrescriben silenciosamente.

El modo offline individual es compatible con la arquitectura; el multijugador y canon compartido necesitan autoridad común. El alcance del offline de producto se decidirá más adelante.

# PARTE IX — NARRATIVA EMERGENTE

## 31. Narrativa derivada de realidad

Las misiones pueden surgir de desapariciones, deudas, relaciones, conflictos territoriales, descubrimientos, promesas, amenazas y cambios ecológicos. El Narrative Engine organiza oportunidades, no crea hechos retroactivos.

## 32. Misiones personales, grupales y globales

Pueden existir misiones individuales, de grupo y eventos globales. Tienen ámbitos y autoridades explícitos. Una historia puede terminar por éxito, fracaso, retirada, resolución por NPC o consecuencias alternativas.

## 33. Historias sin intervención

NPC y facciones continúan actuando aunque nadie observe. El jugador puede llegar tarde, encontrar una historia resuelta o descubrir consecuencias. El mundo no espera a que el jugador active cada conflicto.

# PARTE X — PERSISTENCIA Y SEGURIDAD

## 34. Registro de eventos

Cada evento persistente debe incluir ID, tipo, tiempo, participantes, entidades afectadas, causa, ámbito, visibilidad, autoridad, versión de reglas, sincronización, procedencia y consecuencias.

## 35. Estados de un evento

- Propuesto.
- Provisional.
- Validado.
- Confirmado.
- Difundido.
- Rechazado.
- Aislado.
- Compensado.

Un hecho puede estar confirmado y seguir secreto. Un rumor difundido es un hecho de difusión, no prueba de que su contenido sea verdadero.

## 36. Estado, historia y snapshots

El estado actual permite consultas rápidas; la historia conserva cómo se llegó; los snapshots aceleran recuperación. Los hechos no se sobrescriben silenciosamente. Las rectificaciones se expresan mediante eventos compensatorios.

## 37. Seguridad

El cliente no confirma estado global. El tiempo no depende del reloj local del teléfono. Las crónicas personales respetan permisos y privacidad. Acceder a recuerdos de otro individuo requiere mecanismo de acceso válido.

# PARTE XI — PRUEBAS

1. Dos jugadores descubren misma región: un lugar, dos experiencias.
2. Un jugador conoce un secreto: otros no lo conocen automáticamente.
3. Se publica secreto: se difunde conocimiento.
4. Muere NPC global: muerte coherente en todo el canon.
5. Muere NPC personal: efecto limitado al ámbito.
6. Dos agentes adquieren objeto único: una sola transferencia.
7. NPC conserva identidad y relaciones diferenciadas.
8. Dos jugadores buscan NPC: se respeta ubicación real.
9. Expedición sigue durante ausencia.
10. Misión usa variante sin duplicar identidad global.
11. Entidad de instancia muere sin matar individuo global.
12. Investigación mágica permanece privada hasta difusión.
13. Evento personal modifica región mediante promoción válida.
14. Desconexión no duplica dinero u objeto.
15. Reinicio recupera historia.
16. Meses de ausencia conservan continuidad.
17. Dos ramas incompatibles no sobrescriben canon.
18. Rumor público no se convierte automáticamente en verdad.

# PARTE XII — CRITERIOS DE CIERRE

El diseño estará implementable cuando haya autoridad global, crónicas personales persistentes, clasificación de entidades y eventos, identidad entre instancias, visibilidad y difusión, promoción causal, reconciliación, transacciones, tiempo persistente, modo offline individual y recuperación histórica definidos.

# DECLARACIÓN FUNDACIONAL

El universo tendrá una realidad compartida, pero no una experiencia única. Las personas podrán recorrer los mismos territorios y conocer las mismas entidades mientras viven historias diferentes. Un acontecimiento puede ser verdadero sin ser conocido; un descubrimiento puede permanecer privado; una decisión personal puede terminar afectando a una región. El tiempo continuará y las consecuencias viajarán entre capas cuando exista una relación causal válida.

**El mundo será uno. Las historias serán incontables. Ninguna necesitará ser igual a otra para pertenecer al mismo universo.**

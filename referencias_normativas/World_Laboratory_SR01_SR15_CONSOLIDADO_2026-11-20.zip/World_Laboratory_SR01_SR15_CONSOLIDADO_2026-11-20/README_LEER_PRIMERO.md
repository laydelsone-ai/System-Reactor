# WORLD LABORATORY / SISTEMA REACTOR — PAQUETE CONSOLIDADO SR-01 A SR-15

**Fecha de consolidación:** 20-11-2026  
**Idioma:** español  
**Contenido:** SR-01 a SR-14, SR-15 principal de 88 secciones, SR-15-B complementario de 44 secciones, Anexo A de SR-09 y documentos de continuidad/control.

Este ZIP conserva las versiones más completas de los SR comparados y mantiene el contenido adicional del segundo SR-15 sin reducirlo. Los dos bloques de SR-15 se encuentran diferenciados para evitar que sus numeraciones o autoridades se confundan.

## Empieza aquí

1. `00_GOBIERNO_Y_GUIA/INSTRUCCION_DE_ARRANQUE_PARA_IA.md`
2. `00_GOBIERNO_Y_GUIA/GUIA_MAESTRA_DE_CONTINUIDAD_AUTORIDAD_Y_EJECUCION_v1.0.md`
3. `04_REGISTROS_Y_VERSIONES/REGISTRO_MAESTRO_APROBACIONES_SR01_SR15.md`
4. SR-01 a SR-14 en orden.
5. SR-15 principal v1.0: **88 secciones**.
6. SR-15-B complementario: **44 secciones**.
7. Anexo A de SR-09 — Veyrath y 72 hechizos.
8. Los registros canónicos y referencias complementarias.

## Estructura

- `00_GOBIERNO_Y_GUIA/`: instrucciones, Guía Maestra y referencia complementaria de continuidad del segundo paquete (no normativa).
- `01_NORMATIVAS_SR/`: SR-01 a SR-15 principal y SR-15-B complementario.
- `02_ANEXOS_OFICIALES/`: Anexo A de SR-09 — Veyrath y 72 hechizos.
- `03_CATALOGOS_Y_REFERENCIAS/`: nomenclatura y notas de identidad/nombre.
- `04_REGISTROS_Y_VERSIONES/`: registro de aprobaciones, decisiones, auditoría, procedencia e integración SR-15.
- `05_COMPENDIO/`: lectura continua actualizada de todas las normas incluidas.
- `MANIFEST_SHA256.json`: inventario y hashes SHA-256 de los archivos (el propio manifiesto se excluye de su lista de hashes).

## Regla especial de SR-15: 88 + 44

El cuerpo principal SR-15 v1.0 conserva íntegramente sus 88 secciones numeradas 1–88. El bloque SR-15-B conserva las otras 44 secciones, con numeración local 1–44. Se leen uno después del otro, pero no se mezclan ni renumeran. El bloque B agrega concreción; no reemplaza ni modifica silenciosamente el cuerpo principal ni las normas SR-01 a SR-14. Cualquier contradicción debe reportarse con citas exactas y no resolverse por inferencia.

## Regla de autoridad y estado real

Los SR aprobados son la autoridad normativa. Las guías ayudan a conectar y entender el proyecto, pero no reemplazan las normas. El bloque complementario SR-15-B está incorporado por instrucción del autor como detalle técnico subordinado; su presencia no equivale a una enmienda automática del cuerpo principal. Aprobación documental no significa implementación, compilación, pruebas ni validación en Android. Las etiquetas CALIBRACIÓN, RESERVADO, PENDIENTE, BASELINE TÉCNICO y NO VERIFICADO deben respetarse.

Este ZIP es un paquete documental, no un paquete de código ni de assets.

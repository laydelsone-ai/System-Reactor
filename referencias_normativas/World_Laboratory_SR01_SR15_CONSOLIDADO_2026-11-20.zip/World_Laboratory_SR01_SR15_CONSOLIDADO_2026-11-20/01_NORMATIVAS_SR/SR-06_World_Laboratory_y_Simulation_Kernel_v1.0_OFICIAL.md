# SR-06 — World Laboratory & Simulation Kernel
## Simulación autónoma, observación, cronología, reproducción histórica y experimentación sin jugador

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5; primera validación del universo  
**Dependencias:** SR-01 a SR-05.

# 0. Propósito y alcance

SR-06 define la infraestructura que ejecuta el universo sin necesitar un personaje jugador y las herramientas externas que permiten observarlo, inspeccionarlo, probarlo y reproducir sus acontecimientos.

El World Laboratory no es una demo separada con eventos fingidos. Debe utilizar el mismo núcleo de reglas, entidades, decisiones, causalidad y persistencia que posteriormente utilizará el juego. La interfaz de observación será un cliente de diagnóstico del mismo mundo, no un mundo alternativo construido con scripts independientes.

El primer objetivo es iniciar una simulación con ciudad principal, primer piso de la mazmorra, especies, monstruos, NPC aventureros, organizaciones, recursos y procesos autónomos; dejar avanzar el tiempo sin crear al jugador; y poder localizar y examinar cualquier acontecimiento relevante.

# PARTE I — PRINCIPIOS

## 1. La simulación no requiere jugador

El sistema DEBE poder inicializar un mundo sin crear una entidad jugador. La creación de un jugador será una operación opcional posterior de incorporación al mundo.

La ausencia del jugador no debe detener necesidades, decisiones, expediciones, reproducción, economía, investigación, rivalidades, evolución, muerte o consecuencias.

## 2. Un solo núcleo, varias interfaces

El videojuego, el observador y las herramientas de prueba deben consultar y modificar la misma realidad mediante los contratos de SR-02. No debe existir una simulación simplificada paralela que invente resultados distintos a los del juego.

El cliente jugable muestra una perspectiva de participante. El World Laboratory muestra una perspectiva administrativa y de observación. Comparten estado y reglas; difieren en permisos y presentación.

## 3. Observación pasiva

El observador no es una entidad del mundo. Por defecto no es percibido por NPC, no genera estímulos, no cambia probabilidades, no atrae criaturas, no consume recursos y no altera decisiones.

Las herramientas que cambien variables o introduzcan entidades deben estar separadas en un modo de intervención, registrar quién hizo el cambio, qué se modificó y desde qué snapshot se ejecutó.

## 4. Eventos emergentes, no historias cableadas

El mundo no se construirá escribiendo manualmente cada aventura, muerte, victoria, descubrimiento o misión en el código.

El código implementará **mecanismos generales**: percepción, necesidades, objetivos, planificación, movimiento, combate, daño, recursos, reproducción, investigación, transacciones, memoria, causalidad y reglas de los dominios. Los agentes elegirán acciones según sus capacidades e información. Los dominios resolverán esas acciones y emitirán acontecimientos confirmados. Las cadenas de consecuencias podrán crear situaciones que no fueron escritas de antemano.

El sistema sí necesita tipos genéricos de eventos y escenarios de prueba. Un tipo como `EntityDied`, `ExpeditionStarted` o `ItemTransferred` es un esquema de registro, no una historia predeterminada. Un evento concreto contiene participantes, causa, tiempo, lugar y resultado producidos por la simulación.

Se permiten contenidos diseñados manualmente —lore, especies iniciales, mapas, reglas, plantillas, tutoriales o misiones especiales opcionales—, pero no deben sustituir la generación autónoma de la vida cotidiana ni fingirse emergentes.

# PARTE II — SIMULATION KERNEL

## 5. Responsabilidad

El Simulation Kernel coordina el paso del tiempo, la ejecución de procesos, las decisiones, las operaciones de dominio, las consecuencias y la persistencia. No necesita procesar cada entidad con la misma frecuencia.

## 6. Estado del mundo

El estado de simulación incluye:

- Hora y fecha del mundo.
- Regiones y condiciones ambientales.
- Entidades e identidades.
- Posiciones y territorios.
- Estado vital y capacidades.
- Inventarios y recursos.
- Objetivos y procesos activos.
- Relaciones y organizaciones.
- Expediciones y actividades.
- Acontecimientos y consecuencias pendientes.
- Versiones de reglas y definiciones.

El estado materializado debe poder reconstruirse desde snapshot y eventos según la política de persistencia.

## 7. Ciclo de simulación

El ciclo general es:

1. Avanzar el reloj autorizado.
2. Identificar procesos cuyo momento de evaluación llegó.
3. Actualizar condiciones ambientales y temporales pertinentes.
4. Entregar percepciones a agentes elegibles.
5. Ejecutar decisiones según presupuesto cognitivo.
6. Emitir comandos de acción.
7. Validar precondiciones y autoridad.
8. Resolver interacciones físicas, sociales, económicas o biológicas.
9. Confirmar eventos.
10. Actualizar estado y consecuencias.
11. Notificar agentes y motores interesados.
12. Actualizar índices, snapshots y métricas.

Los pasos pueden ejecutarse de forma incremental o por lotes, siempre que se respeten las dependencias temporales y causales.

## 8. Determinismo y reproducibilidad

Para poder investigar errores, una simulación debe conservar versiones de reglas, semillas aleatorias, comandos externos y eventos confirmados. Cuando el modo de prueba requiera reproducibilidad exacta, el kernel utilizará semillas controladas y orden de ejecución registrado.

El mundo normal puede contener decisiones estocásticas, pero la semilla y las entradas deben permitir repetir experimentos diagnósticos en condiciones equivalentes. Una reproducción aproximada debe indicarse como tal si no puede garantizar equivalencia bit a bit.

# PARTE III — WORLD SCHEDULER

## 9. Tiempo universal

El scheduler administra una cronología del mundo independiente de FPS y reloj visual. El ritmo de conversión entre tiempo real y tiempo del mundo debe ser configurable y persistente, pero no se fija en este documento.

## 10. Niveles de resolución

### 10.1. Interacción

Alta precisión para combate, movimientos cercanos, impactos, reflejos y acciones con consecuencias inmediatas.

### 10.2. Actividad

Precisión media para rutinas, conversación, trabajo, viajes, descanso y expediciones.

### 10.3. Ecología y población

Procesamiento agregado para crecimiento, reproducción, migración, supervivencia, disponibilidad de recursos y presión ambiental.

### 10.4. Historia

Procesamiento por procesos y acontecimientos para generaciones, cambios sociales, guerras, expansión y transformación regional.

Son niveles de resolución de una misma cronología, no relojes independientes.

## 11. Priorización

La frecuencia de evaluación se determina por urgencia, riesgo, impacto causal, relevancia para otros individuos, complejidad, compromisos pendientes, actividad, proximidad a jugadores y significado histórico. La distancia a cámara no es el único criterio.

Una criatura que combate exige actualización inmediata. Una colonia distante puede actualizarse por lotes, pero debe conservar reproducción, recursos, enfermedades y consecuencias relevantes.

## 12. Simulación resumida

El scheduler puede resumir actividades cuando el detalle no cambie el resultado relevante. El resumen debe respetar capacidades, recursos, tiempo, riesgos, dependencias y posibilidad de interrupción.

No puede teletransportar un grupo sin tiempo de viaje, dar por construida una estructura sin materiales o decidir que un aventurero venció un enemigo incompatible solo para terminar un proceso.

## 13. Ausencia y tiempo persistente

En mundo individual offline, al reabrir el juego se calcula tiempo transcurrido con la política temporal local y se procesan las tareas pendientes. No se promete que Android ejecute la simulación mientras la aplicación está cerrada. La persistencia se consigue calculando avance al regresar, no manteniendo la app despierta.

En un mundo compartido, una autoridad coordinada avanza el tiempo global. La desconexión de un jugador no detiene el universo.

# PARTE IV — NPC AUTONOMOUS RUNTIME

## 14. Agente autónomo

Cada entidad cognitiva dispone de un estado interno apropiado a su capacidad: necesidades, motivaciones, objetivos, conocimientos, creencias, relaciones, memoria, capacidades, personalidad y compromisos.

El agente observa solo información disponible para él. No consulta el estado omnisciente del World Model como conocimiento personal.

## 15. Arquitectura de decisión offline

El runtime debe poder funcionar sin API externa. Se recomienda combinar:

- Máquina de estados o comportamientos reactivos para acciones inmediatas.
- Árboles de comportamiento para rutinas y respuestas jerárquicas cuando resulten adecuados.
- GOAP o planificación por objetivos para seleccionar acciones que satisfacen precondiciones y efectos.
- HTN o descomposición jerárquica para actividades largas como expediciones, fabricación e investigación.
- Memoria estructurada y modelo de creencias.
- Utilidad y prioridades para arbitrar necesidades y objetivos en conflicto.
- Aprendizaje basado en resultados para ajustar estimaciones y estrategias.

No se exige usar todas las técnicas en cada agente. El perfil y presupuesto determinan la combinación.

## 16. Modelos generativos opcionales

Un modelo local o remoto puede enriquecer diálogo, formulación de hipótesis y planificación compleja. No es requisito para que el mundo camine. Toda salida debe convertirse en propuesta estructurada y validarse.

Sin un modelo generativo, el agente aún puede actuar mediante objetivos, planificadores, memoria, conocimiento y mecanismos del mundo. La riqueza lingüística puede ser menor; no debe confundirse un diálogo variado con autonomía real.

## 17. Acciones y capacidades

Cada acción necesita precondiciones, requisitos, duración, recursos, efectos esperados, riesgos, interrupciones y resultados. Si el agente carece de capacidad o información, no puede realizarla simplemente porque el planificador la proponga.

## 18. Planes largos y compromiso

Los agentes pueden tener planes de varias etapas: prepararse, reunir suministros, formar grupo, viajar, explorar, regresar y recuperarse. Los planes se reevalúan cuando cambian hechos relevantes. Una interrupción puede provocar retirada, adaptación, suspensión o fracaso.

## 19. Individualidad

Agentes de una especie o profesión no deben tomar siempre la misma decisión. Diferencias de memoria, experiencia, motivación, personalidad, riesgo, relación, conocimiento y situación producen trayectorias distintas. La diversidad no requiere que cada acción sea generada por un LLM.

# PARTE V — EVENTOS EMERGENTES Y CAUSALIDAD

## 20. Qué es un evento

Un evento es un registro de algo que ocurrió o fue confirmado en un dominio. No es una misión escrita ni una predicción. Un comando es una solicitud; un evento confirmado es el hecho resultante.

## 21. Tipos genéricos

El sistema puede definir esquemas como creación, movimiento, interacción, daño, curación, incapacitación, muerte, adquisición, transferencia, consumo, fabricación, descubrimiento, investigación, reproducción, migración, cambio de relación, cambio territorial, inicio/fin de expedición y cambio de organización.

Estos esquemas son vocabulario técnico, no una lista cerrada de historias. Un mismo evento genérico puede aparecer en innumerables contextos.

## 22. Producción de eventos

Los eventos concretos surgen cuando:

1. Un agente, proceso ecológico, temporal o físico propone/realiza una operación.
2. El dominio recibe el comando.
3. Se validan precondiciones, autoridad y recursos.
4. Se resuelve la operación.
5. Se confirma el resultado.
6. Se registra causa, participantes, lugar y tiempo.
7. Causal Engine programa efectos derivados.

El sistema no escribe manualmente «el grupo A muere el día 14». Simula decisiones y condiciones que pueden acabar produciendo esa muerte.

## 23. Eventos derivados

Una muerte puede provocar duelo, sucesión, deuda, cambio de expedición, rumor, alteración de población o nueva oportunidad narrativa. Estas consecuencias no son todas obligatorias: dependen de relaciones, testigos, cultura, memoria y condiciones.

## 24. Narrative Engine

El motor narrativo observa el registro causal y detecta oportunidades: rescate, venganza, investigación, conflicto, deuda, alianza, protección, recuperación de objeto o descubrimiento. La misión organiza objetivos y condiciones; no crea hechos pasados que nunca sucedieron.

## 25. Reglas versus eventos escritos

El contenido artesanal puede definir un mapa, especie, cultura, leyenda, localización o evento excepcional con condiciones concretas. Pero la vida diaria —rutas, decisiones, encuentros, victorias, derrotas, muertes y consecuencias— debe proceder de reglas y agentes. Cada elemento diseñado a mano debe estar identificado como contenido authored, no presentarse engañosamente como emergente.

# PARTE VI — EVENT OBSERVATORY

## 26. Registro consultable

El Observatorio indexa eventos por tiempo, región, tipo, entidad, grupo, facción, gravedad, alcance y estado. Debe permitir filtrar muertes, expediciones, batallas, descubrimientos, investigaciones, evolución, economía, misiones y cambios ecológicos.

## 27. Esquema mínimo de evento

Cada evento persistente incluye:

- Event ID.
- Tipo y versión de esquema.
- Tiempo del mundo.
- Ubicación o región.
- Participantes y entidades afectadas.
- Causa y eventos antecedentes.
- Comando o proceso originador.
- Resultado.
- Ámbito y visibilidad.
- Autoridad de confirmación.
- Versión de reglas.
- Consecuencias pendientes/derivadas.
- Referencias a snapshot o contexto de reconstrucción.

## 28. Importancia y agregación

El sistema distingue eventos críticos, relevantes y rutinarios. No todos deben aparecer en primer plano. Los procesos repetitivos pueden agregarse, pero el usuario debe poder inspeccionar detalles suficientes para explicar el resultado.

Ejemplo: «expedición terminó con dos supervivientes y una baja» debe enlazar al grupo, integrantes, viaje, recursos, encuentro, decisiones y causa del desenlace.

# PARTE VII — GOD VIEW / OBSERVATORIO VISUAL

## 29. Cámara externa

La cámara no pertenece al mundo. Puede operar desde vista aérea, regional, seguimiento o proximidad. La cámara no genera estímulos ni revela información a los NPC.

## 30. Vista aérea y mapa

Debe representar regiones, ciudad, mazmorra, rutas, territorios, grupos, entidades y marcadores de evento. La vista puede cambiar escala desde mapa abstracto hasta escena tridimensional.

## 31. Selección de evento y traslado

Al seleccionar un evento, el observador consulta su ubicación, tiempo y snapshot/contexto asociado. Puede mover la cámara a la zona y abrir:

- Vista actual del lugar.
- Reconstrucción en el instante del evento.
- Reproducción de la secuencia disponible.
- Lista de participantes.
- Causas y consecuencias.
- Estado interno relevante de los agentes, en modo diagnóstico.

Si no hay información suficiente para reconstrucción exacta, debe indicarse que la vista es aproximada o actual, no fingir una grabación inexistente.

## 32. Seguimiento de entidades

El usuario puede seguir NPC, monstruo, individuo excepcional, expedición, grupo, misión, objeto o población. El seguimiento muestra actividad, ubicación, estado, objetivo conocido por el observador y acontecimientos enlazados.

## 33. Panel de inspección

Puede mostrar identidad, especie, estado, necesidades, motivaciones, objetivos, capacidades, memoria relevante, relaciones, inventario, actividad e historial. Esta información privilegiada es solo del observador y no se inyecta en el agente.

## 34. Distinción de perspectivas

La interfaz debe indicar si muestra:

- Estado actual.
- Estado histórico reconstruido.
- Observación aproximada.
- Información objetiva de diagnóstico.
- Conocimiento que el agente tenía en ese momento.

Nunca debe confundir omnisciencia administrativa con lo que sabía el NPC.

# PARTE VIII — HISTORICAL REPLAY

## 35. Reconstrucción histórica

El replay reconstruye un acontecimiento desde registros, snapshots, estados y recursos versionados. No es una nueva línea temporal real ni altera el canon.

## 36. Niveles de fidelidad

- **Exacta:** registros suficientes para reconstruir estados y operaciones precisas.
- **Detallada:** se conservan decisiones y pasos relevantes, pero no cada actualización de movimiento.
- **Resumida:** se conocen etapas, participantes y resultados, no la secuencia visual completa.
- **No reconstruible:** faltan datos; solo puede mostrarse el resultado y evidencias disponibles.

La interfaz debe indicar la fidelidad. No presentar una animación inventada como grabación exacta.

## 37. Reproducibilidad

Una repetición diagnóstica puede usar misma semilla, versiones, comandos y snapshot. El modo de replay no vuelve a ejecutar efectos persistentes en el mundo real.

# PARTE IX — EXPERIMENT BRANCHES

## 38. Ramas de prueba

El laboratorio permite crear ramas a partir de snapshots para probar cambios sin afectar el canon.

Cada rama registra origen, modificaciones, parámetros, semillas, versión de reglas, resultados y diferencias respecto al mundo base.

## 39. Intervenciones permitidas

En modo de experimentación se pueden añadir especies, cambiar recursos, modificar clima, crear una nueva facción, variar población, acelerar reproducción o introducir condiciones de prueba. Toda intervención se registra como acción administrativa externa, no como hecho espontáneo del mundo.

## 40. Promoción al mundo real

Una rama experimental no se fusiona automáticamente. Si se decide usar un resultado, se debe convertir en contenido o cambio versionado y validar su compatibilidad con el mundo canónico.

# PARTE X — OFFLINE-FIRST Y COSTE

## 41. Núcleo local

El Simulation Kernel, scheduler, agentes base, memoria estructurada, causalidad, registro, observatorio y guardado deben poder ejecutarse localmente sin API externa.

## 42. Inteligencia sin coste recurrente

La rutina de miles de entidades no debe depender de inferencias LLM. Se utilizan reglas, planificadores, modelos de comportamiento, prioridades, memoria, utilidad y aprendizaje acotado. El modelo generativo es complemento opcional para tareas selectivas.

Esto no significa inteligencia ilimitada ni diálogo humano indistinguible sin coste. La riqueza emergente depende de la calidad de modelos, datos, reglas y pruebas. Si se desactiva la IA generativa, el mundo sigue teniendo decisiones y consecuencias, aunque determinadas conversaciones o hipótesis sean menos abiertas.

## 43. Equipo de desarrollo y Android

El laboratorio debe ejecutarse inicialmente en un equipo de desarrollo capaz de ejecutar el motor y la interfaz de observación. El móvil objetivo es cliente de juego; no debe ejecutar toda la población ni ser el servidor de inteligencia. El modo offline final puede correr en el dispositivo con escala reducida, según pruebas reales de rendimiento.

## 44. Persistencia local

El mundo individual guarda estado, eventos, snapshots, seeds, versiones y tareas pendientes. Al reabrir, calcula el tiempo transcurrido según reglas y procesa consecuencias. Android no tiene que mantener la app activa durante la ausencia.

# PARTE XI — MÉTRICAS Y PRUEBAS

## 45. Métricas

El laboratorio debe registrar tiempo simulado por segundo real, agentes evaluados, decisiones, comandos, eventos, fallos de validación, tareas pendientes, uso de CPU/RAM, tamaño de almacenamiento, consultas de observatorio, porcentaje de replay reconstruible y coste por ciclo cognitivo.

## 46. Pruebas fundamentales

1. Inicializar mundo sin jugador.
2. Ejecutar población de NPC y monstruos.
3. Crear y finalizar expediciones sin instrucciones del usuario.
4. Registrar victoria, derrota, retirada y bajas mediante resolución real.
5. Seleccionar un evento y trasladar cámara al lugar.
6. Inspeccionar decisiones con información limitada.
7. Avanzar días y semanas sin congelar procesos.
8. Simular recursos escasos y migración.
9. Ejecutar investigación de NPC.
10. Crear misión a partir de hechos observados, sin evento escrito manualmente.
11. Reproducir evento a fidelidad declarada.
12. Crear rama experimental y comprobar aislamiento.
13. Reiniciar sistema y recuperar historia.
14. Desactivar cualquier proveedor de IA externa y mantener funcionamiento básico.
15. Repetir con semilla controlada y explicar diferencias.

## 47. Criterios de cierre

El World Laboratory está listo para la primera validación cuando:

- El mundo arranca sin jugador.
- Las reglas de ejecución son las mismas del juego.
- Los agentes actúan por objetivos y capacidades.
- Los eventos concretos surgen de operaciones y consecuencias.
- La narrativa observa hechos y no los inventa.
- El tiempo puede acelerarse sin romper causalidad.
- El observador es pasivo.
- Los eventos pueden filtrarse y seleccionarse.
- Se puede trasladar cámara a lugares de eventos.
- La fidelidad del replay está etiquetada.
- Las ramas de prueba no contaminan el canon.
- El núcleo funciona offline sin API obligatoria.
- Las métricas permiten detectar coste y errores.

# PARTE XII — IMPLEMENTACIÓN POR ETAPAS

## 48. Etapa A: Kernel mínimo

Implementar reloj, entidades básicas, estado, comandos, eventos, validación, persistencia y scheduler. Sin mapa artístico ni LLM. Probar creación, movimiento, consumo de recursos y muerte.

## 49. Etapa B: Agentes autónomos

Añadir necesidades, objetivos, memoria estructurada, planificador, acciones y ciclos de reevaluación. Introducir NPC sencillos y monstruos con perfiles distintos.

## 50. Etapa C: Región de prueba

Cargar mapa abstracto de ciudad y primer piso, navegación, recursos, peligros y territorios. No es todavía la producción visual final.

## 51. Etapa D: Expediciones autónomas

Añadir preparación, grupos, inventarios, viaje, exploración, combate, retirada, retorno, lesiones y recompensas. Los resultados surgen de decisiones y reglas.

## 52. Etapa E: Observatory

Añadir cronología, filtros, mapa, selección de eventos, cámara, inspección de agentes y replay.

## 53. Etapa F: Simulación prolongada

Ejecutar 10, 30 y 100 días simulados; identificar colapsos, loops, recursos infinitos, poblaciones imposibles, NPC bloqueados y eventos contradictorios. Los 100 días son una prueba, no una promesa de que el mundo ya está terminado.

## 54. Etapa G: ramas y crecimiento

Añadir snapshots, ramas experimentales, cambios de reglas controlados y comparación entre simulaciones.

# DECLARACIÓN FUNDACIONAL

El World Laboratory no será una escena preparada para aparentar vida. Será una ventana de observación sobre el mismo universo que después recibirá al jugador. Sus habitantes deben poder decidir, actuar, investigar, viajar, luchar, fracasar, morir, aprender y producir consecuencias sin una historia concreta escrita para cada ocasión.

El código establece reglas, capacidades, límites, procesos y mecanismos de registro. La simulación produce los acontecimientos concretos. El Observatorio los hace visibles. El Narrative Engine puede convertir consecuencias reales en oportunidades de historia.

**Antes de pedirle al jugador que habite el universo, debemos demostrar que el universo puede vivir sin él.**

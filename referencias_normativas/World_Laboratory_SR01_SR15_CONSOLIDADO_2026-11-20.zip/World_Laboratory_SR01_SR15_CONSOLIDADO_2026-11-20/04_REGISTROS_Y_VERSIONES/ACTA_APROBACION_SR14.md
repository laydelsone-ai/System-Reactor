# ACTA DE APROBACIÓN — SR-14

**Documento:** SR-14 — Narrativa, historia fundacional y generación de historias  
**Versión:** 0.1  
**Fecha:** 20-11-2026  
**Estado:** NORMATIVA OFICIAL APROBADA.

El autor respondió «Aprobado» a la propuesta integral SR-14 v0.1 y su campaña fundacional de referencia. Desde ese acto, SR-14 forma parte del canon normativo subordinado a SR-01 y compatible con SR-02 a SR-13.

Se aprueban la coexistencia de historia fundacional diseñada y resultados emergentes; el derecho a crear tutoriales, misiones manuales y arcos narrativos; la obligación de no forzar victorias, derrotas, muertes, rescates ni descubrimientos; la autonomía de NPC, monstruos e instituciones; y **El Eco de Vhaloren** como campaña inicial de referencia.

Los nombres que el cuerpo de SR-14 identifica expresamente como nombres de trabajo continúan sujetos a la guía de nomenclatura; la aprobación de la estructura narrativa no los convierte en inmutables.

**SR-14 v0.1 — OFICIAL Y APROBADA.**

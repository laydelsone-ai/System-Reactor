# SR-03 — Identidad, inteligencia, memoria y evolución

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5  
**Dependencias:** SR-01 y SR-02.

# PARTE I — IDENTIDAD INDIVIDUAL

## 1. Principio de identidad

Toda entidad persistente posee identidad lógica independiente de apariencia, nombre, especie, cuerpo, nivel, inventario, ubicación o memoria. El sistema debe poder seguir su continuidad a través de cambios válidos.

## 2. Dimensiones de identidad

### 2.1. Identidad universal

Identificador estable y no reutilizable dentro del universo. Permite enlazar acontecimientos y relaciones durante toda la trayectoria.

### 2.2. Identidad vital

Representa etapas: nacimiento, desarrollo, madurez, envejecimiento, muerte, reanimación, resurrección, reencarnación o transformación. Una entidad puede tener varias etapas vitales si sus leyes de continuidad lo permiten.

### 2.3. Identidad corporal

Representa el cuerpo o estructura mediante la que se manifiesta. Puede cambiar por crecimiento, lesión, mutación, evolución, transformación, reencarnación o reconstrucción sin que la identidad lógica cambie automáticamente.

### 2.4. Identidad cognitiva

Representa memoria, conocimientos, personalidad, capacidades, tendencias emocionales, motivaciones y formas de interpretar. Puede evolucionar; no es necesariamente inmutable.

### 2.5. Identidad social

Representa nombre conocido, familia, reputación, profesión, afiliaciones, títulos y relaciones. Puede perderse o cambiar sin que el individuo deje de existir.

## 3. Continuidad

El sistema distinguirá continuidad física, biológica, cognitiva, histórica y metafísica. No considerará que una de ellas prueba automáticamente las demás.

Una persona puede cambiar de cuerpo y conservar identidad; una copia puede conservar recuerdos sin ser el original; una entidad puede perder memoria y conservar continuidad esencial. Los casos ambiguos deben admitir incertidumbre y evidencia gradual.

## 4. Reencarnación mixta

La reencarnación puede conservar en proporciones variables identidad esencial, fragmentos de recuerdos, predisposiciones, capacidades, conocimientos, tendencias emocionales o vínculos residuales. El cuerpo, especie, personalidad y memoria consciente pueden cambiar.

La reencarnación no es copia íntegra ni resurrección automática. La nueva existencia desarrolla una historia propia. El registro debe distinguir continuidad confirmada, probable, parcial, desconocida y semejanza sin continuidad demostrada.

Manifestaciones posibles de continuidad parcial incluyen sueños, familiaridad con lugares, reacciones emocionales, capacidades inusuales o recuerdos fragmentarios. Ninguna constituye prueba automática; pueden existir otras explicaciones.

## 5. Estados de existencia

Los estados posibles incluyen activo, dormido, incapacitado, herido, crítico, muerto, en reanimación, resucitado, reencarnado, transformado o desaparecido. No todos se aplican a todos los tipos de entidad.

La muerte detiene la actividad vital correspondiente; no borra identidad ni historia. Reanimación, resurrección y reencarnación son mecanismos diferentes.

# PARTE II — INTELIGENCIA

## 6. Inteligencia multidimensional

No existe una estadística única que represente toda la inteligencia. Las capacidades pueden desarrollarse independientemente.

Dimensiones:

1. Percepción.
2. Atención.
3. Reconocimiento.
4. Comprensión.
5. Memoria de trabajo.
6. Razonamiento causal, lógico, espacial, práctico, social y abstracto.
7. Planificación.
8. Aprendizaje.
9. Creatividad.
10. Comunicación.
11. Autoconocimiento.
12. Metacognición.

Una criatura puede ser excelente cazadora y no comprender conceptos abstractos. Un artesano puede dominar procedimientos sin poder explicarlos. Un investigador puede razonar bien y tener capacidades físicas limitadas.

## 7. Arquitectura cognitiva individual

El perfil cognitivo puede incluir percepción, atención, modelo del entorno, memoria de trabajo, memoria a largo plazo, motivaciones, emociones, personalidad, planificación, conocimientos, autoconocimiento y comunicación.

No se impondrá una arquitectura humana a todas las especies. Una entidad instintiva puede usar respuestas simples; un aventurero puede planificar; un investigador puede construir hipótesis y diseñar experimentos. Un individuo puede desarrollar capacidades no habituales para su población.

## 8. Motivaciones y necesidades

El individuo puede priorizar supervivencia, alimento, descanso, seguridad, reproducción, territorio, curiosidad, conocimiento, reconocimiento, poder, pertenencia, protección, venganza, lealtad, libertad, creación, fe o ambición.

Las motivaciones pueden entrar en conflicto. El sistema debe representar prioridades cambiantes, compromisos y costes. No todo comportamiento es una misión preasignada.

## 9. Personalidad

La personalidad representa tendencias relativamente estables, no un conjunto de frases. Puede influir en prudencia, riesgo, sociabilidad, persistencia, ambición, generosidad, desconfianza, agresividad y curiosidad. Puede cambiar por experiencias, relaciones, aprendizaje y transformaciones.

## 10. Emociones

Las emociones son estados internos que influyen en percepción, memoria, motivación y decisión; no son solo expresiones faciales. Miedo, ira, tristeza, apego, curiosidad, gratitud o vergüenza pueden modificar prioridades sin anular siempre el razonamiento. Dos individuos reaccionan de manera diferente ante el mismo acontecimiento.

## 11. Ciclo de decisión

1. Percibir información disponible.
2. Interpretarla mediante memoria y conocimiento.
3. Identificar necesidades y objetivos.
4. Generar alternativas.
5. Evaluar consecuencias y riesgos.
6. Seleccionar un plan.
7. Validar capacidades y recursos.
8. Solicitar ejecución.
9. Observar el resultado.
10. Aprender y actualizar memoria.

Una intención no garantiza ejecución. Las acciones deben ser posibles para el cuerpo, conocimientos, herramientas, recursos, tiempo y circunstancias del individuo.

## 12. Decisiones imperfectas

Los individuos pueden equivocarse, tener información incompleta, malinterpretar señales, confiar en alguien que los engaña, actuar por impulso, sobreestimar capacidades, evitar riesgos o cambiar de opinión. Los errores deben corresponder a capacidades, experiencia, personalidad y contexto.

## 13. Agentes autónomos y modelos generativos

Un agente puede perseguir objetivos sin intervención del jugador, iniciar actividades, abandonar planes y adoptar objetivos nuevos. La autonomía tiene límites físicos, cognitivos y materiales.

Los modelos generativos pueden proponer estrategias, diálogos, hipótesis, explicaciones y planes complejos. Sus salidas son propuestas, no hechos ni comandos irrevocables. Deben validarse contra memoria, capacidades, recursos, reglas y permisos.

# PARTE III — INVESTIGACIÓN Y CONOCIMIENTO

## 14. Autonomía epistemológica

Los habitantes pueden investigar las leyes de su realidad. No es una capacidad exclusiva del jugador. NPC, criaturas, monstruos y civilizaciones pueden observar, formular preguntas, probar hipótesis, descubrir propiedades y transmitir conocimientos cuando posean los recursos y capacidades necesarios.

## 15. Ciclo de investigación

1. Observar un fenómeno.
2. Detectar patrón o anomalía.
3. Formular pregunta.
4. Elaborar hipótesis.
5. Diseñar experimento.
6. Reunir herramientas y recursos.
7. Ejecutar prueba.
8. Registrar resultados.
9. Comparar explicaciones.
10. Repetir o modificar el procedimiento.
11. Construir teoría provisional.
12. Aplicar o comunicar el descubrimiento.

No todas las entidades pueden completar todas las etapas. Un monstruo puede aprender que una sustancia le daña sin comprender química; un investigador puede descubrir el mecanismo.

## 16. Verdad, hipótesis y consenso

El mundo distingue estado objetivo, hipótesis, resultado experimental, teoría provisional, conocimiento reproducido, consenso social, dogma, rumor, error y engaño deliberado. Una civilización puede sostener una teoría falsa durante generaciones.

Dos investigadores pueden descubrir independientemente un principio o proponer explicaciones diferentes. El conocimiento puede perderse si mueren sus portadores o desaparecen sus registros e instituciones.

# PARTE IV — MEMORIA

## 17. Tipos de memoria

- Sensorial: señales recientes.
- Episódica: acontecimientos vividos.
- Semántica: conceptos y hechos aprendidos.
- Procedimental: habilidades y técnicas.
- Emocional: asociaciones afectivas.
- Social: relaciones, promesas, deudas y reputación.
- Espacial: lugares y rutas.
- Prospectiva: intenciones y planes futuros.

## 18. Registro de recuerdo

Un recuerdo importante conserva individuo, contenido, momento del hecho, momento de adquisición, fuente, contexto, confianza, importancia emocional, entidades relacionadas, interpretación y estado de conservación.

La fuente permite distinguir vivencia, observación, relato ajeno, lectura, deducción, sueño e imaginación cuando la capacidad cognitiva lo permita.

## 19. Olvido y distorsión

El olvido puede depender de tiempo, relevancia, recuperación, emoción, edad, lesiones, enfermedad o transformación. Puede ser parcial. No elimina el hecho del Chronicle. El recuerdo puede cambiar mientras la historia objetiva permanece.

## 20. Memoria compartida

Bibliotecas, grimorios, gremios, tradiciones orales y archivos pueden conservar conocimientos colectivos. La memoria colectiva puede contener falsedades. Difundir información requiere un mecanismo real de transmisión.

# PARTE V — APRENDIZAJE Y DOMINIO

## 21. Aprender no equivale a desbloquear

Una entidad no adquiere automáticamente una capacidad por alcanzar un nivel. El aprendizaje depende de aptitud, conocimientos previos, experiencia, instrucción, práctica, atención, recursos, comprensión, retroalimentación y tiempo.

## 22. Modalidades de aprendizaje

Experiencial, observacional, guiado, experimental, imitativo, reflexivo, social e instintivo. Pueden combinarse. Observar una acción no garantiza comprenderla ni ejecutarla.

## 23. Conocimiento y dominio

El conocimiento teórico no equivale a dominio práctico. El dominio se desarrolla mediante práctica, corrección, experiencia y adaptación. La transferencia entre disciplinas es posible cuando comparten principios, pero no es automática.

La falta de práctica, lesión, envejecimiento o transformación puede afectar la ejecución práctica de modo distinto al conocimiento teórico.

## 24. Requisitos de aprendizaje mágico

El sistema mágico tendrá especificación propia, pero deberá respetar estos requisitos fundacionales:

1. La magia puede aprenderse mediante estudio, investigación y práctica.
2. Grimorios transmiten información, no dominio automático.
3. Herencia, clase, naturaleza o predisposición individual pueden facilitar ciertos aprendizajes, sin garantizar capacidad absoluta.
4. La especialización en una naturaleza mágica puede facilitar hechizos compatibles.
5. La ejecución debe expresarse mediante palabras o escritura, según el hechizo.
6. Puede existir una lengua mágica original interna del universo.
7. Usar una traducción accesible puede imponer penalizaciones frente a la formulación original, si las reglas mágicas lo determinan.
8. El encantamiento es un proceso de ejecución, no simplemente una acción instantánea activada por botón.
9. Algunos encantamientos pueden ejecutarse caminando; otros requieren inmovilidad, concentración o preparación y pueden ofrecer mayor potencia o complejidad.
10. Los efectos deben interactuar con propiedades del objetivo y leyes físicas/químicas aplicables.

Se distingue conocer la existencia de un hechizo, conocer su formulación, comprenderla, tener predisposición, ejecutarlo, dominarlo, modificarlo e investigarlo. Leer un grimorio no garantiza dominar su contenido.

# PARTE VI — EVOLUCIÓN

## 25. Evolución abierta

Todas las especies y entidades pueden evolucionar cuando naturaleza y circunstancias lo permitan. No existe un árbol cerrado que anticipe todas las formas futuras.

## 26. Dimensiones

- Biológica: anatomía, fisiología, sentidos, metabolismo y reproducción.
- Cognitiva: percepción, memoria, razonamiento y planificación.
- Conductual: estrategias y hábitos.
- Social: estructura, cultura y relaciones.
- Poblacional: rasgos heredables en generaciones.
- Extraordinaria: mecanismos mágicos o metafísicos definidos.

## 27. Fuentes

Herencia, mutación, entorno, alimentación, entrenamiento, aprendizaje, experiencias extremas, exposición a fenómenos, interacciones y reencarnación pueden contribuir. Ninguna fuente garantiza por sí sola una transformación.

## 28. Individuo y población

Los cambios individuales no se transmiten automáticamente genéticamente. Una habilidad aprendida no es necesariamente heredable; una adaptación heredable necesita mecanismo de transmisión. La evolución poblacional considera reproducción, supervivencia, variación y ambiente.

## 29. Costes evolutivos

Toda transformación relevante debe considerar costes y compromisos: consumo energético, movilidad, vulnerabilidad, nuevas necesidades, pérdida de capacidad o dependencia ambiental. La evolución no es acumulación ilimitada de mejoras.

## 30. Linajes

Se registran progenitores, descendientes, linajes, rasgos transmitidos, variaciones y transformaciones. La genealogía no determina completamente el futuro.

## 31. Individuos excepcionales

Un individuo excepcional se explica por trayectoria, condiciones, capacidades y acontecimientos; no es solo una plantilla con números aumentados. Puede tener anatomía, cognición, estrategia o historia singular, junto con vulnerabilidades y costes.

# PARTE VII — INTERACCIONES Y CONTRATOS

## 32. Interdependencia

Un cambio biológico puede alterar percepción; la nueva percepción produce experiencias; las experiencias actualizan memoria; la memoria facilita aprendizaje; el aprendizaje modifica capacidades; las capacidades cambian estrategias; las estrategias influyen en supervivencia y sociedad. El sistema debe representar estas dependencias.

## 33. Contratos entre motores

- Entity Registry: identidad y continuidad.
- Cognitive Engine: interpretación, motivación, planificación e intención.
- Memory Engine: recuerdos, conocimientos, fuentes y olvido.
- Research System: hipótesis, experimentos y descubrimientos.
- Evolution Engine: transformaciones compatibles.
- Governance: validación y procedencia.

Ningún motor convierte una creencia en hecho objetivo ni una propuesta en cambio persistente sin autorización.

# PARTE VIII — PRUEBAS Y CIERRE

## 34. Experimentos obligatorios

1. NPC con memoria incompleta interpreta mal un hecho.
2. Testigo recuerda solo lo percibido.
3. Rumor falso se difunde sin convertirse en verdad.
4. Olvido no elimina la historia.
5. Reencarnación conserva dimensiones variables.
6. Cambio corporal no rompe identidad por defecto.
7. Criatura aprende estrategia tras experiencias.
8. Investigación fallida produce costes y conocimiento limitado.
9. Investigadores independientes alcanzan conclusiones comparables.
10. Una sociedad conserva una teoría falsa.
11. Individuo desarrolla una característica nueva con causa.
12. Rasgo heredable se transmite según mecanismo.
13. Leer un grimorio no garantiza ejecutar un hechizo.
14. Formulación traducida y original pueden tener resultados distintos si el sistema lo establece.

## 35. Criterios de cierre

El documento estará implementable cuando exista un modelo de identidad resistente a transformaciones; continuidad vital; cognición adaptable; decisiones con información incompleta; memoria con procedencia; aprendizaje con costes; investigación autónoma; evolución individual y poblacional; y contratos claros entre motores.

# Declaración fundacional

Una entidad no queda definida solo por lo que es al aparecer. Puede cambiar mediante experiencias, decisiones, relaciones, conocimientos y circunstancias. La identidad permite continuidad; la inteligencia interpreta; la memoria conserva; el aprendizaje transforma conocimientos; la evolución transforma posibilidades. Juntos permiten que un individuo tenga existencia propia.

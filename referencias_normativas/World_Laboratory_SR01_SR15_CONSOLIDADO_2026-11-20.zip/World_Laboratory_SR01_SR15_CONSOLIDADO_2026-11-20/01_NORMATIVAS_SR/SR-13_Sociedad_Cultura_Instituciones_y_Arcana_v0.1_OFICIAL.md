# WORLD LABORATORY / SISTEMA REACTOR

# SR-13 — SOCIEDAD, CULTURA, INSTITUCIONES Y LA ARCANA

**Código:** SR-13  
**Versión:** 0.1  
**Estado:** NORMATIVA OFICIAL APROBADA POR AUTORIZACIÓN PREVIA DEL AUTOR  
**Fecha:** 20 de noviembre de 2026  
**Dependencias:** SR-01 a SR-12; especialmente SR-01, SR-03, SR-04, SR-07, SR-08, SR-10, SR-11 y SR-12.  
**Ámbito:** comunidades, familias, cultura, lenguas, educación, instituciones, leyes, justicia, gobierno, religiones, filosofías, Arcana, profesiones, diplomacia, conflictos y convivencia entre distintas formas de entidad.

---

## CONTROL DEL DOCUMENTO

| Campo | Valor |
|---|---|
| Código | SR-13 |
| Versión | 0.1 — aprobada |
| Estado | Normativa oficial aprobada conforme a autorización expresa previa del autor |
| Autoridad superior | SR-01 — Constitución y leyes fundamentales |
| Ámbito principal | Sociedad, cultura, instituciones y relación civilizatoria con la Arcana |
| Sistemas relacionados | SR-02 a SR-12, según el dominio afectado |

**Convención normativa:** DEBE y NO DEBE expresan obligaciones y prohibiciones. PUEDE expresa una posibilidad permitida. CALIBRACIÓN identifica valores o parámetros que requieren pruebas. RESERVADO identifica catálogos, nombres propios, leyes locales o configuraciones particulares que se desarrollarán en documentos subordinados.

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Aprobada | Primera normativa integral de sociedad e instituciones. Establece la Arcana como fundamento civilizatorio sin convertirla en deidad ni alterar las leyes superiores. |

# PARTE I — PROPÓSITO, AUTORIDAD Y PRINCIPIOS

## 1. Propósito

SR-13 define cómo los individuos forman comunidades, familias, culturas, organizaciones e instituciones; cómo coordinan sus intereses; cómo transmiten conocimientos; cómo crean leyes y autoridades; cómo resuelven disputas; y cómo interpretan el mundo que habitan.

La sociedad no será un decorado construido alrededor del jugador. Las comunidades deben tener necesidades, memoria, normas, conflictos, proyectos, recursos, instituciones y capacidad de cambiar. Sus habitantes pueden cooperar, competir, migrar, enseñar, investigar, comerciar, formar vínculos, romperlos, organizarse o desaparecer por causas coherentes.

SR-13 también establece el lugar de la **Arcana** en la civilización. La decisión de diseño es que la Arcana será uno de los fundamentos más importantes de la vida material, intelectual, cultural y espiritual de este universo. No será una deidad, una mente universal ni una fuerza que conceda favores por devoción. Será el nombre civilizatorio amplio para el conjunto de fenómenos, conocimientos, prácticas y aplicaciones que se relacionan con la Trama, el flujo y las Resonancias, de acuerdo con la autoridad natural y arcana de SR-07.

La civilización podrá apoyarse profundamente en la Arcana sin depender de milagros. Sus avances deberán proceder de comprensión, trabajo, fuentes, herramientas, instituciones, aprendizaje y mantenimiento.

## 2. Autoridad y límites

SR-13 desarrolla la dimensión social de SR-01 y utiliza los contratos de SR-02, la identidad y cognición de SR-03, la causalidad y persistencia de SR-04, las entidades y capacidades de SR-05, la simulación de SR-06, las leyes naturales y arcanas de SR-07, la biología de SR-08, el combate de SR-09, la economía de SR-10, la geografía de SR-11 y la progresión de SR-12.

SR-13 no redefine la Trama, el flujo ni las Resonancias. SR-07 conserva autoridad sobre qué fenómenos arcanos son posibles, sus fuentes, costes, límites, resistencias y contramedidas. SR-13 establece cómo las sociedades descubren, utilizan, regulan, enseñan, comercian, veneran, temen o disputan esos fenómenos.

SR-13 tampoco confirma ni niega la existencia última de dioses, entidades divinas o planos sobrenaturales. Esa cuestión permanece abierta conforme a la decisión cosmológica previa. Las creencias de los habitantes no se convierten automáticamente en hechos objetivos.

## 3. Principios sociales obligatorios

1. **Autonomía:** la sociedad y sus instituciones continúan actuando sin la presencia del jugador.
2. **Pluralidad:** no existe una cultura, gobierno, familia, moral o religión universal para todos los pueblos.
3. **Causalidad:** el poder social, la riqueza, el conocimiento y la autoridad tienen fuentes y límites identificables.
4. **Memoria:** las comunidades conservan relatos, registros y tradiciones, que pueden ser incompletos, disputados o falsos.
5. **Agencia individual:** los habitantes no son simples representantes de su cultura, clase, gremio o religión.
6. **Instituciones imperfectas:** las organizaciones pueden cumplir sus funciones, fracasar, reformarse, corromperse, dividirse o desaparecer.
7. **No privilegio del jugador:** las leyes y los servicios no se doblan automáticamente para facilitar su progreso.
8. **Arcana sin divinidad automática:** el uso, estudio o veneración de la Arcana no implica que exista una voluntad que responda a sus practicantes.
9. **Diversidad de entidades:** la condición social y jurídica debe considerar agencia, identidad y capacidades, no únicamente apariencia o especie.
10. **Persistencia:** las decisiones, conflictos, acuerdos, reformas y daños sociales importantes dejan consecuencias.

# PARTE II — LA ARCANA COMO FUNDAMENTO CIVILIZATORIO

## 4. Qué significa Arcana

**Arcana** es el término civilizatorio general para el conjunto de fenómenos observables, conocimientos, técnicas, artes, disciplinas e infraestructuras que interactúan con la Trama, el flujo y las Resonancias.

La palabra puede tener matices diferentes según la cultura: para una academia puede referirse a un campo de estudio; para un artesano, a un conjunto de técnicas; para una comunidad, al principio que hace posible ciertos fenómenos; para una religión, a una manifestación de lo sagrado; y para una autoridad, a un ámbito que requiere normas de seguridad.

Estas interpretaciones culturales no cambian por sí mismas el funcionamiento objetivo del fenómeno.

### 4.1. Distinciones que deben mantenerse

| Concepto | Sentido normativo | No debe confundirse con |
|---|---|---|
| **Trama** | Estructura o fundamento descrito por SR-07 | Una persona, dios o voluntad que decide resultados |
| **Flujo** | Proceso o magnitud operativa arcana según SR-07 | Conocimiento, fe, talento o dominio |
| **Resonancias** | Patrones, principios o modos de interacción reconocidos por SR-07 | Elementos con ventajas automáticas o personalidades propias |
| **Arcana** | Nombre amplio para el ámbito de fenómenos, estudio, práctica y civilización relacionada con lo anterior | Una sustancia universal ilimitada, un hechizo único o una deidad |
| **Veyrath** | Lengua arcana de formulación definida en el Anexo A de SR-09 | Idioma cotidiano universal o lengua de los dioses |

Las sociedades pueden utilizar vocabulario impreciso o contradictorio. La documentación objetiva del mundo debe conservar la distinción anterior aunque los habitantes no la conozcan.

### 4.2. La Arcana no tiene voluntad

La Trama no posee voluntad propia. Las Resonancias no son, por sí mismas, seres conscientes. La Arcana no escucha plegarias, elige campeones, premia la virtud, castiga pecados ni decide quién merece poder.

Un fenómeno arcano puede producir resultados extraordinarios y cambiar profundamente la vida de una persona, pero su resultado debe proceder de mecanismos compatibles con SR-07. Una coincidencia temporal entre una plegaria y un efecto arcano no demuestra que la plegaria lo haya causado.

Una sociedad PUEDE creer que la Arcana tiene voluntad, que es el cuerpo de un dios, que es la huella de una creación antigua o que constituye la única realidad fundamental. Esas creencias son hechos culturales y psicológicos; no autorizan al sistema a declarar verdadera una explicación cosmológica que sigue reservada.

## 5. La civilización construida alrededor de la Arcana

La decisión de diseño de SR-13 es que la Arcana debe estar presente en gran parte de la historia y organización del mundo. No será una disciplina marginal practicada únicamente por aventureros. Su conocimiento ha influido en la forma en que distintas sociedades construyen, investigan, curan, producen, se comunican, se protegen y explican la realidad.

Esto no significa que todo edificio, herramienta, alimento o servicio funcione mediante magia. La civilización conserva agricultura, minería, carpintería, metalurgia, transporte animal o mecánico, comercio, medicina no arcana y trabajo manual. La Arcana amplía y transforma esas actividades; no las vuelve inútiles.

### 5.1. Ámbitos de influencia

Las sociedades PUEDEN desarrollar aplicaciones arcanas, siempre que cada una respete SR-07 y los costes de SR-10, en ámbitos como:

- **Iluminación y señalización:** lámparas, balizas, marcas de ruta y señales de emergencia.
- **Agua y saneamiento:** detección de contaminación, conducción, filtrado o tratamiento cuando exista un mecanismo válido.
- **Construcción:** medición, estabilización, corte, unión, aislamiento o refuerzo de materiales.
- **Agricultura y conservación:** observación del suelo, control de condiciones, conservación y apoyo al almacenamiento; no creación gratuita de cosechas.
- **Medicina:** diagnóstico, estabilización o tratamiento de lesiones y enfermedades mediante capacidades y procedimientos válidos; no resurrección ordinaria.
- **Comunicación:** señales, transmisión limitada o sistemas de aviso si disponen de fuente, alcance, infraestructura y mantenimiento.
- **Transporte y navegación:** orientación, señalización, análisis ambiental y asistencia técnica; no teletransporte universal por conveniencia.
- **Industria y artesanía:** control de temperatura, precisión, unión, tratamiento de materiales o herramientas especializadas.
- **Investigación:** observación, medición, experimentación, archivo y contraste de hipótesis.
- **Defensa civil:** alarmas, barreras, evacuación, detección de riesgos y protección de infraestructuras.

Cada aplicación debe especificar qué hace, qué no hace, qué fuente utiliza, qué operador o dispositivo requiere, qué consume, quién la mantiene, qué riesgos presenta y qué ocurre cuando falla.

### 5.2. Arcana no equivale a energía gratuita

La Arcana NO DEBE convertirse en un recurso infinito disponible en cualquier lugar. Ninguna aplicación pública se mantiene solo porque exista en la interfaz o porque una ciudad sea avanzada.

Un sistema arcano necesita, según corresponda, una fuente válida, captación o acceso, compatibilidad, conducción, regulación, operador, dispositivo, materiales, mantenimiento y condiciones ambientales. Puede ser caro, limitado, peligroso, especializado o imposible en ciertos lugares.

Si una ciudad pierde una fuente, un canal, un operador cualificado o una infraestructura esencial, puede sufrir cortes, reducción de servicios, daños o conflictos. La respuesta debe ser causal: mantenimiento, sustitución, reparación, rutas alternativas, racionamiento o abandono.

### 5.3. Diferencias de desarrollo

No todas las culturas dominan la Arcana del mismo modo. Una sociedad puede poseer técnicas arcanas sofisticadas y una organización política fragmentada; otra puede utilizar poca Arcana pero destacar en navegación, metalurgia, agricultura, medicina convencional o administración.

El acceso puede variar por recursos, educación, geografía, tradición, seguridad, decisiones políticas y disponibilidad de especialistas. No se debe asumir que todas las regiones están en el mismo nivel de desarrollo.

## 6. La Arcana en la vida cotidiana

La familiaridad con la Arcana podrá ser amplia, pero el dominio técnico continuará siendo desigual. Un ciudadano puede reconocer una lámpara arcana, comprender señales de peligro y saber qué hacer ante una fuga sin ser capaz de formular un hechizo.

La sociedad podrá distinguir entre:

- **Uso cotidiano:** interacción con artefactos o servicios ya preparados.
- **Competencia práctica:** mantenimiento básico o manejo de herramientas arcanas comunes.
- **Formación especializada:** comprensión de principios, diagnóstico, diseño o reparación.
- **Práctica avanzada:** formulación, investigación o intervención compleja que requiere conocimiento, aptitud y control.
- **Investigación de frontera:** trabajo experimental cuyo resultado puede ser incierto y peligroso.

La alfabetización arcana, cuando exista, no será idéntica a saber Veyrath. Tampoco todo uso de una herramienta arcana requiere que el usuario conozca la formulación que permitió fabricarla.

# PARTE III — FAMILIA, COMUNIDAD Y CULTURA

## 7. Individuos, hogares y familias

La familia no tendrá una única forma universal. Puede organizarse por parentesco biológico, adopción, crianza, matrimonio, pactos, afinidad, convivencia, linaje, clan, tutela, comunidad elegida u otras tradiciones.

Un hogar puede contener una familia extensa, una pareja, una persona sola, compañeros sin parentesco, varias generaciones, aprendices, personas acogidas o una combinación de estos grupos.

Las relaciones familiares pueden incluir afecto, cuidado, dependencia, deber, conflicto, distancia, abuso, reconciliación, herencia, rivalidad y ruptura. Ninguna relación familiar debe asumirse siempre positiva ni siempre obligatoria.

### 7.1. Parentesco y herencia social

Debe distinguirse parentesco biológico, filiación legal, crianza, pertenencia cultural, herencia material, tutela y reconocimiento social. No son equivalentes y pueden producir derechos u obligaciones diferentes.

Los linajes pueden conservar nombre, reputación, oficio, patrimonio, títulos, secretos, deudas, alianzas o prejuicios. La descendencia no hereda automáticamente las habilidades, la clase, la reputación individual ni el dominio de sus progenitores.

### 7.2. Hogares y economía

Los hogares participan en la economía mediante trabajo, consumo, cuidado, producción, ahorro, deuda, herencia, cooperación y distribución de recursos. Sus condiciones obedecen SR-10. La pobreza, la prosperidad y la seguridad material tienen consecuencias reales.

## 8. Comunidad e identidad cultural

Una cultura comprende prácticas, recuerdos compartidos, formas de organización, lenguas, conocimientos, símbolos, normas, artes, técnicas, celebraciones, relatos y maneras de interpretar el entorno.

La cultura no es una personalidad colectiva uniforme. Dos personas de una misma comunidad pueden tener convicciones, intereses, costumbres y lealtades distintas. Las culturas contienen desacuerdos internos y cambian con el tiempo.

### 8.1. Componentes culturales posibles

- lengua o conjunto de lenguas;
- relatos de origen e historia;
- costumbres familiares y de hospitalidad;
- alimentación y formas de producción;
- vestimenta, ornamento y expresiones artísticas;
- educación y transmisión de oficio;
- normas de cortesía y resolución de conflictos;
- relación con territorio, naturaleza y Mazmorra;
- interpretaciones de la Arcana;
- creencias religiosas y filosóficas;
- memoria de guerras, migraciones, epidemias y catástrofes;
- formas de celebrar, lamentar, recordar y honrar a los muertos.

### 8.2. Cultura y cambio

Las culturas pueden transformarse por migración, comercio, matrimonios, conquistas, descubrimientos, crisis, nuevas tecnologías, cambios ambientales, reformas, conflictos generacionales y contacto con otras especies o pueblos.

No se debe congelar una cultura en un estado inicial. Tampoco se debe reemplazarla de golpe sin acontecimientos que expliquen el cambio.

## 9. Lenguas, escritura e interpretación

No existe obligación de que todos los habitantes compartan una lengua cotidiana. Podrán existir lenguas regionales, dialectos, lenguas de oficio, lenguas de prestigio, lenguas antiguas, lenguas de comercio y sistemas de escritura propios.

Veyrath conserva su función de lengua arcana en el ámbito definido por el Anexo A de SR-09. No será por defecto la lengua materna de los pueblos, el idioma universal del comercio ni una lengua divina confirmada.

La traducción puede facilitar comunicación, pero puede perder matices, referencias culturales, dobles sentidos y terminología técnica. Un intérprete no adquiere automáticamente conocimiento de la materia que traduce.

La documentación social debe distinguir nombre propio, exónimo, endónimo, título, cargo, apodo, traducción y nombre histórico. Un mismo lugar o institución puede tener varios nombres utilizados por grupos distintos.

## 10. Tradición, arte y memoria colectiva

El arte, la música, la arquitectura, los relatos, los juegos, las ceremonias y las celebraciones forman parte de la vida social. No deben existir solo como objetos decorativos: pueden expresar identidad, transmitir conocimiento, reforzar vínculos, cuestionar autoridades o conservar memoria.

Los relatos colectivos pueden ser ciertos, parcialmente ciertos, falsos, simbólicos o discutidos. Una tradición no cambia por sí sola los hechos objetivos; sí puede modificar decisiones y relaciones si los individuos creen en ella.

Las celebraciones relacionadas con la Arcana pueden coincidir con fenómenos estacionales o resonantes conocidos. Su valor social no prueba una intervención consciente. Si una ceremonia incluye una operación arcana real, esta debe satisfacer los requisitos de SR-07 y no funciona por la mera asistencia o devoción.

# PARTE IV — EDUCACIÓN, CONOCIMIENTO Y FORMACIÓN

## 11. Aprendizaje social

La educación se desarrolla mediante familias, tutores, maestros, escuelas, academias, gremios, talleres, archivos, bibliotecas, instituciones religiosas, tradición oral, investigación y práctica cotidiana.

El acceso depende de recursos, ubicación, estatus, tiempo, leyes, capacidad de las instituciones y decisiones familiares o individuales. No todos los habitantes reciben educación formal; tampoco todos los conocimientos se transmiten por escrito.

### 11.1. Formación básica

Las sociedades pueden enseñar lectura, escritura, cálculo, historia local, normas comunes, seguridad, salud básica, orientación, trabajo doméstico y conocimientos prácticos. El contenido y la universalidad de esa formación varían.

### 11.2. Aprendizaje profesional

Los oficios se aprenden mediante observación, instrucción, práctica, repetición con corrección, responsabilidad creciente y evaluación del trabajo. La edad, capacidad, recursos y cultura influyen en la trayectoria, sin imponer una única edad universal para empezar o terminar.

Un gremio puede reconocer a un profesional; esa certificación no crea su conocimiento. Un individuo puede ser competente sin reconocimiento institucional, y una certificación puede estar equivocada o ser corrupta.

## 12. Academias, archivos y centros de investigación

Pueden existir academias arcanas, escuelas de artesanía, colegios médicos, observatorios, bibliotecas, archivos, círculos de investigación, laboratorios, escuelas militares y centros de estudio independientes.

Cada institución debe tener una finalidad, recursos, miembros, reglas, fuentes de financiación, autoridad, reputación, límites y procedimientos de transmisión o custodia de conocimientos.

La investigación puede fallar, producir resultados ambiguos, ser censurada, quedar sin financiación, generar accidentes o contradecir teorías aceptadas. El descubrimiento requiere evidencia y validación conforme a SR-01, SR-03 y SR-04.

### 12.1. Educación arcana

La formación arcana debe separar al menos:

1. familiaridad cultural con la Arcana;
2. percepción o sensibilidad pertinente;
3. conocimientos básicos sobre seguridad y funcionamiento;
4. teoría de Trama, flujo o Resonancias según SR-07;
5. conocimiento de herramientas, fuentes y materiales;
6. aprendizaje de Veyrath cuando la práctica lo requiera;
7. formulación, ejecución y control;
8. dominio de operaciones concretas;
9. mantenimiento, diagnóstico e investigación;
10. responsabilidad profesional y límites éticos.

No todas las personas tienen aptitud, sensibilidad, estructura o interés para cada práctica. La falta de aptitud para formular no impide necesariamente trabajar con dispositivos preparados, investigar historia arcana, fabricar componentes o prestar apoyo.

## 13. Conocimiento, secreto y propiedad intelectual

El conocimiento puede ser público, privado, familiar, gremial, académico, militar, religioso, restringido o perdido. Las sociedades pueden proteger procedimientos por seguridad, competencia económica, prestigio, control político o tradición.

Un secreto no se convierte en verdad objetiva por estar custodiado. Una institución puede monopolizar información y también equivocarse.

La transmisión de conocimientos debe tener un medio: enseñanza, texto, demostración, práctica, conversación, archivo, contrato o descubrimiento independiente. Leer un texto no otorga automáticamente dominio.

# PARTE V — PROFESIONES, ORGANIZACIONES E INSTITUCIONES

## 14. Oficios y división del trabajo

La sociedad requiere actividades productivas, logísticas, educativas, sanitarias, administrativas, artísticas, defensivas y de investigación. Ninguna profesión debe limitarse a una etiqueta de clase de SR-12.

Una persona puede combinar varios oficios, cambiar de ocupación, trabajar temporalmente, estar desempleada, ejercer informalmente o realizar tareas de cuidado no remuneradas.

La destreza profesional se desarrolla conforme a SR-12 y las condiciones económicas conforme a SR-10. La Arcana puede intervenir en cualquier oficio cuando existan mecanismos y formación válidos.

## 15. Gremios y asociaciones

Los gremios pueden coordinar formación, estándares, reputación, contratos, seguridad, acceso a herramientas, compras conjuntas, negociación, apoyo mutuo y resolución interna de disputas.

Un gremio no tiene monopolio universal por el simple hecho de existir. Puede haber asociaciones rivales, profesionales independientes, talleres familiares, redes informales y trabajo clandestino.

La influencia del gremio depende de su membresía, reputación, capacidad económica, acuerdos, reconocimiento legal y fuerza real. Puede fragmentarse, ser reformado, perder miembros o ser desplazado.

### 15.1. Gremio de aventureros

El gremio de aventureros, ya previsto en SR-10 y SR-11, puede registrar expediciones, publicar contratos, verificar evidencias, canalizar compradores, ofrecer servicios y mantener archivos de incidentes. No es dueño de todos los aventureros ni autoridad automática sobre todo el reino.

La certificación o rango institucional no sustituye las capacidades reales de una persona. Las reclamaciones, disputas de botín, lesiones, fallecimientos y contratos deben resolverse mediante pruebas y reglas aplicables.

### 15.2. Asociaciones profesionales

Pueden existir asociaciones de sanadores, constructores, comerciantes, mineros, exploradores, navegantes, artesanos, investigadores, traductores, maestros y otros grupos. Sus funciones y poder varían por región.

## 16. Instituciones de servicio público

Las comunidades pueden mantener guardias, tribunales, archivos, escuelas, hospitales, almacenes, servicios de agua, saneamiento, bomberos, refugios, caminos, vigilancia, mensajería y ayuda a personas vulnerables.

La existencia de una institución no garantiza su eficacia, cobertura universal ni honestidad. Deben existir presupuestos, trabajadores, equipos, autoridad, reglas, mantenimiento y rendición de cuentas cuando corresponda.

Las instituciones pueden depender de impuestos, donaciones, cuotas, patrimonio, contratos, trabajo comunitario o financiación mixta, conforme a SR-10.

## 17. Instituciones arcanas

La Arcana tendrá instituciones propias y también estará integrada en instituciones ordinarias. No se exige que todas las regiones posean una gran academia central.

Pueden existir:

- **Casas de estudio:** enseñanza, biblioteca, investigación y certificación.
- **Talleres de artefactos:** fabricación, calibración y reparación de dispositivos.
- **Custodias de fuentes:** mantenimiento y seguridad de infraestructuras arcanas.
- **Observatorios:** registro de fenómenos y estudio de Resonancias.
- **Colegios de formulación:** formación en Veyrath, teoría y ejecución.
- **Servicios de inspección:** revisión de instalaciones, incidentes y riesgos.
- **Archivos de conocimiento:** custodia de documentos, fórmulas, registros y descubrimientos.
- **Órdenes de campo:** respuesta a anomalías, rescates, expediciones o trabajos de alto riesgo.

Estos son tipos funcionales, no nombres propios obligatorios. Los nombres definitivos deben seguir la Guía de Nomenclatura y reflejar la cultura que los creó.

# PARTE VI — CREENCIAS, RELIGIONES Y FILOSOFÍAS

## 18. Incertidumbre cosmológica preservada

La existencia, naturaleza, número, origen y mecanismos de los dioses permanecen sin definir. SR-13 no elige una explicación definitiva ni convierte una creencia popular en una ley del universo.

Los habitantes pueden creer en deidades, espíritus, ancestros, fuerzas primordiales, inteligencias, principios impersonales, destino, ciclos, fuerzas de la naturaleza o ninguna entidad sobrenatural. Pueden fundar iglesias, templos, cultos, órdenes, monasterios, movimientos filosóficos y tradiciones de culto.

La decisión de una sociedad de llamar divina a la Arcana no demuestra que la Arcana sea una divinidad. La decisión de otra sociedad de considerarla un fenómeno natural tampoco resuelve la cosmología última.

## 19. Religión como realidad social

Las religiones y sistemas de creencias pueden organizar:

- calendarios, celebraciones y ritos de paso;
- normas de conducta y modelos de virtud;
- ayuda mutua, caridad, hospitalidad y cuidado;
- entierros, duelo y memoria de los muertos;
- educación, archivos y transmisión de relatos;
- liderazgo, jerarquía, pertenencia e identidad;
- arte, música, arquitectura y símbolos;
- juramentos, reconciliación, mediación y justicia comunitaria;
- explicaciones del sufrimiento, la fortuna, la muerte y la existencia.

Pueden proporcionar consuelo, comunidad y sentido, pero también producir disputas, exclusión, coerción, rivalidades, reformas, divisiones y abusos. No deben representarse todas las religiones como buenas ni como malvadas.

## 20. La adoración no concede poder

La oración, devoción, sacrificio, culto, número de creyentes, pureza moral o pertenencia religiosa NO DEBEN conceder por sí solos poderes, bendiciones, hechizos, curación, protección sobrenatural ni intervención divina confirmada.

Una ceremonia colectiva puede tener efectos psicológicos, sociales, políticos, físicos o logísticos reales. Si incluye una operación arcana, el resultado deriva de la formulación, fuente, conocimiento, materiales, condiciones y ejecución que exige SR-07; no de la cantidad de personas que creen.

Un personaje puede interpretar un éxito como respuesta divina. Esa interpretación forma parte de su memoria y cosmovisión, no prueba causalidad sobrenatural.

## 21. La Arcana y lo sagrado

La Arcana podrá ocupar en muchas culturas un lugar comparable al que tienen los grandes principios sagrados en otras sociedades de fantasía. Puede inspirar reverencia, asombro, temor, humildad, disciplina y sentido de pertenencia.

SR-13 recomienda una pluralidad de respuestas culturales:

1. **Vía contemplativa:** entiende la Arcana como orden profundo que debe observarse con respeto.
2. **Vía custodial:** considera deber moral conservar fuentes, conocimientos y equilibrio de infraestructuras.
3. **Vía investigadora:** entiende la Arcana como realidad que debe estudiarse y explicarse mediante evidencia.
4. **Vía devocional:** interpreta la Arcana como manifestación de una divinidad o de un misterio superior, sin que el sistema confirme esa interpretación.
5. **Vía instrumental:** la trata como campo de técnicas y aplicaciones, sin reverencia religiosa.
6. **Vía crítica:** teme sus riesgos, desigualdades, usos militares o consecuencias ambientales y sociales.
7. **Vías sin Arcana central:** culturas que priorizan otros principios, formas de vida o sistemas de conocimiento.

Estas vías son familias conceptuales para construir culturas, no religiones canónicas con nombres o dogmas fijados. Pueden coexistir, mezclarse o enfrentarse dentro de una misma región.

## 22. Diferencia entre fe, magia y fraude

El sistema debe distinguir:

- un acto de fe o rito social;
- una operación arcana demostrable;
- un fenómeno natural mal interpretado;
- una coincidencia;
- una afirmación no verificada;
- una falsificación o fraude deliberado;
- un fenómeno extraordinario legítimo cuya causa todavía se desconoce.

No se debe declarar fraude únicamente porque una afirmación sea extraña. Tampoco se debe declarar milagro porque un testigo lo crea. La investigación requiere evidencia, límites de conocimiento y posibilidad de error.

# PARTE VII — LEYES, JUSTICIA Y ORDEN SOCIAL

## 23. Pluralidad jurídica

No existe un único código legal para todos los pueblos. Las leyes pueden derivar de monarquías, consejos, asambleas, autoridades religiosas, costumbres, pactos, códigos gremiales, comunidades locales u organizaciones distintas.

Cada régimen debe poder definir jurisdicción, autoridad, sujetos, normas, procedimientos, sanciones, apelaciones, excepciones, aplicación y límites reales de cumplimiento.

Una ley escrita puede no aplicarse de forma uniforme. Una costumbre puede tener gran fuerza social aunque no esté codificada. El sistema debe distinguir norma formal, práctica habitual, abuso de autoridad y percepción popular.

## 24. Justicia y resolución de conflictos

Las comunidades pueden utilizar tribunales, jueces, árbitros, mediadores, consejos, jurados, autoridades locales o mecanismos tradicionales. El procedimiento debe considerar pruebas, testigos, reputación, documentos, interpretación, conflicto de intereses y posibilidad de error.

La justicia puede ser desigual, lenta, corrupta, severa, reparadora, restaurativa o arbitraria según la institución y el contexto. SR-13 no presupone que toda autoridad sea legítima ni que toda rebelión sea justa.

### 24.1. Categorías de conflicto

Pueden surgir disputas por propiedad, deuda, contratos, herencia, agresión, homicidio, negligencia, fraude, uso de Arcana, daño a infraestructura, abuso de autoridad, discriminación, acceso a recursos, límites territoriales o incumplimiento de pactos.

Las consecuencias deben respetar SR-09 cuando exista daño o combate y SR-10 cuando se afecten recursos, deudas o propiedad.

## 25. Aplicación de la ley y seguridad

Guardias, vigilantes, milicias, investigadores, autoridades locales y otras organizaciones pueden mantener el orden. Su poder efectivo depende de personal, disciplina, equipo, logística, jurisdicción, reputación y cooperación comunitaria.

La ley no se ejecuta telepáticamente. Los responsables necesitan información, acceso, tiempo y capacidad para actuar. La corrupción, el miedo, los conflictos de jurisdicción y la falta de recursos pueden impedir su aplicación.

## 26. Regulación de la Arcana

Las sociedades pueden regular la Arcana por seguridad pública, estabilidad de infraestructuras, protección militar, protección de fuentes, propiedad intelectual, monopolio, religión o control político.

Las reglas pueden exigir permisos para ciertas operaciones, inspecciones, certificaciones, límites de acceso, registro de artefactos, formación mínima, protocolos de emergencia o sanciones por uso peligroso.

La regulación no hace automáticamente segura una práctica ni convierte en ilegal toda investigación no autorizada. Deben existir tensiones reales entre libertad de investigación, seguridad, poder institucional, necesidad social y monopolio.

# PARTE VIII — GOBIERNO, PODER Y POLÍTICA

## 27. Formas de gobierno

Pueden existir reinos, principados, ciudades libres, confederaciones, repúblicas, consejos, ligas, clanes, señoríos, teocracias, gobiernos militares, administraciones gremiales o sistemas híbridos.

Ninguna forma de gobierno es universal ni necesariamente estable. Su legitimidad puede derivar de tradición, sucesión, consentimiento, conquista, capacidad de proteger, riqueza, religión, ley, reputación, fuerza o combinación de factores.

### 27.1. Autoridad y sucesión

Cada régimen puede tener reglas de sucesión, elección, nombramiento, herencia, destitución, regencia o disputa. La autoridad formal y el poder real pueden estar separados.

Un gobernante puede conservar el título y perder control territorial; una institución puede influir en decisiones sin ocupar el gobierno; una ciudad puede obedecer formalmente a un reino y negociar su autonomía de hecho.

### 27.2. Administración

La administración puede incluir recaudación, registros, justicia, caminos, comercio, obras públicas, seguridad, salud, educación, diplomacia y gestión de recursos. Su eficacia depende de personal, presupuesto, información, transporte y mecanismos de supervisión.

## 28. Poder político y Arcana

El dominio de recursos arcanos, especialistas, infraestructuras, archivos y fuentes puede influir en la política. Sin embargo, la Arcana no determina automáticamente quién gobierna ni garantiza la victoria militar.

Las sociedades pueden disputar quién controla una fuente, quién puede estudiar Veyrath, quién mantiene una instalación, quién recibe servicios, qué investigaciones se permiten y quién asume los riesgos.

Un monopolio arcano puede generar riqueza y estabilidad, pero también dependencia, desigualdad, contrabando, corrupción o resistencia. Una distribución más abierta puede ampliar acceso y competencia, pero aumentar riesgos si falta formación, mantenimiento o supervisión.

## 29. Diplomacia y relaciones entre pueblos

Los pueblos y gobiernos pueden mantener alianzas, rivalidades, tratados, comercio, matrimonios políticos, intercambio de estudiantes, acuerdos de tránsito, protección mutua, disputas fronterizas, embargos, espionaje y guerra.

Los acuerdos deben contener partes, obligaciones, duración, condiciones, mecanismos de cumplimiento y consecuencias de incumplimiento. La firma de un tratado no obliga a que todos los actores lo respeten.

# PARTE IX — DIVERSIDAD DE ENTIDADES Y CONVIVENCIA

## 30. Especie, cultura y persona no son equivalentes

La especie no determina automáticamente personalidad, moral, inteligencia, religión, ocupación, ciudadanía o lealtad. Las culturas pueden tener tendencias o tradiciones, pero no deben aplicarse como atributos idénticos a cada individuo.

Los prejuicios, estereotipos y discriminación pueden existir dentro del mundo como hechos sociales. El sistema debe distinguir esas creencias de la naturaleza objetiva del individuo.

## 31. Estatus jurídico de entidades no humanas

La condición de persona jurídica o sujeto social puede variar entre sociedades. Para valorar el reconocimiento de una entidad deben considerarse, cuando proceda:

- identidad individual persistente;
- agencia y capacidad de decisión;
- comprensión de normas y acuerdos;
- capacidad de comunicar voluntad, consentimiento o rechazo;
- memoria y continuidad;
- posibilidad de sufrir daño o perjuicio conforme a su naturaleza;
- responsabilidad y capacidad de reparar consecuencias;
- vínculos sociales y participación comunitaria.

Un gólem activo no obtiene automáticamente todos los derechos de una persona; tampoco debe ser tratado automáticamente como una herramienta si demuestra identidad, agencia y comprensión suficientes. Las sociedades pueden discrepar y revisar sus leyes conforme a nuevos descubrimientos.

Los monstruos no obtienen ciudadanía automática por ser individuos, pero una criatura inteligente, comunicativa y con agencia puede generar dilemas morales, jurídicos y políticos que el mundo debe poder representar.

## 32. Ciudadanía, pertenencia y migración

La pertenencia a una comunidad puede derivar de nacimiento, residencia, adopción, juramento, servicio, naturalización, parentesco, ciudadanía, membresía o costumbre. Cada sociedad define sus propios procedimientos.

Migrantes, refugiados, viajeros, aventureros y personas desplazadas pueden encontrar acogida, rechazo, explotación, integración o conflicto. Las rutas, fronteras, recursos y leyes afectan estos procesos.

# PARTE X — CONFLICTO, GUERRA Y PROTECCIÓN COMUNITARIA

## 33. Conflictos internos y externos

Las sociedades pueden experimentar disputas políticas, rivalidades económicas, tensiones religiosas, conflictos gremiales, rebeliones, criminalidad organizada, luchas por sucesión, guerras, ocupaciones y procesos de reconciliación.

Los conflictos no se activan para producir una misión. Surgen de intereses, recursos, identidades, temores, agravios, oportunidades, información y decisiones de actores concretos.

## 34. Guerra y Arcana

La Arcana puede transformar fortificaciones, comunicación, logística, reconocimiento, protección, medicina, sabotaje y combate. No sustituye las necesidades de alimentación, transporte, descanso, materiales, disciplina, mando, información y reemplazos.

Las operaciones arcanas de guerra requieren fuentes, operadores, preparación, infraestructura, conocimiento y contramedidas. Una fuerza que depende de un único sistema puede quedar vulnerable si este falla, se interrumpe o es capturado.

No toda guerra será una batalla de magos. La fuerza física, el terreno, la movilidad, la diplomacia, la economía, la inteligencia y la moral pueden ser decisivos.

## 35. Desastres y protección civil

Incendios, derrumbes, inundaciones, epidemias, anomalías arcanas, fallos de infraestructuras, crisis de abastecimiento y ataques pueden afectar comunidades.

La respuesta depende de preparación, conocimientos, recursos, organización, rutas y confianza pública. Una institución puede salvar vidas, fracasar o agravar una crisis. Las consecuencias deben persistir y afectar la memoria colectiva.

# PARTE XI — VIDA SOCIAL DE LA MAZMORRA Y LOS AVENTUREROS

## 36. La Mazmorra como fuerza social

La Mazmorra influye en la economía, la política, la cultura, la educación y la vida familiar de las regiones cercanas. No es únicamente un escenario de combate.

Puede generar empleo, riqueza, investigación, rutas comerciales, migración, prestigio, desigualdad, lesiones, muerte, deuda, dependencia económica y conflictos sobre acceso y control.

Los pisos descubiertos, los mapas, los patrones de monstruos y las historias de expedición pueden convertirse en conocimiento valioso. Su fiabilidad dependerá de evidencia, experiencia, actualización y posibilidad de error.

## 37. Cultura aventurera

La profesión de aventurero puede tener prestigio, desprecio, temor, reconocimiento o ambivalencia. Los habitantes pueden admirar a quienes protegen rutas, desconfiar de quienes atraen peligros, depender de su trabajo o lamentar sus pérdidas.

Las familias de aventureros fallecidos, desaparecidos o incapacitados pueden afrontar duelo, deuda, reclamaciones, herencia, apoyo comunitario o abandono institucional. El gremio y las autoridades pueden ofrecer servicios, pero no garantizan solución.

Los aventureros no forman una clase social homogénea. Hay principiantes, veteranos, exploradores, mercenarios, investigadores, escoltas, saqueadores ilegales, trabajadores de apoyo, sanadores y grupos con objetivos distintos.

# PARTE XII — AUTONOMÍA SOCIAL, MEMORIA Y PERSISTENCIA

## 38. Organizaciones como actores autónomos

Las instituciones y organizaciones deben poder tener:

- identidad y propósito;
- miembros, cargos y reglas internas;
- recursos, patrimonio, deudas e ingresos;
- autoridad formal y poder efectivo;
- reputación y relaciones externas;
- conocimientos, archivos y secretos;
- objetivos a corto y largo plazo;
- conflictos internos y mecanismos de sucesión;
- límites materiales, políticos y legales;
- acontecimientos relevantes y memoria histórica.

No es necesario simular cada conversación o trámite rutinario con máxima precisión. SR-06 puede utilizar resolución agregada, siempre que preserve consecuencias relevantes.

## 39. Cambio institucional

Una institución puede fundarse, crecer, reformarse, fusionarse, dividirse, cambiar sus objetivos, perder legitimidad, ser capturada, quebrar, ser prohibida o desaparecer.

Los cambios importantes deben tener causas: recursos, decisiones, conflictos, cambios de miembros, presión social, descubrimientos, derrotas, reformas o transformaciones externas.

## 40. Memoria social y versiones de la historia

Los archivos oficiales, relatos populares, testimonios, tradiciones religiosas y memorias familiares pueden diferir. La realidad objetiva se conserva conforme a SR-04, mientras los individuos conocen versiones parciales.

La propaganda, censura, falsificación, pérdida de archivos, traducción, oralidad y olvido pueden modificar lo que una sociedad cree recordar. El registro histórico no se altera automáticamente porque una autoridad cambie un libro.

# PARTE XIII — CONTRATOS DE DATOS Y TRAZABILIDAD

## 41. Perfil social mínimo

El modelo lógico debe poder representar, según corresponda:

- identidad individual y vínculos;
- hogar, familia, parentesco y tutela;
- pertenencia cultural y comunitaria;
- lenguas conocidas y grado de competencia;
- educación, maestros, alumnos y credenciales;
- ocupaciones, oficios, profesiones y asociaciones;
- creencias, afiliaciones religiosas o filosóficas y grado de convicción;
- reputación y relaciones sociales;
- ciudadanía, residencia y estatus jurídico;
- obligaciones, contratos y derechos;
- instituciones, cargos y membresías;
- normas, jurisdicciones y autoridades;
- acceso a servicios y recursos;
- conocimiento arcano y acceso a formación o infraestructura;
- acontecimientos, decisiones, causas y consecuencias.

No todas las entidades necesitan todos los campos. Los datos inaplicables deben declararse como tales, no rellenarse con valores ficticios.

## 42. Perfil institucional mínimo

Cada organización relevante debe poder registrar:

- identificador y denominación en sus lenguas;
- tipo, propósito y ámbito territorial;
- fecha y causa de fundación;
- reglas, estatutos o costumbres;
- autoridad, cargos y sucesión;
- miembros y criterios de admisión;
- recursos, patrimonio y obligaciones;
- infraestructura y dependencias;
- relaciones, alianzas, conflictos y jurisdicciones;
- conocimiento y archivos;
- legitimidad, reputación y poder efectivo;
- estado operativo, reformas y acontecimientos;
- causa y procedencia de sus cambios.

## 43. Trazabilidad de decisiones sociales

Los acontecimientos sociales relevantes deben registrar, según corresponda, participantes, fecha, lugar, jurisdicción, autoridad, norma aplicable, evidencias, decisiones, disensos, consecuencias, coste, recursos y procedencia.

La simulación no necesita registrar cada gesto o conversación trivial. Debe preservar suficiente información para reconstruir las decisiones con impacto duradero.

# PARTE XIV — PRUEBAS OBLIGATORIAS

## 44. Escenarios de verificación

1. Una familia mantiene vínculos y obligaciones durante varios ciclos de simulación sin intervención del jugador.
2. Dos miembros de una misma cultura mantienen creencias o decisiones incompatibles sin que uno deje de pertenecer a ella.
3. Un migrante cambia de comunidad y afronta procedimientos y reacciones locales.
4. Una institución pierde financiación y reduce servicios de manera coherente.
5. Un gremio rival compite por miembros sin monopolio automático.
6. Una persona competente ejerce un oficio sin certificación formal, si la ley local lo permite.
7. Una academia transmite teoría sin conceder dominio práctico automático.
8. Un personaje conoce un dispositivo arcano común sin saber formular Veyrath.
9. Una infraestructura arcana deja de funcionar por pérdida de fuente, mantenimiento o componente válido.
10. Una ciudad mantiene servicios alternativos cuando una instalación arcana falla, si posee recursos y organización.
11. Una celebración religiosa produce cohesión social sin conceder poderes por devoción.
12. Una ceremonia que incluye una formulación arcana funciona por sus condiciones y ejecución, no por el número de creyentes.
13. Dos religiones interpretan un mismo fenómeno de manera distinta sin que el sistema confirme automáticamente una de ellas.
14. Una autoridad cambia un registro oficial, pero no altera los hechos históricos objetivos.
15. Un tribunal comete un error por pruebas incompletas y el mundo conserva sus consecuencias.
16. Una reforma legal modifica conductas futuras sin reescribir retroactivamente todos los casos previos.
17. Una institución corrupta conserva influencia pese a perder legitimidad pública.
18. Una organización se divide por desacuerdos internos y genera entidades institucionales nuevas con procedencia.
19. Un investigador descubre una aplicación arcana y necesita recursos, evidencia, validación y transmisión para difundirla.
20. Un monopolio arcano genera desigualdad y resistencia social con causas materiales.
21. Una comunidad rechaza tecnología arcana por temor, doctrina, coste o experiencia histórica.
22. Otra comunidad utiliza la Arcana ampliamente sin compartir una religión común.
23. Un gólem activo solicita reconocimiento social y distintas instituciones lo evalúan según agencia, identidad y leyes locales.
24. Un monstruo inteligente manifiesta comunicación o intención y genera dilemas sociales sin recibir ciudadanía automática.
25. Una guerra interrumpe rutas, instituciones, servicios, educación y comercio; las consecuencias persisten.
26. Una crisis de la Mazmorra afecta reputación, economía, migración y política de la ciudad.
27. Los NPC organizan ayuda comunitaria sin una misión asignada al jugador.
28. Un habitante cambia de profesión por experiencia, necesidades y oportunidades, sin que la clase anterior lo bloquee.
29. Una institución continúa operando fuera de cámara con resolución agregada compatible con SR-06.
30. La misma semilla y las mismas entradas deterministas reproducen el mismo resultado cuando así se configure la prueba.

# PARTE XV — CALIBRACIÓN Y DECISIONES RESERVADAS

## 45. Parámetros sujetos a calibración

No quedan fijados por esta versión:

- nombres propios de reinos, ciudades, culturas, instituciones, religiones y cargos;
- lenguas cotidianas, escrituras, familias lingüísticas y reglas fonéticas detalladas;
- composición demográfica y distribución cultural de cada región;
- estructura detallada de hogares y parentesco por especie y cultura;
- índices de alfabetización, escolarización y acceso a educación;
- presupuestos, plantillas y capacidad de cada institución;
- formas de gobierno específicas, territorios, fronteras y leyes locales;
- tasas de criminalidad, corrupción, movilidad social y migración;
- alcance de servicios públicos y modelos de financiación;
- licencias, registros, clasificación de riesgos y regulación arcana regional;
- catálogo de artefactos e infraestructuras arcanas;
- distribución de conocimiento, monopolios, redes clandestinas y seguridad;
- religiones, doctrinas, órdenes, calendarios y tradiciones particulares;
- legislación sobre entidades activas no biológicas y monstruos inteligentes;
- relaciones diplomáticas, guerras y cronologías históricas específicas.

Estos vacíos no autorizan a inventar cifras o nombres definitivos sin procedencia. Se desarrollarán en atlas, catálogos, cronologías, fichas culturales y normas locales.

## 46. Decisiones estructurales ya aprobadas

La aprobación de SR-13 establece como norma que:

1. La Arcana ocupa un lugar central en la civilización y puede influir profundamente en infraestructura, economía, educación, cultura, política, medicina, investigación y vida cotidiana.
2. Arcana es un término amplio para fenómenos, conocimientos y aplicaciones relacionados con Trama, flujo y Resonancias; no redefine esos conceptos ni sustituye SR-07.
3. La Trama no tiene voluntad propia y la Arcana no concede poder por fe, oración, culto o número de creyentes.
4. Las interpretaciones religiosas y filosóficas de la Arcana pueden coexistir y estar en desacuerdo; ninguna queda confirmada automáticamente.
5. La existencia y naturaleza última de dioses y entidades divinas sigue sin resolverse.
6. Las infraestructuras arcanas necesitan fuente, mecanismo, operador o dispositivo, mantenimiento, costes y condiciones; no existe energía gratuita o ilimitada por conveniencia.
7. La sociedad no es homogénea: sus culturas, instituciones, gobiernos, leyes y religiones pueden diferir y cambiar.
8. Los individuos no quedan definidos por su especie, clase, cultura, familia o religión.
9. Las entidades no humanas y activas no biológicas pueden dar lugar a debates de estatus social y jurídico según agencia, identidad y capacidades.
10. Los acontecimientos sociales e institucionales relevantes persisten y producen consecuencias.

# DECLARACIÓN NORMATIVA FINAL

El mundo no necesita una voluntad divina confirmada para tener un fundamento extraordinario. En este universo, la Arcana atraviesa la historia de las civilizaciones: inspira preguntas, sostiene oficios, transforma ciudades, crea oportunidades, concentra poder, exige conocimiento y provoca conflictos. Puede ser contemplada como misterio, estudiada como fenómeno, utilizada como técnica, regulada como riesgo o venerada como sagrada.

Pero no es una persona que responde a quien la llama. No decide quién merece vivir, sanar, vencer o gobernar. Los pueblos pueden atribuirle intenciones; las instituciones pueden reclamar su autoridad; los investigadores pueden proponer explicaciones. La realidad objetiva permanece sujeta a las leyes del universo, no a la fe de sus habitantes.

La sociedad debe surgir de individuos que recuerdan, necesitan, desean, aprenden, se equivocan, cooperan y compiten. Sus instituciones deben tener poder y límites. Sus culturas deben tener identidad sin encerrar a sus miembros. Sus creencias deben influir en la vida sin convertirse automáticamente en magia. Y la Arcana debe ser suficientemente importante para que el mundo sea reconocible por ella, sin volverlo uniforme ni ilimitado.

**SR-13 v0.1 — NORMATIVA OFICIAL APROBADA.**

**Aprobación efectiva:** el autor autorizó expresamente que esta normativa quedara aprobada en la entrega, dejando al diseñador libertad para construir y aprobar la propuesta sin solicitar confirmación adicional salvo duda bloqueante. No se identificaron dudas bloqueantes.

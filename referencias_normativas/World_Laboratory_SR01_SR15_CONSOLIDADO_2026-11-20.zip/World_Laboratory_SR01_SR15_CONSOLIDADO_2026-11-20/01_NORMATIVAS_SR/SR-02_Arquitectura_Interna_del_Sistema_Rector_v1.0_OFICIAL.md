# SR-02 — Arquitectura interna del Sistema Rector

> **EDICIÓN OFICIAL:** documento aprobado por el autor e integrado en el canon normativo SR-01 a SR-15. Las secciones marcadas como PENDIENTE, CALIBRACIÓN o RESERVADO siguen abiertas en el alcance que el propio documento declara; la aprobación no inventa ni cierra esos parámetros.

**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Ámbito:** Fases 0–5  
**Dependencia:** SR-01.

# 0. Propósito

El Sistema Rector es la autoridad de coordinación que mantiene la coherencia del universo, permite que sus habitantes actúen autónomamente y valida las consecuencias de esas acciones. No es una única IA omnisciente ni un conjunto de scripts narrativos. Es una arquitectura de motores especializados, contratos de datos, autoridades de dominio y servicios de persistencia.

Debe poder funcionar en una máquina local para un mundo individual offline y escalar posteriormente a servicios distribuidos para un mundo compartido. La distribución física puede cambiar; los contratos lógicos no deben depender de un proveedor concreto.

# 1. Arquitectura de alto nivel

Los componentes principales son:

1. **System Core:** coordinación, reglas, versiones y autoridad.
2. **Entity Registry:** identidad y relaciones persistentes.
3. **World Model:** representación del estado objetivo.
4. **Cognitive Engine:** percepción, motivación, decisión y planificación.
5. **Memory Engine:** recuerdos, conocimientos y procedencia.
6. **Evolution Engine:** aprendizaje, adaptación y transformación.
7. **Causal Engine:** dependencias, causas y consecuencias.
8. **Narrative Engine:** detección y organización de oportunidades narrativas.
9. **Social Engine:** relaciones, grupos, sociedades y organizaciones.
10. **Ecology Engine:** poblaciones, recursos y procesos ecológicos.
11. **Creation Engine:** entidades, organismos, objetos y estructuras.
12. **Chronicle Engine:** acontecimientos históricos, snapshots y auditoría.
13. **Validation & Governance:** integridad, permisos y resolución de conflictos.
14. **World Execution:** tiempo, scheduling, simulación y clientes.

Los motores son límites de responsabilidad; no implican necesariamente procesos o servidores distintos en la primera implementación.

# 2. System Core

El núcleo coordina operaciones, aplica la constitución, versiona las reglas y determina qué autoridad puede confirmar cada cambio. No decide arbitrariamente las vidas de todos los habitantes. Los agentes formulan intenciones y los dominios resuelven las consecuencias dentro de sus competencias.

El núcleo proporciona:

- Identidad de mundo y versión de reglas.
- Registro de dominios y autoridades.
- Contratos de comandos y eventos.
- Coordinación de transacciones.
- Control de permisos.
- Gestión de fallos y recuperación.
- Políticas de prioridad y presupuesto.

# 3. Entity Registry

Mantiene identificadores persistentes, tipo de entidad, ámbito de autoridad, genealogía, vínculos, alias, continuidad y estado de ciclo vital. No utiliza el nombre ni la apariencia como clave.

Debe distinguir identidad de especie, plantilla, individuo, representación y proyección. Una representación gráfica no crea una identidad; una plantilla tampoco constituye un individuo.

Las operaciones de creación, división, fusión, copia, reencarnación y transformación deben declarar qué identidad se conserva y qué identidad nueva aparece.

# 4. World Model

Representa el estado objetivo consultable: entidades, ubicación, estado fisiológico, recursos, territorios, posesiones, relaciones objetivas, condiciones ambientales y procesos activos.

No es la memoria de un NPC. El World Model puede saber dónde está un objeto; un personaje solo lo sabe si lo ha visto, investigado o recibido información válida.

El World Model tendrá vistas materializadas para consultas rápidas y una relación rastreable con los acontecimientos que produjeron cada estado.

# 5. Cognitive Engine

El motor cognitivo administra agentes con capacidades diferenciadas. Su ciclo normativo es:

1. Percepción de señales disponibles.
2. Interpretación mediante conocimiento y memoria.
3. Evaluación de necesidades, motivaciones y objetivos.
4. Generación de alternativas.
5. Planificación de acciones.
6. Evaluación de riesgos, recursos y restricciones.
7. Emisión de una intención o comando.
8. Observación del resultado.
9. Aprendizaje y actualización de memoria.

El motor no ejecuta cambios globales directamente. Emite acciones que los dominios validan.

La arquitectura debe permitir perfiles de diferente complejidad. Un animal instintivo no requiere planificación lingüística; un aventurero puede usar planificación táctica; un investigador puede emplear razonamiento causal y experimentación. No se debe ejecutar un modelo generativo caro en cada ciclo de cada individuo.

# 6. Memory Engine

Gestiona memoria sensorial, episódica, semántica, procedimental, emocional, social, espacial y prospectiva. Cada recuerdo relevante mantiene origen, fecha de adquisición, contexto, confianza, importancia y referencias a entidades/eventos.

Distingue recuerdo, creencia, hipótesis, rumor, conocimiento reproducido y hecho objetivo. Permite olvido, deterioro y reinterpretación sin alterar la historia objetiva.

La memoria colectiva necesita mecanismos de transmisión: enseñanza, comunicación, documentos, comercio, investigación o instituciones.

# 7. Evolution Engine

Administra desarrollo individual, adaptación, mutación, transformación, herencia, evolución poblacional, evolución cognitiva y reencarnación cuando corresponda.

Cada cambio debe indicar mecanismo, condiciones, coste, beneficios, riesgos, rasgos afectados y procedencia. El motor no convierte cualquier deseo en transformación. Debe coordinarse con biología, ecología, Creation Engine y Governance.

# 8. Causal Engine

Relaciona operaciones con sus antecedentes y consecuencias. Debe poder explicar por qué una entidad tiene su estado actual, qué consecuencias están pendientes y qué dominios deben reaccionar.

Las consecuencias pueden ser inmediatas, individuales, sociales, económicas, ecológicas, regionales o históricas. El motor no inventa automáticamente resultados; determina dependencias y dispara evaluaciones pertinentes.

Los procesos largos pueden representarse como tareas causales pendientes con condiciones, fecha de revisión, recursos reservados y reglas de interrupción.

# 9. Narrative Engine

Detecta potencial narrativo en acontecimientos reales: desapariciones, promesas, rivalidades, deudas, hallazgos, conflictos y amenazas. Puede generar descripciones, objetivos y oportunidades, pero no falsifica hechos ni garantiza que el jugador resuelva una historia.

Una misión es una estructura de oportunidad y objetivos basada en el estado del mundo, no una autorización para crear resultados arbitrarios.

# 10. Social Engine

Gestiona relaciones asimétricas, parentesco, reputación, grupos, facciones, jerarquías, cultura, normas, alianzas, conflictos y memoria colectiva. Las organizaciones tienen miembros, recursos, objetivos, conocimientos y limitaciones. Las entidades no humanas pueden desarrollar sociedades cuando sus capacidades lo permitan.

# 11. Ecology Engine

Gestiona poblaciones, nacimiento, mortalidad, migración, depredación, reproducción, competencia, recursos, territorios, adaptación y presión ambiental. Debe conservar continuidad incluso si una zona no está cargada visualmente.

# 12. Creation Engine

Crea entidades lógicas, organismos, materiales, objetos, estructuras, capacidades y representaciones. Separa identidad lógica de assets visuales. Su especificación especializada se encuentra en SR-05.

# 13. Chronicle Engine

Registra acontecimientos objetivos con identidad, tiempo, participantes, autoridad, procedencia, versión de reglas y consecuencias. Mantiene relación entre historia inmutable, snapshots y estados materializados.

Los hechos confirmados no se sobrescriben silenciosamente. Las correcciones se expresan mediante eventos compensatorios, rectificaciones o mecanismos de dominio explícitos.

# 14. Validation & Governance

Valida estructura, causalidad, recursos, permisos, integridad histórica, reglas del dominio y concurrencia. Una rareza no es automáticamente un error. Ante un resultado excepcional, el sistema investiga si existe una causa válida antes de descartarlo.

La validación se especializa por dominio: física, biología, magia, economía, identidad, combate, creación, historia y sincronización no comparten una única regla simplista.

# 15. Contrato de comandos y acontecimientos

Una entidad o motor no modifica directamente el estado de otro dominio. Emite un comando tipado que incluye:

- Command ID único.
- Actor/entidad solicitante.
- Objetivo o entidades afectadas.
- Ámbito.
- Precondiciones observadas.
- Motivo o referencia al plan.
- Recursos requeridos.
- Versión del estado relevante.
- Correlation ID para vincular operaciones.

El dominio autorizado valida y, si corresponde, produce uno o más eventos confirmados. Los eventos son hechos; los comandos son solicitudes. Un comando rechazado no se convierte en hecho.

# 16. Flujo de una acción

1. Un agente percibe una situación.
2. Interpreta mediante memoria y conocimiento.
3. Selecciona un objetivo.
4. Planifica una o varias acciones.
5. Emite un comando.
6. El dominio competente valida precondiciones.
7. Governance verifica permisos e invariantes.
8. La operación se ejecuta de forma transaccional.
9. Chronicle registra el acontecimiento confirmado.
10. World Model actualiza la vista de estado.
11. Causal Engine programa consecuencias.
12. Los motores interesados reciben notificaciones.
13. Los agentes afectados pueden percibir el resultado y aprender.

# 17. Autoridad y concurrencia

Cada dominio tiene autoridad de escritura. No se utiliza «gana el último cambio» como política universal. Las operaciones sobre objetos únicos, recursos limitados, salud, propiedad, ubicación y recompensas requieren resolución atómica o serialización por clave de dominio.

Ejemplo: dos agentes pueden solicitar recoger el mismo objeto, pero solo una operación puede confirmar la transferencia de propiedad. La otra recibe un resultado válido: objeto ya tomado, acción fallida o alternativa de dominio.

# 18. Arquitectura de eventos y persistencia

El sistema utiliza registro de acontecimientos para hechos importantes, snapshots para recuperación y estado materializado para consultas eficientes. Cada evento incluye tipo, identificador, tiempo del mundo, entidades, ámbito, autoridad, versión, procedencia, causa y referencias a consecuencias.

No se registra cada fotograma. Se registran cambios de significado persistente y se agregan procesos repetitivos cuando el detalle no sea necesario.

# 19. Tiempo y scheduling

El scheduler administra tiempo universal con múltiples niveles de resolución: interacción, actividad, ecología e historia. Prioriza procesos por riesgo, impacto causal, complejidad, urgencia, relevancia para otros individuos y consecuencias pendientes.

Una zona no renderizada sigue teniendo estado y procesos. Puede actualizarse mediante simulación agregada, no por la cámara.

El tiempo global persiste durante la ausencia del jugador. En modo offline individual, el sistema local calcula el tiempo transcurrido al reabrir. En mundo compartido, la autoridad común determina el avance y resuelve sincronización.

# 20. Model Gateway e inteligencia opcional

La arquitectura puede conectar diferentes modelos locales o remotos, pero no dependerá de uno solo. El gateway selecciona herramientas según complejidad, latencia, coste y disponibilidad.

Código determinista y simulación estructurada resuelven invariantes, física, inventarios, transacciones y validaciones. Planificadores resuelven objetivos. Modelos generativos pueden proponer lenguaje, hipótesis y planes de alta complejidad. Toda propuesta se valida.

La caída de un proveedor no debe detener movimiento, combate básico, economía, persistencia ni continuidad del mundo.

# 21. Separación de cliente y servidor

El cliente Android se ocupa de renderizado, controles, animación, audio, UI, caché y predicción local. No es autoridad del estado compartido.

El motor de mundo administra estado, reglas, transacciones y sincronización. En modo offline, una instancia local del mismo núcleo puede ser autoridad de ese mundo individual. No se mantendrán dos implementaciones divergentes de las reglas si puede compartirse el mismo código de dominio.

# 22. Escalabilidad sin sobrearquitectura

La primera versión puede ejecutarse como proceso local modular. Los límites de dominio y contratos deben permitir distribuir componentes después. No se instalarán todos los servicios posibles desde el primer día.

PostgreSQL u otro almacenamiento relacional puede servir como fuente persistente; archivos locales pueden cubrir prototipos; colas, cachés, índices de búsqueda y servicios distribuidos se incorporarán solo cuando la carga lo justifique. La elección definitiva de tecnología corresponde al documento técnico de implementación.

# 23. Pruebas obligatorias

- 100 días simulados con continuidad.
- Muerte de NPC y actualización de relaciones.
- Desaparición de depredador y respuesta ecológica.
- Repetición de combate con aprendizaje estratégico.
- Escasez y adaptación.
- Varias generaciones y herencia.
- Fabricación experimental validada.
- Historias paralelas distintas con leyes iguales.
- Conflicto de concurrencia sobre objeto único.
- Caída de proveedor generativo sin paralizar mundo.
- Recuperación tras reinicio.
- NPC que formula hipótesis y puede equivocarse.

# 24. Criterios de cierre

La arquitectura estará lista para implementación cuando se definan: contratos de entidad y evento, autoridad por dominio, ciclo cognitivo, memoria con procedencia, scheduler, validadores, persistencia, manejo de concurrencia, políticas offline y pruebas repetibles. No basta con que los motores existan como nombres o módulos vacíos.

# Declaración fundacional

El Sistema Rector no es el personaje que controla el universo. Es el conjunto de mecanismos que permite que cada entidad exista, decida y produzca consecuencias dentro de una realidad coherente. Los motores pueden ser distribuidos; las leyes y la autoridad deben seguir siendo comunes.

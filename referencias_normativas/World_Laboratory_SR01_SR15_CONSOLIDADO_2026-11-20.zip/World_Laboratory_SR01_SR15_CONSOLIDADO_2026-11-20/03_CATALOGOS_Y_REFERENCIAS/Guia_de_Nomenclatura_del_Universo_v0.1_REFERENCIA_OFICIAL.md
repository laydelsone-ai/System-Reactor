# GUÍA DE NOMENCLATURA DEL UNIVERSO

**Proyecto:** World Laboratory / Sistema Reactor  
**Versión:** 0.1  
**Estado:** Directriz editorial aprobada por el autor  
**Fecha:** 2026-11-20

## Propósito

Establecer una identidad lingüística propia para los nombres del universo. Los nombres no deben parecer etiquetas temporales, nombres genéricos de fantasía ni palabras generadas al azar. Deben contribuir a que cada pueblo, cultura, región e institución se reconozca como parte de un mundo con historia.

## Principios de creación

1. **Identidad antes que cantidad.** Es preferible un nombre fuerte y reconocible a una lista larga de nombres intercambiables.
2. **Familias culturales.** Cada cultura o tradición podrá tener patrones de sonido, longitud, acentuación y escritura propios. No se impondrá una única estética a todo el mundo.
3. **Fácil lectura en español.** Los nombres deben poder pronunciarse sin tener que descifrar grupos de consonantes innecesarios.
4. **Sonoridad con carácter.** Se buscarán combinaciones fonéticas distintivas, equilibradas y memorables; no se abusará de apóstrofes, letras raras o terminaciones repetidas.
5. **No usar clichés como atajo.** Evitar nombres genéricos como «Bosque Oscuro», «Torre del Rey», «Tierras Malditas» o fórmulas equivalentes, salvo que sean nombres populares dentro del mundo y tengan justificación cultural.
6. **Diferenciación semántica.** Un reino, ciudad, bosque, mazmorra, clan, lengua y persona no deben confundirse por compartir nombres casi idénticos.
7. **Historia cuando aporte valor.** Se podrán desarrollar raíces, traducciones, cambios históricos, exónimos y nombres antiguos cuando enriquezcan el mundo; no se inventará una etimología forzada para cada término.
8. **Coherencia lingüística.** Una vez definidos los rasgos de una lengua cultural, los nombres vinculados a ella respetarán sus patrones salvo préstamos, evolución histórica o excepciones explicadas.
9. **Originalidad verificable.** Los nombres importantes se revisarán para evitar confusión con franquicias, personajes y topónimos notorios ya existentes.
10. **Control de canon.** Las propuestas no se vuelven nombres oficiales hasta incorporarse a un catálogo o documento aprobado.

## Referencia estética del autor

**Varyath** es la referencia que el autor señaló como ejemplo del estilo que le agrada: una sonoridad propia, breve y evocadora; fantástica pero no genérica; una grafía fácil de reconocer y recordar. Se empleará como patrón orientativo, no como molde que todos los nombres deban copiar.

**Nota de continuidad:** «Veyrath» es la denominación que figura en el Anexo A de magia aprobado. No se renombra automáticamente por parecido con «Varyath». Si se desea que «Varyath» sea la forma corregida del nombre de la lengua arcana, deberá confirmarse como corrección nominal específica.

## Aplicación

Esta guía se aplicará a topónimos, reinos, ciudades, barrios, regiones naturales, mazmorras, pisos, especies, linajes, personajes, idiomas, instituciones, artefactos, hechizos y fenómenos. Los futuros catálogos deberán procurar consistencia sin sacrificar la diversidad cultural del universo.

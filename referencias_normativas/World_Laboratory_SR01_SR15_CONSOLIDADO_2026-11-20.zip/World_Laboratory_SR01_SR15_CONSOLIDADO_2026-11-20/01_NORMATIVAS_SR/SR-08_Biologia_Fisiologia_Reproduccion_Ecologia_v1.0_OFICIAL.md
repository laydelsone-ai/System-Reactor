# SR-08 — BIOLOGÍA, FISIOLOGÍA, REPRODUCCIÓN Y ECOLOGÍA

**Código:** SR-08  
**Versión:** 1.0  
**Estado:** NORMATIVA OFICIAL — APROBADA POR EL AUTOR  
**Fecha de aprobación:** 2026-11-20  
**Ámbito:** organismos, entidades activas no biológicas, anatomía, fisiología, reproducción, herencia, desarrollo, monstruos, salud, ecosistemas y poblaciones.  
**Dependencias normativas:** SR-01 a SR-07.  
**Documento precedente:** *SR-08 — Biología, fisiología, reproducción y ecología*, borrador parcial 0.1, aprobado íntegramente por el autor y ampliado mediante las decisiones del 2026-11-20.

---

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Borrador parcial | Fundamentos, alcance biológico, anatomía, fisiología, reproducción, herencia y ecología. |
| 1.0 | Oficial aprobada | Incorpora íntegramente el borrador aprobado y las decisiones del autor sobre entidades activas no biológicas, generación de monstruos, compatibilidad interespecífica, herencia, longevidad monstruosa, crecimiento de poder, reencarnación, biología arcana, biomas de la mazmorra, enfermedades y alimentación. |

Las fórmulas, parámetros cuantitativos y catálogos concretos que este documento deja reservados no invalidan las reglas generales aprobadas. Deberán desarrollarse mediante especificaciones subordinadas o versiones posteriores de SR-08, sin contradecir esta normativa ni SR-01 a SR-07.

---

# 0. PROPÓSITO, AUTORIDAD Y LÍMITES

## 0.1. Propósito

SR-08 establece las reglas mediante las cuales los organismos existen, mantienen sus funciones, se desarrollan, se reproducen, transmiten características, se adaptan e interactúan con otros organismos y con sus entornos.

Su objetivo es que humanos, animales, monstruos y otras formas de vida no sean simples entidades colocadas en el mundo para cumplir una función narrativa. Cuando su naturaleza lo permita, podrán alimentarse, descansar, crecer, reproducirse, enfermar, recuperarse, desplazarse, competir, cooperar, migrar y afectar a su entorno mediante procesos causales.

SR-08 también establece la distinción entre organismos biológicos y entidades no biológicas que, pese a no estar vivas biológicamente, tienen actividad propia y pueden producir cambios en el mundo sin necesitar una manipulación externa inmediata.

## 0.2. Autoridad normativa

SR-01 conserva la autoridad constitucional. SR-08 desarrolla los mecanismos biológicos y ecológicos, pero no puede modificar la Ley de existencia, identidad, estado objetivo, causalidad, tiempo, vida, muerte, reencarnación, agencia, memoria, evolución universal, ecología, sociedad, progresión, consecuencias ni separación entre realidad y representación.

Las definiciones de especie, plantilla, individuo, anatomía funcional, fisiología, genotipo, fenotipo, creación, nacimiento y representación se coordinan con SR-05.

La identidad individual, continuidad, reencarnación, inteligencia, memoria, personalidad, aprendizaje y evolución individual se coordinan con SR-03.

La materia, energía, química, temperatura, presión, movimiento, materiales, Trama, flujo, Resonancias, costes, resistencias y demás interacciones naturales y arcanas obedecen SR-07.

La simulación autónoma, los procesos ecológicos fuera de la observación, la causalidad, la persistencia y la simulación por niveles de resolución se coordinan con SR-02, SR-04 y SR-06.

## 0.3. Alcance propio

SR-08 regula:

- fundamentos biológicos y clasificación funcional de organismos;
- distinción entre vida biológica, actividad autónoma y existencia como entidad;
- anatomía, órganos y sistemas corporales;
- fisiología, metabolismo, nutrición y necesidades vitales;
- sentidos y mecanismos sensoriales biológicos o equivalentes;
- crecimiento, desarrollo, edad y ciclos vitales;
- reproducción, gestación, incubación, nacimiento y herencia;
- compatibilidad reproductiva entre especies monstruosas;
- variación biológica, adaptación y formación de nuevos linajes;
- longevidad y acumulación de poder en monstruos;
- enfermedades, parásitos, inmunidad y recuperación;
- hábitats, nichos, poblaciones, relaciones tróficas y procesos ecológicos;
- generación de monstruos por la Mazmorra y reproducción de monstruos;
- biomas y organización ecológica por grupos de pisos de la Mazmorra;
- migración, competencia, depredación, extinción local y recolonización;
- interacción entre organismos y condiciones naturales o arcanas, dentro de los límites de SR-07.

## 0.4. Límites: materias que SR-08 no redefine

1. SR-08 no define la identidad personal ni cuándo una transformación conserva identidad; corresponde a SR-01 y SR-03.
2. SR-08 no convierte inteligencia, memoria, personalidad o aprendizaje en propiedades automáticas de una especie. SR-03 conserva la autoridad sobre cognición.
3. SR-08 no define el sistema general de progresión, niveles, experiencia o escalas universales de poder. Sí regula los fundamentos biológicos y los rasgos de longevidad de los monstruos establecidos aquí.
4. SR-08 no sustituye las reglas especializadas de combate, daño, movimiento, materiales o fabricación.
5. SR-08 no define la cosmología, el origen último de la vida, el origen de la Trama ni la existencia o naturaleza de deidades.
6. SR-08 no presume que todo ser sobrenatural sea biológico ni que toda entidad activa sea un organismo.
7. SR-08 no establece fórmulas universales, porcentajes concretos de compatibilidad, tasas de crecimiento, edades, esperanza de vida ni parámetros ecológicos que todavía no hayan sido aprobados.

## 0.5. Lenguaje normativo

- **DEBE / NO DEBE:** requisito obligatorio.
- **PUEDE / PODRÁ:** posibilidad permitida, condicionada por la naturaleza de la entidad y las demás leyes.
- **NO SE PRESUME:** no puede darse por cierto sin mecanismo, evidencia o regla aprobada.
- **RESERVADO:** el principio está fijado, pero su fórmula, catálogo o parámetro necesita desarrollo posterior.

---

# PARTE I — EXISTENCIA, VIDA Y CLASIFICACIÓN DE ENTIDADES

## 1. Vida como proceso biológico

### 1.1. Vida biológica

La vida biológica es un proceso organizado de continuidad, mantenimiento y transformación de un organismo mediante mecanismos fisiológicos propios de su naturaleza.

Estar biológicamente vivo no implica necesariamente inteligencia, lenguaje, cultura, autoconciencia ni emociones humanas.

No existe una anatomía, metabolismo, sistema sensorial o ciclo vital universal obligatorio. Cada especie puede definir mecanismos diferentes, siempre compatibles con las leyes del universo.

### 1.2. Organismo

Un **organismo** es una entidad cuya continuidad y funcionamiento se sostienen mediante procesos biológicos o equivalentes definidos en su ficha de especie. Puede ser unicelular, multicelular, modular, colonial, vegetal, animal, fúngico, parasitario u otra forma compatible con las leyes del universo.

La clasificación no se limita a la biología terrestre. Los organismos fantásticos pueden poseer procesos, órganos y fuentes de mantenimiento no conocidos en la naturaleza real, siempre que estén definidos y respeten SR-07.

### 1.3. Entidad activa no biológica

Una **entidad activa no biológica** es una entidad que no se considera biológicamente viva en el sentido ordinario de organismo, pero dispone de un mecanismo propio que le permite mantenerse operativa, actuar o producir cambios en el mundo sin necesitar una manipulación externa inmediata.

Los gólems y los no-muertos pertenecen a esta distinción cuando su actividad procede de un mecanismo de animación, persistencia, estructura, energía o naturaleza no biológica. Esta clasificación no determina por sí sola la identidad que conserva un no-muerto ni resuelve si hubo reanimación, resurrección o alguna otra continuidad; esas cuestiones permanecen bajo SR-01.

La expresión «entidad activa» describe su capacidad de actividad y causalidad propia. No significa automáticamente que posea inteligencia, conciencia, emociones, reproducción biológica o metabolismo orgánico.

### 1.4. Entidad inerte, objeto y material

Una piedra, un trozo de madera u otro objeto inerte existe como entidad, objeto o material según SR-01 y SR-05, pero no se clasifica por ello como organismo ni como entidad activa autónoma.

Un objeto inerte puede producir efectos cuando es utilizado, desplazado, transformado o afectado por procesos externos o ambientales. La diferencia normativa es que no inicia por sí mismo una conducta o actividad autónoma comparable a la de un gólem o no-muerto activo.

Esta distinción no niega que los objetos y materiales participen en cadenas causales; distingue la causalidad pasiva de la actividad autónoma.

### 1.5. Dimensiones independientes

El sistema DEBE mantener separadas, como mínimo, estas dimensiones:

- **Existencia:** si la entidad forma parte del estado objetivo del universo.
- **Naturaleza:** biológica, activa no biológica, objeto/material, fenómeno u otra categoría válida.
- **Estado biológico:** vivo, lesionado, incapacitado, muerto u otros estados pertinentes cuando la entidad sea un organismo.
- **Actividad operativa:** activa, inactiva, latente, suspendida, destruida o estados equivalentes según su mecanismo.
- **Agencia e inteligencia:** capacidades de percepción, decisión y acción definidas por SR-03.

Una entidad puede estar biológicamente muerta y, sin embargo, continuar operativa como entidad activa no biológica. También puede estar viva biológicamente sin tener inteligencia compleja ni agencia deliberativa.

## 2. Diversidad y definición de especie

### 2.1. Diversidad de formas

No existirá una anatomía, metabolismo, sistema sensorial o ciclo vital universal. Cada especie podrá declarar los mecanismos que necesita para mantenerse y desarrollar su ciclo de vida.

Un organismo podrá ser unicelular, multicelular, segmentado, radial, bilateral, colonial, modular, vegetal, animal o poseer otra organización compatible con las leyes del universo.

### 2.2. Ficha de especie

Toda especie biológica catalogada DEBE poder definir, según corresponda:

- identificador y clasificación utilizada;
- linaje, parentesco o especies relacionadas, cuando se conozcan;
- distribución, hábitats y biomas conocidos;
- anatomía y plan corporal;
- fisiología y metabolismo;
- necesidades y condiciones ambientales;
- sentidos y estructuras sensoriales;
- ciclo vital, desarrollo, madurez y longevidad;
- mecanismos reproductivos y compatibilidad;
- genotipo o configuración hereditaria y fenotipo;
- ecología, dieta, depredadores, presas, competidores y relaciones;
- capacidades funcionales y limitaciones;
- variabilidad entre individuos;
- rasgos naturales y arcanos;
- partes corporales y materiales aprovechables, cuando existan;
- procedencia y grado de conocimiento disponible.

### 2.3. Especie no equivale a plantilla idéntica

Compartir una especie no obliga a que todos sus individuos tengan el mismo tamaño, apariencia, estado fisiológico, capacidad, personalidad, memoria o trayectoria.

Las diferencias podrán proceder de herencia, desarrollo, edad o duración de existencia, ambiente, lesiones, enfermedades, aprendizaje, entrenamiento, adaptación, transformación o evolución, siempre mediante mecanismos compatibles con los SR aplicables.

### 2.4. Clasificación y conocimiento incompleto

La clasificación de los habitantes puede ser incompleta o errónea. El registro objetivo del universo DEBE distinguir la definición real de una especie de las hipótesis, nombres populares, leyendas y clasificaciones utilizadas por sociedades o investigadores.

Una criatura desconocida no se convierte automáticamente en una especie nueva: puede ser una variante, etapa vital, individuo excepcional, híbrido, transformación, organismo conocido mal identificado o fenómeno aún sin explicación suficiente.

La taxonomía del mundo permanecerá abierta. El catálogo inicial de especies será útil para poblar el mundo, pero NO DEBE convertirse en una lista cerrada de todas las especies que pueden existir.

## 3. Organismos, inteligencia y representación

### 3.1. Vida e inteligencia son dimensiones distintas

La existencia de vida no concede inteligencia. La inteligencia tampoco demuestra por sí sola que una entidad sea biológica.

Un organismo puede actuar mediante procesos fisiológicos e instintivos sin poseer razonamiento complejo. Una especie puede incluir individuos con capacidades cognitivas diferentes. Las capacidades cognitivas se describirán mediante SR-03 y no se inferirán únicamente de la apariencia, tamaño, peligrosidad o posición ecológica.

### 3.2. Existencia y representación

La entidad biológica o activa existe independientemente de que su modelo visual, animación o representación esté disponible. Una falla de representación no elimina al organismo ni modifica su estado vital u operativo.

Los modelos, esqueletos, rigs, animaciones y efectos visuales no conceden por sí solos capacidades biológicas, mágicas o cognitivas. Se conserva la separación entre existencia y representación establecida por SR-01 y SR-05.

---

# PARTE II — ANATOMÍA, FISIOLOGÍA Y SENTIDOS

## 4. Anatomía funcional

### 4.1. Plan corporal

Cada organismo podrá declarar un plan corporal propio: bípedo, cuadrúpedo, multipodal, serpentino, volador, acuático, segmentado, radial u otro compatible con su naturaleza.

La anatomía deberá explicar funcionalmente soporte, postura, locomoción, alimentación, protección, percepción, reproducción y otras funciones pertinentes. No se exige que cada organismo tenga todos esos sistemas.

### 4.2. Órganos y sistemas

Los organismos podrán utilizar, según su naturaleza, sistemas respiratorios, circulatorios, digestivos, nerviosos, sensoriales, musculoesqueléticos, excretores, reproductores, protectores, energéticos u otros.

La ausencia de un sistema conocido no debe tratarse automáticamente como una deficiencia si la especie dispone de otro mecanismo funcional válido.

### 4.3. Coherencia anatómica

La anatomía deberá ser compatible con las capacidades atribuidas al organismo. La existencia visual de alas no demuestra que pueda volar; la presencia de colmillos no demuestra que produzca veneno; una estructura sensorial no demuestra que detecte cualquier estímulo.

Las capacidades deberán corresponder a estructuras y mecanismos declarados o a una excepción natural/arcana definida y validada conforme a SR-07.

### 4.4. Anatomía y representación

Los modelos, esqueletos, rigs y animaciones deben respetar el plan corporal y las restricciones funcionales. La representación no puede conceder capacidades ni resolver por sí sola procesos fisiológicos.

## 5. Fisiología y mantenimiento

### 5.1. Procesos de mantenimiento

Cada organismo deberá disponer de procesos de mantenimiento adecuados a su naturaleza. Estos pueden incluir obtención de energía o recursos, reparación, regulación interna, eliminación de residuos, descanso, renovación de tejidos, intercambio con el entorno o mecanismos equivalentes.

No todos los organismos necesitan comer, respirar oxígeno, dormir, mantener temperatura corporal o utilizar química orgánica convencional. La necesidad concreta dependerá de su definición fisiológica.

### 5.2. Variables fisiológicas

La ficha de una especie podrá declarar variables como reservas energéticas, hidratación, temperatura interna, oxigenación o equivalente, fatiga, estado nutricional, integridad de tejidos, carga tóxica, equilibrio interno y capacidad de recuperación.

Esta lista no es obligatoria ni universal. Los nombres, unidades, relaciones y umbrales se definirán por especie o por familias fisiológicas compatibles.

### 5.3. Necesidad y disponibilidad

Una necesidad fisiológica no garantiza que el recurso necesario esté disponible. La falta de alimento, agua, descanso, refugio, temperatura adecuada u otro recurso puede producir consecuencias según duración, intensidad, fisiología y circunstancias.

La simulación no debe reponer recursos ni eliminar estados adversos por conveniencia narrativa. Las variaciones deberán tener causas rastreables.

### 5.4. Estado fisiológico y conducta

El estado fisiológico puede limitar o modificar movimiento, percepción, concentración, resistencia, reproducción, recuperación y otras capacidades. La relación exacta con la toma de decisiones se coordina con SR-03.

Un organismo que necesita descansar no tiene por qué hacerlo inmediatamente: puede estar impedido, priorizar otra motivación, ignorar la necesidad o asumir un riesgo. La necesidad influye; no sustituye la agencia individual.

### 5.5. Fuentes de mantenimiento no convencionales

Una especie puede obtener recursos mediante fuentes no convencionales —incluidos minerales, compuestos químicos, radiación, flujo arcano u otros fenómenos— cuando su fisiología lo permita.

Un organismo que no necesita alimentarse de forma convencional NO queda exento de las leyes de conservación, fuente, coste y mantenimiento de SR-07. Deberá existir una fuente, proceso o mecanismo que explique cómo mantiene su actividad y estructura.

## 6. Sistemas sensoriales

### 6.1. Sensores biológicos y equivalentes

Cada especie podrá poseer sentidos y órganos capaces de detectar estímulos pertinentes: luz, movimiento, sonido, vibración, sustancias químicas, temperatura, presión, campos o fenómenos especiales cuando exista un mecanismo definido.

Las entidades activas no biológicas podrán poseer sensores o medios de detección propios, pero sus mecanismos no se presumirán biológicos.

### 6.2. Límites sensoriales

Todo sentido tendrá límites de alcance, precisión, condiciones ambientales, interferencias, resolución y fiabilidad. Ningún organismo o entidad recibe información omnisciente por el hecho de existir en el mundo.

### 6.3. Separación de responsabilidades

SR-08 define órganos y mecanismos sensoriales. SR-03 define atención, interpretación, memoria, creencias, aprendizaje y decisiones. Detectar un estímulo no equivale a comprenderlo ni recordarlo.

---

# PARTE III — DESARROLLO, REPRODUCCIÓN, HERENCIA Y NUEVAS ESPECIES

## 7. Ciclos vitales y desarrollo

### 7.1. Etapas vitales

Cada especie podrá tener etapas de desarrollo propias: formación embrionaria, gestación, incubación, nacimiento, eclosión, crecimiento, madurez, envejecimiento, metamorfosis, latencia u otras que correspondan.

No se impondrá a todas las especies el ciclo humano ni las mismas etapas. Las transiciones entre etapas deberán tener condiciones y consecuencias fisiológicas verificables.

### 7.2. Edad y desarrollo

La edad cronológica y el desarrollo fisiológico son conceptos relacionados, pero no necesariamente idénticos. La velocidad de crecimiento, maduración y envejecimiento podrá variar según especie, herencia, nutrición, salud, ambiente y mecanismos extraordinarios válidos.

Las especies que no envejecen biológicamente no tendrán senescencia cronológica por defecto. Su tiempo de existencia podrá seguir siendo relevante para otros procesos, como los rasgos especiales de los monstruos definidos en el artículo 12.

### 7.3. Madurez

La madurez biológica, capacidad reproductiva y madurez social/legal son dimensiones distintas. Alcanzar una no implica automáticamente alcanzar las demás. Los umbrales concretos se definirán por especie y por los sistemas sociales competentes.

## 8. Reproducción

### 8.1. Principio general

La reproducción deberá respetar la fisiología y el mecanismo propio de cada especie. SR-05 exige considerar compatibilidad, recursos, estado de los progenitores, tiempo de desarrollo, supervivencia, entorno, herencia y variación.

### 8.2. Mecanismos posibles

Como catálogo abierto —no como decisión de que todas las especies los utilicen— podrán existir reproducción sexual, asexual, hermafroditismo, división, gemación, puesta de huevos, gestación interna, esporas, reproducción colonial u otros mecanismos biológicos o equivalentes.

Cada mecanismo deberá definir condiciones, costes, límites, frecuencia posible, desarrollo de la descendencia y relación de procedencia.

### 8.3. Nueva identidad

El nacimiento o aparición de un nuevo individuo deberá crear una identidad nueva y conservar una relación de procedencia/genealogía cuando corresponda, de acuerdo con SR-01 y SR-05. La continuidad vital de los progenitores no se transfiere automáticamente a la descendencia.

### 8.4. Reproducción no garantizada

La existencia de una especie no significa que todos sus individuos puedan o deban reproducirse. La reproducción podrá depender de madurez, fertilidad, compatibilidad, estado fisiológico, recursos, ambiente, comportamiento y otras condiciones propias de la especie.

### 8.5. Reproducción entre especies

La reproducción entre especies diferentes y la posible generación de descendencia híbrida se permite **únicamente entre especies clasificadas como monstruos**.

No se habilita por esta regla la reproducción híbrida entre monstruos y humanos, animales no monstruosos u otras categorías ajenas al conjunto de monstruos. La reproducción dentro de una misma especie seguirá dependiendo de la fisiología y los mecanismos propios de esa especie.

La compatibilidad interespecífica no significa que cualquier pareja pueda reproducirse. Se aplicará la estadística definida en el artículo 9 y las condiciones individuales pertinentes.

## 9. Compatibilidad reproductiva entre especies monstruosas

### 9.1. Índice de compatibilidad

El sistema DEBE poder almacenar una **compatibilidad reproductiva porcentual**, de 0 % a 100 %, para cada par de especies monstruosas cuya reproducción interespecífica se evalúe.

El índice representa la compatibilidad biológica/estructural de los mecanismos reproductivos y hereditarios de ese par. Su función es determinar si existe posibilidad de producir descendencia viable tras un apareamiento válido.

### 9.2. Interpretación del porcentaje

- **0 %:** no existe posibilidad conocida de descendencia viable por el mecanismo de reproducción evaluado.
- **Mayor que 0 % y menor que 100 %:** existe una posibilidad condicionada; el índice participa en la probabilidad de lograr descendencia viable.
- **100 %:** la compatibilidad entre ambas especies no constituye un impedimento; no garantiza por sí sola fecundación, gestación, incubación, nacimiento ni supervivencia.

El índice no reemplaza la madurez, fertilidad, salud, estado fisiológico, comportamiento, recursos, ambiente ni demás requisitos reproductivos. Tampoco implica que todo apareamiento produzca un nacimiento.

### 9.3. Simetría y particularidades

La compatibilidad entre dos especies se tratará como una relación de pareja. Si una diferencia fisiológica hace que el resultado dependa de la dirección o del rol reproductivo, la ficha podrá mantener subíndices específicos, siempre con procedencia y mecanismo definidos. No se presumirá simetría absoluta cuando la biología no la permita.

### 9.4. Fórmula y estimación

El porcentaje será un dato explícito del modelo reproductivo, pero su fórmula exacta, los factores y el procedimiento para estimarlo quedan RESERVADOS. No se inventará una fórmula universal ni se asignarán porcentajes arbitrarios a especies todavía no definidas.

## 10. Herencia, genética y variación

### 10.1. Modelo hereditario combinado

La herencia utilizará una base genética inspirada en principios naturales —información hereditaria, unidades o variantes transmisibles, recombinación, dominancia, rasgos poligénicos, mutación y regulación— cuando la naturaleza del organismo lo permita.

No se obliga a todas las especies a utilizar ADN, cromosomas o bioquímica terrestre. Para organismos extraordinarios podrán existir configuraciones hereditarias análogas, modulares o específicas, siempre que sean consistentes, transmisibles y verificables.

### 10.2. Genotipo y fenotipo

Se conserva la distinción de SR-05: el genotipo o configuración hereditaria es información transmisible según el mecanismo de reproducción; el fenotipo es su expresión resultante junto con el desarrollo, ambiente y demás circunstancias.

### 10.3. Rasgos heredables y adquiridos

Podrán ser heredables, según especie, rasgos como tamaño potencial, estructura corporal, pigmentación, sensores, metabolismo, predisposiciones cognitivas, resistencia, adaptaciones, afinidades o predisposiciones arcanas.

Lesiones, cicatrices, técnicas aprendidas, hábitos, modificaciones corporales y experiencias no se heredan automáticamente sin un mecanismo específico.

### 10.4. Herencia de híbridos monstruosos

La descendencia de especies monstruosas distintas podrá combinar, perder, expresar parcialmente o reorganizar rasgos heredados de ambos linajes, de acuerdo con su configuración hereditaria y compatibilidad.

No se garantiza que el híbrido sea una mezcla simétrica, que herede todas las capacidades de ambos progenitores ni que sea viable en cualquier ambiente. Las incompatibilidades pueden producir ausencia de descendencia viable, rasgos no funcionales, vulnerabilidades u otros resultados explicables por el mecanismo.

### 10.5. Mutación y variación nueva

Las mutaciones y otras variaciones hereditarias podrán producir características no registradas previamente. Deberán tener una procedencia causal, viabilidad y consecuencias funcionales; no serán una excusa para introducir capacidades arbitrarias.

### 10.6. Especies emergentes no catalogadas

El catálogo de especies iniciales no es exhaustivo. La reproducción interespecífica de monstruos, la recombinación y la variación hereditaria podrán producir linajes o formas que no coincidan con especies previamente catalogadas.

El primer híbrido no tendrá que clasificarse automáticamente como una especie nueva. Podrá registrarse inicialmente como individuo híbrido, variante o linaje en observación. Si la descendencia y generaciones posteriores forman una población heredable y suficientemente diferenciada, el sistema podrá reconocer una nueva especie conforme a criterios taxonómicos que se desarrollarán posteriormente.

La aparición de una especie nueva deberá conservar progenitores, compatibilidad, configuración hereditaria, procedencia, cambios y evidencias. No se requiere que una persona la diseñe o registre manualmente antes de que pueda existir.

---

# PARTE IV — MONSTRUOS, LONGEVIDAD Y CRECIMIENTO POR PERSISTENCIA

## 11. Naturaleza de los monstruos

### 11.1. Clasificación

«Monstruo» es una categoría funcional y taxonómica del universo, no una declaración de que todas las criaturas compartan anatomía, metabolismo, inteligencia, origen o ciclo vital.

Los monstruos podrán ser organismos biológicos o, cuando se defina y justifique, entidades activas de otra naturaleza. Sus fichas deberán declarar su mecanismo de existencia y sus propiedades relevantes.

### 11.2. Especies iniciales y catálogo abierto

El mundo podrá comenzar con especies monstruosas predeterminadas para permitir la formación de poblaciones y ecosistemas iniciales. Ese catálogo es una base de poblamiento, no un límite de diversidad futura.

Las especies emergentes, híbridas, mutadas o descubiertas podrán ampliar el catálogo sin exigir diseño manual previo, siempre que cumplan las reglas de identidad, procedencia, viabilidad y validación.

## 12. Longevidad monstruosa y acumulación de fuerza

### 12.1. Ausencia de envejecimiento senescente

Los monstruos, como regla general aprobada, **no envejecen en el sentido de sufrir deterioro biológico por edad cronológica**. No se les aplicará automáticamente una fase de vejez que reduzca sus capacidades por el mero paso del tiempo.

Esto no significa que sean invulnerables, inmortales o inmunes a lesiones, enfermedad, depredación, destrucción, inanición u otras causas de muerte o pérdida de actividad. Esas condiciones dependerán de su naturaleza y mecanismos.

### 12.2. Duración de existencia

Aunque no envejezcan, el sistema registrará cuánto tiempo lleva existiendo cada monstruo desde su generación, nacimiento o inicio de la continuidad correspondiente. Esta duración se denomina **antigüedad de existencia** para no confundirla con envejecimiento senescente.

### 12.3. Fortalecimiento por longevidad

Como regla general, cuanto más tiempo sobreviva un monstruo, mayor podrá ser su fuerza y poder acumulados. La duración de existencia constituye un factor positivo de desarrollo monstruoso, aunque la tasa, el tipo de poder y sus manifestaciones podrán variar por especie e individuo.

El fortalecimiento no tiene una fórmula universal fijada en esta versión. No se presupone que cada segundo produzca un incremento medible ni que todos los monstruos crezcan al mismo ritmo. Sí se establece que la longevidad es una fuente natural de fortalecimiento y no un simple número decorativo.

El fortalecimiento por longevidad no convierte automáticamente al monstruo en otra especie ni reemplaza el entrenamiento, la experiencia, el aprendizaje o las capacidades actuales.

### 12.4. Relación con la profundidad de la Mazmorra

Se espera que, en términos generales, las poblaciones de pisos más profundos incluyan monstruos de mayor fuerza, porque una parte de sus individuos puede permanecer viva durante periodos mucho más prolongados al estar expuesta a una presión menor de aventureros y sufrir menos muertes por intervención externa.

Esta relación es ecológica e histórica, no un multiplicador arbitrario asignado por número de piso. La profundidad por sí sola no garantiza que cada individuo sea más fuerte que cualquier monstruo de un piso superior. Pueden existir individuos jóvenes o recién generados en pisos profundos, así como individuos excepcionalmente longevos y poderosos en pisos superiores.

### 12.5. Rasgos arcanos de persistencia

La permanencia prolongada de un monstruo puede favorecer la aparición, acumulación o manifestación de rasgos arcanos, incluidos rasgos relacionados con la Resonancia de Persistencia descrita en SR-07.

En poblaciones de monstruos que viven durante periodos muy prolongados, puede llegar a ser común —incluso mayoritario— que los individuos antiguos manifiesten algún rasgo arcano. No es una garantía individual ni una regla de aparición inmediata.

Estos rasgos podrán influir en resistencia, estabilidad, regeneración, reservas, percepción, estructura corporal, interacción con la Trama u otras capacidades compatibles con SR-07. Sus efectos, fuentes, límites, costes y consecuencias deberán estar definidos.

### 12.6. Diferencia entre longevidad, aprendizaje y reencarnación

El fortalecimiento acumulado por longevidad, el entrenamiento, el aprendizaje y la reencarnación son procesos distintos que pueden coexistir:

- la longevidad monstruosa puede fortalecer al individuo por su duración de existencia;
- el entrenamiento mejora capacidades mediante práctica y adaptación;
- el aprendizaje modifica conocimientos, estrategias y procedimientos conforme a SR-03;
- la reencarnación puede conservar componentes de la existencia anterior conforme a SR-01 y SR-03.

Ninguno de estos procesos concede automáticamente todos los demás beneficios.

---

# PARTE V — APRENDIZAJE, ENTRENAMIENTO Y CONTINUIDAD ENTRE VIDAS

## 13. Desarrollo individual y entrenamiento

### 13.1. Mejora por experiencia

Los individuos podrán mejorar mediante entrenamiento, práctica, exposición, adaptación, investigación y aprendizaje. La mejora debe derivar de experiencias y procesos compatibles con la entidad.

### 13.2. Diferencia entre aprendizaje y herencia

Una técnica aprendida, estilo de combate, hábito o conocimiento no se convierte automáticamente en rasgo hereditario. La transmisión entre generaciones requiere enseñanza, imitación, cultura, herencia válida o algún mecanismo definido.

### 13.3. Diferencia entre progreso y evolución biológica

El aumento de capacidad de un individuo por entrenamiento o aprendizaje no equivale necesariamente a evolución biológica de la especie. Una transformación anatómica estable puede ser un cambio individual, una adaptación, una mutación o una evolución, según su mecanismo y heredabilidad.

SR-03 conserva la autoridad sobre aprendizaje y evolución individual; SR-08 regula las consecuencias fisiológicas, anatómicas y hereditarias que correspondan.

## 14. Reencarnación y experiencia previa

### 14.1. Continuidad mixta

Se aplica la Ley de reencarnación de SR-01: una nueva existencia podrá conservar componentes variables de la anterior. No se garantiza que todos los recuerdos, capacidades o tendencias sobrevivan.

### 14.2. Memoria de combate y estilos previos

Un individuo reencarnado podrá conservar recuerdos procedimentales, estilos de combate, reconocimiento de patrones, experiencias de enfrentamientos, conocimientos tácticos o tendencias desarrolladas durante una existencia anterior, cuando esos componentes formen parte de lo que la continuidad mixta permite conservar.

Esa experiencia previa podrá darle una ventaja real al reconocer situaciones, anticipar técnicas o elegir estrategias. No implica que el nuevo cuerpo posea automáticamente la fuerza, velocidad, anatomía, reservas, equipamiento o capacidades físicas de la vida anterior.

### 14.3. Evidencia y recuperación

Los recuerdos pueden ser completos, fragmentarios, inconscientes, distorsionados o desconocidos para el propio individuo. Su persistencia se coordina con SR-03 y debe respetar la distinción entre recuerdo, conocimiento y verdad objetiva.

---

# PARTE VI — BIOLOGÍA ARCANA Y MATERIALES ORGÁNICOS

## 15. Integración de lo arcano en la biología

### 15.1. Principio

La magia puede formar parte de la biología de determinadas especies. No se limita a ser una influencia externa aplicada sobre un organismo.

Una especie podrá poseer, cuando su naturaleza lo permita, órganos, tejidos, estructuras, reservas, conductos, sensores, glándulas, núcleos u otros componentes especializados que interactúen con la Trama, el flujo arcano o las Resonancias.

### 15.2. Diversidad de funciones arcanas

Los mecanismos biológicos arcanos podrán permitir, según cada especie:

- almacenar, producir, absorber, canalizar o transformar flujo arcano;
- detectar flujo, concentraciones o determinadas Resonancias;
- emitir o conducir fenómenos arcanos;
- estabilizar, desviar o resistir operaciones arcanas;
- mantener estructuras corporales o funciones fisiológicas extraordinarias;
- desarrollar afinidades o predisposiciones que no conceden por sí solas dominio o conocimiento mágico.

La disponibilidad y funcionamiento de estos mecanismos obedecerán SR-07. La anatomía no concede automáticamente hechizos aprendidos ni dominio técnico.

### 15.3. Resistencia e inmunidad arcana

Algunas especies o individuos podrán tener resistencia elevada o inmunidad a fenómenos arcanos. La inmunidad puede ser parcial o total respecto de un conjunto definido de operaciones, efectos, fuentes o interacciones.

La inmunidad deberá tener un mecanismo natural o arcano compatible con SR-07 y describir su alcance. No se presumirá que resistir un hechizo implica resistir toda magia, ni que la inmunidad a una Resonancia proteja frente a cualquier fenómeno arcano.

Una inmunidad arcana de alcance general solo podrá declararse cuando su mecanismo explique qué interacciones bloquea y cuáles, si las hubiera, siguen siendo posibles. No será una excepción sin causa ni una etiqueta visual.

### 15.4. Herencia y adquisición de rasgos arcanos

Los rasgos arcanos podrán ser heredados, desarrollados durante la vida, adquiridos por exposición, entrenamiento, transformación o combinación de mecanismos, de acuerdo con SR-07 y el artículo 12. La ficha de especie deberá distinguir predisposición hereditaria de rasgo adquirido.

## 16. Partes corporales y materiales de fabricación

### 16.1. Propiedades aprovechables

Partes de organismos y monstruos podrán convertirse en materiales útiles para fabricación, investigación, alquimia u otros procesos: huesos, placas, caparazones, pieles, órganos, glándulas, venenos, fibras, fluidos, tejidos cristalinos, estructuras conductoras o componentes arcanos.

No todas las especies tendrán partes aprovechables ni toda parte tendrá valor. Las propiedades físicas, químicas y arcanas deberán derivarse de su composición y mecanismo real.

### 16.2. Obtención y procedencia

La obtención de una parte corporal requiere un proceso causal válido: extracción, recolección tras la muerte, desprendimiento natural, exuvia, secreción u otro mecanismo apropiado. La existencia del monstruo no genera automáticamente materiales en el inventario de quien lo derrota.

Los materiales obtenidos conservarán procedencia, especie/individuo de origen, estado, calidad cuando corresponda y propiedades relevantes, conforme a SR-05.

### 16.3. No confundir materiales y recompensa

Este documento permite que partes corporales sean materias primas para fabricación. No establece cofres, contenedores rompibles ni recompensas ambientales. El sistema de cristales que los monstruos dejan al morir, su valoración por nivel/calidad/fuerza y su papel económico quedan para la normativa de economía, objetos, combate o mazmorra que corresponda; no se fijan fórmulas aquí.

---

# PARTE VII — MAZMORRA, MONSTRUOS Y ECOLOGÍA POR PISOS

## 17. Generación de monstruos por la Mazmorra

### 17.1. Hecho establecido

La Mazmorra genera monstruos. Este hecho forma parte del conocimiento general establecido para el universo.

### 17.2. Exclusividad del mecanismo no conocida

No se establece que la generación propia de la Mazmorra sea la única forma en que pueden existir o aparecer monstruos. La reproducción entre monstruos también es posible bajo los mecanismos de este documento.

Por tanto, el sistema debe admitir como mínimo la generación de monstruos por la Mazmorra y la reproducción de monstruos, sin afirmar que una de esas vías excluye a la otra.

### 17.3. Mecanismo específico reservado

El proceso exacto por el que la Mazmorra genera monstruos, sus fuentes, condiciones, ritmo, límites, selección de especies, relación con los pisos y posible naturaleza arcana no queda explicado por esta norma. No se debe inventar una explicación definitiva ni atribuir voluntad, conciencia o intención a la Mazmorra sin una decisión normativa posterior.

### 17.4. Procedencia individual

Todo monstruo generado deberá tener identidad individual y procedencia registrada. Cuando su origen sea la Mazmorra, el evento de generación deberá distinguirse de un nacimiento por reproducción. Ambos crean una nueva entidad, pero no comparten necesariamente el mismo proceso biológico.

## 18. Biomas y organización ecológica de la Mazmorra

### 18.1. Pisos individuales y bloques de bioma

Cada piso de la Mazmorra será una unidad espacial con identidad y configuración propias. Sin embargo, no se exige que cada piso constituya un bioma completamente distinto.

Los pisos podrán organizarse en **bloques o lotes de bioma**: varios pisos comparten un bioma general o una familia ecológica, mientras cada piso conserva diferencias individuales de distribución, topología, densidad, especies, recursos, peligros y características ambientales.

### 18.2. Rangos de pisos

Los rangos de biomas podrán abarcar varios pisos. Como ejemplos de organización posibles, no como distribución definitiva:

- pisos 1–5: una familia de bioma;
- pisos 6–8: otra familia;
- pisos 9–15: otra familia;
- pisos posteriores: nuevos bloques según el diseño general de la Mazmorra.

Los rangos exactos, nombres y biomas definitivos no quedan fijados en SR-08. El ejemplo sirve para establecer que la unidad de bioma puede abarcar varios pisos consecutivos.

### 18.3. Diferenciación interna de cada piso

Aunque varios pisos pertenezcan al mismo bloque de bioma, cada piso deberá conservar una identidad espacial y ecológica propia. Las diferencias podrán incluir:

- distribución y proporción de cámaras y corredores;
- composición de especies y variantes;
- densidad y frecuencia de generación de monstruos;
- recursos, vetas minerales, agua, vegetación u otros elementos;
- temperatura, humedad, presión, iluminación y condiciones ambientales;
- zonas de alimentación, refugio, reproducción o descanso;
- rutas migratorias, cuellos de botella y conexiones verticales;
- peligros naturales, anomalías o fenómenos arcanos;
- especies dominantes, depredadores y presas;
- presencia de individuos excepcionales o guardianes cuando el diseño lo establezca.

### 18.4. Biomas especiales y cambios de zona

Dentro de un mismo conjunto de pisos podrán existir zonas particulares o transiciones ecológicas, como áreas acuáticas, forestales, minerales, cavernosas, pantanosas u otras. Un cambio de subzona no obliga a que cada piso adquiera una categoría de bioma completamente distinta.

Las referencias a series, juegos u otras obras pueden servir como inspiración de estructura, pero no convierten automáticamente sus mapas, rangos, nombres ni distribución de jefes en canon de este universo.

### 18.5. Variación en densidad y especies

La cantidad de monstruos y la composición de especies podrán variar entre pisos pertenecientes al mismo bloque de bioma. Un piso puede tener menor densidad que los pisos vecinos, otro puede contener mayor concentración de determinadas especies y otro puede albergar un individuo excepcional o guardián.

No se exige una densidad uniforme ni una distribución idéntica por piso. Las diferencias deberán surgir de reglas de población, generación, recursos, migración y ecología, no de ajustes arbitrarios destinados únicamente al encuentro del jugador.

### 18.6. Ecosistemas conectados

Cada piso podrá mantener procesos ecológicos propios, pero no se presume aislamiento absoluto. Cuando existan rutas o mecanismos que permitan el tránsito entre pisos, los organismos podrán desplazarse, migrar, perseguir, huir, expandirse o competir a través de esas conexiones si su anatomía, comportamiento y capacidades lo permiten.

La conexión entre pisos no obliga a todas las especies a migrar. Las barreras, condiciones ambientales, peligros y costes de tránsito podrán limitar el movimiento.

## 19. Zona segura por piso

### 19.1. Política de aparición

Cada piso tendrá una pequeña zona segura en la que la aparición espontánea normal de monstruos estará ausente o significativamente restringida conforme a la política de generación que se defina.

### 19.2. No es una barrera absoluta

La zona segura NO es una barrera física, mágica o causal que prohíba la entrada de monstruos. Un monstruo podrá llegar a ella si tiene una razón causal y conductual para hacerlo, por ejemplo perseguir, huir, migrar, buscar recursos o responder a otra circunstancia.

La conducta habitual de las poblaciones podrá hacer que normalmente la ignoren, pero esa tendencia no equivale a una prohibición universal.

### 19.3. Responsabilidad de sistemas

La baja o nula aparición espontánea en la zona segura corresponde a las reglas de generación y ecología. La entrada de un monstruo corresponde a navegación, motivación, persecución, huida y causalidad. No se deberá falsificar su posición ni anular su agencia para mantener la zona segura.

---

# PARTE VIII — DIETA, CADENAS TRÓFICAS Y POBLACIONES

## 20. Alimentación y fuentes de recursos

### 20.1. Diversidad alimentaria

Las especies podrán utilizar distintas fuentes de mantenimiento, según su fisiología. Se permiten, entre otras:

- plantas, frutos, semillas, raíces y biomasa vegetal;
- animales, presas y otros organismos;
- monstruos y biomasa de otras especies monstruosas;
- carroña y restos orgánicos;
- minerales, sales, metales o compuestos inorgánicos cuando exista un mecanismo de aprovechamiento;
- energía química o fenómenos ambientales;
- flujo arcano u otras fuentes arcanas compatibles con SR-07;
- simbiosis, parasitismo, absorción, filtración u otros mecanismos.

Una especie puede combinar varias fuentes, cambiar de dieta durante su ciclo vital o utilizar una fuente solo en determinadas condiciones.

### 20.2. Organismos sin alimentación convencional

Pueden existir organismos que no necesiten ingerir alimentos de manera convencional. No obstante, su mantenimiento y continuidad deberán explicarse mediante una fuente o proceso definido. No se permite energía, materia, reparación o actividad gratuita que contradiga SR-07.

### 20.3. Dieta y comportamiento

La dieta influye en hábitat, rutas, horarios, territorio, competencia, migración, reproducción y riesgo. El organismo no tiene que conseguir alimento siempre: puede fracasar, pasar hambre, cambiar de estrategia, desplazarse o morir según su fisiología y circunstancias.

## 21. Relaciones ecológicas

### 21.1. Relaciones posibles

Los ecosistemas podrán contener depredación, herbivoría, omnivoría, carroñería, parasitismo, mutualismo, comensalismo, competencia, simbiosis, cooperación, territorialidad y otras relaciones.

No se presume que dos especies sean enemigas por defecto ni que todos los monstruos ataquen a cualquier otra entidad que encuentren. Su conducta depende de alimentación, defensa, reproducción, territorio, percepción, inteligencia, necesidades y demás condiciones.

### 21.2. Cadenas y redes tróficas

Las relaciones alimentarias deberán poder formar cadenas y redes tróficas con múltiples niveles. La eliminación o reducción de una población podrá afectar a depredadores, presas, competidores, parásitos, recursos y condiciones del hábitat.

### 21.3. Competencia por recursos

Los organismos pueden competir por alimento, agua, refugio, minerales, espacio, pareja reproductiva, zonas de cría o fuentes arcanas. La competencia puede producir desplazamiento, cambio de dieta, conflicto, cooperación forzada, migración o reducción de población.

### 21.4. No orientación obligatoria al jugador

Las relaciones ecológicas no existen solo para producir encuentros con jugadores. Las criaturas pueden realizar sus actividades, evitar riesgos, alimentarse, reproducirse, descansar o desplazarse sin presencia del jugador, conforme a SR-01, SR-04 y SR-06.

## 22. Hábitats, poblaciones y migración

### 22.1. Hábitat y nicho

El hábitat es el conjunto de condiciones y recursos que permiten o limitan la presencia de una población u organismo. El nicho ecológico describe su función y el conjunto de relaciones dentro del ecosistema.

### 22.2. Dinámica de población

Las poblaciones cambian mediante nacimientos, generación de monstruos, muertes, enfermedades, depredación, competencia, migración y otros procesos causales. No se conservará una población fija por conveniencia del jugador.

### 22.3. Migración y desplazamiento

Los organismos podrán migrar por alimento, clima, reproducción, presión de depredadores, competencia, deterioro del hábitat, peligro u otras causas. Las rutas migratorias no dependen de que el jugador esté presente.

### 22.4. Extinción local y recolonización

Una especie podrá desaparecer de una región o piso si las condiciones y presiones lo causan. La recolonización podrá ocurrir cuando exista una fuente poblacional, ruta, mecanismo de generación o condición compatible. No se garantiza que una población extinta localmente reaparezca ni se prohíbe su recuperación cuando sea causalmente posible.

La extinción global, la extinción de un linaje y la ausencia local son resultados diferentes y deberán registrarse separadamente.

### 22.5. Capacidad ecológica y recursos

Los hábitats tienen límites de recursos y condiciones de soporte. La población no puede crecer indefinidamente por simple conveniencia. La capacidad de carga, la disponibilidad de fuentes y los efectos de densidad deberán definirse por bioma, especie y escala cuando se desarrollen los modelos cuantitativos.

### 22.6. Procesos ecológicos autónomos

La actividad de un ecosistema no puede depender exclusivamente de misiones, encuentros o eventos activados por el jugador. Los procesos ecológicos deben continuar durante la ausencia mediante los niveles de resolución y simulación resumida previstos en SR-04 y SR-06, sin perder consecuencias relevantes.

---

# PARTE IX — SALUD, ENFERMEDADES, PARÁSITOS Y RECUPERACIÓN

## 23. Enfermedades y estados patológicos

### 23.1. Diversidad de patologías

Los organismos podrán sufrir enfermedades, infecciones, infestaciones, intoxicaciones, deficiencias, lesiones patológicas, alteraciones fisiológicas y otros estados adversos si su naturaleza lo permite.

No todas las patologías tienen que ser contagiosas ni todos los organismos comparten un sistema inmunitario equivalente.

### 23.2. Mecanismos de transmisión

Cuando exista transmisión, deberá definirse el mecanismo correspondiente: contacto, fluidos, aire, agua, alimento, vector, parásito, superficie, transmisión vertical, exposición ambiental u otro compatible con el organismo y el fenómeno.

La proximidad por sí sola no garantiza contagio. Deben existir condiciones de exposición, susceptibilidad y transmisión.

### 23.3. Curso de la enfermedad

Una patología podrá tener periodo de incubación, fase asintomática, síntomas, progresión, complicaciones, recuperación, secuelas, portación o muerte. No todas las patologías necesitan todas las etapas.

### 23.4. Inmunidad y susceptibilidad

La susceptibilidad y la respuesta dependerán de especie, individuo, estado fisiológico, exposición previa, herencia, mecanismos defensivos y naturaleza del agente o fenómeno. Podrán existir inmunidad adquirida, resistencia parcial, tolerancia, portadores o susceptibilidad especializada.

### 23.5. Diagnóstico y conocimiento

El organismo puede padecer una enfermedad sin conocerla. El diagnóstico requiere síntomas observables, pruebas, conocimientos o instrumentos apropiados. Las interpretaciones médicas pueden ser incompletas o erróneas conforme a SR-01 y SR-03.

### 23.6. Tratamiento y recuperación

Los tratamientos deberán actuar mediante mecanismos compatibles con la patología y el organismo. La recuperación puede requerir tiempo, reposo, alimentación, cuidados, recursos, medicamentos, procedimientos o intervenciones arcanas validadas.

No se permite curación universal, instantánea o gratuita por conveniencia narrativa.

### 23.7. Entidades no biológicas

Gólems, no-muertos y otras entidades activas no biológicas no tendrán que padecer enfermedades biológicas convencionales. Podrán presentar fallos, corrosión, degradación, infestación, contaminación, inestabilidad o alteraciones arcanas cuando su mecanismo lo permita. Esos estados no deben etiquetarse automáticamente como enfermedad biológica.

---

# PARTE X — EVOLUCIÓN, ADAPTACIÓN Y CAMBIO DE ESPECIES

## 24. Evolución poblacional

### 24.1. Evolución abierta

Las especies y linajes podrán cambiar a través de generaciones cuando variaciones hereditarias, selección, deriva, aislamiento, mutación, reproducción u otros mecanismos produzcan cambios poblacionales viables.

No habrá árboles evolutivos cerrados que determinen anticipadamente todas las formas posibles.

### 24.2. Costes y límites

La evolución no es necesariamente positiva. Puede producir costes, vulnerabilidades, necesidades nuevas, pérdida de capacidades o dificultades de adaptación.

Una nueva estructura o capacidad deberá tener función, condiciones, costes y consecuencias coherentes. No se acepta una mejora gratuita solo porque resulte conveniente.

### 24.3. Adaptación individual

Un individuo puede desarrollar cambios fisiológicos o funcionales durante su vida por entrenamiento, uso, exposición, lesión, recuperación, aprendizaje o mecanismos extraordinarios. Estos cambios no se consideran automáticamente evolución hereditaria de la especie.

### 24.4. Diferencia con longevidad monstruosa

El fortalecimiento de monstruos por longevidad establecido en el artículo 12 es un proceso individual acumulativo. No constituye por sí mismo una evolución de especie ni requiere descendencia.

### 24.5. Nuevos linajes

La aparición de un linaje nuevo podrá derivar de reproducción híbrida, mutación, aislamiento, selección u otros mecanismos válidos. La clasificación formal de una nueva especie deberá conservar su historia y evidencias y no depender de una decisión narrativa arbitraria.

---

# PARTE XI — CONTRATOS ENTRE SISTEMAS Y AUTORIDAD

## 25. Separación de responsabilidades

### 25.1. SR-01 — Constitución

Establece los límites últimos de existencia, identidad, vida, muerte, reencarnación, causalidad, agencia, evolución, ecología y persistencia.

### 25.2. SR-03 — Identidad, cognición, memoria y evolución individual

Gestiona identidad, continuidad, reencarnación, inteligencia, percepción cognitiva, motivaciones, recuerdos, aprendizaje, experiencia de combate y evolución individual. SR-08 proporciona los datos biológicos que condicionan esas funciones.

### 25.3. SR-05 — Creation Engine

Define y crea especies, plantillas, individuos, anatomías, configuraciones hereditarias, capacidades, materiales y representaciones. SR-08 establece los requisitos biológicos y ecológicos que esas definiciones deben satisfacer.

### 25.4. SR-07 — Leyes naturales y arcanas

Determina la viabilidad de procesos materiales, energéticos, químicos, térmicos, físicos y arcanos. SR-08 no puede eludir sus leyes al describir metabolismo, regeneración, inmunidad, órganos arcanos o alimentación energética.

### 25.5. SR-02, SR-04 y SR-06 — Simulación, causalidad y persistencia

Los motores de simulación deberán ejecutar los procesos biológicos y ecológicos sin depender del jugador, registrar su procedencia y preservar sus consecuencias al cambiar de escala o resolución.

## 26. Contratos de datos mínimos

Las estructuras técnicas detalladas se definirán en documentos de implementación, pero el modelo lógico DEBE poder representar:

- especie/definición y versión;
- individuo e identidad conforme a SR-01/SR-03;
- tipo de entidad: organismo biológico o entidad activa no biológica, según corresponda;
- anatomía, órganos, capacidades y limitaciones;
- fisiología, necesidades, fuentes y variables relevantes;
- ciclo vital, madurez y edad o antigüedad de existencia;
- genotipo/configuración hereditaria y fenotipo;
- progenitores, genealogía y compatibilidad reproductiva;
- rasgos heredados y adquiridos;
- estado de salud, enfermedades, parásitos e inmunidad;
- dieta y relaciones ecológicas;
- población, hábitat, bioma y piso/región;
- rasgos arcanos, resistencia e inmunidad con alcance definido;
- partes corporales y materiales aprovechables;
- procedencia, eventos causales y nivel de conocimiento.

No se obliga a que todos los campos sean utilizados por todas las especies. La ficha debe declarar qué dimensiones son pertinentes y cuáles no aplican.

## 27. Procedencia y cambios

Todo nacimiento, generación de monstruo, enfermedad relevante, mutación, hibridación, cambio de especie, adquisición de rasgo, extinción local, migración significativa y otro cambio biológico/ecológico persistente deberá poder relacionarse con su causa y procedencia según SR-01, SR-02, SR-04 y SR-06.

La generación de un monstruo por la Mazmorra debe distinguirse de un nacimiento reproductivo. La obtención de un material corporal debe distinguirse de una recompensa abstracta. El descubrimiento de una especie debe distinguirse de su aparición objetiva.

---

# PARTE XII — PRUEBAS OBLIGATORIAS Y CRITERIOS DE CUMPLIMIENTO

## 28. Pruebas fundamentales

El sistema deberá permitir realizar, cuando los mecanismos correspondientes estén implementados, las siguientes pruebas:

1. **Vida vs. actividad no biológica:** clasificar un organismo, un gólem activo, un no-muerto y un objeto inerte sin confundir sus naturalezas.
2. **Anatomía-capacidad:** impedir o limitar una capacidad cuando la anatomía y el mecanismo no la soporten.
3. **Necesidad y escasez:** comprobar consecuencias de falta de alimento, agua, descanso u otros recursos relevantes.
4. **Fuentes no convencionales:** comprobar que organismos que no comen de forma convencional mantienen su continuidad mediante una fuente definida.
5. **Sensibilidad limitada:** demostrar que los organismos solo perciben lo que sus sensores y condiciones permiten.
6. **Reproducción intraespecífica:** verificar compatibilidad, madurez, recursos, gestación/incubación, nacimiento e identidad nueva.
7. **Compatibilidad monstruosa:** probar pares de especies con 0 %, porcentaje intermedio y 100 %, manteniendo separadas compatibilidad y demás condiciones reproductivas.
8. **Hibridación:** producir descendencia monstruosa viable cuando proceda y conservar ambos linajes y la configuración hereditaria.
9. **Nueva especie emergente:** demostrar que varias generaciones pueden producir un linaje diferenciable no predefinido, sin convertir automáticamente el primer híbrido en especie nueva.
10. **Herencia y adquisición:** demostrar que un rasgo adquirido no se transmite automáticamente sin mecanismo.
11. **Longevidad monstruosa:** comprobar que la duración de existencia fortalece al monstruo según su modelo sin aplicar senescencia por edad.
12. **Presión por aventureros:** demostrar que mortalidad diferencial puede producir poblaciones más antiguas y potencialmente más poderosas en zonas menos visitadas, sin asignar bonificación fija por piso.
13. **Rasgos arcanos persistentes:** comprobar que la exposición/permanencia puede producir rasgos arcanos con procedencia, sin garantizarlo para todos.
14. **Experiencia y reencarnación:** comprobar que un recuerdo procedimental preservado puede mejorar una decisión futura sin conceder automáticamente atributos físicos del cuerpo anterior.
15. **Resistencia e inmunidad arcana:** comprobar el alcance definido de la resistencia o inmunidad frente a operaciones pertinentes.
16. **Materiales corporales:** comprobar obtención, propiedades y procedencia de partes aprovechables, sin crear inventarios o recompensas gratuitas.
17. **Biomas por bloques:** comprobar que varios pisos comparten una familia de bioma pero cada piso conserva distribución y composición propias.
18. **Zona segura:** comprobar que no aparecen monstruos por generación espontánea normal bajo la política establecida, pero que un monstruo puede entrar por una causa válida.
19. **Dieta y red trófica:** comprobar dependencia entre fuentes, presas, depredadores, carroñeros y organismos de fuentes no convencionales.
20. **Enfermedades:** probar transmisión, incubación, síntomas, susceptibilidad, diagnóstico, tratamiento y recuperación según cada modelo.
21. **Migración y extinción local:** demostrar que una población puede reducirse o desaparecer localmente y recolonizar únicamente cuando exista una vía causal válida.
22. **Simulación resumida:** comprobar que los procesos ecológicos continúan sin jugador y que el cambio de resolución no borra consecuencias relevantes.
23. **Reproducibilidad y procedencia:** repetir experimentos con entradas y versiones controladas y conservar trazas de los cambios relevantes.

## 29. Criterios de cierre de SR-08

SR-08 se considera normativamente establecido en sus principios generales desde la aprobación de la versión 1.0. Su desarrollo técnico estará listo para implementación completa cuando:

1. La clasificación de organismos y entidades activas no biológicas no contradiga SR-01.
2. Especie, individuo, identidad, plantilla y representación estén separados conforme a SR-03 y SR-05.
3. Anatomía y fisiología permitan validar las capacidades y limitaciones atribuidas.
4. Necesidades y fuentes de mantenimiento produzcan consecuencias causales.
5. Reproducción y nacimiento creen individuos con identidad y procedencia correctas.
6. La compatibilidad monstruosa opere como estadística porcentual y no como garantía absoluta de nacimiento.
7. Herencia, variación y especies emergentes se representen sin catálogo cerrado.
8. Los monstruos no sufran senescencia cronológica general y su longevidad tenga relación causal con el fortalecimiento.
9. Aprendizaje, entrenamiento, longevidad, herencia y reencarnación permanezcan como procesos diferenciados.
10. Los rasgos arcanos biológicos respeten fuentes, costes, límites y contramedidas de SR-07.
11. La ecología de la Mazmorra admita biomas por bloques, pisos diferenciados, variación poblacional y conexiones cuando existan.
12. Las zonas seguras no actúen como barreras absolutas.
13. Enfermedades, parásitos, dieta, migración, competencia, depredación y dinámica de población tengan mecanismos verificables.
14. La simulación multiescala preserve consecuencias biológicas y ecológicas relevantes.
15. Los cambios biológicos y ecológicos relevantes conserven procedencia y causalidad.

---

# PARTE XIII — DECISIONES RESERVADAS

Las siguientes materias no contradicen ni invalidan SR-08 v1.0. Se reservan para catálogos, parámetros, pruebas o normas subordinadas futuras:

- taxonomía definitiva y catálogo inicial de especies;
- criterios operativos detallados para reconocer un linaje como especie nueva;
- mecanismo exacto por el que la Mazmorra genera monstruos y sus límites;
- fórmula de compatibilidad reproductiva y factores que determinan cada porcentaje;
- mecanismos reproductivos concretos de cada especie monstruosa;
- configuración genética o hereditaria detallada de cada familia de organismos;
- edades, madurez, gestación, incubación y esperanza de vida por especie no monstruosa;
- curvas, tasas y límites del fortalecimiento monstruoso por longevidad;
- mecanismo y umbrales temporales de aparición de rasgos arcanos de persistencia;
- catálogos y rangos definitivos de biomas por pisos de la Mazmorra;
- distribución de especies, densidades, zonas especiales y guardianes por piso;
- fórmulas ecológicas, capacidad de carga, tasas de extinción y recolonización;
- patógenos, parásitos, enfermedades y mecanismos inmunitarios concretos;
- unidades, variables y ecuaciones fisiológicas por especie;
- reglas detalladas de cosecha, conservación, calidad y fabricación a partir de partes corporales;
- clasificación de entidades sobrenaturales distintas de los ejemplos aprobados;
- mecanismos biológicos/arcanos específicos de cada especie.

Ningún punto reservado podrá resolverse mediante una constante arbitraria o un evento escrito para forzar un resultado. Deberá definirse mediante mecanismos compatibles con la jerarquía normativa.

---

# DECLARACIÓN NORMATIVA

SR-08 establece que la diversidad biológica y ecológica del universo no está limitada a un catálogo cerrado de especies ni a una anatomía terrestre universal. Los organismos mantienen sus funciones mediante mecanismos propios; las entidades activas no biológicas pueden actuar y producir cambios sin ser confundidas con organismos vivos; los monstruos pueden surgir de la Mazmorra y reproducirse entre especies monstruosas cuando exista compatibilidad; la herencia puede producir linajes no catalogados; la longevidad de los monstruos constituye una fuente de fortalecimiento y puede favorecer rasgos arcanos de persistencia; y los pisos de la Mazmorra forman ecosistemas organizados en bloques de bioma con identidad individual por piso.

La vida, la reproducción, la salud, la adaptación, el fortalecimiento y la ecología no existen para servir exclusivamente al jugador. Son procesos del universo y deben continuar, producir consecuencias y conservar procedencia tanto en presencia como en ausencia del jugador, conforme a SR-01 a SR-07.

**SR-08 v1.0 — Normativa oficial aprobada.**


## NOTA DE CONSOLIDACIÓN Y REFERENCIA CANÓNICA — 2026-11-20

Esta copia consolida el texto completo de **SR-08 v1.0**, cuya aprobación por el autor ya consta en el control de versiones. La consolidación no modifica sus reglas, no elimina materias reservadas y no cambia su jerarquía normativa.

La asignación de responsabilidades entre documentos queda expresamente fijada así:

- **SR-08** gobierna biología, fisiología, reproducción, herencia, salud, monstruos y ecología.
- **SR-09** gobierna combate, daño, lesiones, incapacitación, curación aplicada al combate y adaptación táctica; debe respetar la anatomía y fisiología de SR-08.
- El **Anexo de Veyrath y catálogo de hechizos de SR-09** define la lengua y el contenido mágico de referencia para la primera fase, subordinado a las leyes arcanas de SR-07. No convierte la lengua, los hechizos ni el sistema de casteo en materias biológicas de SR-08.

Los puntos reservados de SR-08 siguen siendo trabajo futuro de catálogos y parámetros, no vacíos que permitan improvisar resultados. Cualquier futura modificación normativa deberá publicarse como una nueva versión y conservar la trazabilidad de cambios.

**Estado canónico tras la consolidación: SR-08 v1.0 — aprobada; texto normativo preservado.**

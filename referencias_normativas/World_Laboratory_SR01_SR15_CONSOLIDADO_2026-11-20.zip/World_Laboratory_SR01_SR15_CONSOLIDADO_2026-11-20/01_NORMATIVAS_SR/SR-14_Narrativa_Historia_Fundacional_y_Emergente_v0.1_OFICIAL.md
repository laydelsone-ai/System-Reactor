# WORLD LABORATORY / SISTEMA REACTOR

# SR-14 — NARRATIVA, HISTORIA FUNDACIONAL Y GENERACIÓN DE HISTORIAS

**Código:** SR-14  
**Versión:** 0.1 — edición oficial aprobada  
**Estado:** NORMATIVA OFICIAL — APROBADA EXPRESAMENTE POR EL AUTOR EL 2026-11-20.  
**Fecha:** 20 de noviembre de 2026  
**Dependencias:** SR-01 a SR-13, especialmente SR-01, SR-02, SR-03, SR-04, SR-06, SR-07, SR-09, SR-10, SR-11, SR-12 y SR-13.  
**Ámbito:** historia anterior al comienzo, prólogo, motivación del personaje, objetivos de campaña, misiones diseñadas, tutoriales, narrativas personales, rumores, secretos, pistas, historias emergentes, consecuencias y memoria narrativa.

---

## CONTROL DEL DOCUMENTO

| Campo | Valor |
|---|---|
| Código | SR-14 |
| Versión | 0.1 — edición oficial aprobada |
| Estado | Normativa oficial aprobada por el autor |
| Autoridad superior | SR-01 — Constitución y leyes fundamentales |
| Dependencias principales | SR-01 a SR-13 |
| Principio central aprobado | Historia fundacional escrita + resultados emergentes autónomos |
| Campaña inicial de referencia | El Eco de Vhaloren |

**Convención normativa:** DEBE y NO DEBE expresan obligaciones o prohibiciones si se aprueba el documento. PUEDE expresa una posibilidad permitida. PROPUESTA identifica contenido narrativo o nombres provisionales. CALIBRACIÓN identifica valores ajustables. RESERVADO identifica detalles que se desarrollarán después.

# PARTE I — PROPÓSITO Y PRINCIPIOS

## 1. Propósito

SR-14 define cómo el universo cuenta historias sin convertirse en una secuencia de acontecimientos prefabricados. Establece una historia anterior al inicio del jugador, motivos para actuar, objetivos de campaña, tutoriales, misiones diseñadas manualmente y mecanismos para que los acontecimientos posteriores evolucionen según las decisiones de jugadores, NPC, monstruos e instituciones.

El proyecto necesita una identidad narrativa previa. El jugador debe comprender que entra en un mundo con historia, tensiones, preguntas sin resolver y motivos para explorar. No debe empezar en una Mazmorra sin saber por qué existe, qué busca la gente en ella, qué riesgos afronta la ciudad ni por qué su propio personaje ha adquirido sus capacidades.

Al mismo tiempo, la historia no debe decidir de antemano cada victoria, derrota, muerte, rescate, descubrimiento o relación. El autor puede diseñar los antecedentes, personajes iniciales, misterios, misiones y objetivos; el mundo debe resolver sus resultados mediante sus agentes y reglas.

## 2. Principio rector: historia escrita, destino abierto

SR-14 adopta dos componentes inseparables:

1. **Historia fundacional y contenido autoral:** hechos históricos, contexto, misterios, personajes iniciales, motivaciones, tutoriales, objetivos y arcos de campaña creados deliberadamente.
2. **Historia emergente:** resultados producidos por entidades autónomas que actúan según sus capacidades, información, motivaciones, recursos, memoria y circunstancias.

La primera proporciona dirección. La segunda proporciona incertidumbre, diversidad y consecuencias.

Una historia escrita puede decir que una expedición desapareció, que una señal fue recibida y que el gremio busca voluntarios. No puede afirmar que el jugador necesariamente la rescatará, que vencerá a un monstruo concreto o que un NPC sobrevivirá si el mundo no ha resuelto esos resultados.

## 3. Autoridad y compatibilidad

SR-14 desarrolla el ámbito narrativo permitido por SR-01 y respeta:

- **SR-01:** agencia, causalidad, independencia del jugador, información limitada, eventos emergentes, historias individuales, persistencia y consecuencias.
- **SR-02:** los sistemas narrativos emiten solicitudes y comandos, pero los dominios competentes validan las acciones y confirman los resultados.
- **SR-03:** identidad, memoria, cognición, aprendizaje, interpretación y continuidad personal.
- **SR-04:** separación entre canon del mundo, crónica personal e instancias o sesiones; realidad objetiva y visibilidad de acontecimientos.
- **SR-05:** procedencia de personajes, objetos, entidades y capacidades.
- **SR-06:** simulación autónoma, avance temporal, agentes y generación de situaciones sin jugador.
- **SR-07:** causalidad física y arcana; la narrativa no puede imponer un resultado que las leyes no permitan.
- **SR-08:** biología, monstruos, ecología y consecuencias reales de la existencia.
- **SR-09:** combate, lesiones, muerte, curación, adaptación y pérdida.
- **SR-10:** contratos, recompensas, financiación, inventarios y recursos reales.
- **SR-11:** localizaciones, rutas, pisos, conexiones y persistencia espacial.
- **SR-12:** capacidades, aprendizaje, clases, habilidades, evolución y trayectoria.
- **SR-13:** culturas, instituciones, Arcana, creencias, leyes y relaciones sociales.

SR-14 no modifica ninguna ley anterior. Define contenido y mecanismos narrativos que operan dentro de ellas.

## 4. Lo que SR-14 prohíbe

- Convertir al jugador en elegido, profetizado o invulnerable sin que exista una regla superior aprobada que lo permita.
- Congelar el mundo para esperar a que el jugador acepte una misión.
- Garantizar la supervivencia de NPC importantes solo porque tengan diálogo o aparezcan en la historia.
- Crear enemigos, objetos, recompensas o recursos sin origen para completar una escena.
- Declarar que una misión tuvo éxito si las condiciones reales no se cumplieron.
- Ocultar una derrota o muerte confirmada para preservar un capítulo.
- Hacer que todos los NPC tengan conocimiento de la trama completa.
- Convertir todo acontecimiento emergente en una misión obligatoria.
- Simular elecciones del jugador que realmente no cambian ninguna variable, relación, conocimiento o consecuencia.

# PARTE II — ARQUITECTURA NARRATIVA

## 5. Cinco capas de narrativa

SR-14 organiza la narrativa en cinco capas. No son mundos separados; son niveles de autoría, información y persistencia.

### 5.1. Historia fundacional

Conjunto de hechos previos al inicio: historia antigua, origen conocido de instituciones, expediciones anteriores, descubrimientos, guerras, fenómenos, leyendas y preguntas sin resolver.

Algunos hechos son objetivos. Otros son versiones, rumores, interpretaciones o documentos parciales. La historia fundacional no obliga a que sus personajes históricos sigan vivos ni a que sus explicaciones sean correctas.

### 5.2. Escenario inicial

Estado de mundo preparado para iniciar una partida: fecha, situación de la ciudad, instituciones activas, problemas conocidos, expediciones, recursos, amenazas, rumores y contratos disponibles.

El escenario inicial puede incluir algunos acontecimientos manuales, pero una vez inicializado, las consecuencias continúan por simulación.

### 5.3. Arco narrativo principal

Una secuencia de objetivos y revelaciones diseñada por los autores. Define qué preguntas se plantean y qué hechos podrían descubrirse, pero permite varias formas de avanzar y resultados alternativos.

Un arco es una estructura de posibilidades y condiciones, no una lista de escenas que deben ocurrir en orden fijo.

### 5.4. Crónica personal

Historia individual del personaje: orígenes, relaciones, motivaciones, promesas, decisiones, reputación, descubrimientos, éxitos, errores, heridas, pérdidas y consecuencias.

Puede relacionarse con la historia principal, pero no tiene que ser idéntica a la de otros personajes o partidas.

### 5.5. Narrativa emergente

Historias generadas por cadenas de acontecimientos que no se escribieron individualmente: NPC que fundan un grupo, un aventurero que fracasa y genera una deuda, un monstruo que aprende una táctica, una rivalidad que provoca una disputa, una ruta que se pierde o una comunidad que organiza un rescate.

La narrativa emergente debe poder surgir incluso sin misiones activas y sin presencia del jugador.

## 6. Canon, conocimiento y relato

Toda información narrativa debe diferenciar:

- **Hecho objetivo:** ocurrió y está confirmado por la simulación.
- **Hecho histórico conocido:** ocurrió y existe evidencia suficiente para registrarlo.
- **Testimonio:** una entidad afirma haber percibido algo.
- **Rumor:** información transmitida sin verificación completa.
- **Hipótesis:** explicación provisional basada en indicios.
- **Creencia:** interpretación aceptada por una persona o comunidad.
- **Leyenda:** relato transmitido cuya exactitud puede ser parcial, simbólica o incierta.
- **Falsedad deliberada:** afirmación creada para engañar, si existe evidencia de intención.

La interfaz narrativa no debe convertir rumor o creencia en una afirmación omnisciente. La realidad objetiva se conserva conforme a SR-04.

# PARTE III — HISTORIA FUNDACIONAL INICIAL

## 7. Función de la historia previa

Antes de controlar al personaje, el jugador debe conocer:

1. qué clase de mundo habita;
2. qué lugar ocupa la ciudad y la Mazmorra en la vida de la gente;
3. por qué los aventureros descienden;
4. qué se sabe y qué se ignora sobre la Arcana y la Mazmorra;
5. qué acontecimiento reciente crea una razón concreta para actuar;
6. qué motivos personales puede tener su personaje;
7. qué riesgos y costes reales implica participar.

La historia no necesita explicar todos los misterios. Debe ofrecer suficiente contexto para que las preguntas sean interesantes.

## 8. Campaña inicial: El Eco de Vhaloren

**Estado:** historia de inicio de referencia aprobada para los pisos 1–5. Los nombres Vhaloren, Nareth, Orrun y Khael se conservan como nombres narrativos de trabajo sujetos a integración con la nomenclatura cultural definitiva; no sustituirlos por nombres improvisados ni tratarlos como inmutables antes de esa integración.

### 8.1. Antecedente antiguo

En distintas zonas de los primeros pisos existen estructuras que no parecen pertenecer a la geología ordinaria ni a las excavaciones mineras recientes. Pilares, cámaras, canales, inscripciones y piezas de una arquitectura anterior aparecen integradas en la roca.

Los estudiosos conocen fragmentos de estas ruinas, pero no su propósito completo, sus constructores ni la fecha exacta de su origen. Algunas inscripciones parecen describir operaciones de alineación y enlace entre puntos de la Mazmorra. Otras son ilegibles o contradictorias.

Una cámara del quinto piso contiene un mecanismo antiguo al que los registros de investigación llaman provisionalmente **Vhaloren**. No se conoce quién lo construyó ni por qué está allí. Su funcionamiento no implica una voluntad consciente: se trata de una estructura arcana que debe ser estudiada conforme a SR-07.

### 8.2. El acontecimiento reciente: el Triple Eco

Durante un periodo prolongado, el mecanismo de Vhaloren no mostró actividad confirmada. En el escenario inicial, un instrumento de observación arcana instalado en la ciudad registra una secuencia de tres pulsos procedentes de la dirección de la Mazmorra.

El acontecimiento es real: el instrumento registró la señal. Su interpretación todavía no está resuelta. Puede tratarse de una reactivación, un cambio de condiciones, un fenómeno local, una operación ejecutada por alguna entidad o una causa desconocida compatible con las leyes del mundo. No es una llamada de un dios ni una comunicación consciente salvo que una investigación futura demuestre un mecanismo distinto.

La señal afecta a los intereses de varias instituciones:

- El gremio quiere determinar si existe una ruta recuperable y si hay personas desaparecidas que puedan ser rescatadas.
- Los estudiosos de la Arcana quieren medir y comprender el fenómeno.
- Las autoridades locales quieren conocer los riesgos para la ciudad y sus infraestructuras.
- Comerciantes y proveedores anticipan oportunidades y costes de expedición.
- Algunos grupos religiosos o filosóficos interpretan el evento desde sus creencias, sin que esas interpretaciones queden confirmadas.

### 8.3. La expedición desaparecida

Antes del Triple Eco, una expedición organizada para estudiar las ruinas de los primeros cinco pisos alcanzó una cámara profunda y dejó de enviar informes regulares. Su última información verificable menciona una estructura que parecía responder a tres componentes de alineación.

No se debe fijar que todos sus miembros estén vivos ni que todos hayan muerto. El estado de cada miembro debe existir en la simulación y evolucionar según sus recursos, lesiones, decisiones, ubicación, tiempo y oportunidades. La campaña comienza con una pregunta verificable: **¿qué ocurrió con la expedición y qué relación tiene su último informe con el Triple Eco?**

### 8.4. Las tres Anclas

Los documentos incompletos de la expedición mencionan tres componentes. El gremio y los investigadores los llaman provisionalmente:

| Nombre de trabajo | Función hipotética | Qué permitiría comprobar |
|---|---|---|
| **Nareth** | Ancla de Traza | Reconstruir o estabilizar una referencia de ruta dentro del mecanismo |
| **Orrun** | Ancla de Pulso | Regular la interacción entre el dispositivo y el flujo arcano |
| **Khael** | Ancla de Vínculo | Establecer o verificar una conexión entre dos puntos del sistema |

No son tres llaves mágicas que se abren por voluntad del jugador. Son componentes de un mecanismo cuya función exacta debe comprobarse. Los nombres pueden ser apodos asignados por los investigadores actuales, no necesariamente sus nombres originales.

Los componentes tienen ubicación, estado, procedencia y propiedades reales. Pueden hallarse integrados en una estructura, en un depósito, entre restos de una expedición, en posesión de una entidad, en una zona inaccesible o en una instalación dañada. No aparecen automáticamente en cofres ni son creados al aceptar una misión.

Pueden ser recuperados por el jugador o por otros agentes. Su pérdida, destrucción, traslado o uso debe cambiar el estado de la campaña.

### 8.5. Objetivo de la primera campaña

La primera campaña ofrece un objetivo concreto, comprensible y de varias etapas:

**Investigar el Triple Eco, localizar los tres componentes de alineación, alcanzar la cámara de Vhaloren en el quinto piso y determinar el destino de la expedición desaparecida. Si el mecanismo puede ser restaurado, abrir una ruta de retorno o recuperación que permita rescatar a quienes sigan con vida y recuperar pruebas de lo sucedido.**

La campaña puede terminar en rescate, recuperación de restos y registros, descubrimiento parcial, fracaso, destrucción del mecanismo, solución alternativa o una combinación de resultados. La historia no garantiza que exista un superviviente.

### 8.6. Un adversario excepcional, no un enemigo esperando al jugador

La cámara o sus rutas pueden estar ocupadas por un monstruo de gran poder, incluso un individuo antiguo que haya acumulado fuerza y rasgos arcanos conforme a SR-08, aprendizaje conforme a SR-09 y progresión conforme a SR-12.

El diseño aprobado permite definir un individuo excepcional inicial con identidad, anatomía, capacidades, memoria, necesidades, territorio y conducta propios. No debe aparecer únicamente cuando el jugador activa una misión, ni permanecer inmóvil esperando el combate. Puede desplazarse, cazar, retirarse, adaptarse, enfrentarse a otras criaturas, ser herido o morir por acciones de NPC antes de que llegue el jugador.

El jugador puede necesitar combatirlo, esquivarlo, negociar si su cognición lo permite, distraerlo, encontrar otra ruta o cambiar el plan. La categoría narrativa de «jefe» describe su importancia para el arco, no le concede invulnerabilidad ni inmunidad a las reglas.

## 9. Lo que la campaña no afirma

La historia inicial no revela todavía:

- el origen último de la Mazmorra;
- quién o qué creó Vhaloren;
- si la Mazmorra tiene una única fuente de generación de monstruos;
- si existe una conciencia detrás de los fenómenos;
- el origen final de las estructuras antiguas;
- la verdad última sobre los dioses;
- el destino definitivo de todos los supervivientes;
- el contenido de los pisos que todavía no forman parte de la primera fase.

La campaña ofrece preguntas y objetivos sin cerrar la cosmología ni apropiarse de decisiones reservadas a SR-01 y SR-07.

# PARTE IV — EL JUGADOR: ORIGEN, MOTIVACIÓN Y HABILIDADES

## 10. El jugador no comienza como elegido

El personaje entra en un mundo que ya existe. No necesita una profecía, una marca divina ni una capacidad única para tener motivos importantes.

Puede empezar como un individuo común con entrenamiento previo, un aprendiz, un trabajador, un guardia, un asistente médico, un estudiante de Arcana, un minero, un explorador principiante, un migrante o una persona con experiencia en otra ocupación.

El sistema no debe asumir que todos los personajes comienzan con la misma biografía, clase, hogar, vínculos o habilidades.

## 11. Motivaciones iniciales

El jugador debe poder seleccionar o combinar motivos compatibles con el mundo, por ejemplo:

- obtener ingresos o salir de una deuda;
- sostener a su hogar o ayudar a una persona cercana;
- encontrar a alguien desaparecido;
- investigar la Arcana o las ruinas;
- convertirse en explorador reconocido;
- proteger a la ciudad o a una comunidad;
- cumplir una promesa, contrato o deber;
- continuar una tradición familiar;
- escapar de una situación anterior;
- buscar conocimiento, prestigio, autonomía o aventura;
- investigar un acontecimiento personal relacionado con la Mazmorra.

La motivación afecta prioridades, relaciones y decisiones. No obliga a aceptar todas las misiones ni predetermina cómo responderá el jugador.

## 12. Cómo obtiene habilidades el personaje

Las habilidades iniciales deben proceder de su historia anterior: entrenamiento, oficio, educación, práctica, entorno, maestro, experiencia o aprendizaje. SR-12 conserva autoridad sobre su adquisición y dominio.

Ejemplos:

- Un antiguo guardia puede conocer posturas básicas, uso de escudo y protocolos de vigilancia por entrenamiento real.
- Un aprendiz de sanador puede conocer primeros auxilios básicos sin dominar cirugía ni curación avanzada.
- Una persona que trabajó en una mina puede reconocer herramientas, vetas, riesgos de derrumbe y técnicas de extracción elementales.
- Un estudiante arcano puede conocer conceptos y algunas palabras de Veyrath, pero no necesariamente ejecutar hechizos con seguridad.
- Un aventurero con experiencia puede tener habilidades prácticas y también errores, malos hábitos o lagunas.

No se debe regalar una habilidad porque el jugador seleccionó una etiqueta de clase. El origen define oportunidades y conocimientos previos; la práctica y el aprendizaje continúan después del inicio.

## 13. Introducción jugable y tutorial orgánico

El tutorial puede ser escrito manualmente y tener una secuencia controlada de enseñanza. Debe ocurrir dentro del mundo cuando sea posible:

1. El personaje despierta o comienza en su hogar o alojamiento asignado conforme a SR-11.
2. Recibe información contextual sobre su situación, recursos y obligaciones.
3. Contacta con el gremio o una institución pertinente.
4. Un instructor, compañero o responsable explica las reglas de seguridad y las interfaces esenciales.
5. El jugador practica movimiento, inventario, interacción, equipo, combate básico o formulación mágica según sus capacidades.
6. Realiza un encargo inicial de bajo riesgo o una exploración guiada.
7. Aprende a observar, retirarse, asistir a un herido, entregar evidencia y cobrar una recompensa válida.
8. Recibe la posibilidad de participar en la investigación del Triple Eco.

El tutorial puede ofrecerse como obligatorio, guiado, abreviado o saltable según el diseño final. Saltarlo no debe conceder habilidades que no se posean, ni bloquear contenido.

Cuando el jugador practica de verdad durante el tutorial, puede producir aprendizaje válido conforme a SR-12. Una animación o una explicación no concede automáticamente dominio.

# PARTE V — MISIONES DISEÑADAS Y MISIONES EMERGENTES

## 14. Las misiones manuales están permitidas

Los gremios, autoridades, familias, academias, comerciantes y particulares pueden ofrecer misiones diseñadas manualmente por los autores. SR-01 permite contenido manual como lore, plantillas, tutoriales y misiones especiales opcionales.

Las misiones escritas a mano pueden proporcionar:

- tutorial y onboarding;
- objetivos iniciales claros;
- historias de personajes importantes;
- investigaciones históricas;
- contratos de campaña principal;
- acontecimientos especiales y contenido opcional;
- encargos únicos con consecuencias conocidas en su planteamiento.

La misión manual define el encargo y sus condiciones, no puede falsificar el resultado. El mundo debe resolver si se cumple, fracasa, cambia, caduca o es completado por otra entidad.

## 15. Misiones generadas por el mundo

Los agentes e instituciones también pueden crear encargos a partir de necesidades y acontecimientos reales:

- una persona desaparecida;
- una ruta bloqueada;
- una caravana que necesita escolta;
- una deuda o contrato incumplido;
- falta de materiales en un taller;
- una criatura que amenaza una zona;
- un recurso que escasea;
- un investigador que necesita una muestra;
- una familia que busca ayuda;
- una expedición que solicita apoyo;
- un testigo que necesita protección;
- una infraestructura arcana que requiere inspección.

La misión debe tener emisor, motivo, objetivo, condiciones, recursos, recompensa y consecuencias. No se genera una misión para fingir que algo ocurrió: el problema que la origina debe existir o ser una necesidad legítima del emisor.

## 16. Tipos de misión

| Tipo | Ejemplo | Validación principal |
|---|---|---|
| Tutorial | Practicar una defensa o usar el inventario | Acción efectivamente realizada y comprendida en el contexto de formación |
| Exploración | Cartografiar una cámara | Presencia, observación y registro de ruta verificables |
| Investigación | Identificar un fenómeno arcano | Evidencias, método y conclusión debidamente diferenciados |
| Recuperación | Encontrar un componente o documento | Existencia, procedencia, estado y transferencia legítima |
| Rescate | Localizar y evacuar una persona | Estado real, ruta, recursos y resultado de la evacuación |
| Eliminación o contención | Detener una amenaza | Identidad y estado real del objetivo, no solo una animación de muerte |
| Escolta | Acompañar a una entidad | Llegada, supervivencia, recorrido y obligaciones cumplidas |
| Fabricación | Preparar un equipo | Materiales, proceso, calidad y entrega conforme a SR-10 |
| Social o diplomática | Negociar un acuerdo | Consentimiento y compromisos de las partes |
| Investigación personal | Resolver una pregunta de la biografía | Evidencias y efecto sobre la crónica personal |
| Campaña | Recuperar las tres Anclas | Condiciones de cada etapa y estado real del mundo |

## 17. Contrato mínimo de misión

Cada misión debe declarar, según corresponda:

- identificador y versión del contenido;
- emisor y autoridad para ofrecerla;
- patrocinador y fuente de financiación;
- motivo real del encargo;
- destinatarios y requisitos;
- objetivo principal y objetivos secundarios;
- condiciones de éxito y fracaso;
- evidencia aceptable;
- recompensa, pago, costes y penalizaciones pactadas;
- ubicación, plazo y rutas conocidas;
- riesgos conocidos y desconocidos;
- exclusividad o posibilidad de varios participantes;
- fecha de publicación, expiración o cancelación;
- visibilidad y reputación asociada;
- estados y consecuencias posibles.

El contrato no crea recursos. Las recompensas respetan SR-10: debe existir financiación, patrocinador, bienes o crédito válido.

## 18. Competencia y concurrencia de misiones

Una misión puede ser aceptada por una persona, grupo, organización o varios participantes si el contrato lo permite. La misma necesidad no debe generar recompensas duplicadas sin que exista un acuerdo válido.

Si dos grupos intentan recuperar un mismo objeto único, su disponibilidad y propiedad se validan mediante SR-02 y SR-10. Si un NPC consigue el objetivo primero, la misión puede completarse, cancelarse, transformarse o quedar sin recompensa para otros, según el contrato.

## 19. Fracaso, abandono y caducidad

Una misión puede fracasar por muerte, lesión, pérdida de recursos, plazo vencido, información errónea, destrucción del objetivo, intervención de terceros, cambio político o decisión de sus participantes.

El fracaso no debe borrar el acontecimiento. Puede generar deuda, reputación, duelo, reclamaciones, nuevos contratos, cambios de precio, rutas alternativas, represalias o reconciliación.

El jugador puede abandonar un encargo. El abandono no detiene el mundo ni elimina las consecuencias contractuales que correspondan.

# PARTE VI — EL ARCO PRINCIPAL COMO ESTRUCTURA ABIERTA

## 20. Etapas de referencia de El Eco de Vhaloren

Las etapas siguientes definen un arco inicial de referencia. Cada etapa contiene condiciones y resultados posibles; no todas tienen que ocurrir exactamente en este orden si las circunstancias del mundo permiten otra vía.

### Etapa 0 — Antes del primer descenso

Se crea o determina la biografía inicial, la motivación, las habilidades previas, el hogar, los recursos y las relaciones pertinentes. Se ofrece el tutorial de acuerdo con el perfil.

**Resultado esperado:** el jugador entiende por qué su personaje puede realizar algunas acciones y por qué otras todavía requieren aprendizaje.

### Etapa 1 — La señal

La ciudad recibe el Triple Eco. El gremio, las autoridades y los estudiosos reciben información distinta. Se publica un encargo para verificar su origen y revisar el último informe de la expedición desaparecida.

**Resultado abierto:** el jugador puede aceptar, rechazar, investigar por su cuenta o incorporarse después. Otros agentes también pueden actuar.

### Etapa 2 — Las primeras pruebas

El grupo debe localizar rastros reales: rutas, restos, marcas, registros, muestras o testimonios relacionados con la expedición. El piso 1 ofrece el primer contacto con las ruinas y el tipo de riesgo presente.

**Resultado abierto:** las pruebas pueden ser incompletas, haber sido movidas, encontrarse en manos de otros o haber sido interpretadas mal.

### Etapa 3 — Las tres Anclas

Se reconstruye la hipótesis de Nareth, Orrun y Khael. Cada componente puede encontrarse mediante rutas, desafíos, investigación, negociación, recuperación o intervención sobre estructuras.

**Resultado abierto:** NPC y monstruos pueden alterar su localización. Los componentes pueden perderse, dañarse, quedar inaccesibles o ser reunidos por otros agentes.

### Etapa 4 — El descenso y la cámara

El grupo alcanza el área de Vhaloren en el piso 5 si reúne conocimientos, recursos, capacidades y acceso suficientes. No hay garantía de que el camino más directo sea el más seguro.

**Resultado abierto:** el adversario excepcional puede seguir allí, haberse desplazado, haber sido derrotado o haber cambiado el entorno.

### Etapa 5 — Alineación y prueba

Los componentes se utilizan conforme a los mecanismos descubiertos. El sistema valida si la instalación es compatible, si faltan piezas, si hay daños o si se necesita una solución alternativa.

**Resultado abierto:** se puede restaurar el mecanismo, lograr una activación parcial, provocar un fallo, descubrir que la hipótesis era incorrecta o encontrar otra vía.

### Etapa 6 — Retorno, rescate o verdad

La cámara puede revelar el destino de la expedición: supervivientes, restos, registros, una retirada anterior, un engaño, una ruta diferente o resultados combinados. El resultado deriva del estado real de los integrantes y de la evidencia.

**Resultado abierto:** no se garantiza rescate. Recuperar la verdad, incluso si nadie sobrevive, puede ser un resultado narrativo y socialmente importante.

### Etapa 7 — Consecuencia y siguiente horizonte

El gremio, las autoridades, los investigadores, los comerciantes y los habitantes reaccionan a los hechos. Puede cambiar el acceso a rutas, la reputación, la economía, el conocimiento público o la preparación para descender más profundo.

La primera campaña puede cerrar su conflicto principal sin resolver la naturaleza última de la Mazmorra. El siguiente arco surge de nuevos objetivos y consecuencias.

## 21. Condiciones alternativas de progreso

El arco puede avanzar aunque una etapa no se complete como estaba prevista:

- Un NPC recupera una Ancla; el jugador puede investigar cómo lo logró, ayudarlo o buscar otra.
- Una Ancla es destruida; puede requerirse reconstrucción, sustitución o una ruta alternativa.
- Un superviviente muere; la misión puede pasar de rescate a recuperación de restos y evidencia.
- Un grupo abandona la investigación; otra organización puede asumirla.
- Un monstruo excepcional muere antes del encuentro; el objetivo se adapta al nuevo estado.
- La cámara ya ha sido activada por terceros; el jugador llega a un mundo cambiado.
- La señal resulta ser un fenómeno distinto a la hipótesis inicial; la campaña cambia de explicación sin fingir que la teoría original era cierta.

# PARTE VII — URGENCIA Y MOTIVACIÓN SIN COERCIÓN

## 22. Crear razones para actuar

El mundo debe presentar objetivos con relevancia, presión y consecuencias. La motivación puede surgir de:

- riesgo para una comunidad;
- personas desaparecidas o amenazadas;
- recompensas y oportunidades;
- promesas o deudas;
- deber profesional;
- deseo de conocimiento;
- rivalidad y prestigio;
- protección de familiares o compañeros;
- necesidad material;
- cambio ambiental o institucional.

El sistema puede hacer que una oportunidad caduque o que una situación empeore con el tiempo. No debe detener el reloj hasta que el jugador acepte.

## 23. No confundir urgencia con obligación del jugador

El mundo puede presentar una crisis grave. El jugador no está obligado a resolverla personalmente. Otros agentes pueden intentarlo; pueden tener éxito, fracasar o empeorar la situación. La ausencia del jugador no congela a las instituciones ni a los adversarios.

El jugador conserva agencia: puede priorizar asuntos personales, abandonar la región, apoyar a otra facción, investigar una causa distinta o no involucrarse. Cada opción tiene consecuencias, no una pantalla de fracaso obligatorio.

## 24. Relevancia personal

La historia fundacional debe ofrecer puntos de entrada a biografías diversas, sin declarar a todos los jugadores parientes del mismo personaje desaparecido ni elegidos por el mismo misterio.

Una misma campaña puede adquirir sentido diferente:

- para un personaje, es una oportunidad laboral;
- para otro, la posibilidad de encontrar a alguien;
- para otro, una investigación sobre la Arcana;
- para otro, una deuda o una promesa;
- para otro, una misión de protección comunitaria;
- para otro, el comienzo de una ambición aventurera.

Las motivaciones personales se registran en la crónica y pueden cambiar por aprendizaje, pérdida, relaciones y decisiones.

# PARTE VIII — PERSONAJES, DIÁLOGOS Y RELACIONES

## 25. Personajes escritos con autonomía

Los personajes importantes pueden tener biografía, voz, apariencia, vínculos y acontecimientos previos diseñados. Una vez introducidos, deben actuar mediante el mismo modelo de agencia, memoria, necesidades, capacidades y causalidad que los demás agentes.

No deben conocer la trama completa por ser personajes principales. Pueden equivocarse, ocultar información, morir, abandonar sus cargos, cambiar de lealtad o contradecir su presentación inicial.

## 26. Diálogo como acto social

Una conversación puede transmitir información, revelar sentimientos, negociar, mentir, amenazar, enseñar, persuadir, consolar o crear compromisos. Sus resultados dependen de lo que cada participante sabe, pretende, puede expresar y está dispuesto a aceptar.

Las líneas escritas manualmente son válidas para situaciones de alto valor narrativo, tutoriales, presentaciones y personajes destacados. La conversación dinámica puede combinar plantillas, intenciones, memoria y lenguaje generado offline o mediante recursos opcionales futuros. Ninguna respuesta debe otorgar conocimientos que el personaje no posee.

## 27. Relaciones y consecuencias

Las relaciones pueden cambiar por confianza, cooperación, promesas, ayuda, traición, competencia, pérdida, reputación, afinidad cultural, miedo, deuda y experiencias compartidas.

Una relación no debe ser una sola barra que determine todo. Puede incluir dimensiones como confianza, afecto, respeto, temor, dependencia, rivalidad, deuda, admiración o resentimiento, según proceda.

La amistad no se concede por completar una misión. El vínculo se desarrolla mediante acontecimientos y percepción individual.

# PARTE IX — RUMORES, PISTAS, SECRETOS Y MISTERIOS

## 28. Pistas con procedencia

Una pista tiene origen: documento, testigo, observación, huella, objeto, medición, archivo, tradición o inferencia. Puede ser verdadera, parcial, engañosa, falsa o estar desactualizada.

El sistema debe registrar quién la conoce, cómo la obtuvo, qué interpretación hizo y a quién la transmitió. Una pista no revela automáticamente todos los hechos relacionados.

## 29. Misterios diseñados

Los autores pueden crear misterios con:

- una pregunta central;
- hechos objetivos ya definidos o deliberadamente reservados;
- evidencias disponibles;
- interpretaciones razonables y errores posibles;
- fuentes de información y restricciones;
- hipótesis alternativas;
- consecuencias de cada descubrimiento.

Un misterio no debe depender de que el jugador encuentre exactamente una única pista obligatoria. Debe permitir rutas alternativas de descubrimiento y, cuando corresponda, investigación incompleta.

## 30. Secretos y conocimiento limitado

Un secreto existe si hay información que no es pública y una razón para que no lo sea. Puede ser conocido por una persona, organización, familia, autoridad o nadie. Quien lo guarda puede morir, olvidarlo, revelarlo o ser descubierto.

La muerte de un guardián del secreto no borra automáticamente el contenido: pueden quedar documentos, testigos, objetos o ninguna evidencia recuperable.

# PARTE X — OBJETIVOS, JEFES Y ENCUENTROS ESPECIALES

## 31. Jefe como individuo, no como función inmortal

Un jefe de piso o enemigo principal debe existir como entidad coherente con SR-08 y SR-09. Puede tener capacidades excepcionales, historia, comportamiento, territorio, memoria y adaptación. Su importancia narrativa no lo exime de daño, derrota, retirada, muerte ni consecuencias.

Un jefe puede ser creado manualmente como individuo inicial, pero desde su creación debe existir en la simulación y estar sujeto a ella. No debe reaparecer automáticamente tras morir salvo que exista un mecanismo de reproducción, generación o sustitución compatible con las normas superiores.

## 32. Objetivos alternativos al combate

No toda misión requiere matar. Los objetivos pueden ser investigar, contener, evitar, distraer, negociar, rescatar, escoltar, escapar, cartografiar, reparar, sellar, recuperar o sobrevivir.

La victoria narrativa puede consistir en cumplir el objetivo sin derrotar al adversario. La derrota de un jefe puede producir una oportunidad, no necesariamente una recompensa automática ni una solución para todo el problema.

## 33. Recompensas y botín

Las recompensas obedecen SR-10. El contenido narrativo no crea cristales, monedas, equipo o propiedades sin procedencia. Los reconocimientos, títulos y reputación también requieren autoridad y evidencia.

Una recompensa puede ser información, acceso, confianza, protección, enseñanza, un contrato futuro o un cambio de estatus, siempre que sea concedida por un actor o mecanismo válido.

# PARTE XI — HISTORIAS EMERGENTES Y GENERACIÓN DE OBJETIVOS

## 34. De acontecimiento a historia

Una historia emergente puede formarse cuando varios acontecimientos relacionados crean una secuencia comprensible: causa, decisión, obstáculo, consecuencia y memoria.

Ejemplo: una expedición pierde a su guía; un superviviente regresa; una familia organiza una búsqueda; el gremio publica un contrato; dos grupos compiten por aceptarlo; uno llega tarde; la familia decide cambiar la recompensa; la noticia altera la reputación de la zona. Ninguno de esos resultados necesita estar escrito individualmente si existen los mecanismos y los agentes adecuados.

## 35. De necesidad a misión

Un sistema puede detectar una necesidad o un acontecimiento que justifique una misión. El encargo se publica cuando un actor o institución tiene motivación, recursos y autoridad para hacerlo.

No todo evento genera una misión. Los habitantes pueden resolver problemas por sí mismos, ignorarlos, pedir ayuda privada, formar una asociación, negociar o fracasar sin convertir cada acción en una tarea del jugador.

## 36. Relevancia narrativa

No todos los eventos merecen el mismo tratamiento. La selección narrativa puede considerar impacto, singularidad, relaciones afectadas, riesgo, consecuencias, novedad, duración y significado para los participantes.

La prioridad de presentación no modifica la probabilidad ni el resultado de los acontecimientos. Un evento no debe volverse más probable solo porque la interfaz lo considere interesante.

# PARTE XII — PERSISTENCIA, CANON Y SIMULACIÓN

## 37. Integración con SR-04

La narrativa respeta las capas de SR-04:

- **World Canon:** hechos objetivos del mundo, acontecimientos, lugares, organizaciones, individuos y cambios compartidos.
- **Personal Chronicle:** recuerdos, relaciones, decisiones, descubrimientos privados, misiones personales y consecuencias individuales.
- **Instance / Session:** expediciones, encuentros, sesiones o misiones personales cuando utilicen un contexto de instancia.

Una misión personal no puede crear una versión contradictoria de un acontecimiento global. Un recuerdo puede estar equivocado, pero no cambia el hecho objetivo.

## 38. La historia continúa cuando el jugador no está

Los arcos principales, misiones, expediciones y conflictos pueden avanzar durante la ausencia del jugador. Otros agentes pueden aceptar contratos, recuperar objetivos, morir, fracasar, resolver el problema o cambiar su naturaleza.

SR-06 puede resumir procesos secundarios, pero debe preservar recursos, tiempo, capacidad, riesgos y resultados causales. La simulación offline no requiere que Android mantenga la aplicación abierta: el avance temporal se calcula al regresar conforme a las normas temporales.

## 39. Registro de acontecimientos narrativos

Un evento narrativamente relevante debe poder conservar, según corresponda:

- ID y tipo;
- fecha y lugar;
- participantes e identidades;
- motivaciones conocidas o inferidas;
- acción y causa;
- estado previo y posterior;
- evidencia y procedencia;
- alcance y visibilidad;
- consecuencias inmediatas y pendientes;
- misión o arco relacionado;
- interpretaciones, rumores y recuerdos asociados.

# PARTE XIII — CONTRATOS DE DATOS

## 40. Definición de arco narrativo

Un arco debe poder definir:

- identidad y versión;
- antecedentes históricos;
- situación inicial;
- preguntas y objetivos;
- etapas o nodos de avance;
- condiciones de activación;
- actores e instituciones implicados;
- ubicaciones y recursos pertinentes;
- pistas y fuentes de información;
- estados posibles, ramas y fallos;
- hechos que deben permanecer invariantes;
- hechos cuyo resultado se deja a simulación;
- consecuencias y transiciones posteriores.

## 41. Definición de nodo narrativo

Un nodo puede declarar:

- condición de entrada;
- hechos necesarios y hechos opcionales;
- tareas o posibilidades disponibles;
- agentes que pueden actuar;
- recursos y costes;
- condiciones de éxito, fracaso, caducidad o transformación;
- evidencia exigida;
- eventos que deben confirmarse;
- nodos siguientes posibles.

Un nodo no es una escena obligatoria. Puede cerrarse porque un NPC lo completó, porque el objetivo dejó de existir o porque la situación cambió.

## 42. Registro de motivación

La motivación personal debe poder incluir fuente, objeto de interés, prioridad, intensidad, conocimiento, compromisos, conflictos y evolución. Puede cambiar por eventos, relaciones, aprendizaje, trauma, pérdida, oportunidad o decisión.

## 43. Contrato de misión

El contrato de misión definido en §17 debe ser compatible con SR-10 y las autoridades de SR-02. La interfaz no debe inventar un pagador, un objeto ni un resultado; debe mostrar el estado validado de la misión.

# PARTE XIV — PRUEBAS OBLIGATORIAS

## 44. Escenarios de validación

1. La historia fundacional se presenta al inicio sin revelar toda la verdad del universo.
2. Un jugador puede comenzar con biografía y motivación distintas a las de otro.
3. Las habilidades iniciales tienen origen verificable en historia, entrenamiento, conocimiento o práctica.
4. Elegir una motivación no concede una clase ni habilidades automáticamente.
5. Un tutorial manual puede enseñar una interfaz sin crear resultados falsos en el mundo.
6. Una misión escrita manualmente puede fracasar si sus condiciones no se cumplen.
7. Un NPC puede aceptar y completar una misión de campaña antes que el jugador.
8. Si un NPC recupera un objeto único, el inventario y el contrato cambian de manera coherente.
9. Ignorar una misión no congela su situación ni al mundo.
10. El destino de la expedición desaparecida depende de su estado simulado, no de una escena garantizada.
11. Los tres componentes tienen identidad, ubicación, estado y procedencia reales.
12. Los componentes no aparecen de un cofre arbitrario ni se duplican al repetir la misión.
13. Un jefe puede desplazarse, luchar, retirarse, aprender, morir o ser derrotado por NPC.
14. La muerte de un personaje importante no se revierte para mantener la trama.
15. Una pista verdadera puede ser interpretada mal por un testigo.
16. Un rumor falso puede difundirse sin convertirse en hecho.
17. Un jugador puede resolver un objetivo por un método distinto al previsto en el encargo.
18. Una misión caducada genera consecuencias sin bloquear el resto del juego.
19. La campaña puede avanzar con éxito parcial, fracaso o solución alternativa.
20. Una misión manual tiene un emisor y una fuente válida de recompensa.
21. Una institución no puede pagar una recompensa sin fondos, crédito o bienes comprometidos.
22. Un personaje no conoce pistas que no haya percibido, deducido o recibido.
23. El diálogo no otorga conocimientos no adquiridos.
24. La creencia de un personaje sobre el Triple Eco no modifica la causa objetiva del evento.
25. El jugador puede rechazar la campaña principal y continuar viviendo en el mundo.
26. Las consecuencias de una misión aparecen en World Canon y/o Personal Chronicle según su alcance.
27. La ausencia del jugador permite que las misiones y expediciones avancen según SR-06.
28. Dos partidas con condiciones iniciales distintas pueden producir historias y resultados diferentes.
29. Una repetición determinista con semilla y entradas idénticas reproduce el mismo resultado en modo de prueba.
30. Una escena escrita no puede invalidar una consecuencia ya confirmada por el dominio competente.

# PARTE XV — DECISIONES RESERVADAS Y CALIBRACIÓN

## 45. Elementos que deben desarrollarse posteriormente

- cronología histórica completa de la región y de la ciudad;
- nombre, cultura e historia de quienes construyeron Vhaloren, si se descubre;
- nombres canónicos de los tres componentes;
- identidades y biografías de la expedición desaparecida;
- distribución final y condiciones exactas de los componentes en los pisos 1–5;
- ficha, especie y conducta del individuo excepcional del piso 5, si se incluye;
- lista final de misiones manuales del tutorial;
- diálogos y escenas de personajes principales;
- variantes de motivación y biografía inicial;
- condiciones exactas y calendario del Triple Eco;
- reglas de caducidad, recompensa, reputación y acceso a contratos;
- intensidad y ritmo de capítulos, pistas y revelaciones;
- mecanismo de transición de la primera campaña a los pisos y arcos posteriores.

Estos elementos pueden añadirse mediante catálogos y anexos. No pueden contradecir SR-01 a SR-13.

## 46. Contenido fijo y contenido variable de la campaña

| Contenido | Tratamiento propuesto |
|---|---|
| Existencia de la señal inicial | Hecho fijo del escenario inicial |
| Registro de tres pulsos | Hecho fijo; interpretación abierta |
| Existencia de ruinas y mecanismo Vhaloren | Hecho fijo dentro del escenario de campaña |
| Función exacta de Vhaloren | Misterio investigable |
| Existencia inicial de la expedición desaparecida | Hecho histórico fijo |
| Destino y supervivencia de sus miembros | Estado simulado, no resultado garantizado |
| Existencia de tres componentes | Hipótesis de campaña basada en registros; validar físicamente cada componente |
| Ubicación y posesión de cada componente | Variable y persistente |
| Monstruo excepcional | Individuo inicial opcional sujeto a simulación |
| Victoria del jugador | Nunca garantizada |
| Rescate completo | Nunca garantizado |
| Consecuencias institucionales | Resultado de hechos y decisiones confirmados |

## 47. Regla de no modificación de normas anteriores

SR-14 no requiere enmiendas a SR-01–SR-13 porque:

- SR-01 ya permite lore, mapas, plantillas, tutoriales y misiones especiales manuales, mientras prohíbe escribir cada resultado emergente de antemano.
- SR-04 ya distingue World Canon, Personal Chronicle e Instance / Session, permitiendo historias individuales sin duplicar hechos globales.
- SR-06 ya establece que los agentes actúan sin jugador y que las misiones pueden nacer de acontecimientos reales.
- SR-10 ya regula contratos, fondos, inventario y recompensas.
- SR-11 ya define los espacios reales donde ocurren los objetivos.
- SR-12 ya explica el origen y el desarrollo de habilidades.
- SR-13 ya establece las instituciones, culturas y lugar civilizatorio de la Arcana.

**Conclusión normativa:** la historia fundacional y las misiones diseñadas son contenido autoral permitido. Los resultados y consecuencias deben seguir siendo causales y autónomos.

# DECLARACIÓN NARRATIVA FINAL

El jugador no llega a un mundo vacío esperando que invente un motivo para existir. Llega a una civilización con una historia anterior, instituciones con intereses, una Mazmorra cuya importancia afecta a la vida cotidiana, un misterio que reclama atención y personas que tienen razones para descender.

El mundo le ofrece una historia que puede comenzar, pero no le promete cómo terminará. Puede aceptar el encargo, rechazarlo, llegar tarde, fracasar, descubrir otra verdad o cambiar el destino de quienes lo rodean. Otros habitantes pueden actuar mientras él duda, descansa o persigue algo distinto. Una victoria escrita no vale más que una consecuencia verdadera.

La historia fundacional da dirección. La autonomía da incertidumbre. La memoria convierte los resultados en historia. Y la historia, una vez ocurrida, pertenece al mundo.

**SR-14 v0.1 — NORMATIVA OFICIAL APROBADA POR EL AUTOR EL 2026-11-20.**

# SR-11 — GEOGRAFÍA, ASENTAMIENTOS Y MAZMORRA

**Código:** SR-11  
**Versión:** 0.1 — aprobada  
**Estado:** NORMATIVA OFICIAL APROBADA  
**Fecha:** 2026-11-20  
**Dependencias:** SR-01 a SR-10, especialmente SR-01, SR-02, SR-04, SR-05, SR-06, SR-07, SR-08, SR-09 y SR-10.  
**Ámbito:** geografía objetiva, estructura espacial, región inicial, reino, ciudad, barrios, vivienda, muralla, bosque fronterizo, torre de acceso, Mazmorra, pisos, salas, corredores, conexiones, navegación y persistencia espacial.

---

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Aprobada | Primera especificación integral de geografía, asentamientos y Mazmorra; aprobada por el autor el 20-11-2026. |

**Convención normativa:** DEBE y NO DEBE expresan requisitos obligatorios. PUEDE expresa una posibilidad permitida. CALIBRACIÓN identifica valores ajustables mediante pruebas. RESERVADO identifica decisiones o catálogos que se desarrollarán después. Las dimensiones, nombres propios, planos exactos y distribuciones específicas permanecen sujetos a calibración y desarrollo posterior, conforme a la aprobación.

# PARTE I — PROPÓSITO, AUTORIDAD Y PRINCIPIOS

## 1. Propósito

SR-11 define cómo se organiza el espacio físico del universo y cómo se relacionan sus regiones, asentamientos, construcciones, interiores, caminos, biomas, pisos y salas. Establece una primera región de referencia para el juego: un reino con una ciudad principal, una muralla fronteriza, un bosque al otro lado de ella y una torre monumental que sirve como acceso a una Mazmorra de escala interior extraordinaria.

El espacio no será un conjunto de menús o escenarios inconexos que aparecen únicamente cuando el jugador los necesita. Los lugares tienen ubicación, dimensiones, conexiones, condiciones, historia, propiedad, ocupación y consecuencias. Pueden existir, cambiar y ser utilizados por habitantes y criaturas aunque el jugador no los vea.

## 2. Autoridad y límites

SR-11 desarrolla la dimensión espacial de las leyes de SR-01 y respeta los límites de autoridad, comandos y validación de SR-02; la realidad objetiva y persistencia de SR-04; entidades, objetos, materiales y representación de SR-05; simulación multiescala y continuidad temporal de SR-06; movimiento, fuerzas y colisiones de SR-07; hábitats y ecología de SR-08; combate en cualquier espacio físicamente válido de SR-09; y propiedad, recursos, comercio, fabricación y botín de SR-10.

SR-11 no determina por sí solo el catálogo definitivo de especies, la distribución definitiva de monstruos, la historia política completa del reino, la religión, las leyes civiles, los precios, las clases ni el sistema de progresión. Esos dominios se desarrollan en sus documentos especializados.

## 3. Principios espaciales obligatorios

1. **Geografía objetiva:** un lugar no deja de existir porque el jugador no lo haya descubierto o porque la cámara no lo represente.
2. **Continuidad:** el territorio inicial debe sentirse como una región conectada. Los cambios de zona no deben convertirse en teletransportes arbitrarios.
3. **Causalidad espacial:** entrar, salir, cruzar, derribar, bloquear, ocupar o modificar un lugar requiere una vía y condiciones compatibles con el mundo.
4. **Escala coherente:** dimensiones, alturas, distancias, capacidad de paso y tiempos de viaje deben ser compatibles con los cuerpos, objetos y medios de desplazamiento.
5. **Identidad de los lugares:** dos salas que cumplen la misma función pueden ser distintas en geometría, composición, conexiones, historia y condiciones.
6. **Independencia del jugador:** asentamientos, rutas, habitantes, ecosistemas y espacios continúan evolucionando durante su ausencia, según SR-01 y SR-06.
7. **Conocimiento limitado:** descubrir o recordar un sitio es distinto de que ese sitio exista. Cada entidad conoce únicamente lo que ha percibido, investigado o recibido legítimamente.
8. **Combate espacialmente libre:** cualquier lugar puede convertirse en escenario de combate si sus dimensiones, accesos y condiciones físicas lo permiten. No se necesitan arenas especiales.
9. **Diferenciación ecológica:** pisos que compartan una familia de bioma siguen teniendo identidad espacial y ecológica individual, conforme a SR-08.
10. **Representación subordinada:** el mapa, la cámara, el modelo 3D y la interfaz muestran el espacio; no son autoridad para alterar su realidad.

## 4. Alcance de la primera región

### 4.1. Alcance incluido

La primera gran zona jugable se organizará alrededor de un reino o territorio principal. Debe incluir:

- una ciudad principal de fantasía;
- los barrios y servicios necesarios para sostener una población autónoma;
- el gremio de aventureros;
- viviendas y un hogar inicial asociado al personaje;
- tabernas, alojamiento y establecimientos comerciales;
- talleres y espacios de producción;
- caminos y espacios abiertos que conecten los lugares;
- una muralla que marque la frontera entre el reino desarrollado y el bosque exterior;
- la presencia geográfica del bosque al otro lado de la muralla;
- una torre monumental que contiene el acceso a la Mazmorra;
- los pisos interiores de la Mazmorra, con desarrollo inicial prioritario de los pisos 1–5.

### 4.2. Alcance reservado

La expansión completa del territorio exterior a la muralla, otros reinos, continentes, ciudades lejanas, rutas internacionales y regiones remotas queda fuera del primer bloque de construcción detallada. Su existencia futura no queda negada: simplemente no se exige construirla en esta etapa.

La frontera de contenido inicial no debe confundirse con una pared invisible presentada como parte de la geografía. Cuando el jugador alcance un límite de la zona desarrollada, el mundo debe comunicarlo de forma coherente: muralla, puerta cerrada, camino vigilado, terreno inaccesible, distancia o una causa equivalente.

# PARTE II — MODELO DEL ESPACIO Y ESCALA

## 5. Jerarquía espacial

El modelo debe admitir una jerarquía flexible como la siguiente:

1. **Mundo:** universo espacial completo.
2. **Región mayor:** continente, masa territorial o gran región, si se define en el futuro.
3. **Reino o territorio:** ámbito geográfico y político amplio.
4. **Subregión:** entorno natural, frontera, valle, bosque, llanura u otra unidad.
5. **Asentamiento o hito:** ciudad, aldea, fortaleza, torre, instalación o lugar significativo.
6. **Distrito o zona:** parte reconocible de un asentamiento o terreno.
7. **Estructura:** edificio, muralla, puente, torre, puerta, taller u obra construida.
8. **Interior:** volumen transitable dentro de una estructura.
9. **Sala, cámara o corredor:** espacio local conectado a otros espacios.
10. **Elemento espacial:** puerta, escalera, ventana, pasarela, columna, desnivel, obstáculo, cobertura, entrada, salida o conexión.

No todos los lugares requieren todos los niveles. La jerarquía permite describir desde una región extensa hasta una puerta concreta sin mezclar escalas.

## 6. Coordenadas y dimensiones

### 6.1. Espacio lógico tridimensional

El espacio lógico será tridimensional aunque la presentación habitual sea isométrica. Se propone el siguiente convenio técnico:

- eje X: horizontal este-oeste;
- eje Z: horizontal norte-sur;
- eje Y: altura y desnivel;
- distancias expresadas en unidades métricas de referencia;
- cada lugar define un marco local cuando su orientación o geometría lo requiera.

La orientación cardinal se mostrará de forma consistente en mapas, brújulas y datos de navegación. La convención exacta de norte positivo y sentido de rotación podrá cerrarse en SR-15, pero no podrá variar entre subsistemas.

### 6.2. Unidades

**PROPUESTA DE TRABAJO:** 1 unidad espacial del motor equivale a 1 metro. Esta equivalencia facilita dimensionar cuerpos, puertas, corredores, alturas, velocidad, alcances y colisiones. Se recomienda mantenerla como base técnica, sujeta a verificación en SR-15.

### 6.3. Medidas iniciales orientativas

Las siguientes medidas son referencias para blockout y pruebas, no dimensiones canónicas definitivas:

| Elemento | Referencia inicial | Estado |
|---|---:|---|
| Región inicial conectada | alrededor de 2 × 2 km | Calibración |
| Huella urbana principal | alrededor de 300 × 250 m | Calibración |
| Sectores de carga/actualización | bloques de 128 × 128 m | Decisión técnica pendiente de SR-15 |
| Unidad espacial | 1 unidad = 1 m | Propuesta técnica |

Las medidas deberán contrastarse con tiempos de desplazamiento, densidad urbana, líneas de visión, número de agentes, tamaño de la Mazmorra, navegación y rendimiento en Android. No se ampliará o comprimirá una zona para resolver un problema visual sin comprobar sus consecuencias sobre movimiento y simulación.

## 7. Continuidad, caminos y conexiones

Los lugares conectados deben tener una vía físicamente comprensible: calles, senderos, puertas, escaleras, rampas, puentes, túneles, galerías, ascensores, pasajes o mecanismos propios del mundo.

Una conexión debe declarar, según corresponda:

- origen y destino;
- posición y orientación de entrada y salida;
- dimensiones útiles y altura libre;
- sentido permitido o restricciones;
- condiciones de acceso;
- estado: abierta, cerrada, bloqueada, dañada, vigilada o destruida;
- capacidad aproximada de paso;
- riesgos y obstáculos;
- medio de recorrido y tiempo estimado.

No se supone que toda conexión sea bidireccional. Una caída, salto, puerta unidireccional o mecanismo puede permitir pasar en un sentido y no en el otro, siempre que exista una explicación espacial válida.

## 8. Navegación y accesibilidad física

La navegación debe respetar anatomía, tamaño, capacidad, movilidad, carga, lesiones, terreno y obstáculos. Un pasaje apto para una persona puede no serlo para una criatura grande. Una entidad herida puede no atravesar un desnivel que antes superaba.

Los corredores no deben tratarse como líneas abstractas si su anchura, altura, pendiente o superficie limitan el movimiento. Las puertas y pasajes pueden bloquearse, abrirse, cerrarse, romperse o quedar obstruidos de acuerdo con sus materiales y las reglas físicas de SR-07.

La navegación automática puede calcular rutas, pero no concede capacidades inexistentes. Si una ruta deja de ser transitable, el agente debe buscar una alternativa, esperar, retroceder, solicitar ayuda o cambiar su objetivo de forma coherente.

# PARTE III — REINO Y CIUDAD PRINCIPAL

## 9. Concepto general de ciudad

La ciudad principal será una urbe de fantasía habitada, funcional y visualmente reconocible. La inspiración de ambientación puede tomar como referencia la sensación de una ciudad de aventureros de fantasía —incluido el tipo de organización urbana que recuerda a DanMachi—, pero la geografía, los edificios, los nombres, las historias y las identidades deberán ser originales.

La ciudad no debe parecer un decorado construido únicamente para ofrecer servicios al jugador. Debe tener circulación, viviendas, abastecimiento, talleres, ocio, autoridad, mantenimiento, zonas de actividad y espacios menos concurridos. Sus habitantes deben tener razones para estar en cada lugar y horarios compatibles con sus actividades.

## 10. Organización recomendada de distritos

La siguiente distribución es una propuesta funcional. Los límites pueden ser orgánicos y no necesariamente calles rectas o barrios geométricos.

### 10.1. Centro cívico y plaza de la torre

Espacio de referencia visual para orientarse. Debe permitir llegar a la torre, recibir noticias, encontrarse con otros habitantes y acceder a vías principales. La torre será un hito dominante en la silueta urbana.

### 10.2. Distrito del gremio

Debe incluir el edificio del gremio de aventureros y espacios adecuados para registro, información, tablones o encargos, reuniones, evaluación, gestión de grupos y administración. El gremio ocupa un lugar importante en la vida de aventureros, pero no controla por defecto todos los empleos, el comercio, la propiedad o los accesos de la ciudad. Su autoridad social y legal se definirá con mayor detalle en SR-13.

### 10.3. Distrito comercial

Mercados, tiendas, puestos, almacenes, proveedores y espacios de carga. Debe existir relación física entre establecimientos, rutas de transporte y zonas de almacenamiento. El inventario y los precios respetan SR-10; una tienda no es una interfaz con mercancía infinita.

### 10.4. Distrito de tabernas y alojamiento

Tabernas, posadas, comedores, hospedajes y espacios de reunión. Pueden diferenciarse por precio, reputación, clientela, ubicación, seguridad, calidad y horarios. El alojamiento temporal no sustituye a la propiedad residencial.

### 10.5. Distrito residencial

Viviendas de distintos tamaños, calidades y condiciones. Debe admitir hogares de NPC, casas alquiladas, habitaciones, viviendas de aventureros y hogares asociados al personaje. Las viviendas tienen accesos, interiores y ocupantes persistentes.

### 10.6. Distrito de talleres y servicios

Herrerías, sastrerías, carpinterías, talleres de cuero, reparación, preparación de equipo y otros oficios que se definan. Las instalaciones requieren herramientas, materiales, trabajadores y tiempo conforme a SR-10.

### 10.7. Servicios cívicos y de seguridad

Se pueden incluir puestos de guardia, instalaciones de entrenamiento, atención médica, depósitos, administración, fuentes de agua, baños, saneamiento, establos y servicios logísticos. Su forma y cantidad dependerán de la población y del nivel tecnológico del reino.

### 10.8. Lugares de creencia y reunión comunitaria

Pueden existir templos, santuarios, altares, capillas y espacios de culto. Su presencia representa las creencias, culturas y organizaciones de los habitantes. Conforme a la decisión cosmológica ya aprobada, la adoración por sí sola no concede bendiciones, poderes ni intervención divina automática. SR-13 desarrollará su dimensión social.

## 11. Morfología urbana y arquitectura

La ciudad debe combinar calles principales y secundarias, plazas, callejones, patios, desniveles, escaleras, puentes, pasajes, entradas de edificios y espacios de servicio. No todos los recorridos deben ser anchos ni rectos.

Se recomienda una arquitectura de fantasía medieval-funcional: piedra, madera, tejas, metal, mampostería, entramados, balcones, aleros, torres secundarias, fachadas comerciales y construcciones de distinta antigüedad. Los edificios importantes deben tener identidad arquitectónica propia; los edificios comunes pueden reutilizar familias de assets con variaciones controladas.

La ciudad debe poder mostrar crecimiento histórico: ampliaciones, reparaciones, edificios antiguos, construcciones nuevas, incendios, reformas y deterioro. No todo se genera como si hubiera sido construido el mismo día.

## 12. El hogar inicial del personaje

### 12.1. Variación entre personajes y mundos

El hogar o punto residencial inicial no tiene que ser idéntico para todos los personajes ni para todos los mundos nuevos. El sistema puede seleccionar, mediante reglas y semilla del mundo, una vivienda, habitación, alojamiento o ubicación inicial entre opciones válidas.

La variación no será una aparición arbitraria en cualquier edificio. Debe respetar disponibilidad, acceso, condiciones económicas o narrativas, capacidad de alojamiento y coherencia con la historia inicial del personaje.

### 12.2. Persistencia

Una vez asignado, el hogar pasa a formar parte del estado persistente del mundo y del personaje. No cambia al cerrar y abrir la aplicación. Una nueva partida o un mundo nuevo puede producir otra asignación.

Si se reinstala la aplicación y no se restaura la partida anterior, se considera una nueva instancia y puede generarse otro hogar inicial. Si se restaura un respaldo de la misma partida, debe recuperarse el hogar original junto con el resto del estado. Así se conserva la idea de variación sin contradecir la continuidad de identidad y persistencia de SR-01.

### 12.3. Función residencial

El hogar debe ser un espacio utilizable, no solo una pantalla de inventario. Puede tener cama o zona de descanso, almacenamiento real, acceso, mobiliario, iluminación y posibilidades de mejora según recursos y reglas futuras. Su contenido no se crea gratuitamente: los objetos tienen procedencia y propiedad conforme a SR-05 y SR-10.

# PARTE IV — MURALLA Y BOSQUE FRONTERIZO

## 13. La muralla

Una gran muralla separa el territorio desarrollado del reino y el bosque exterior. Es un elemento físico visible, transitable solo por accesos válidos y relevante para la silueta del mapa.

La muralla debe tener altura, grosor, materiales, puertas, torres o puestos de vigilancia cuando corresponda. Sus segmentos pueden sufrir deterioro, daños, reparaciones, ocupación o cambios históricos. No debe comportarse como una frontera mágica invulnerable salvo que un mecanismo específico y aprobado lo establezca.

## 14. Puertas y control fronterizo

Los pasos a través de la muralla tienen ubicación y estado. Pueden estar abiertos, cerrados, vigilados, bloqueados o restringidos por circunstancias. El acceso depende de condiciones reales y sociales: horarios, guardias, permisos, amenazas o daños. El sistema político y sus leyes se concretarán en SR-13.

## 15. El bosque exterior

El bosque se sitúa al otro lado de la muralla y constituye una gran región natural. Su existencia y su continuidad geográfica deben quedar representadas desde el diseño del mundo, aunque su extensión completa no forme parte del contenido jugable detallado inicial.

En la primera versión se recomienda:

- representar visualmente la masa forestal y su escala más allá de la muralla;
- permitir vistas, sonidos y señales ambientales coherentes desde el lado del reino;
- desarrollar solo la franja próxima a la frontera cuando sea necesaria para una escena o sistema concreto;
- reservar el bosque profundo, sus asentamientos, rutas, especies y regiones para una expansión posterior;
- evitar que el límite de contenido se presente como una teleportación o una geografía contradictoria.

La flora, fauna, clima, recursos, poblaciones y peligros del bosque se desarrollarán con SR-08 y catálogos ecológicos. No se asumirán especies, monstruos o recursos solo por estar representados visualmente.

# PARTE V — TORRE MONUMENTAL Y MAZMORRA

## 16. Torre de acceso

La entrada a la Mazmorra se presenta mediante una torre gigantesca, monumental y dominante, inspirada en la escala visual de una torre como Babel en la ficción de fantasía. Debe ser uno de los hitos más reconocibles del reino y tener una presencia arquitectónica capaz de orientar al jugador desde distintos puntos de la ciudad.

La torre puede contener vestíbulos, accesos, espacios de control, rutas de entrada y servicios relacionados con las expediciones. Su distribución exterior debe ser coherente con su estructura visible, salvo en el punto en que comienza el fenómeno espacial que da acceso a la Mazmorra.

## 17. Diferencia entre exterior e interior

**DECISIÓN DE DISEÑO INCORPORADA:** las dimensiones interiores de la Mazmorra no tienen por qué corresponderse con las dimensiones físicas exteriores de la torre. La torre puede parecer relativamente limitada por fuera y contener en su interior pisos, regiones, cámaras y distancias enormemente superiores.

Esta discrepancia es una propiedad espacial objetiva del mundo. No debe resolverse fingiendo que todos los pisos caben dentro del volumen exterior mediante una escala visual engañosa. Tampoco se debe atribuir automáticamente a una deidad o a una explicación cosmológica no aprobada. El mecanismo último puede reservarse para un desarrollo posterior, siempre que la existencia observable de la discrepancia se mantenga consistente.

## 18. Pisos como unidades espaciales

Cada piso es una unidad espacial con identidad propia. Puede contener múltiples salas, corredores, desniveles, rutas alternativas, zonas ambientales, obstáculos y conexiones. No todos los pisos requieren la misma topología ni el mismo tamaño.

Los pisos pueden estar conectados por escaleras, rampas, pozos, galerías, ascensores, mecanismos, pasajes o transiciones especiales. Cada transición debe describir qué permite atravesarla, sus requisitos y sus riesgos. No habrá cambios de piso mediante teletransporte arbitrario por conveniencia del juego.

La transición entre pisos debe conservar ubicación, orientación, estado, tiempo y consecuencias relevantes. Un grupo que desciende, una criatura que asciende o una ruta que se bloquea generan cambios persistentes cuando corresponda.

## 19. Bloques de bioma y pisos individuales

Conforme a SR-08, varios pisos pueden pertenecer a una misma familia de bioma. Como ejemplo de organización posible, los pisos 1–5 podrían formar un primer bloque, los pisos 6–8 otro y los pisos 9–15 otro. Estos intervalos son referencias conceptuales, no una distribución definitiva.

Pertenecer al mismo bloque no convierte dos pisos en copias. Cada piso debe conservar diferencias propias en:

- geometría y topología;
- cantidad, proporción y disposición de salas y corredores;
- alturas, desniveles y conexiones;
- condiciones ambientales;
- composición y distribución de especies;
- densidad y comportamiento de poblaciones;
- recursos, minerales, agua, vegetación y materiales;
- rutas migratorias, refugios, zonas de alimentación y reproducción;
- peligros, anomalías y fenómenos;
- individuos excepcionales, guardianes o zonas singulares cuando existan.

La familia de bioma define un parentesco ambiental, no un plano repetido ni una lista fija de enemigos idéntica en cada piso.

## 20. Identidad espacial y variedad de salas

Cada sala debe tener una identidad reconocible mediante varios atributos combinados: forma, proporciones, volumen, altura, suelo, paredes, techo, visibilidad, iluminación, materiales, elementos arquitectónicos, depósitos naturales, accesos, obstáculos, acústica, humedad, temperatura, historia y función ecológica.

La repetición de una plantilla geométrica puede utilizarse como herramienta de producción, pero no debe hacer que todas las salas parezcan una misma cámara con decoración intercambiada. Se permiten familias modulares, siempre que existan variaciones significativas y una composición espacial coherente.

## 21. Zona segura

Cada piso puede disponer de una zona segura pequeña en relación con la extensión total del piso. Su característica es que los monstruos no aparecen allí por generación espontánea normal y no la utilizan como área habitual de aparición o patrullaje.

La zona no constituye una barrera absoluta ni una burbuja invulnerable. Un monstruo puede entrar si existe una causa válida, por ejemplo:

- perseguir a una entidad que entra en la zona;
- huir de una amenaza o de otro monstruo;
- migrar o desplazarse por una ruta que atraviesa el área;
- ser conducido, atraído o arrastrado hacia ella;
- aprovechar una abertura, ruta o conexión que permita el acceso;
- producirse una alteración del entorno que cambie su accesibilidad.

La causa, el recorrido y el acontecimiento deben registrarse. Un monstruo no debe aparecer dentro de la zona únicamente para sorprender al jugador sin una procedencia espacial válida. La política no prohíbe que un jugador sea atacado allí; define cómo y por qué puede ocurrir.

La zona segura tampoco debe garantizar descanso, anonimato, invulnerabilidad ambiental o ausencia de conflictos entre entidades inteligentes. Esas condiciones dependen del lugar y de los sistemas correspondientes.

## 22. Combate y uso táctico del terreno

Toda zona de la Mazmorra donde exista espacio suficiente puede convertirse en campo de batalla. Esto incluye salas grandes, galerías, escaleras, pasillos estrechos, desniveles, puentes, cruces y zonas de conexión.

El entorno influye en el combate de acuerdo con SR-07 y SR-09:

- un corredor estrecho limita la cantidad de combatientes que pueden luchar en paralelo;
- las criaturas grandes pueden quedar bloqueadas o tener dificultades para girar;
- las armas largas pueden resultar incómodas en espacios reducidos;
- la altura, cobertura y visibilidad afectan a la detección y la línea de ataque;
- una caída, derrumbe, superficie resbaladiza o zona inundada puede alterar el combate;
- el sonido puede atraer o alertar a entidades según sus capacidades;
- las rutas de retirada y flanqueo dependen de conexiones realmente existentes.

No se ampliará una sala ni se eliminará una pared de forma invisible para permitir una animación o una formación de combate. Las acciones se adaptan al espacio disponible.

## 23. Recompensas y contenido ambiental

La Mazmorra no dependerá de cofres, cajas, barriles rompibles o contenedores colocados como fuente principal de recompensas. Conforme a SR-10, el botín principal procederá de cristales y materiales obtenidos de los monstruos, más otras recompensas causales como descubrimientos, información, rutas, rescates, reputación o acceso.

La presencia de restos mineros, herramientas abandonadas, pilares, ruinas, minerales visibles, marcas, estructuras derruidas y otros elementos ambientales está permitida. No deben transformarse automáticamente en cofres de recompensa ni generar objetos sin procedencia.

Los minerales expuestos forman parte de la geología del lugar. Su extracción requiere que exista un depósito real y respeta herramientas, capacidades, tiempo, riesgos y reglas económicas de SR-10.

# PARTE VI — DISEÑO DE REFERENCIA DEL PISO 1

## 24. Identidad general

**DECISIÓN DE DISEÑO INCORPORADA:** el piso 1 tendrá una identidad predominantemente minera y subterránea, con paredes rocosas, galerías excavadas, zonas de mineral visible y ruinas antiguas integradas en el entorno. Debe transmitir que el lugar tiene una historia anterior a la llegada del aventurero actual.

Los pilares, arcos o estructuras antiguas pueden aparecer parcialmente enterrados, fracturados, erosionados o incorporados a la roca. No deben parecer decoración colocada de forma aleatoria. Su distribución debe sugerir una arquitectura o función previa, aunque su origen histórico completo quede reservado.

## 25. Cantidad mínima y variedad

El primer piso debe contar con **al menos 12 salas o cámaras diferenciables**. Este mínimo no incluye cada tramo de corredor como una sala independiente. Las salas deben presentar variaciones notables de proporción, forma, altura, anchura, iluminación, depósitos minerales, ruinas y conexiones.

La distribución debe mezclar:

- corredores estrechos y largos;
- galerías anchas y relativamente cortas;
- cámaras amplias con pilares;
- salas de techo bajo;
- espacios con diferencias de altura;
- bifurcaciones y cruces;
- pasajes de conexión con visibilidad limitada;
- cámaras con minerales claramente visibles;
- zonas con agua, humedad, grietas o derrumbes cuando el diseño ambiental lo justifique.

Los corredores no deben compartir todos la misma anchura ni longitud. Las dimensiones deben afectar de verdad al tránsito, la navegación, la visibilidad y el combate.

## 26. Catálogo mínimo de salas de referencia

La siguiente lista es una propuesta de composición inicial para garantizar diversidad. Los nombres son etiquetas funcionales de diseño, no nombres propios del mundo.

| N.º | Tipo de sala | Rasgo espacial dominante | Elementos distintivos posibles |
|---:|---|---|---|
| 1 | Umbral de descenso | Cámara de transición y orientación | Entrada, roca tallada, primer cambio de iluminación |
| 2 | Galería de extracción | Espacio largo y relativamente estrecho | Marcas de herramientas, vetas minerales expuestas |
| 3 | Cámara de pilares antiguos | Volumen amplio y alto | Pilares erosionados, fragmentos de arcos y suelo irregular |
| 4 | Cruce de galerías | Intersección de varias rutas | Bifurcaciones, líneas de visión parciales |
| 5 | Veta mineral | Cámara mediana con paredes ricas en depósitos | Minerales visibles, salientes y zonas de extracción peligrosa |
| 6 | Corredor de compresión | Pasaje angosto con altura limitada | Cuellos de botella, giros, poca capacidad de paso |
| 7 | Sala de fractura | Espacio dividido por grieta o desnivel | Bordes, pasos estrechos y riesgo de caída |
| 8 | Galería inundada o húmeda | Cámara o corredor con agua localizada | Superficie resbaladiza, humedad, reflejos y drenaje |
| 9 | Cámara de ruinas enterradas | Espacio donde la arquitectura antigua domina | Muros parcialmente cubiertos por roca y restos estructurales |
| 10 | Cavidad de techo elevado | Sala amplia con gran altura vertical | Paredes escarpadas, formaciones rocosas y ecos |
| 11 | Excavación colapsada | Cámara irregular parcialmente obstruida | Derrumbes, rutas bloqueadas y alternativas estrechas |
| 12 | Refugio de la zona segura | Espacio pequeño, resguardado y reconocible | Accesos controlables, lugar de pausa sin invulnerabilidad absoluta |

Se pueden añadir salas adicionales, cámaras secretas, pasos secundarios, conexiones verticales y subzonas sin reducir el mínimo de doce espacios diferenciados.

## 27. Conectividad del piso 1

La estructura debe tener una ruta principal comprensible, desvíos opcionales, al menos una bifurcación relevante y conexiones que permitan orientarse y tomar decisiones. Se recomienda incorporar uno o más circuitos alternativos para que el piso no sea un único pasillo lineal.

La zona segura debe estar dentro del sistema espacial del piso, conectada por una ruta real y no simplemente superpuesta como una instancia aparte. Su ubicación exacta y cercanía a la entrada quedan pendientes de definir en el plano final.

Un plano de producción posterior debe incluir:

- ID único de cada sala y corredor;
- contorno y elevación;
- puertas, pasos, escaleras y conexiones;
- rutas principales y secundarias;
- obstáculos y zonas de riesgo;
- puntos de referencia visual;
- depósitos minerales;
- hábitats, refugios y relaciones ecológicas;
- zona segura y sus posibles entradas;
- puntos de transición al piso superior o inferior.

## 28. Ruinas y antigüedad

Las ruinas son parte de la identidad del piso, no un decorado que debe explicarse por completo desde el primer momento. Se pueden mostrar cimientos, pilares, arcos, relieves erosionados, cortes de piedra, superficies pulidas y estructuras cuya función no sea evidente.

El sistema no debe afirmar una historia concreta que todavía no haya sido aprobada. Los personajes pueden formular hipótesis distintas a partir de sus conocimientos. Los descubrimientos se convierten en hechos conocidos por cada entidad según evidencias, investigación y comunicación, de acuerdo con SR-01 y SR-04.

# PARTE VII — MUNDO VIVO, INFORMACIÓN Y PERSISTENCIA ESPACIAL

## 29. Ocupación de lugares

Un lugar puede tener propietarios, ocupantes, visitantes, responsables, trabajadores, habitantes temporales o presencia de criaturas. La ocupación no se confunde con la propiedad. Un NPC puede trabajar en un local sin ser dueño; un viajero puede alojarse en una posada sin adquirirla.

La ubicación de una entidad debe ser compatible con el acceso y el tiempo transcurrido. El mundo no debe mover agentes entre lugares sin recorrido, capacidad o mecanismo válido.

## 30. Cambios físicos y memoria del lugar

Los espacios pueden cambiar por desgaste, construcción, reparación, incendio, derrumbe, inundación, erosión, excavación, acumulación, limpieza, ocupación, conflicto o actividad ecológica. Los cambios relevantes deben conservar causa y persistencia.

No todos los cambios visuales necesitan registro histórico individual. SR-06 puede agrupar procesos repetitivos, pero debe preservar el estado final y los acontecimientos cuya consecuencia importe. Una puerta destruida, un puente caído, una ruta bloqueada o una sala inundada deben seguir existiendo en ese estado al regresar el jugador, salvo que haya ocurrido una reparación o transformación válida.

## 31. Mapas, cartografía y descubrimiento

El mapa de interfaz representa información disponible, no omnisciencia automática. Debe distinguir:

- espacio conocido y recorrido;
- espacio observado a distancia;
- espacio descrito por terceros;
- espacio inferido o estimado;
- espacio desconocido;
- rutas confirmadas y rutas inciertas;
- puertas, pasos o conexiones cuyo estado se desconoce.

Un mapa comprado, recibido o encontrado tiene origen, autoría y calidad. Puede estar incompleto, anticuado, sesgado o equivocado. La cartografía puede mejorar con exploración y verificación.

Los NPC también pueden poseer mapas y conocimientos diferentes. No comparten automáticamente lo que el jugador descubre. La información se transmite por observación, conversación, documentos, señales o mecanismos definidos.

## 32. Tiempo de viaje y simulación fuera de pantalla

Los tiempos de desplazamiento dependen de distancia, velocidad, terreno, pendientes, carga, lesiones, clima, tráfico, medio de transporte, obstáculos y decisiones. Un viaje no se resuelve solo por cambiar un marcador de mapa.

Las regiones no renderizadas siguen teniendo estado. La simulación puede usar niveles de resolución distintos según distancia, riesgo y relevancia, conforme a SR-06. Cambiar de detalle no debe borrar las consecuencias causales: una ruta puede quedar bloqueada, una población puede migrar, una estructura puede deteriorarse y un lugar puede cambiar de ocupación aunque el jugador no esté allí.

## 33. Observabilidad y rendimiento

La cámara isométrica 2.5D es una decisión de presentación, no una simplificación de la geometría lógica. El mundo se construye con escenas y modelos 3D. Se pueden utilizar carga por sectores, niveles de detalle, visibilidad, instanciación de elementos repetidos y simulación agregada fuera de pantalla.

La carga de sectores no debe crear límites ficticios para los habitantes ni hacer que una entidad desaparezca del mundo por quedar fuera de cámara. La representación puede descargarse; el estado lógico permanece.

Las dimensiones máximas, densidad de agentes, tamaño de sector, frecuencia de actualización, memoria y presupuesto gráfico se cerrarán mediante pruebas reales en Android y SR-15. No se fijan aquí como leyes geográficas.

# PARTE VIII — CONTRATOS ESPACIALES Y VALIDACIÓN

## 34. Datos mínimos de un lugar

Toda entidad espacial relevante debe poder representar, según corresponda:

- identificador estable y tipo de lugar;
- nombre conocido, nombres alternativos y estado de descubrimiento;
- ubicación, orientación, límites y marco de coordenadas;
- región o estructura superior a la que pertenece;
- dimensiones, volumen y niveles de altura;
- materiales y características ambientales;
- accesos, conexiones y restricciones;
- transitabilidad por categorías de tamaño/capacidad;
- ocupantes, propietarios y responsables cuando existan;
- bioma, hábitat y relaciones ecológicas si aplican;
- estado físico, daños, modificaciones y mantenimiento;
- historia y eventos relevantes;
- visibilidad, conocimiento y procedencia de la información;
- nivel de resolución de simulación actual.

No todos los lugares necesitan todos los campos. El sistema declara qué atributos aplican y cuáles no.

## 35. Datos mínimos de una conexión

Una conexión debe poder representar su identificador, origen, destino, tipo, geometría, dirección, dimensiones, altura libre, estado, requisitos, capacidad, tiempo de recorrido estimado, peligros, bloqueo y causa de cambios. La conexión no equivale a una orden de teletransporte.

## 36. Validaciones obligatorias

Antes de confirmar una operación espacial persistente se valida:

1. que el origen y destino existan;
2. que la conexión esté disponible y en el estado declarado;
3. que la entidad pueda atravesarla por tamaño, movilidad, anatomía y estado;
4. que existan tiempo y recorrido compatibles;
5. que no haya obstáculos, puertas cerradas o bloqueos ignorados;
6. que la operación no duplique una entidad ni cree ubicaciones incompatibles;
7. que los cambios físicos tengan mecanismo, recursos y consecuencias;
8. que la actualización conserve causalidad y procedencia;
9. que los cambios de conocimiento no se confundan con cambios del mundo objetivo.

# PARTE IX — DECISIONES RESERVADAS Y CALIBRACIÓN

## 37. Decisiones que no se cierran en SR-11 v0.1

Quedan reservados para anexos, catálogos o documentos posteriores:

- nombre oficial del mundo, reino, ciudad, torre, muralla, bosque y barrios; estos nombres deberán seguir la guía de nomenclatura del proyecto y evitar etiquetas genéricas o fantasía intercambiable;
- forma definitiva, orientación, coordenadas y plano completo de la región;
- dimensiones finales de ciudad, muralla, torre, pisos y salas;
- número total de pisos de la Mazmorra;
- distribución exacta de los bloques de bioma y sus límites;
- plano definitivo y conexiones de los pisos 1–5;
- población, especies, densidad y distribución de monstruos por piso;
- ubicación exacta de guardianes, jefes y zonas especiales;
- historia, función original y explicación final de las ruinas;
- mecanismo último de la discrepancia entre el exterior de la torre y el interior de la Mazmorra;
- legislación, guardias, permisos y organización política de la ciudad;
- nombres y diseño de los edificios y establecimientos concretos;
- reglas detalladas para alquiler, propiedad residencial y asignación del hogar;
- dimensión completa del bosque y regiones exteriores;
- parámetros finales de navegación y rendimiento Android.

Los puntos reservados no autorizan a contradecir las decisiones ya fijadas: continuidad espacial; ciudad funcional de fantasía; hogar inicial variable entre personajes o mundos nuevos; muralla entre reino y bosque; torre de acceso monumental; interior de Mazmorra mucho mayor que su exterior; pisos individualizados; zona segura no inviolable; primer piso minero con ruinas y un mínimo de doce salas distintas; y combate posible en todo espacio físicamente válido.

## 38. Calibraciones de prueba

Las dimensiones propuestas en §6.3, los tiempos de viaje, la capacidad de paso, las distancias de visión, la densidad de edificios, el tamaño de los sectores y las dimensiones de los corredores deberán calibrarse con pruebas de navegación, combate, cámara, población, simulación y rendimiento.

La calibración puede ajustar cifras sin alterar los principios. Cambiar la continuidad del mundo, la existencia objetiva de lugares, la estructura conceptual de la torre, la política de la zona segura o el mínimo de salas del piso 1 requeriría una revisión normativa y aprobación expresa.

# PARTE X — PRUEBAS OBLIGATORIAS

## 39. Escenarios de verificación

1. Un lugar conocido sigue existiendo aunque quede fuera de cámara.
2. Un NPC llega a un edificio usando una ruta transitable y tarda un tiempo compatible con la distancia.
3. Un corredor demasiado estrecho impide o limita el paso de una criatura de gran tamaño.
4. Una entidad herida no puede ejecutar una ruta que su condición física ya no permite.
5. Una puerta cerrada bloquea el tránsito hasta que exista una acción válida para abrirla o atravesarla.
6. Una conexión dañada cambia la navegación y persiste al reabrir el mundo.
7. La ciudad contiene gremio, vivienda, tabernas, comercio, talleres y servicios conectados espacialmente.
8. Los establecimientos tienen entradas, interiores y relaciones con calles y rutas de abastecimiento.
9. Un nuevo personaje o mundo puede recibir un hogar inicial distinto mediante una regla válida.
10. Reabrir la misma partida conserva el hogar asignado.
11. Restaurar un respaldo conserva la identidad espacial del mundo original.
12. La muralla separa el territorio del reino y el bosque exterior de forma físicamente comprensible.
13. El bosque puede representarse sin exigir que toda su extensión sea jugable en la primera versión.
14. La torre es reconocible desde distintos puntos de la ciudad y contiene un acceso espacial consistente.
15. El tamaño interior de la Mazmorra puede exceder el volumen exterior de la torre sin que los pisos se reduzcan a decorados falsos.
16. Dos pisos del mismo bloque de bioma presentan diferencias espaciales y ecológicas reales.
17. La zona segura no genera monstruos de forma espontánea normal.
18. Un monstruo puede entrar en la zona segura cuando se registra una causa y una ruta válidas.
19. El piso 1 contiene al menos doce salas diferenciables con paredes rocosas, minerales visibles y elementos de ruinas antiguas.
20. Las galerías del piso 1 varían en longitud, anchura, altura y geometría.
21. Un combate puede desarrollarse en un corredor estrecho sin ampliar artificialmente el espacio.
22. La anchura y la cobertura del terreno alteran el número de combatientes y las opciones tácticas.
23. Un mapa diferencia lugares explorados, observados, descritos, inferidos y desconocidos.
24. Un mapa antiguo o erróneo puede ser corregido mediante exploración y evidencia.
25. La región no renderizada continúa simulándose en una resolución apropiada.
26. Una ruta o estructura cambia durante la ausencia del jugador y el cambio persiste al regresar.
27. Los minerales visibles no generan inventario automático: su extracción exige un depósito real y una acción válida.
28. La Mazmorra no entrega botín principal mediante cofres, cajas o contenedores colocados arbitrariamente.
29. La transición entre pisos conserva posición, tiempo, orientación y consecuencias pertinentes.
30. Descargar un sector gráfico no elimina ni teletransporta las entidades lógicas que lo ocupan.

## 40. Criterios de cierre

SR-11 estará listo para considerarse normativamente completo cuando:

- exista un modelo espacial jerárquico con identidad y continuidad;
- la región inicial esté definida en plano y escala calibrada;
- ciudad, hogar, gremio, comercio, servicios, muralla y accesos tengan conexiones coherentes;
- la frontera entre reino y bosque esté espacialmente resuelta;
- la torre y la discrepancia entre interior y exterior estén integradas;
- la Mazmorra tenga una estructura de pisos y conexiones verificable;
- los bloques de bioma respeten SR-08;
- el piso 1 tenga al menos doce salas diferenciadas y una topología definida;
- la zona segura y sus excepciones funcionen por causalidad;
- la navegación y el combate respeten geometría y capacidades;
- conocimiento, mapa, simulación fuera de pantalla y persistencia espacial sean coherentes;
- las pruebas de esta norma puedan ejecutarse sin contradicciones con SR-01 a SR-10.

---

# DECLARACIÓN NORMATIVA

El espacio de este universo no es un decorado subordinado al jugador. Cada región, ciudad, edificio, camino, cámara, corredor y piso existe con ubicación, dimensiones, conexiones, condiciones e historia. La región inicial se articula alrededor de una ciudad de fantasía funcional, una muralla que marca la frontera del reino y una torre monumental que contiene una Mazmorra cuya extensión interior no está limitada por la silueta exterior. Sus pisos pertenecen a familias ecológicas sin perder su identidad individual. El primer piso presenta una geografía minera y antigua con al menos doce salas distintas, rutas de anchura y longitud variables, minerales visibles y ruinas integradas en la roca. La zona segura reduce la aparición habitual de monstruos, pero no anula las causas que podrían permitir una intrusión. Cualquier espacio físicamente válido puede albergar movimiento, vida, actividad y combate.

**SR-11 v0.1 — NORMATIVA OFICIAL APROBADA.**

---

# ANEXO EDITORIAL — IDENTIDAD Y NOMENCLATURA DEL UNIVERSO

Este anexo registra una directriz de estilo aprobada para el desarrollo de nombres propios. No fija todavía nombres geográficos concretos ni sustituye los catálogos culturales y lingüísticos que se desarrollarán después.

1. **Originalidad reconocible:** los nombres propios deben tener identidad y no parecer etiquetas genéricas de fantasía ni combinaciones aleatorias de sílabas.
2. **Coherencia sonora:** los nombres de una misma cultura, región o tradición pueden compartir patrones fonéticos y ortográficos; culturas distintas pueden tener familias sonoras diferenciadas.
3. **Pronunciación natural:** deben poder leerse y pronunciarse razonablemente en español, salvo que exista una razón cultural o lingüística deliberada para una pronunciación particular.
4. **Memorabilidad:** se priorizarán nombres distinguibles entre sí. No se crearán muchos topónimos que solo cambien una letra o una terminación.
5. **Adecuación:** el nombre debe corresponder al carácter del lugar, pueblo, individuo, institución o fenómeno, sin depender de clichés como «Oscuro», «Sangriento», «del Rey» o «Antiguo» como solución automática.
6. **Diversidad controlada:** no todos los nombres tienen que sonar élficos, solemnes o arcanos. La variedad debe reflejar pueblos, lenguas, historia, geografía y clases sociales diferentes.
7. **Etimología opcional, no forzada:** un nombre puede tener origen, evolución histórica y significado cultural, pero no es obligatorio inventar una explicación artificial para cada palabra.
8. **Separación entre lenguas:** el nombre de una lengua, su escritura, sus reglas y sus nombres derivados deben mantenerse coherentes. No se cambiará un término ya aprobado por semejanza estética sin una revisión explícita.
9. **Control de colisiones:** antes de canonizar nombres importantes se comprobará que no se confundan con otros términos del propio universo ni con nombres notorios de franquicias conocidas.
10. **Canon controlado:** los nombres sugeridos durante la lluvia de ideas no se vuelven canónicos hasta que sean seleccionados para el catálogo correspondiente.

**Referencia estética solicitada por el autor:** «Varyath». Se utilizará como muestra de la clase de sonoridad y personalidad que desea para futuros nombres: breve, distintiva, fantástica sin resultar genérica y con una grafía reconocible. Esta referencia no autoriza a renombrar automáticamente «Veyrath», denominación de la lengua arcana registrada en el Anexo A aprobado. Si el autor pretendía que «Varyath» sustituyera ese nombre concreto, se tramitará como corrección nominal explícita; hasta entonces se conservan separados.

Esta directriz se aplicará a futuros topónimos, pueblos, culturas, linajes, personajes, instituciones, objetos singulares, fenómenos y conceptos.

# SR-10 — ECONOMÍA, COMERCIO, RECURSOS, BOTÍN Y FABRICACIÓN

**Código:** SR-10  
**Versión:** 0.1 — edición oficial aprobada  
**Estado:** NORMATIVA OFICIAL — APROBADA EXPRESAMENTE POR EL AUTOR EL 2026-11-20.  
**Fecha:** 2026-11-20  
**Dependencias:** SR-01 a SR-09, especialmente SR-02, SR-04, SR-05, SR-06, SR-07, SR-08 y SR-09.  
**Ámbito:** economía autónoma, propiedad, moneda, intercambio, mercados, gremios, recompensas, cristales de monstruos, materiales, extracción, fabricación, reparación, servicios, salarios, impuestos, escasez y persistencia económica.

---

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Oficial aprobada | Primera especificación integral de economía y producción. |

> **Convención:** DEBE y NO DEBE expresan reglas obligatorias si se aprueba el documento. PUEDE expresa una posibilidad. CALIBRACIÓN identifica valores numéricos ajustables. RESERVADO identifica catálogos que se desarrollarán después.

# PARTE I — PROPÓSITO Y PRINCIPIOS

## 1. Propósito

SR-10 establece cómo se producen, obtienen, transforman, valoran, intercambian, consumen, almacenan y pierden los recursos del mundo. La economía debe existir como sistema autónomo: NPC, familias, aventureros, comerciantes, artesanos, organizaciones y autoridades toman decisiones económicas incluso cuando el jugador no está presente.

La economía no será una tienda de menús aislada del mundo. Los bienes tienen existencia, procedencia, ubicación, propietario, estado y disponibilidad. Los precios y la oferta deben surgir de recursos, producción, demanda, transporte, riesgo, escasez, competencia, información y decisiones.

## 2. Principios obligatorios propuestos

1. **Economía causal:** no se crea riqueza, inventario ni mercancía sin fuente, producción, transferencia o mecanismo definido.
2. **Mundo autónomo:** la actividad económica continúa sin jugador y durante el tiempo de ausencia.
3. **Propiedad coherente:** un objeto individual no puede venderse dos veces ni pertenecer simultáneamente a propietarios incompatibles.
4. **Escasez real:** comerciantes y talleres no tienen inventario infinito por defecto.
5. **Valor contextual:** el precio depende del bien, calidad, condición, ubicación, oferta, demanda, riesgo e información disponible.
6. **Trazabilidad:** bienes relevantes conservan origen, transformaciones y transferencias.
7. **Recompensa orgánica:** la Mazmorra recompensa principalmente mediante cristales y materiales obtenidos de monstruos; no mediante cofres o cajas rompibles.
8. **Producción con coste:** fabricar, reparar, transportar, investigar y comerciar requiere tiempo, capacidades, instalaciones y recursos.
9. **Sin automatismos de clase:** ser herrero, comerciante o aventurero no crea automáticamente bienes, conocimientos ni ingresos.
10. **Integridad contable:** toda transacción confirmada debe cuadrar en bienes, moneda, deuda o servicio prestado.

## 3. Autoridad y límites

SR-10 desarrolla las reglas económicas de SR-01 y utiliza los contratos de comandos, validación, transacciones y eventos de SR-02. Respeta la realidad y persistencia de SR-04; los objetos, materiales, calidad, propiedad y genealogía de SR-05; la simulación temporal de SR-06; la materia, energía y costes de SR-07; la biología y extracción de SR-08; y las consecuencias de combate y botín de SR-09.

SR-10 no define por sí mismo la geografía final, la lista completa de especies, el catálogo definitivo de materiales, el sistema de niveles ni la estructura final de clases. Esos elementos se vincularán mediante fichas subordinadas.

# PARTE II — UNIDADES DE VALOR Y MEDIOS DE INTERCAMBIO

## 4. Unidad de cuenta

Se propone una moneda de uso general aceptada en el reino y sus rutas comerciales. Su nombre canónico queda **reservado** para el documento de cultura e instituciones; para las pruebas se utilizará la denominación neutral **unidad monetaria (UM)**.

La UM permite comparar bienes, salarios, servicios, recompensas y obligaciones. No implica que todas las regiones, pueblos o culturas acepten la misma moneda ni que el trueque desaparezca.

### 4.1. Denominaciones de prueba

Para simplificar la interfaz y las cuentas se propone una estructura decimal:

- 1 moneda de oro (MO) = 100 monedas de plata (MP).
- 1 MP = 100 monedas de cobre (MC).
- 1 MO = 10.000 MC.

> **Nota de nomenclatura aprobada:** MC, MP y MO son abreviaturas heredadas de trabajo, no nombres canónicos definitivos. El autor indicó que desea sustituirlas por una nomenclatura más original en una revisión posterior. Hasta entonces, la interfaz y el contenido narrativo deben usar una etiqueta neutral (UM/unidad monetaria) y no fijar esas abreviaturas como identidad del mundo. La relación de conversión es un parámetro de referencia sujeto a calibración.

Los nombres y la proporción son parámetros de diseño sujetos a aprobación; la economía lógica debe poder admitir monedas regionales y tipos de cambio sin rehacer el sistema.

### 4.2. Moneda física y saldo

El dinero puede existir como:
- monedas físicas transportables;
- depósitos o saldos custodiados por una institución;
- obligaciones documentadas, pagarés o crédito cuando la sociedad lo permita.

El dinero físico puede perderse, robarse, transportarse o almacenarse. Un saldo institucional depende de la solvencia, legitimidad y continuidad de quien lo custodia. No se presume una banca moderna universal.

## 5. Valor, precio y equivalencia

El valor no es una propiedad absoluta que obligue a todos a pagar lo mismo. SR-10 distingue:

- **Valor material:** utilidad y propiedades físicas, químicas o arcanas.
- **Valor funcional:** utilidad para una tarea o necesidad.
- **Valor de mercado:** precio al que compradores y vendedores están dispuestos a intercambiar en condiciones concretas.
- **Valor sentimental, histórico o simbólico:** relevancia individual o cultural que no tiene por qué traducirse en precio.
- **Precio anunciado:** oferta de un vendedor.
- **Precio de transacción:** cantidad realmente aceptada y pagada.

La interfaz puede mostrar una estimación, pero no debe presentarla como precio universal garantizado.

# PARTE III — ECONOMÍA AUTÓNOMA Y MERCADOS

## 6. Actores económicos

El sistema debe poder representar, según corresponda:

- individuos y hogares;
- aventureros y grupos de expedición;
- comerciantes ambulantes y establecimientos;
- artesanos, talleres y manufacturas;
- agricultores, ganaderos, recolectores y mineros;
- transportistas, guías y proveedores;
- gremios y asociaciones;
- instituciones religiosas, educativas o asistenciales;
- autoridades, recaudadores y tesorerías;
- organizaciones y empresas de distinta escala.

Cada actor tendrá recursos, necesidades, capacidades, objetivos, restricciones y conocimientos acordes con su naturaleza y situación. No todos necesitan una contabilidad individual al mismo nivel de detalle.

## 7. Oferta, demanda y formación de precios

Los precios pueden responder a:
- cantidad disponible y ritmo de reposición;
- cantidad de compradores y urgencia de sus necesidades;
- calidad, condición, rareza y procedencia;
- distancia, transporte, peajes y riesgo;
- estación, clima, conflictos y rutas interrumpidas;
- competencia entre vendedores;
- información, reputación, confianza y negociación;
- costes de producción, almacenamiento y oportunidad.

### 7.1. Límites contra oscilaciones absurdas

Los precios no deben multiplicarse o colapsar por una sola transacción insignificante. El sistema utilizará reservas, ventanas de observación, elasticidad, inventario relativo y límites de ajuste por periodo.

La escasez extrema puede generar precios muy altos, racionamiento, sustitución, mercado negro o ausencia de oferta; no obliga a que siempre aparezca un vendedor.

### 7.2. Inventario de comerciantes

Los comerciantes venden lo que poseen, lo que pueden conseguir o lo que tienen comprometido mediante proveedores. Una tienda puede:
- quedarse sin existencias;
- comprar bienes a clientes;
- encargar mercancía;
- cambiar sus precios;
- cerrar temporalmente;
- quebrar;
- trasladarse;
- contratar personal;
- sufrir robo, pérdida o interrupción de suministro.

El inventario mostrado debe corresponder con el inventario real y sus reservas. No se regenerará por abrir y cerrar una interfaz.

## 8. Mercados y espacios comerciales

Los mercados son lugares físicos o redes de intercambio. La ciudad inicial puede disponer de mercado general, tiendas especializadas, talleres, puestos temporales y servicios del gremio.

El comercio presencial requiere encuentro, acceso, tiempo y transferencia válida. Los encargos a distancia requieren mensajeros, contratos, rutas o mecanismos institucionales disponibles. No se presupone una casa de subastas mágica global.

## 9. Negociación, reputación y fraude

El precio final puede depender de negociación, confianza, reputación, urgencia, conocimiento, idioma, relaciones y poder de mercado.

Pueden existir engaños, falsificaciones, peso incorrecto, mercancía defectuosa, robo, contrabando y estafas si hay actores, motivos y oportunidades. El sistema debe distinguir:
- hecho objetivo;
- conocimiento del comprador;
- sospecha;
- denuncia;
- investigación;
- resolución.

Una interfaz puede advertir de riesgos conocidos, pero no revelar automáticamente todo fraude que el personaje no pueda detectar.

# PARTE IV — PROPIEDAD, INVENTARIO Y TRANSACCIONES

## 10. Propiedad y posesión

Se distinguen:
- **propietario:** entidad con derecho reconocido sobre el bien;
- **poseedor:** quien lo tiene físicamente o controla su acceso;
- **custodio:** quien lo guarda por encargo;
- **vendedor:** quien ofrece el bien y debe tener autoridad para transferirlo;
- **titular de derecho:** quien posee una reclamación, contrato o gravamen.

La posesión no demuestra por sí sola propiedad legítima. Los objetos abandonados, perdidos, robados, heredados o disputados requieren reglas sociales y jurídicas que se desarrollarán con SR-13.

## 11. Inventarios y almacenamiento

Cada objeto relevante puede registrar:
- identificador y tipo;
- cantidad o unidades;
- propietario y poseedor;
- ubicación y contenedor;
- masa, volumen y requisitos de transporte;
- condición, integridad y durabilidad cuando aplique;
- calidad, composición y propiedades;
- procedencia y cadena de transformaciones;
- restricciones, contaminación, deterioro o peligros;
- estado de reserva, venta, préstamo o compromiso.

Los límites de carga deben derivarse de capacidades, equipo, volumen, masa y condiciones. La interfaz puede resumirlos, pero el modelo no debe permitir transportar cantidades físicamente imposibles.

Almacenes, viviendas, puestos y talleres tienen capacidad, seguridad, acceso, costes y riesgo. Un objeto almacenado no está disponible para otra persona sin autorización o mecanismo válido.

## 12. Transacciones atómicas

Toda compra, venta, intercambio, pago, préstamo, depósito, retiro o contratación debe validarse y ejecutarse como operación atómica:
1. comprobar identidad y autoridad;
2. comprobar propiedad y disponibilidad;
3. bloquear o reservar temporalmente bienes y fondos;
4. verificar cantidades, precios, impuestos y condiciones;
5. transferir simultáneamente lo pactado;
6. registrar el evento;
7. liberar reservas y actualizar inventarios.

Si falla una precondición, la transacción no puede dejar una transferencia parcial no prevista. Los intentos fallidos pueden generar consecuencias sociales o económicas, pero no se contabilizan como operaciones confirmadas.

## 13. Deudas, contratos y crédito

El crédito no es dinero gratuito. Todo préstamo debe indicar principal, acreedor, deudor, calendario, intereses o ausencia de ellos, garantías, condiciones de incumplimiento y jurisdicción reconocida.

Pueden existir deudas personales, comerciales, gremiales o públicas. El incumplimiento puede provocar pérdida de reputación, penalizaciones, confiscación legal, renegociación, insolvencia o conflicto. La prisión o violencia no son consecuencias automáticas: dependen de las leyes e instituciones de SR-13.

# PARTE V — MAZMORRA, CRISTALES Y RECOMPENSAS

## 14. Principio de botín

La recompensa principal de la Mazmorra procede de los monstruos y de las actividades causales de exploración, extracción y supervivencia.

**No se diseñará el bucle económico alrededor de cofres, cajas, barriles o contenedores rompibles que aparezcan como fuentes arbitrarias de riqueza.** Puede haber contenedores funcionales en el mundo —almacenes, bolsas, herramientas, depósitos o pertenencias—, pero su contenido debe tener propietario, historia y procedencia.

## 15. Cristales de monstruo

Al morir, los monstruos pueden dejar cristales conforme a SR-08 y SR-09. El cristal es una recompensa material real del individuo, no una cifra abstracta creada directamente en el inventario del jugador.

La cantidad, tamaño, calidad y valor potencial dependen de una combinación definida por especie y caso:
- nivel de desarrollo o potencia efectiva;
- fuerza y capacidades acumuladas;
- calidad y estabilidad del cristal;
- edad o longevidad cuando sea relevante;
- rasgos arcanos y Resonancias;
- daño, contaminación o degradación sufrida;
- método de extracción y conservación;
- demanda y usos disponibles.

No se debe asumir que el número de piso fija automáticamente el valor. La profundidad puede correlacionarse con fuerza y rareza por las reglas ecológicas, pero un monstruo individual conserva sus propios atributos e historia.

### 15.1. Valoración

El sistema separa:
1. **propiedades intrínsecas:** tamaño, pureza, estabilidad, composición, afinidad y potencia medible;
2. **valor de tasación:** estimación técnica realizada por alguien con conocimientos e instrumentos;
3. **precio ofrecido:** cantidad que un comprador concreto está dispuesto a pagar;
4. **precio final:** resultado de la negociación.

Dos cristales del mismo monstruo no tienen por qué valer igual si difieren en estado, composición o demanda.

### 15.2. Recompensa y propiedad

El cristal no se asigna automáticamente a quien asestó el último golpe. La distribución depende de:
- propiedad o derecho previo sobre la expedición;
- acuerdos de grupo;
- participación y contribución pactadas;
- reglas del gremio o contrato;
- reclamaciones legítimas;
- decisión de los participantes cuando no exista acuerdo previo.

El sistema no inventará un reparto universal obligatorio. Puede ofrecer herramientas de reparto, pero debe respetar contratos y decisiones válidas.

### 15.3. Monstruos que no dejan cristal

Puede haber excepciones justificadas por especie, biología, estado de muerte, destrucción del núcleo, extracción previa o anomalía. No se debe garantizar una recompensa idéntica en cada muerte.

## 16. Extracción de materiales corporales

Las partes aprovechables se obtienen mediante procesos válidos según SR-08:
- extracción después de la muerte;
- recolección de desprendimientos o exuvias;
- obtención de secreciones o sustancias;
- minería de estructuras minerales;
- recuperación de componentes que se desprendieron durante el combate.

La extracción requiere herramientas, tiempo, conocimientos y condiciones adecuadas. Puede fallar, degradar el material, contaminarlo o dañar componentes valiosos.

La ficha del material registra individuo o especie de origen, método de obtención, fecha, estado, calidad, propiedades y responsable de la extracción.

## 17. Recompensas no materiales

La Mazmorra también puede generar valor mediante:
- información y mapas;
- rutas descubiertas;
- pruebas de hazañas;
- contratos cumplidos;
- rescates;
- investigación;
- reconocimiento y reputación;
- acceso legítimo a servicios o encargos.

Estas recompensas no sustituyen el botín físico ni deben convertirse en moneda gratuita sin un pagador o mecanismo económico.

# PARTE VI — MATERIALES, FABRICACIÓN Y ARTESANÍA

## 18. Catálogo de materiales

Cada material debe describir propiedades pertinentes, no solo nombre y rareza:
- composición;
- masa y volumen;
- dureza, tenacidad, elasticidad y fragilidad;
- resistencia térmica, química y ambiental;
- conductividad o aislamiento;
- compatibilidad biológica o arcana;
- afinidades y Resonancias;
- estabilidad, deterioro y conservación;
- métodos de extracción y procesamiento;
- usos posibles y restricciones.

Las etiquetas común, raro, épico o legendario pueden servir como clasificación social o de interfaz, pero no sustituyen las propiedades reales.

## 19. Fabricación

Fabricar es un proceso con:
- diseño o receta;
- materiales y cantidades;
- herramientas e instalaciones;
- conocimientos y capacidades;
- tiempo de trabajo;
- consumo de energía y otros recursos;
- secuencia de operaciones;
- tolerancias y condiciones;
- resultado, calidad y posibles defectos.

Una receta conocida no garantiza un resultado perfecto. El éxito depende de la capacidad, equipo, materiales, preparación, entorno y complejidad.

### 19.1. Invención y descubrimiento

Los artesanos pueden experimentar y descubrir procedimientos. Un descubrimiento requiere pruebas, recursos, tiempo y evidencia. Una receta nueva puede ser privada hasta que se enseñe, venda o difunda.

### 19.2. Calidad del producto

La calidad surge de composición, diseño, precisión, ejecución, tratamiento, ajuste y estado. No debe asignarse solo por nivel del fabricante.

Un artesano experto puede producir resultados superiores con materiales adecuados, pero no convertir materia inadecuada en un material con propiedades imposibles.

## 20. Reparación, mantenimiento y deterioro

Los objetos pueden deteriorarse por uso, impacto, fatiga, corrosión, temperatura, humedad, contaminación, magia u otros mecanismos pertinentes.

La reparación puede:
- restaurar funcionalidad;
- recuperar parte de la integridad;
- sustituir componentes;
- reforzar o modificar;
- dejar marcas o secuelas;
- fallar o empeorar el estado si se ejecuta mal.

Reparar no debe restaurar automáticamente un objeto a estado nuevo ni borrar su historia. El coste depende de daño, material, complejidad, disponibilidad de piezas, mano de obra y urgencia.

## 21. Encantamiento y objetos arcanos

El encantamiento obedece SR-07 y requiere mecanismo, fuente, coste, estabilidad, compatibilidad y mantenimiento cuando corresponda. La fabricación de un objeto mágico no puede saltarse las reglas de Trama, flujo, Resonancias, resistencias y causalidad.

El material no concede por sí solo conocimiento de Veyrath ni dominio de hechizos. Un objeto puede almacenar o facilitar una operación solo si su mecanismo está definido y validado.

# PARTE VII — TRABAJO, SALARIOS Y SERVICIOS

## 22. Trabajo y remuneración

Los individuos pueden trabajar por salario, pago por tarea, participación en beneficios, trueque, manutención, deuda o acuerdo mixto.

La remuneración depende de:
- tarea y dificultad;
- duración y riesgo;
- habilidad y reputación;
- escasez de trabajadores;
- responsabilidad;
- condiciones del contrato;
- oferta y demanda local.

No todos los trabajos requieren un salario monetario. Hogares, comunidades y organizaciones pueden distribuir trabajo y recursos por cooperación, obligación, tradición o reciprocidad.

## 23. Servicios

Los servicios pueden incluir:
- alojamiento y alimentación;
- transporte y escolta;
- reparación y fabricación;
- curación y atención médica;
- tasación y certificación;
- almacenamiento y custodia;
- enseñanza y entrenamiento;
- investigación y traducción;
- mapas, guías y exploración;
- permisos, trámites y servicios institucionales.

El precio y la disponibilidad dependen de personal, instalaciones, recursos, reputación, urgencia y riesgo. La atención médica no puede garantizar curación si no hay conocimientos, medios o recursos suficientes, conforme a SR-09.

## 24. Gremio de aventureros

El gremio puede operar como institución de coordinación, certificación y servicios. Funciones que el gremio puede desempeñar:
- registrar aventureros y grupos;
- publicar contratos y encargos;
- verificar resultados y evidencias;
- tasar o canalizar cristales;
- facilitar compradores y proveedores;
- custodiar bienes o fondos si posee infraestructura;
- ofrecer información y servicios de apoyo;
- gestionar cuotas, comisiones y recompensas;
- mantener registros de expediciones, bajas y reclamaciones.

El gremio no crea riqueza por autoridad narrativa. Toda recompensa debe proceder de fondos, contratos, recursos, contribuciones o presupuesto institucional.

El gremio no tiene monopolio obligatorio sobre toda actividad aventurera. Pueden existir comerciantes privados, compradores independientes y acuerdos directos.

# PARTE VIII — IMPUESTOS, ORGANIZACIONES Y RIESGOS

## 25. Fiscalidad

Los impuestos, tasas, peajes y licencias dependen de jurisdicción, leyes, autoridad y capacidad de recaudación. SR-10 define su tratamiento económico; SR-13 definirá legitimidad y régimen político.

Los tributos deben tener base, sujeto, importe o fórmula, momento de cobro, beneficiario y consecuencias de incumplimiento. No se deducen monedas invisibles del inventario.

## 26. Organizaciones y tesorerías

Gremios, talleres, caravanas, templos, asociaciones y autoridades pueden tener tesorería, activos, obligaciones, ingresos, gastos y reservas.

La insolvencia debe ser posible. Una organización no puede pagar recompensas si carece de fondos, crédito o recursos comprometidos.

## 27. Riesgo económico

La economía puede sufrir:
- robo y pérdida;
- quiebra;
- inflación o deflación local;
- escasez;
- falsificación;
- interrupción de rutas;
- desastres;
- guerras y bloqueos;
- monopolios;
- corrupción;
- especulación;
- deterioro y caducidad.

Estos fenómenos requieren causas, actores y consecuencias. No se activan como penalizaciones arbitrarias para el jugador.

# PARTE IX — SIMULACIÓN, PERSISTENCIA Y RENDIMIENTO

## 28. Economía fuera de pantalla

La economía continúa cuando el jugador no está presente. No es necesario simular cada intercambio trivial con detalle individual. SR-06 permite niveles de resolución:

- **Alta resolución:** transacciones cercanas, conflictos, bienes singulares, operaciones del jugador, eventos relevantes.
- **Resolución agregada:** producción rutinaria, consumo, inventarios y comercio de poblaciones.
- **Resolución histórica:** tendencias, balances y cambios de largo plazo.

Al cambiar de nivel, los resultados deben conservar masa, bienes, moneda, propiedad y causalidad. No se permite que un comerciante venda más unidades de las que tenía o que una población consuma recursos inexistentes.

## 29. Persistencia y eventos económicos

Deben registrarse eventos significativos:
- `ItemCreated`, `ItemTransformed`, `ItemRepaired`, `ItemDestroyed`;
- `OwnershipTransferred`, `ItemStored`, `ItemLost`, `ItemStolen`;
- `TradeCompleted`, `TradeFailed`, `DebtCreated`, `DebtSettled`, `ContractFulfilled`;
- `MonsterCrystalRecovered`, `MaterialHarvested`, `MaterialProcessed`;
- `CraftingStarted`, `CraftingCompleted`, `CraftingFailed`;
- `MarketPriceChanged`, `StockDepleted`, `BusinessOpened`, `BusinessClosed`;
- `TaxCollected`, `WagePaid`, `OrganizationInsolvent`.

Los eventos confirmados conservan actor, tiempo, lugar, causa, cantidades, bienes, valores, autoridad y procedencia. Los intentos fallidos se distinguen de hechos consumados.

## 30. Integridad económica

El sistema debe detectar:
- creación o duplicación de objetos sin causa;
- ventas de bienes no poseídos o no disponibles;
- transferencias simultáneas incompatibles;
- pagos sin fondos;
- recompensas sin pagador;
- monedas creadas o destruidas sin mecanismo;
- fabricación sin materiales;
- extracción sin cuerpo, fuente o método;
- existencias negativas;
- diferencias entre inventario y registro de eventos.

Las correcciones deben realizarse mediante eventos compensatorios o procedimientos autorizados, nunca borrando silenciosamente la historia.

# PARTE X — DATOS Y CONTRATOS MÍNIMOS

## 31. Contrato mínimo de objeto económico

Cada bien debe poder representar, cuando corresponda:
- ID y definición;
- cantidad y unidad;
- propietario, poseedor y custodio;
- ubicación y contenedor;
- estado, condición y durabilidad;
- masa y volumen;
- composición, calidad y propiedades;
- origen y genealogía;
- restricciones y compromisos;
- valoraciones conocidas y su fuente;
- historial de fabricación, reparación y transferencias.

## 32. Contrato mínimo de actor económico

- identidad y tipo de actor;
- ubicación y jurisdicción;
- recursos, inventario y tesorería;
- necesidades y objetivos;
- capacidades productivas y comerciales;
- reputación y relaciones;
- contratos, deudas y obligaciones;
- conocimiento de precios y mercados;
- permisos y autoridad.

## 33. Contrato mínimo de transacción

- ID único;
- partes y representantes;
- bienes, cantidades y estado;
- precio, moneda y método de pago;
- impuestos y comisiones;
- condiciones y plazos;
- reservas y precondiciones;
- resultado;
- fecha, lugar y autoridad;
- evento de procedencia.

# PARTE XI — CALIBRACIÓN INICIAL Y PRUEBAS

## 34. Parámetros que se calibrarán

No se fijan como constantes universales en esta versión:
- salarios concretos;
- precios de alimentos, alojamiento, armas y servicios;
- proporciones de moneda y nombres regionales;
- impuestos y comisiones;
- tasas de producción y consumo;
- elasticidad y velocidad de ajuste de precios;
- valores base de cristales por especie;
- costes y tiempos de fabricación;
- deterioro y reparación por material;
- densidad y volumen de mercancía por región.

Se calibrarán mediante escenarios de prueba con economía pequeña, mediana y abundante, y con simulaciones de ausencia prolongada del jugador.

## 35. Pruebas obligatorias

1. Un monstruo muere y deja un cristal solo si su ficha y estado lo permiten; el cristal aparece en el mundo con procedencia.
2. Un jugador no recibe automáticamente el cristal si no tiene derecho o acceso a recogerlo.
3. Un grupo con acuerdo de reparto distribuye el botín según el contrato vigente.
4. Dos agentes intentan comprar el mismo objeto único: solo una transacción puede completarse.
5. Un comerciante vende sus existencias y queda sin stock; no reaparece mercancía por abrir la tienda.
6. Una ruta comercial interrumpida reduce suministro y puede modificar precios o disponibilidad.
7. Un artesano fabrica un objeto y consume materiales, tiempo y capacidad de taller.
8. Un intento de fabricación sin material suficiente es rechazado sin crear el producto.
9. Un objeto dañado requiere reparación válida; el pago no restaura el objeto por sí mismo.
10. Un material extraído conserva la especie o individuo de origen y el método de obtención.
11. Un taller puede rechazar un trabajo por falta de personal, herramientas, materiales o capacidad.
12. Una organización sin fondos no puede pagar una recompensa salvo que exista crédito o financiación válida.
13. La economía avanza durante la ausencia del jugador sin duplicar bienes ni crear monedas arbitrarias.
14. El trueque puede completarse sin moneda si ambas partes aceptan y la transferencia es válida.
15. La tasación de un cristal puede diferir del precio final de venta.
16. Un objeto robado puede estar en posesión de alguien distinto de su propietario.
17. La pérdida o destrucción de un objeto actualiza su disponibilidad y su historia.
18. Una simulación agregada produce resultados compatibles con las capacidades, recursos y tiempos disponibles.

# PARTE XII — DECISIONES APROBADAS Y PARÁMETROS RESERVADOS

Los siguientes principios forman parte de SR-10 v0.1 aprobada por el autor. Los valores concretos, nombres regionales, precios y tarifas que el documento identifica como calibrables o reservados no se consideran cerrados por esta aprobación:

1. Economía autónoma y persistente, incluso sin jugador.
2. Moneda común de referencia con posibilidad de monedas regionales y trueque.
3. Precios contextuales, sin precios universales rígidos ni inventarios infinitos.
4. Propiedad, posesión, custodia y transacciones diferenciadas.
5. Recompensa de Mazmorra centrada en cristales y materiales de monstruos, nunca en cofres rompibles como sistema principal.
6. Cristales con propiedades y valoración basadas en el individuo, su estado y la demanda.
7. Materiales corporales obtenidos mediante extracción causal, no añadidos automáticamente al inventario.
8. Fabricación, reparación y encantamiento con materiales, tiempo, herramientas, conocimiento y costes.
9. Gremio como intermediario y proveedor de servicios, no como fuente ilimitada de dinero ni monopolio absoluto.
10. Trabajo, salarios, contratos, deuda, impuestos y tesorerías sujetos a mecanismos y registros.
11. Simulación económica multinivel compatible con funcionamiento offline y catch-up.
12. Los nombres definitivos de moneda, tarifas y precios se reservan para catálogos y calibración posterior.

**Estado de aprobación:** SR-10 v0.1 aprobada expresamente por el autor el 2026-11-20.  
**Nota de moneda:** UM es la unidad de cuenta de trabajo. Las abreviaturas MC, MP y MO y sus nombres asociados son rótulos provisionales no canónicos; el usuario indicó que desea elegir nombres mejores más adelante. No fijarlos en interfaz, lore ni assets como nombres definitivos.  
**Siguiente documento:** SR-11 — Geografía, asentamientos y Mazmorra.

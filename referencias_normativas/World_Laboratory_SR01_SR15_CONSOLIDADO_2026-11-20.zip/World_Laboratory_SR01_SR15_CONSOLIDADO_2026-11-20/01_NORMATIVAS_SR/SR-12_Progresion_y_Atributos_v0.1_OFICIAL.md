# WORLD LABORATORY / SISTEMA REACTOR

# SR-12 — PROGRESIÓN, ATRIBUTOS, EXPERIENCIA, CLASES Y MAESTRÍA

**Código:** SR-12  
**Versión:** 0.1  
**Estado:** NORMATIVA OFICIAL APROBADA  
**Fecha:** 20 de noviembre de 2026  
**Dependencias:** SR-01 a SR-11, especialmente SR-01, SR-02, SR-03, SR-04, SR-05, SR-06, SR-07, SR-08, SR-09, SR-10, SR-11 y Anexo A — Veyrath.  
**Ámbito:** progresión individual, atributos, crecimiento, experiencia, aprendizaje, habilidades, dominio, niveles, ascensos, clases, especializaciones, entrenamiento, adaptación, desarrollo de NPC y monstruos, y continuidad de progresión a través de reencarnación.

---

## CONTROL DEL DOCUMENTO

| Campo | Valor |
|---|---|
| Código | SR-12 |
| Versión | 0.1 — aprobada |
| Estado | Normativa oficial aprobada por instrucción expresa del autor al solicitar la entrega como aprobación efectiva, salvo dudas bloqueantes |
| Alcance | Progresión individual y colectiva de capacidades, conocimientos, habilidades y perfiles |
| Autoridad superior | SR-01 — Constitución y leyes fundamentales |
| Sistemas relacionados | SR-02 a SR-11, según dominio; especialmente SR-03, SR-05 a SR-10, SR-11 y Anexo A — Veyrath |

**Convención normativa:** DEBE y NO DEBE expresan obligaciones o prohibiciones. PUEDE expresa una posibilidad permitida. CALIBRACIÓN identifica parámetros cuantitativos ajustables mediante pruebas. RESERVADO identifica catálogos o reglas particulares que se desarrollarán después. Los valores de escalas y fórmulas que se indiquen como referencia no sustituyen la validación empírica ni las leyes de anatomía, cognición y causalidad.

## CONTROL DE VERSIONES

| Versión | Estado | Descripción |
|---|---|---|
| 0.1 | Aprobada | Primera normativa integral de progresión y atributos. Distingue crecimiento real, experiencia, nivel, aprendizaje, dominio, clase y evolución. |

# PARTE I — PROPÓSITO Y PRINCIPIOS FUNDAMENTALES

## 1. Propósito

SR-12 define cómo una entidad desarrolla, conserva, pierde, transforma y perfecciona sus capacidades a lo largo de su existencia. Establece un sistema de progresión suficientemente claro para un RPG, pero compatible con un universo autónomo donde jugadores, NPC y monstruos tienen trayectorias propias.

La progresión no será una simple barra que, al llenarse, concede aumentos arbitrarios. Las capacidades deben desarrollarse por causas identificables: entrenamiento, práctica, estudio, experiencia, adaptación, enseñanza, uso, recuperación, maduración, transformaciones válidas y acontecimientos significativos.

El sistema debe permitir tanto un personaje especializado como uno versátil; tanto un monstruo que aprende por instinto como uno excepcional que analiza a sus adversarios; tanto un artesano que alcanza maestría sin combatir como un guerrero cuya experiencia se centra en tácticas y técnica.

## 2. Principios obligatorios

1. **Progresión multidimensional:** atributos, conocimientos, habilidades, dominio, experiencia y nivel son dimensiones relacionadas pero distintas.
2. **Causalidad:** ninguna capacidad aparece sin una fuente o mecanismo de adquisición.
3. **Aprender no equivale a desbloquear:** un nivel o clase no concede automáticamente conocimientos, técnicas, hechizos ni destrezas.
4. **Práctica con sentido:** la práctica correcta y retroalimentada desarrolla dominio; repetir sin comprender o corregir tiene rendimiento decreciente.
5. **Individualidad:** dos individuos de la misma especie, nivel o clase pueden tener capacidades muy diferentes.
6. **Apertura:** no existe un catálogo cerrado de todas las habilidades, clases, especializaciones o trayectorias posibles.
7. **No exclusividad:** una clase o especialización facilita una orientación, pero no prohíbe aprender disciplinas externas.
8. **Límites reales:** anatomía, fisiología, cognición, recursos, tiempo, entorno, materiales y leyes arcanas condicionan el crecimiento.
9. **Costes y compromisos:** el desarrollo puede exigir tiempo, energía, recursos, recuperación, riesgos y renuncias; una mejora puede traer efectos secundarios.
10. **Mundo autónomo:** NPC y monstruos progresan cuando tienen oportunidades y causas suficientes, aunque el jugador no participe.
11. **Sin escalado por conveniencia:** el mundo no eleva estadísticas de enemigos solo para igualarlos al jugador.
12. **Continuidad:** los conocimientos, memorias y capacidades conservadas en una reencarnación obedecen SR-01 y SR-03; no se transfieren gratuitamente las condiciones del cuerpo anterior.

## 3. Autoridad y límites

SR-12 desarrolla la Ley de progresión de SR-01 y utiliza el modelo de identidad, cognición, memoria, aprendizaje y evolución individual de SR-03. Se apoya en:

- **SR-02:** autoridad de dominio, validación de comandos, integridad de cambios y registro de eventos.
- **SR-04:** causalidad, continuidad de la realidad y persistencia histórica de los acontecimientos que justifican el progreso.
- **SR-05:** capacidades, anatomía, estructuras y requisitos de cada entidad.
- **SR-06:** simulación autónoma, paso del tiempo y progreso fuera de pantalla.
- **SR-07:** viabilidad física y arcana de capacidades, entrenamiento y transformaciones.
- **SR-08:** biología, desarrollo, longevidad, fisiología y adaptación.
- **SR-09:** combate, aprendizaje táctico, estados, perfiles y clases.
- **SR-10:** adquisición y desarrollo de oficios, fabricación, reparación, recursos y actividades económicas.
- **SR-11:** geografía, asentamientos, ambientes y oportunidades espaciales en las que se desarrollan entrenamiento, exploración, trabajo y experiencia.
- **Anexo A — Veyrath:** adquisición, ejecución y dominio de formulaciones mágicas.

En caso de conflicto:

- SR-01 conserva autoridad constitucional.
- SR-03 determina qué conoce, recuerda, aprende o puede comprender una entidad.
- SR-05 determina qué estructuras, capacidades y condiciones son posibles para una entidad.
- SR-07 determina si una acción o transformación es físicamente o arcanamente viable.
- SR-08 determina límites biológicos y procesos de los organismos y monstruos.
- SR-09 determina consecuencias de combate, estados y requisitos tácticos.
- SR-12 organiza la progresión de estas dimensiones, pero no puede ignorar las restricciones anteriores.

# PARTE II — QUÉ SIGNIFICA PROGRESAR

## 4. Dimensiones que no deben confundirse

El sistema DEBE mantener separadas estas dimensiones:

| Dimensión | Qué representa | Qué no representa |
|---|---|---|
| Atributo | Una capacidad general o aptitud relativamente estable del individuo | Un conocimiento concreto o una técnica dominada |
| Estado | Condición temporal o persistente que modifica el rendimiento | Un crecimiento permanente por sí solo |
| Conocimiento | Información, conceptos, reglas, fórmulas, tácticas o procedimientos comprendidos o recordados | Capacidad automática para ejecutarlos correctamente |
| Habilidad | Acción o procedimiento que la entidad puede intentar realizar bajo ciertas condiciones | Éxito garantizado ni dominio absoluto |
| Dominio | Calidad, consistencia, precisión y autonomía con que ejecuta una habilidad o disciplina | Fuerza física o reserva que no posee |
| Experiencia | Evidencia acumulada de exposición, práctica, retos, errores y resultados | Una moneda canjeable por cualquier poder |
| Nivel de trayectoria | Resumen grueso de la evolución global validada | Una orden para aumentar todos los atributos |
| Clase | Perfil de formación, práctica, predisposición o función reconocible | Una profesión obligatoria, una especie o un paquete automático de poderes |
| Evolución | Transformación individual, biológica, cognitiva o extraordinaria con mecanismo propio | Un simple aumento numérico ni una subida de nivel |
| Reputación | Cómo otros individuos o instituciones perciben al sujeto | Su capacidad objetiva real |

Un personaje puede ser de nivel alto y tener poco dominio en una disciplina nueva. Otro puede ser de nivel moderado y poseer una maestría excepcional en un oficio concreto. Ambos resultados son válidos.

## 5. Progresión de varios ejes

Toda entidad puede desarrollar varias líneas en paralelo, según su naturaleza:

- desarrollo corporal y funcional;
- desarrollo cognitivo y sensorial;
- aprendizaje técnico y práctico;
- conocimiento teórico, lingüístico, mágico y científico;
- maestría marcial, artesanal, social, exploratoria u otras;
- adaptación táctica y conductual;
- estabilidad y resiliencia emocional;
- aptitudes arcanas, cuando sean aplicables;
- evolución biológica o estructural, cuando proceda;
- madurez, experiencia vital y reputación.

No se exige que todas las líneas progresen al mismo ritmo. La entidad puede especializarse, cambiar de interés, abandonar disciplinas, sufrir retrocesos o iniciar una trayectoria completamente distinta.

# PARTE III — ATRIBUTOS Y CAPACIDADES

## 6. Modelo general de atributos

Los atributos describen tendencias y capacidades del individuo. No sustituyen la anatomía, masa, proporciones, órganos, estructura, entrenamiento, equipo, salud, experiencia ni condiciones ambientales.

SR-12 adopta un **marco común de atributos**, no una lista universal obligatoria. Cada especie, individuo o entidad activa utilizará los campos pertinentes. Un gólem puede registrar integridad estructural y estabilidad del núcleo; un organismo puede registrar resistencia fisiológica; una criatura sin sistema nervioso humano tendrá un modelo sensorial propio.

### 6.1. Escala de referencia

Cuando convenga a la interfaz, los atributos de aptitud podrán expresarse en una escala de referencia de 0 a 100. Esta escala resume una evaluación funcional, no constituye una unidad física ni significa que dos especies con el mismo número tengan exactamente la misma fuerza, velocidad o percepción.

La resolución física utiliza magnitudes y propiedades adecuadas a la entidad: masa, fuerza, aceleración, resistencia de materiales, capacidades sensoriales, límites fisiológicos y demás datos de dominio. La cifra visible nunca reemplaza esos datos.

El 100 no es una frontera metafísica universal. Los límites individuales y de especie deben definirse por sus mecanismos reales. Una entidad extraordinaria puede quedar fuera de una escala de presentación ordinaria, siempre que el cambio tenga procedencia y no se use para eludir las leyes. Los valores exactos, rangos y conversiones quedan sujetos a calibración.

## 7. Atributos corporales y funcionales

Los siguientes constituyen el núcleo recomendado para entidades que posean cuerpo y movimiento compatibles. No todos aplican a todas las anatomías.

| Atributo | Definición funcional | Factores que también intervienen |
|---|---|---|
| **Fuerza** | Capacidad de producir fuerza y vencer resistencias | Masa muscular o mecanismo equivalente, palancas anatómicas, postura, técnica, fatiga y lesiones |
| **Potencia** | Capacidad de producir trabajo o fuerza de manera explosiva | Fuerza, velocidad de contracción, coordinación y disponibilidad energética |
| **Agilidad** | Capacidad de cambiar de dirección, postura y trayectoria con control | Anatomía, movilidad articular, equilibrio, velocidad y entorno |
| **Coordinación** | Integración precisa de movimientos y acciones simultáneas | Sistema nervioso o mecanismo equivalente, práctica, atención y percepción |
| **Resistencia física** | Capacidad de sostener actividad y tolerar esfuerzo prolongado | Fisiología, respiración o fuente equivalente, reservas, temperatura y recuperación |
| **Percepción** | Calidad funcional con que capta señales relevantes del entorno | Sentidos disponibles, alcance, ruido, iluminación, atención y entrenamiento sensorial |

No se incluirá una estadística universal de «velocidad» que ignore la longitud de las extremidades, locomoción, masa, terreno, resistencia y aceleración. La velocidad de desplazamiento, reacción y ejecución se derivará de las variables pertinentes. La interfaz puede mostrar valores resumidos.

## 8. Atributos cognitivos y de aprendizaje

| Atributo | Definición funcional | Límite importante |
|---|---|---|
| **Razonamiento** | Capacidad para relacionar información, inferir, comparar, planificar y resolver problemas | No concede información que no se haya percibido o recibido |
| **Memoria** | Capacidad funcional de codificar, conservar y recuperar experiencias e información | No significa recuerdo perfecto ni ausencia de olvido |
| **Atención** | Capacidad para seleccionar y sostener el procesamiento de señales o tareas | Puede verse afectada por fatiga, lesión, estrés, distracción y contexto |
| **Capacidad de aprendizaje** | Facilidad general para adquirir, corregir, retener y transferir conocimiento y procedimientos | No reemplaza aptitudes específicas, práctica, enseñanza ni tiempo |

La inteligencia no se reducirá a un único número. Una entidad puede tener gran memoria y bajo razonamiento abstracto, o gran capacidad espacial con comunicación limitada. Estas diferencias son válidas y deben poder expresarse.

### 8.1. Aptitudes por dominio

Además de la capacidad general de aprendizaje, cada individuo PUEDE tener aptitudes diferenciadas, por ejemplo:

- marcial y táctica;
- arcana y lingüística;
- artesanal y mecánica;
- científica e investigadora;
- social y comunicativa;
- sensorial y espacial;
- memoria verbal, visual o procedimental;
- estrategia, coordinación o liderazgo.

Una aptitud alta facilita ciertos aprendizajes, pero no proporciona los conocimientos ni garantiza el resultado. La aptitud también puede cambiar a través de entrenamiento, maduración, adaptación o transformación válida.

## 9. Resiliencia emocional

SR-12 adopta **Resiliencia emocional (RE)** como nombre de referencia para la capacidad de soportar, procesar y recuperar estabilidad funcional ante presión, miedo, pérdida, trauma, sorpresa y acontecimientos emocionalmente intensos, conforme a SR-09.

RE no significa ausencia de miedo, indiferencia, falta de empatía ni inmunidad al trauma. Su influencia se combina con personalidad, vínculos, preparación, experiencia, interpretación, contexto, exposición y apoyo social.

Debe distinguirse de:

- **Impacto emocional del acontecimiento:** intensidad objetiva/contextual del evento, que puede registrarse en una escala de referencia de 0 a 10.
- **Respuesta emocional individual:** miedo, pánico, duelo, ira, culpa, bloqueo, determinación, etc., según la entidad.
- **Resiliencia emocional:** capacidad individual de soportar, procesar y recuperarse.
- **Secuela psicológica:** efecto persistente que puede requerir tiempo, ayuda, tratamiento o nuevas experiencias.

Un mismo acontecimiento puede provocar respuestas distintas en testigos diferentes. Una resiliencia elevada no borra memorias dolorosas ni vuelve imposible el pánico.

## 10. Aptitudes arcanas

Las aptitudes arcanas solo se aplican a entidades cuya naturaleza, estructura y relación con la Trama y las Resonancias lo permitan. No todos los individuos tienen las mismas capacidades.

El perfil puede incluir, según SR-07:

- sensibilidad o percepción de fenómenos arcanos;
- afinidad o compatibilidad con determinadas Resonancias;
- capacidad de canalización;
- control y estabilidad de flujo;
- eficiencia en una operación concreta;
- tolerancia a sobrecarga;
- reservas o fuentes utilizables, si existen.

Estos datos no son un permiso para ignorar las fuentes, costes, resistencias, contramedidas o leyes arcanas. **MP**, cuando se muestre, representa una reserva o magnitud operativa definida por SR-07; no es conocimiento mágico, afinidad ni dominio.

## 11. Valores derivados y estadísticas de interfaz

Puntos de vida (HP), reservas arcanas (MP), resistencia disponible, velocidad, salto, recuperación, carga transportable, precisión de ejecución y otras cifras de interfaz son valores derivados, estados o mediciones funcionales. No deben tratarse todos como atributos primarios.

Sus resultados pueden depender de varios atributos, anatomía, tamaño, órganos, equipo, lesiones, estados, experiencia y entorno. Las fórmulas definitivas se definirán en contratos de dominio y calibración. No se aprueba una fórmula universal que sirva a todas las especies.

# PARTE IV — CRECIMIENTO Y CAMBIO DE ATRIBUTOS

## 12. Desarrollo real, no puntos gratuitos

Los atributos pueden crecer cuando existen estímulos y mecanismos suficientes: entrenamiento, práctica, esfuerzo progresivo, adaptación, nutrición o energía pertinente, descanso, recuperación, maduración, rehabilitación, exposición o transformaciones extraordinarias autorizadas.

La subida de nivel no añade puntos gratuitos a todos los atributos. Los ascensos pueden representar que una entidad consolidó un cambio significativo, pero el sistema debe conservar la causa del cambio y sus efectos.

## 13. Potencial, límites y rendimientos decrecientes

Cada individuo puede tener un perfil de potencial y margen de desarrollo condicionado por:

- especie, anatomía, estructura y herencia;
- desarrollo, madurez, edad o duración de existencia;
- estado de salud y recursos;
- aptitud individual y experiencia previa;
- calidad, intensidad y continuidad del entrenamiento;
- oportunidades reales y condiciones ambientales;
- lesiones, transformaciones, adaptación o evolución;
- relación entre carga, descanso y recuperación.

El potencial no debe tratarse como un número infalible conocido desde el nacimiento. Puede ser estimado de manera incompleta por el sistema, especialistas o el propio individuo. No es necesariamente inmutable: una transformación válida puede alterar límites y costes.

Al acercarse a un límite funcional, el crecimiento suele requerir mayor tiempo, calidad de práctica, recuperación o métodos especializados. Deben aplicarse rendimientos decrecientes cuando el proceso lo justifique, no un bloqueo arbitrario.

## 14. Costes, lesiones y recuperación

Entrenar más no siempre produce mejores resultados. La sobrecarga puede causar fatiga, lesión, pérdida temporal de precisión, enfermedad, agotamiento arcano, desgaste estructural o retroceso funcional. La recuperación requiere condiciones adecuadas y puede ser incompleta.

La lesión puede impedir entrenar una técnica o utilizar una capacidad incluso si el conocimiento permanece intacto. Una prótesis, adaptación anatómica o rehabilitación puede abrir una nueva forma de ejecución, pero necesita aprendizaje y compatibilidad.

## 15. Pérdida, desuso y regresión

El dominio práctico puede deteriorarse con el desuso. La precisión, velocidad, resistencia o coordinación pueden disminuir por edad, enfermedad, lesión, deterioro, inactividad o transformaciones.

El conocimiento teórico no desaparece necesariamente a la misma velocidad. Una entidad puede recordar cómo hacer algo y, sin embargo, haber perdido la condición física o la práctica necesarias para ejecutarlo.

La regresión no debe borrar sin causa la historia de aprendizaje. Debe distinguir olvido, deterioro corporal, pérdida de acceso, falta de práctica, daño neurológico o estructural y pérdida real de conocimiento.

# PARTE V — EXPERIENCIA Y APRENDIZAJE

## 16. Experiencia: evidencia de trayectoria

La experiencia se registra por dominios o ámbitos cuando sea pertinente. Puede proceder de combate, exploración, estudio, oficio, investigación, relaciones, enseñanza, liderazgo, supervivencia, creación, errores y otros acontecimientos.

La experiencia no es una moneda que se gasta para comprar habilidades inconexas. Si la implementación usa puntos o contadores numéricos, estos serán una representación administrativa del progreso observado y no una fuente autónoma de capacidades.

## 17. Fuentes válidas de aprendizaje

Una entidad puede aprender mediante:

1. práctica deliberada y entrenamiento;
2. experiencia directa y resolución de problemas;
3. observación y análisis de acciones ajenas;
4. instrucción, mentoría y enseñanza;
5. experimentación, investigación y ensayo de hipótesis;
6. imitación y repetición con corrección;
7. interacción social y transmisión cultural;
8. adaptación instintiva o fisiológica compatible con su naturaleza;
9. estudio de documentos, diagramas, grimorios y demostraciones;
10. recuerdos procedimentales disponibles de experiencias anteriores.

La observación no garantiza comprensión. La comprensión no garantiza ejecución. Una ejecución exitosa aislada no significa dominio. El sistema registrará esas etapas de manera diferenciada.

## 18. Ciclo de aprendizaje

El proceso de aprendizaje podrá representarse mediante las siguientes etapas, sin exigir que todos los dominios sigan una secuencia idéntica:

1. **Exposición:** la entidad encuentra información, acción, problema o estímulo.
2. **Percepción:** obtiene señales suficientes para analizarlo.
3. **Codificación:** conserva una representación o recuerdo.
4. **Comprensión:** interpreta principios, relaciones, reglas o propósito.
5. **Ensayo:** intenta la acción o aplica el conocimiento.
6. **Retroalimentación:** observa el resultado, error, corrección o consecuencias.
7. **Consolidación:** estabiliza el aprendizaje mediante práctica y recuperación.
8. **Transferencia:** adapta lo aprendido a situaciones nuevas cuando comprende principios relevantes.
9. **Dominio:** ejecuta con consistencia y autonomía dentro de límites identificables.

La memoria puede ser incompleta; la interpretación puede ser errónea; una práctica defectuosa puede consolidar malos hábitos. El aprendizaje no siempre conduce a una mejora.

## 19. Índice de Aprendizaje Efectivo

SR-12 incorpora el índice de referencia establecido en SR-09 Anexo A:

`LE = 0.35C + 0.25A + 0.15K + 0.10I + 0.15F`

Donde:

- **C:** capacidad individual general de aprendizaje;
- **A:** aptitud específica para el dominio;
- **K:** conocimientos previos pertinentes;
- **I:** calidad de instrucción o guía;
- **F:** calidad de práctica, retroalimentación y corrección.

Los componentes utilizan una escala de referencia de 0 a 100 cuando sean aplicables. LE orienta la eficiencia potencial del proceso; no otorga información, materiales, oportunidades ni dominio inexistentes. Tampoco es una probabilidad directa de éxito.

Los pesos se mantienen como referencia aprobada en el contexto de aprendizaje mágico de SR-09 Anexo A y se aplican como modelo general inicial sujeto a calibración. No deben duplicarse bonificaciones por la misma fuente: por ejemplo, una ventaja de clase no debe sumarse dos veces si ya está representada en A o en I.

## 20. Etapas de dominio

Para una habilidad o disciplina con escala de 0 a 100, se adoptan las siguientes etiquetas de referencia:

| Rango | Etapa | Interpretación |
|---:|---|---|
| 0–19 | Familiarización | Reconoce elementos básicos; depende de guía y puede cometer errores fundamentales |
| 20–39 | Comprensión inicial | Entiende parte del procedimiento y puede ensayar con asistencia o condiciones favorables |
| 40–59 | Ejecución básica | Puede realizar versiones sencillas, con limitaciones y consistencia variable |
| 60–79 | Competencia | Ejecuta de forma funcional en situaciones conocidas y corrige errores habituales |
| 80–94 | Dominio | Ejecuta con alta consistencia, adapta procedimientos y comprende variaciones frecuentes |
| 95–100 | Dominio experto | Presenta control excepcional, lectura profunda y capacidad de adaptación dentro de los límites de la disciplina |

Estas etapas no son permisos automáticos. Un nivel 80 en una técnica no garantiza que el individuo pueda realizarla con un brazo lesionado, sin herramientas necesarias o bajo condiciones incompatibles.

## 21. Rendimientos decrecientes y práctica significativa

La práctica debe tener valor cuando desarrolla comprensión, precisión, consistencia, adaptación o retención. Repetir una acción sin desafío, riesgo, corrección ni variación no debe producir progreso ilimitado.

El valor formativo de una experiencia dependerá, según corresponda, de:

- dificultad y novedad del problema;
- participación real del individuo;
- calidad de atención y percepción;
- posibilidad de corregir errores;
- calidad de guía, explicación y herramientas;
- relevancia de las consecuencias;
- recuperación y consolidación;
- dominio que ya se posee.

La repetición puede seguir siendo necesaria para mantener la habilidad, pero mantener no equivale a crecer. Un ejercicio rutinario puede consolidar, estabilizar o preservar, mientras que su contribución al crecimiento se reduce si deja de ofrecer aprendizaje nuevo.

## 22. Errores, fracaso y aprendizaje

El fracaso puede producir aprendizaje cuando la entidad percibe y comprende por qué falló, cuenta con información suficiente o recibe retroalimentación válida. Fallar no concede experiencia automáticamente.

Un error puede reforzar una creencia incorrecta, consolidar una mala técnica o provocar miedo y evitación. El sistema debe permitir aprendizaje negativo y no convertir toda derrota en un beneficio garantizado.

## 23. Aprendizaje táctico y adaptación

Los combatientes pueden aprender patrones de adversarios, ajustar tiempos, reconocer hábitos y preparar contramedidas según SR-09. La adaptación requiere observación suficiente, memoria, interpretación, oportunidad y capacidad para ejecutar una respuesta.

La adaptación no es instantánea ni omnisciente. Puede ser errónea, incompleta, tardía o contraproducente. Un adversario puede cambiar su patrón, ocultar información, engañar o contrarrestar una respuesta aprendida.

El jugador también aprende a través del personaje. La experiencia personal del usuario detrás de la pantalla no debe conceder automáticamente conocimiento al personaje si no existe una vía válida dentro del mundo.

# PARTE VI — HABILIDADES, TÉCNICAS Y CONOCIMIENTOS

## 24. Habilidad y adquisición

Una habilidad es una capacidad aprendida para ejecutar una acción, procedimiento, estrategia o conjunto de operaciones. Toda habilidad relevante debe poder especificar:

- identificador y versión;
- disciplina y subdominio;
- descripción funcional;
- requisitos anatómicos, cognitivos, materiales o arcanos;
- conocimientos previos;
- método de adquisición;
- dificultad y riesgos;
- nivel de dominio y evidencia;
- condiciones de uso y limitaciones;
- costes, recuperación o consumo de recursos;
- formas de practicar, enseñar o transmitir;
- incompatibilidades y variantes;
- efectos del desuso, lesiones o transformaciones.

## 25. Familias de habilidades

La clasificación es abierta. Como base se reconocen:

- **Marciales:** manejo de armas, combate sin armas, defensa, desplazamiento táctico, formaciones y lectura del oponente.
- **Arcanas:** percepción de la Trama, canalización, formulación, control, sellos, barreras y operaciones de Resonancia.
- **Físicas:** carrera, salto, escalada, natación, equilibrio, carga y manipulación.
- **Exploratorias:** rastreo, orientación, cartografía, reconocimiento de rutas y detección de peligros.
- **Médicas:** primeros auxilios, diagnóstico, estabilización, cirugía, rehabilitación y tratamientos especializados.
- **Artesanales:** minería, forja, carpintería, reparación, alquimia, sastrería, cocina y fabricación.
- **Cognitivas:** investigación, análisis, memoria técnica, planificación y resolución de problemas.
- **Sociales:** negociación, persuasión, docencia, diplomacia, administración, liderazgo y mediación.
- **Supervivencia:** recolección, refugio, gestión de recursos, preparación, conservación y lectura ambiental.

Ninguna familia concede acceso automático a todas sus habilidades. Conocer teoría, saber ejecutar un procedimiento y ser capaz de hacerlo bajo presión son logros distintos.

## 26. Magia, Veyrath y aprendizaje por componentes

SR-12 respeta SR-07 y el Anexo A de SR-09. El aprendizaje mágico debe mantener separadas al menos estas dimensiones:

1. percibir o conocer la existencia de la Trama/Resonancia pertinente;
2. reconocer la existencia de un hechizo;
3. aprender palabras individuales de Veyrath;
4. comprender significado, gramática y orden;
5. conocer la oración completa;
6. comprender el efecto, fuente, coste y condiciones;
7. ejecutar con apoyo o en condiciones favorables;
8. ejecutar correctamente de manera consistente;
9. dominar la formulación y adaptarla solo cuando las reglas lo permitan;
10. investigar variaciones o nuevas formulaciones con riesgos y validación.

Aprender nueve palabras no equivale a dominar una oración de nueve palabras. Conocer una fórmula no garantiza disponer de reserva, sensibilidad, estabilidad, concentración, anatomía compatible ni condiciones ambientales. Los grimorios transmiten información, no dominio automático.

El autocompletado se rige por los requisitos del Anexo A: es específico de cada fórmula y exige dominio demostrado, ejecuciones correctas y práctica distribuida; no se concede por alcanzar un nivel general o elegir una clase mágica.

# PARTE VII — NIVELES, ASCENSOS Y RECONOCIMIENTO

## 27. Nivel de trayectoria

SR-12 establece un **Nivel de Trayectoria** como indicador resumido de la evolución general del individuo cuando el sistema o la interfaz necesiten una referencia sencilla.

El nivel resume evidencia sostenida de desarrollo en capacidades, dominio, conocimientos, experiencia, logros y transformaciones compatibles. No es una medida exhaustiva ni una descripción infalible del poder real.

Un Nivel de Trayectoria:

- no otorga atributos de forma automática;
- no entrega habilidades, hechizos, equipo ni conocimientos;
- no garantiza victoria frente a un nivel inferior;
- no reemplaza las capacidades específicas ni la lectura táctica;
- puede ser diferente de la estimación de una institución o de lo que otros personajes creen;
- debe poder permanecer oculto, aproximado o desconocido para los habitantes.

## 28. Ascenso de nivel

Los ascensos representan hitos de desarrollo y requieren evidencia acumulada y méritos significativos. No basta con matar una cantidad predeterminada de monstruos, repetir tareas o llenar una barra con actividad de bajo riesgo.

La evaluación puede considerar:

- crecimiento sostenido y verificable;
- experiencias que hayan exigido capacidades reales;
- progreso en una o varias disciplinas relevantes;
- superación de límites funcionales o resolución de desafíos importantes;
- calidad de decisiones y aprendizaje;
- continuidad y consolidación, no solo un éxito fortuito;
- condiciones propias de especie, cuerpo, reencarnación o transformación.

El sistema puede registrar progreso previo al ascenso, pero el evento de ascenso debe tener justificación causal. No se requiere que todos los individuos asciendan a la misma velocidad ni que todos utilicen el mismo indicador.

## 29. Efectos del ascenso

Un ascenso puede reflejar una mayor capacidad general, abrir nuevas posibilidades de entrenamiento, habilitar acceso a evaluaciones o títulos y actualizar la clasificación del individuo. No aplica bonificaciones universales instantáneas.

Cuando un ascenso represente una transformación extraordinaria real, sus efectos físicos, cognitivos o arcanos se registrarán como cambios específicos con fuente, coste y consecuencia. El mero cambio de número no modifica el cuerpo.

## 30. Rangos institucionales y estimaciones

Gremios, academias, ejércitos, talleres y otras instituciones pueden crear rangos propios de certificación, reputación, licencia o peligro. Estos rangos describen estándares sociales o administrativos y no son equivalentes obligatorios al Nivel de Trayectoria.

La evaluación de una entidad puede ser incompleta. Un aventurero puede ocultar capacidades; un monstruo puede ser mal clasificado; un artesano puede poseer maestría no reconocida por un gremio. La certificación no crea la capacidad: acredita que una institución ha observado evidencia suficiente según sus reglas.

# PARTE VIII — CLASES, PERFILES Y ESPECIALIZACIÓN

## 31. Qué es una clase

Una clase representa una orientación reconocible de formación, práctica, predisposición, función o especialización. Es una forma de describir la trayectoria del individuo, no una estructura que lo encierra.

La clase puede facilitar el aprendizaje de conocimientos relacionados, orientar la búsqueda de maestros, herramientas o métodos y ofrecer una identidad social. No entrega técnicas, atributos, hechizos, armas, equipo ni permisos automáticamente.

## 32. Adquisición y reconocimiento de clase

Una clase no se obtiene simplemente seleccionándola en un menú o alcanzando un nivel. Puede reconocerse a partir de evidencia acumulada de:

- práctica sostenida en una disciplina;
- conocimientos pertinentes;
- desempeño verificable;
- métodos de entrenamiento;
- continuidad o propósito de la trayectoria;
- reconocimiento social, profesional o institucional cuando corresponda.

Pueden coexistir cuatro perspectivas distintas:

1. **Autoidentificación:** cómo se describe el individuo a sí mismo.
2. **Perfil observado:** qué capacidades y prácticas demuestra realmente.
3. **Reconocimiento social:** cómo lo clasifican otros individuos o comunidades.
4. **Certificación institucional:** qué título o clase reconoce una organización.

Estas perspectivas pueden discrepar. Ninguna debe reescribir automáticamente las capacidades reales.

## 33. Clases múltiples, híbridas y cambio de trayectoria

Un individuo puede desarrollar varias clases, perfiles o especializaciones simultáneamente. No existe un límite universal de ranuras ni prohibición de combinar disciplinas.

Las combinaciones pueden dar lugar a perfiles híbridos. Un espadachín puede aprender magia; un herrero puede convertirse en investigador arcano; un sanador puede desarrollar combate defensivo; un explorador puede especializarse en cartografía y supervivencia.

Cambiar de interés no borra lo aprendido. Algunas prácticas pueden perder dominio por desuso, pero la historia y el conocimiento conservado permanecen según las reglas de memoria y deterioro.

## 34. Influencia de clase en el aprendizaje

Una clase puede aportar predisposición o facilitar métodos de aprendizaje, pero su efecto debe combinarse con capacidad individual, aptitud del dominio, conocimientos previos, calidad de enseñanza y práctica.

La clase no puede conceder una bonificación duplicada por una aptitud ya contada. Tampoco garantiza que el individuo sea bueno en su propia área: un Guerrero puede tener aptitud marcial mediocre y un artesano sin clase marcial puede llegar a ser un excelente combatiente mediante entrenamiento.

## 35. Catálogo inicial de perfiles de clase

El catálogo siguiente cubre las necesidades iniciales y es deliberadamente abierto. Se introducen **nombres de catálogo distintivos** para alejar el proyecto de etiquetas genéricas repetidas. Estos rótulos son nombres funcionales de referencia, no afirman todavía que todas las culturas del mundo utilicen la misma lengua o denominación. Las culturas podrán tener variantes, traducciones, títulos locales y nombres propios.

### 35.1. Primera línea y combate cercano

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Kharven** | Combatiente versátil de primera línea; combina presión, defensa y adaptación |
| **Dhorak** | Guardián de formación; protege aliados y controla el espacio |
| **Rhaed** | Especialista en espada y técnica de filo |
| **Thyren** | Duelista; prioriza distancia, lectura, precisión y respuesta individual |
| **Othrak** | Lancero o combatiente de armas de asta; controla alcance y aproximación |
| **Varkesh** | Combatiente de impulso; acepta riesgo para producir presión física elevada |
| **Kaedran** | Especialista en escudo, bloqueo, escolta y protección localizada |
| **Mordren** | Luchador de agarres, derribos y combate cercano sin depender de armas |

### 35.2. Distancia, caza y hostigamiento

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Saelith** | Arquero; domina arco, selección de trayectoria y posición |
| **Vaerik** | Tirador de precisión con armas de proyectil compatibles |
| **Orrakai** | Hostigador móvil; ataca, cambia de posición y evita fijar el frente |
| **Mavrith** | Cazador; rastrea, interpreta señales y prepara la aproximación |
| **Khorad** | Especialista en trampas, mecanismos y control del terreno |
| **Aelkar** | Lanzador de jabalinas, cuchillos u otras armas arrojadizas |

### 35.3. Sigilo e infiltración

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Nyrvek** | Infiltrador; prioriza acceso, ocultación y movimiento discreto |
| **Eshkar** | Asesino; prepara ataques de precisión contra objetivos vulnerables |
| **Velthir** | Ladrón; apertura, sustracción, escape y manipulación de cerraduras |
| **Soryn** | Espía; obtiene, verifica y transmite información sin depender del combate |
| **Ithrak** | Saboteador; altera sistemas, suministros y estructuras con conocimiento suficiente |

### 35.4. Magia y artes arcanas

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Thael** | Estudioso y ejecutor de formulaciones arcanas generales |
| **Orvakh** | Brujo de operaciones arcanas complejas, restricciones y efectos condicionados; no presupone pactos divinos |
| **Elarith** | Especialista en Resonancias elementales o fenómenos naturales compatibles |
| **Ysvara** | Ilusionista; altera señales perceptivas dentro de límites verificables |
| **Vaelkor** | Invocador o modelador de entidades/estructuras arcanas, sujeto a fuentes y contratos |
| **Ordel** | Sellador; prepara marcas, anclajes, cierres y condiciones persistentes |
| **Oryth** | Defensor arcano; barreras, desvío, refuerzo y protección |
| **Keldran** | Mago de combate; integra formulación y movimiento en enfrentamientos |
| **Avarok** | Combatiente mixto que combina arma y operaciones arcanas aprendidas |
| **Kelyth** | Investigador arcano; analiza Trama, Resonancias, hechizos y fenómenos |

### 35.5. Sanación y apoyo

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Maerith** | Sanador; diagnóstico, estabilización, tratamiento y curación según dominio |
| **Aunor** | Apoyo integral; coordina ayuda, preparación y asistencia al grupo |
| **Kelvarn** | Médico de campo; primeros auxilios, hemorragias y evacuación |
| **Daryth** | Especialista en barreras, protección y mitigación de riesgos |
| **Ossira** | Especialista en recuperación, rehabilitación y cuidados prolongados |
| **Veylor** | Coordinador táctico; transmite órdenes, información y sincroniza aliados |

### 35.6. Oficios, fabricación y materiales

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Darsk** | Herrero y trabajador de metales; forja, tratamiento y reparación |
| **Kovaren** | Armero; diseño, equilibrio y fabricación de armas |
| **Rasken** | Armero de protección; armaduras, escudos y protección localizada |
| **Izhven** | Alquimista; mezcla, extracción y procesos materiales compatibles |
| **Runkar** | Grabador de sellos, inscripciones y sistemas preparados |
| **Merovan** | Artesano general; domina fabricación y reparación de objetos diversos |
| **Saevra** | Herborista y recolector especializado en materias orgánicas |
| **Ormek** | Ingeniero y constructor; mecanismos, estructuras y herramientas |
| **Ilyra** | Sastre, curtidor o especialista en materiales flexibles y vestimenta técnica |
| **Kethren** | Joyero y lapidario; corte, valoración y montaje de gemas y cristales |

### 35.7. Exploración, conocimiento y sociedad

| Nombre de catálogo | Perfil funcional |
|---|---|
| **Kheran** | Cartógrafo y topógrafo; registra rutas, distancias y estructura espacial |
| **Theryn** | Explorador de Mazmorra; reconoce salas, amenazas, rutas y recursos |
| **Myrak** | Superviviente; administra recursos, refugio, descanso y riesgo ambiental |
| **Edravel** | Estratega; analiza sistemas complejos y prepara planes con información limitada |
| **Selyr** | Investigador; formula hipótesis, diseña pruebas y registra evidencias |
| **Vaedrin** | Erudito; organiza y relaciona conocimiento teórico |
| **Rhovan** | Negociador y mediador; acuerdos, intercambios y resolución de disputas |
| **Kelthas** | Comerciante y tasador; mercados, valoración, procedencia y negociación |
| **Otheryn** | Maestro o instructor; transmisión, evaluación y corrección del aprendizaje |
| **Varael** | Administrador y organizador; logística, recursos y coordinación institucional |

**Nota de nomenclatura:** estos nombres son la primera propuesta de identidad de catálogo. La procedencia lingüística, etimología, variaciones regionales y nombres culturales se definirán con SR-13 y la guía de nomenclatura. No se declara que sean palabras de Veyrath ni que pertenezcan a una única cultura.

## 36. Sanador y apoyo como perfiles esenciales, no obligatorios

La capacidad de primeros auxilios básicos no estará monopolizada por una clase. Cualquier entidad que haya aprendido y pueda ejecutar la acción podrá prestar ayuda básica.

Un perfil como Maerith o Kelvarn facilitará el aprendizaje médico y el acceso a procedimientos especializados, pero no garantiza curar cualquier lesión. La curación arcana debe respetar Veyrath y SR-07; la cirugía y medicina deben respetar anatomía, recursos, herramientas y tiempo.

Los perfiles de apoyo pueden incluir logística, carga, inventario, primeros auxilios, evacuación, análisis, coordinación, asistencia táctica, barreras, protección, administración de consumibles y apoyo arcano. No todos dominarán todos los campos.

# PARTE IX — NPC, MONSTRUOS Y PROGRESIÓN AUTÓNOMA

## 37. Mismas leyes fundamentales

Los NPC y monstruos no son decorado escalado al jugador. Son entidades con atributos, aptitudes, conocimientos, experiencias, limitaciones y trayectorias propias.

Un NPC puede aprender un oficio, retirarse del combate, entrenar, estudiar, enseñar, cambiar de clase, especializarse o perder dominio por desuso. Un monstruo puede aprender tácticas, reconocer rutinas, adaptar su conducta, desarrollar capacidades o cambiar su perfil por mecanismos válidos.

No todas las entidades necesitan niveles visibles, clases reconocidas ni estadísticas con idéntica presentación. El mundo puede utilizar evaluaciones internas equivalentes para la simulación sin imponerles una identidad de RPG.

## 38. Progresión de monstruos

La progresión monstruosa debe distinguir:

- crecimiento por entrenamiento y uso;
- aprendizaje por enfrentamientos y experiencia;
- adaptación táctica individual;
- fortalecimiento por longevidad establecido en SR-08;
- cambios fisiológicos o rasgos arcanos permitidos;
- evolución poblacional y nuevos linajes.

El fortalecimiento por longevidad no equivale a nivel, clase o habilidad. Un monstruo antiguo puede ser poderoso por haber sobrevivido y acumulado capacidades, pero no necesita ser más inteligente ni más técnico en todos los dominios.

## 39. Sin escalado dinámico del enemigo

El sistema NO DEBE modificar el nivel, atributos, salud, daño o equipo de una criatura solo para mantener una dificultad fija alrededor del jugador.

La dificultad surge de la región, piso, especie, individuo, experiencia, edad del monstruo, ecología, equipo, preparación, circunstancias y decisiones. Un jugador puede encontrar un enemigo muy superior, uno débil, uno enfermo, uno joven o uno excepcional.

## 40. Aprendizaje colectivo y transmisión

Las entidades pueden enseñar, entrenar, escribir manuales, compartir conocimiento, fundar escuelas, crear tradiciones y transmitir técnicas. La difusión requiere canales y tiempo reales.

Un gremio puede preservar un método; una familia puede transmitir una práctica; un maestro puede formar aprendices; un grupo de aventureros puede desarrollar una táctica. La memoria colectiva puede contener errores, pérdidas, mitos o versiones contradictorias.

# PARTE X — REENCARNACIÓN Y CONTINUIDAD DE LA PROGRESIÓN

## 41. Identidad y nueva vida

La reencarnación se rige por SR-01 y SR-03. SR-12 no altera los mecanismos de identidad, continuidad ni distribución de memoria aprobados en esos documentos.

Una nueva vida puede conservar recuerdos, conocimientos, hábitos, preferencias, experiencias de combate o memoria procedimental de manera total, parcial, fragmentaria o latente, según el mecanismo aplicable. No se presume que todo sea conservado.

## 42. Lo que puede conservarse

Según la forma de reencarnación y el estado de la memoria, pueden persistir:

- recuerdos autobiográficos;
- conocimiento teórico;
- comprensión de principios;
- idiomas o vocabulario;
- patrones tácticos;
- hábitos y memoria procedimental;
- reconocimiento de amenazas;
- preferencias y predisposiciones;
- experiencias emocionales;
- aptitudes o rasgos que SR-01/03 permitan conservar.

La conservación no implica acceso perfecto. Un recuerdo puede ser fragmentario, inaccesible, confundido, emocionalmente intenso o difícil de traducir a un cuerpo nuevo.

## 43. Lo que no se transfiere automáticamente

No se transfieren automáticamente:

- fuerza, velocidad, masa ni estructura física del cuerpo anterior;
- órganos, sentidos o anatomía que el nuevo cuerpo no posea;
- reservas de HP, MP o energía;
- equipo, dinero, propiedad o inventario;
- licencias, reputación y reconocimiento institucional;
- dominio corporal que la nueva anatomía no pueda ejecutar;
- acceso a una técnica que dependa de recursos o mecanismos ausentes.

Una persona reencarnada puede recordar cómo blandía una espada con maestría, pero necesitará adaptar postura, alcance, peso, equilibrio y control motor al cuerpo actual. La memoria facilita el reaprendizaje; no elimina el proceso.

## 44. Memoria de combate y adaptación corporal

La experiencia de combate de una vida anterior puede facilitar la comprensión de patrones, tácticas y decisiones. El nuevo individuo deberá practicar para convertir esa comprensión en ejecución fiable.

Un hábito automático puede no ajustarse a una anatomía diferente. La entidad puede cometer errores durante la adaptación. El sistema debe permitir conservar la ventaja intelectual sin regalar la capacidad física completa.

# PARTE XI — CONDICIONES TEMPORALES Y ESTADOS

## 45. Estados y modificadores

Los atributos y capacidades pueden verse modificados temporalmente por:

- fatiga, descanso insuficiente y agotamiento;
- dolor, lesión, enfermedad y recuperación;
- hambre, sed, temperatura y exposición;
- drogas, venenos, medicamentos y sustancias;
- estados mágicos, buffs y debuffs;
- concentración, pánico, miedo, motivación o desorientación;
- equipo, peso, postura y restricciones ambientales;
- condiciones sociales o psicológicas pertinentes.

Cada estado debe declarar su origen, objetivo, variables afectadas, intensidad, duración o condición de terminación, acumulación, resistencias, tratamiento y consecuencias. Una mejora temporal no se registra como crecimiento permanente.

## 46. Fatiga, recuperación y mantenimiento

El progreso físico requiere alternar carga y recuperación de manera compatible con el organismo. La recuperación depende de descanso, alimentación o fuente equivalente, hidratación o mantenimiento aplicable, tratamiento, ambiente y tiempo.

Un personaje puede perder rendimiento mientras conserva su dominio; descansar puede restaurar rendimiento sin aumentar maestría. A la inversa, una lesión puede deteriorar la ejecución sin borrar el conocimiento aprendido.

# PARTE XII — DATOS, TRAZABILIDAD Y REGLAS DE IMPLEMENTACIÓN

## 47. Perfil de progresión mínimo

El modelo lógico de cada entidad que utilice progresión debe poder registrar, según corresponda:

- identidad estable y procedencia;
- definición de especie/estructura y versión;
- atributos base y actuales;
- aptitudes de aprendizaje generales y por dominio;
- valores derivados y recursos aplicables;
- estado temporal, lesión, fatiga y restricciones;
- potencial estimado y grado de incertidumbre;
- conocimientos y fuentes de adquisición;
- habilidades, variantes y requisitos;
- nivel de dominio y evidencias;
- experiencia por dominio o eventos relevantes;
- nivel de trayectoria y evidencia de ascenso;
- clases, perfiles, especializaciones y fechas de reconocimiento;
- entrenamiento, maestros, prácticas y resultados;
- cambios por evolución, adaptación o transformaciones;
- memoria y elementos conservados de vidas anteriores, cuando corresponda;
- eventos de pérdida, deterioro, olvido, recuperación o reaprendizaje.

No todas las entidades tendrán todos los campos. Los atributos no aplicables deben declararse como tales y no rellenarse con valores ficticios.

## 48. Registro causal del progreso

Los cambios relevantes deben tener procedencia. El sistema debe poder responder:

- qué capacidad cambió;
- cuál era su estado previo y cuál es el actual;
- qué proceso produjo el cambio;
- cuándo ocurrió y durante cuánto tiempo;
- qué entrenamiento, conocimiento, fuente, maestro o acontecimiento intervino;
- qué costes, lesiones, recursos y consecuencias existieron;
- quién validó o reconoció el cambio, si hubo autoridad institucional;
- si el cambio es temporal, estable, reversible o hereditario.

La experiencia repetitiva trivial no requiere conservar cada segundo, pero la evidencia suficiente para justificar ascensos, maestrías, títulos y transformaciones importantes debe persistir.

## 49. Simulación fuera de pantalla

La progresión continúa cuando una entidad tiene oportunidades de entrenar, estudiar, trabajar, combatir, explorar, descansar o adaptarse durante el tiempo global. El sistema puede resumir actividades repetitivas mediante SR-06, pero debe conservar costes, tiempo, riesgo, recursos y resultados coherentes.

No se concederá dominio experto a un NPC solo porque transcurrió tiempo. Deben existir actividades, oportunidades y condiciones compatibles con el progreso.

# PARTE XIII — CALIBRACIÓN Y DECISIONES RESERVADAS

## 50. Parámetros sujetos a calibración

Los siguientes valores deberán ajustarse mediante pruebas y datos del juego, sin cambiar los principios de SR-12:

- escala de presentación de cada atributo;
- curvas de crecimiento y rendimientos decrecientes;
- límites de potencial por especie, estructura y edad;
- conversión de atributos a rendimiento físico;
- factores de fatiga y recuperación;
- coste y ritmo de entrenamiento;
- aporte relativo de instrucción, práctica, observación y reflexión;
- actualización de maestría por disciplina;
- requisitos exactos de ascenso de Nivel de Trayectoria;
- umbrales de certificación institucional;
- influencia cuantitativa de predisposición de clase;
- retención y deterioro de dominio por desuso;
- memoria procedimental transferida mediante reencarnación;
- aprendizaje de patrones y cantidad de evidencia necesaria;
- valores particulares de aptitud por especie y entidad.

No deben introducirse constantes universales solo para simplificar el balance si contradicen diferencias anatómicas, cognitivas o ecológicas.

## 51. Catálogos y desarrollos posteriores

Quedan reservados para anexos o catálogos subordinados:

- ficha completa de cada atributo y su curva;
- catálogo exhaustivo de habilidades y técnicas;
- catálogo cultural de clases, títulos y denominaciones regionales;
- árbol abierto de especializaciones por disciplina;
- métodos, instituciones, maestros y pruebas de formación;
- clases particulares de especies, monstruos y entidades no biológicas;
- requisitos de habilidades arcanas por palabra, hechizo y Resonancia;
- progresión de oficios y calidad de fabricación junto a SR-10;
- fórmulas detalladas de experiencia y ascenso;
- efectos de entrenamiento por edad, especie, anatomía y longevidad;
- compatibilidad de prótesis, cuerpos transformados y nuevas anatomías;
- perfiles particulares de NPC importantes.

Los nombres de catálogo introducidos en §35 son referencias iniciales y no fijan por sí solos una lengua, cultura, origen geográfico o historia. Su desarrollo debe seguir la Guía de Nomenclatura del Universo y la normativa social/cultural futura.

# PARTE XIV — PRUEBAS OBLIGATORIAS

## 52. Escenarios de validación

1. Dos individuos de la misma especie y nivel tienen atributos y dominios diferentes por su historia.
2. Un personaje sube de nivel sin recibir aumentos automáticos en todos sus atributos.
3. Un individuo aumenta fuerza mediante entrenamiento y recuperación adecuados, con costes y límites anatómicos.
4. Un individuo intenta entrenar con lesión y la lesión impone restricciones funcionales reales.
5. El descanso restaura rendimiento temporal sin incrementar automáticamente dominio.
6. Un personaje conserva conocimiento teórico, pero pierde ejecución práctica por desuso.
7. La práctica repetitiva sin retroalimentación presenta rendimiento decreciente.
8. Un fracaso produce aprendizaje únicamente cuando hay percepción y comprensión suficientes.
9. Un grimorio transmite información sin conceder dominio instantáneo.
10. Aprender todas las palabras de una fórmula Veyrath no concede automáticamente dominio de la oración completa.
11. Un Mago aprende espada y un Herrero aprende magia sin que la clase lo prohíba.
12. Una clase reconocida no concede automáticamente habilidades, atributos ni equipo.
13. Dos entidades con la misma clase presentan capacidades diferentes.
14. Un individuo se identifica con una clase que el gremio no reconoce; ninguna perspectiva altera por sí sola su capacidad objetiva.
15. Un especialista cambia de trayectoria sin perder todo lo aprendido.
16. Un NPC progresa sin presencia del jugador mediante entrenamiento y oportunidades reales.
17. Un monstruo aprende a anticipar un patrón repetido tras observación suficiente, pero no instantáneamente.
18. Un monstruo antiguo es fuerte por longevidad, sin que esa fuerza implique automáticamente inteligencia o maestría.
19. Un enemigo de nivel inferior conserva su estado y no escala artificialmente al nivel del jugador.
20. Una entidad con alta memoria y bajo razonamiento muestra un perfil cognitivo diferenciado.
21. Una entidad con elevada capacidad de aprendizaje no adquiere una habilidad sin exposición ni práctica.
22. Una entidad con baja aptitud progresa lentamente, pero puede alcanzar dominio mediante condiciones y tiempo suficientes.
23. Un mismo acontecimiento provoca distintas respuestas emocionales según RE, vínculos, experiencia y exposición.
24. Una resiliencia elevada no vuelve imposible el pánico o el duelo.
25. Una entidad reencarnada conserva recuerdos procedimentales, pero debe adaptarlos a una anatomía nueva.
26. La reencarnación no transfiere automáticamente HP, MP, fuerza física, equipo ni propiedad.
27. Una entidad no biológica utiliza capacidades equivalentes apropiadas sin recibir atributos humanos ficticios.
28. Una criatura con percepción sensorial distinta aprende solo patrones que pueda detectar.
29. Un título institucional se pierde o cambia sin alterar automáticamente la capacidad real que representa.
30. Un ascenso se rechaza cuando la actividad registrada es repetitiva, trivial o insuficiente para los méritos exigidos.
31. Un entrenamiento produce una lesión por sobrecarga y el sistema registra coste, pausa y recuperación.
32. Un cambio evolutivo individual afecta atributos o potencial solo con mecanismo, fuente y consecuencias verificables.
33. La simulación fuera de pantalla conserva progreso y costes de actividad sin registrar cada fotograma.
34. Repetir una simulación con idénticas entradas deterministas produce un resultado reproducible.

## 53. Criterios de cumplimiento

SR-12 se considera normativamente establecido cuando el sistema distingue de forma verificable atributos, estados, conocimiento, habilidades, dominio, experiencia, nivel, clase y evolución; permite progresión autónoma de jugadores, NPC y monstruos; registra fuentes y costes de los cambios importantes; conserva límites anatómicos, cognitivos y arcanos; y evita otorgar capacidades por conveniencia, repetición trivial o mero aumento de nivel.

---

# DECLARACIÓN NORMATIVA FINAL

La progresión no es una escalera que todos ascienden de la misma manera. Es la historia comprobable de aquello que una entidad ha vivido, comprendido, practicado, soportado, construido y transformado.

Un nivel puede resumir una trayectoria, pero no reemplazarla. Una clase puede describir una vocación, pero no encerrar el futuro. Un atributo puede expresar una capacidad, pero no ignorar el cuerpo que la sostiene. La experiencia puede orientar el aprendizaje, pero no comprar conocimiento. La memoria puede conservar una vida anterior, pero no regalar el cuerpo que ya no existe.

Cada jugador, NPC y monstruo debe poder convertirse en algo distinto por sus propias causas, dentro de las leyes del universo. Ningún progreso importante existe sin historia, fuente, coste o consecuencia.

**SR-12 v0.1 — NORMATIVA OFICIAL APROBADA.**

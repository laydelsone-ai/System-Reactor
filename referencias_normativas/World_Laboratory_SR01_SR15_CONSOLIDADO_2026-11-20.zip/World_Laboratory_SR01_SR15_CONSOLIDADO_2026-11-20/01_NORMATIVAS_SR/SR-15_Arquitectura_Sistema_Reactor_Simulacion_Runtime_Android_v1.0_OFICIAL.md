# WORLD LABORATORY / SISTEMA REACTOR

# SR-15 — ARQUITECTURA DEL SISTEMA REACTOR, SIMULACIÓN, RUNTIME E IMPLEMENTACIÓN ANDROID

**Código:** SR-15  
**Versión:** 1.0  
**Estado:** NORMATIVA TÉCNICA OFICIAL — APROBADA POR AUTORIZACIÓN EXPRESA DEL AUTOR EL 2026-11-20.  
**Dependencias:** SR-01 a SR-14.  
**Ámbito:** arquitectura lógica, ejecución de simulación, agentes autónomos, tiempo, persistencia, navegación, combate, presentación, herramientas de observación, Android, pruebas, despliegue y evolución técnica.  
**Plataforma objetivo inicial:** Android.  
**Motor aprobado para la implementación inicial:** Godot 4.7.2 Standard, GDScript.  
**Estilo visual aprobado:** semi-realista estilizado, mundo 3D con presentación 2.5D, cámara isométrica ortográfica.  

---

## CONTROL DEL DOCUMENTO

SR-15 convierte las obligaciones de SR-01 a SR-14 en contratos técnicos de implementación y verificación. No reemplaza las normas de dominio ni convierte decisiones técnicas en autoridad sobre el canon. En caso de contradicción, prevalecen SR-01 y las normas especializadas aplicables.

La aprobación de SR-15 autoriza esta arquitectura como dirección técnica oficial. No significa que los sistemas descritos ya estén implementados, compilados, probados o optimizados. Cada estado de implementación debe demostrarse por artefactos, pruebas y resultados reproducibles.

### Convenciones normativas

- **DEBE:** requisito obligatorio para toda implementación aplicable.
- **NO DEBE:** comportamiento prohibido.
- **PUEDE:** posibilidad permitida, no garantizada.
- **CALIBRACIÓN:** valor que exige pruebas y puede ajustarse sin cambiar el principio.
- **RESERVADO:** decisión de contenido o parámetro todavía no fijado.
- **IMPLEMENTADO:** solo puede usarse cuando exista código verificable.
- **VALIDADO:** solo puede usarse después de superar criterios reproducibles.

## PARTE I — PROPÓSITO Y VISIÓN TÉCNICA

### 1. Propósito

SR-15 define una arquitectura ejecutable para el Sistema Reactor y World Laboratory. Su objetivo es construir una única realidad simulada, persistente y causal, en la que jugadores, NPC, monstruos, organizaciones, ecosistemas, objetos, economía, Arcana e historia compartan el mismo núcleo de verdad.

El proyecto tiene dos modos de uso que no deben convertirse en simuladores distintos:

1. **World Laboratory:** inicia y ejecuta un mundo sin necesidad de crear un jugador humano. El Observatorio permite inspeccionar agentes, territorios, expediciones, combates, cambios ecológicos, economía, eventos y crónicas.
2. **RPG Android:** permite que una persona se incorpore como participante del mundo. El personaje jugador se integra como una entidad con identidad, capacidades, memoria, motivaciones, recursos, riesgos y consecuencias. No se crea un segundo mundo simplificado para el modo jugador.

Ambos modos DEBEN usar los mismos contratos de entidad, tiempo, causalidad, comandos, eventos, sistemas de dominio y persistencia. La diferencia principal está en la interacción y la presentación.

### 2. Resultado que debe producir el sistema

El sistema debe permitir que el universo:

- exista y avance sin el jugador;
- tenga habitantes con identidad, necesidades, memoria, objetivos y conocimiento limitado;
- genere conductas y acontecimientos por mecanismos generales y reglas causales, no por una lista de escenas precocinadas;
- mantenga rastros de hechos, decisiones, transferencias, daños, descubrimientos y consecuencias;
- simule procesos a distintos niveles de detalle sin congelar regiones lejanas;
- continúe tras cerrar y reabrir la aplicación, dentro de los límites honestos de un dispositivo offline;
- represente la misma realidad lógica en el Observatorio y en el juego;
- admita contenido diseñado manualmente —historia, tutoriales, especies iniciales, misiones, mapas y hechizos— sin forzar los resultados narrativos;
- se ejecute inicialmente como aplicación Android offline-first, sin servidor ni API pagada obligatoria.

### 3. No objetivos y límites

SR-15 NO autoriza:

1. convertir el proyecto en un MMO compartido por múltiples dispositivos sin una autoridad online común;
2. depender de un LLM remoto o de una API pagada para cada NPC, combate o ciclo de simulación;
3. permitir que un LLM escriba directamente el estado objetivo o confirme eventos;
4. usar escenas, animaciones, partículas o interfaces como autoridad de la realidad;
5. mantener todos los modelos, todos los agentes y toda la geometría cargados simultáneamente en Android;
6. crear microservicios, colas distribuidas y bases de datos remotas antes de que una necesidad comprobada lo justifique;
7. fingir autonomía con rutinas visuales o misiones cableadas una por una;
8. afirmar que un APK que abre una escena vacía ya es un videojuego funcional;
9. asumir que las dimensiones de mapa, número máximo de NPC, frecuencia del scheduler o presupuestos de memoria ya están calibrados;
10. introducir cambios en las normas SR-01 a SR-14 por comodidad del código.

## PARTE II — JERARQUÍA, AUTORIDAD Y CONTRATOS

### 4. Jerarquía de autoridad

Toda acción técnica DEBE respetar el orden constitucional de SR-01. Para la implementación se aplicará esta lectura:

1. SR-01 fija existencia, identidad, causalidad, muerte, tiempo, persistencia, agencia y gobernanza.
2. SR-02 fija arquitectura del Sistema Rector, autoridades y contratos entre motores.
3. SR-03 fija identidad, inteligencia, memoria, aprendizaje y evolución individual.
4. SR-04 fija realidad híbrida, continuidad, persistencia, crónicas y mundo offline.
5. SR-05 fija creación, procedencia, materiales, objetos, organismos y assets.
6. SR-06 fija World Laboratory, Simulation Kernel, scheduler, agentes autónomos, Observatorio y reproducción histórica.
7. SR-07 fija leyes naturales, Arcana, Trama, flujo, Resonancias, costes y causalidad física/arcana.
8. SR-08 fija biología, fisiología, reproducción, ecología, monstruos y entidades activas no biológicas.
9. SR-09 y su Anexo A fijan combate, daño, curación, clases de combate, aprendizaje táctico, Veyrath y 72 hechizos de referencia para pisos 1–5.
10. SR-10 fija economía, propiedad, comercio, recursos, botín y fabricación.
11. SR-11 fija geografía, asentamientos, continuidad espacial y Mazmorra.
12. SR-12 fija progresión, atributos, experiencia, clases, dominio y aptitudes.
13. SR-13 fija sociedad, culturas, instituciones y papel civilizatorio de la Arcana.
14. SR-14 fija historia fundacional, misiones diseñadas, tutoriales y narrativa emergente.
15. SR-15 fija cómo implementar, ejecutar, almacenar, mostrar y validar lo anterior.

SR-15 no puede arbitrar un conflicto semántico de las normas de dominio. Debe registrar la contradicción, señalar las secciones implicadas y detener la operación en conflicto hasta que se resuelva por autoridad competente.

### 5. Separación entre cuatro clases de verdad

Todo dato debe poder identificarse como una de estas categorías:

- **Estado objetivo:** lo que el mundo determina que existe o ha ocurrido.
- **Observación:** lo que un agente o sensor pudo percibir.
- **Creencia/conocimiento:** lo que un agente recuerda, infiere o considera cierto.
- **Presentación:** lo que la interfaz muestra al usuario.

Una creencia equivocada no cambia el estado objetivo. Una pista no confirmada no es un hecho. Una animación no es prueba de daño. Una flecha de misión no concede conocimiento al personaje. El Observatorio puede mostrar el estado objetivo, pero debe distinguirlo de la información que cada individuo posee.

### 6. Autoridades de dominio

Cada módulo que pueda confirmar cambios persistentes debe declarar una autoridad de dominio. Como mínimo:

| Dominio | Autoridad responsable |
|---|---|
| Identidad y existencia | Entity Registry / Identity Service |
| Estado del mundo y causalidad | World State + Causal Validator |
| Cognición y memoria | Cognitive Engine / Memory Engine |
| Biología y ecología | Biology & Ecology Domain |
| Combate y lesiones | Combat & Physiology Domain |
| Arcana y hechizos | Arcane Domain, limitado por SR-07 y SR-09 Anexo A |
| Economía y propiedad | Economy & Inventory Domain |
| Geografía y navegación | World Geography / Navigation Domain |
| Sociedad y organizaciones | Social & Institution Domain |
| Misiones e historia | Narrative Domain, sin autoridad sobre resultados físicos |
| Persistencia | Persistence Layer, sin derecho a inventar hechos |
| Presentación | Client/Presentation Layer, sin autoridad sobre el estado |

### 7. Flujo obligatorio de una acción

Toda acción con efectos persistentes debe recorrer este flujo:

1. **Intención:** una entidad formula un objetivo o una acción; la intención no cambia todavía el mundo.
2. **Percepción/contexto:** el agente utiliza solo información a la que tuvo acceso.
3. **Plan:** se produce una propuesta de acción estructurada.
4. **Comando:** la propuesta se transforma en un comando tipado, con actor, objetivo, tiempo, contexto y precondiciones.
5. **Validación:** el dominio competente valida identidad, permisos, estado, recursos, geometría, capacidades, causalidad y concurrencia.
6. **Resolución:** el sistema calcula el resultado conforme a las leyes y al nivel de detalle aplicable.
7. **Evento confirmado:** solo después de validar se registra el evento.
8. **Actualización:** se modifica el estado materializado y se generan efectos secundarios válidos.
9. **Percepción y memoria:** agentes afectados pueden percibir el hecho y recordarlo según sentidos, atención, distancia y capacidad.
10. **Presentación:** interfaz, animación, sonido y efectos representan el resultado ya confirmado.

Una acción rechazada puede producir un evento de intento fallido si aporta información o historia, pero no debe aplicar efectos que el comando no consiguió.

## PARTE III — ARQUITECTURA DEL RUNTIME

### 8. Decisión arquitectónica: monolito modular

La primera implementación DEBE ser un **monolito modular local**, separado por dominios y contratos. No se dividirá de inicio en microservicios. Una sola aplicación Android contiene la simulación y la presentación, pero los límites de dominio deben permitir extraer componentes a futuro si el rendimiento o la sincronización lo justifican.

El proyecto no debe crear un nodo Godot para cada entidad lógica del mundo. Los datos de entidades y agentes se almacenan en estructuras de dominio ligeras. Los nodos de Godot se reservan principalmente para objetos visibles, físicas activas, interacción y componentes de escena actualmente cargados.

### 9. Capas del sistema

1. **Application Shell:** ciclo de vida Android, inicialización, configuración, perfiles, menú, guardado seguro y entrada/salida.
2. **Simulation Kernel:** reloj del mundo, scheduler, colas de trabajo, estado global, orden de resolución y registro de eventos.
3. **Domain Engines:** identidad, cognición, memoria, creación, biología, ecología, combate, Arcana, economía, sociedad, geografía y narrativa.
4. **Infrastructure:** almacenamiento local, serialización, migraciones, random determinista, telemetría local, caché y recursos.
5. **Presentation:** cámara, interfaz, input, modelos, animaciones, audio, VFX, LOD y carga visual de sectores.
6. **Observatory Tools:** inspección, búsqueda de eventos, métricas y reproducción de crónicas; lectura pasiva por defecto.
7. **Build & Test:** importación de assets, análisis, pruebas, exportación Android y empaquetado.

### 10. Módulos mínimos

| Módulo | Responsabilidad | No puede hacer |
|---|---|---|
| SystemCore | Coordinar módulos, versiones, arranque y cierre | Saltarse validadores |
| EntityRegistry | IDs, continuidad y referencias | Fusionar identidades por similitud visual |
| WorldModel | Estado objetivo y relaciones espaciales | Alterarse por texto narrativo no validado |
| CognitiveEngine | percepción, necesidades, objetivos, decisión | conocer datos no observados |
| MemoryEngine | recuerdos, fuentes, confianza y olvido | convertir rumor en hecho |
| LearningEngine | aprendizaje, dominio y adaptación | conceder dominio por una lectura aislada |
| CreationEngine | crear entidades, especies, objetos y recursos | crear activos sin procedencia o validar capacidades visuales como físicas |
| BiologyEcologyEngine | procesos biológicos y poblacionales | generar individuos sin mecanismos definidos |
| CombatEngine | acciones en tiempo real, daño y lesiones | depender de animaciones para calcular impacto |
| ArcaneEngine | formular, validar y resolver magia | saltarse Trama, costes o gramática Veyrath |
| EconomyEngine | transacciones, propiedad y valoración | inventarios o dinero infinitos |
| GeographyEngine | regiones, pisos, conexiones y coordenadas | cambiar la geografía por la cámara |
| NavigationEngine | rutas regionales y movimiento local | teletransportar como sustituto de locomoción normal |
| SocialEngine | familias, instituciones, leyes y relaciones | imponer lealtades sin causa |
| NarrativeEngine | arcos, misiones, pistas y objetivos | forzar victorias, muertes o rescates |
| ChronicleEngine | eventos, cronología y procedencia | inventar reconstrucciones exactas sin evidencia |
| PersistenceEngine | journaling, snapshots y recuperación | confirmar eventos no registrados |
| PresentationEngine | representar el estado y la interacción | definir el estado objetivo |

### 11. Contratos entre módulos

Los módulos se comunican mediante comandos, consultas y eventos tipados. No deben escribir directamente en estructuras internas de otros dominios.

- Las **consultas** no cambian estado.
- Los **comandos** solicitan un cambio y se someten a validación.
- Los **eventos** describen un hecho ya confirmado.
- Las **propuestas de IA** son datos no autoritativos hasta que se conviertan en comandos válidos.

Los comandos deben tener identificador único, actor, objetivo opcional, tiempo de mundo, versión de esquema, origen, precondiciones y datos específicos. Los eventos deben tener ID, tipo, tiempo, secuencia, participantes, ubicación, causas, consecuencias, versión de regla y procedencia.

## PARTE IV — MODELO DE ENTIDADES Y DATOS

### 12. Identidad lógica

Cada entidad persistente tiene un ID estable, no reutilizable. El nombre, el modelo 3D, la escena, el skin, la ubicación, la clase y el nivel no sirven como clave primaria. Una entidad puede existir aunque su representación no esté cargada o el asset todavía no exista.

### 13. Tipos de entidad

El runtime debe poder representar, al menos:

- organismo biológico;
- entidad activa no biológica, como gólem o no-muerto conforme a SR-08;
- objeto, herramienta, arma, armadura o material;
- recurso ambiental;
- estructura, habitación, región, piso, camino o portal;
- institución, facción, gremio, hogar o comunidad;
- fenómeno, proceso o acontecimiento;
- conocimiento, técnica, hechizo, fórmula o habilidad.

### 14. Datos mínimos de una entidad

Toda entidad persistente tendrá, según corresponda:

- ID y tipo;
- versión de esquema;
- origen y procedencia;
- tiempo de creación y estado de ciclo vital;
- posición o ubicación lógica;
- propietario, poseedor o custodio, si aplica;
- relaciones relevantes;
- plantilla/especie/clase, si aplica;
- estado objetivo actual;
- referencias a historial y eventos;
- referencia opcional a uno o más assets visuales;
- flag de persistencia y política de simulación.

### 15. Datos mínimos de un agente autónomo

Un agente incluye los campos que correspondan a su naturaleza:

1. identidad y perfil de entidad;
2. percepción y capacidades sensoriales;
3. necesidades y estados fisiológicos;
4. motivaciones, preferencias y aversiones;
5. objetivos actuales, prioridades y planes;
6. memoria episódica, semántica y procedimental según SR-03;
7. creencias e hipótesis con origen y confianza;
8. conocimientos, habilidades, dominio y aprendizaje;
9. relaciones sociales y compromisos;
10. capacidades físicas, cognitivas y arcanas;
11. recursos, inventario, propiedad y acceso;
12. tolerancias, resiliencia emocional y estados;
13. historial de decisiones y consecuencias;
14. nivel de resolución del scheduler;
15. representación visual opcional.

El agente no recibe una ficha omnisciente del mundo. Las consultas cognitivas deben filtrar el estado objetivo según sentidos, rango, oclusión, tiempo, memoria, comunicación y calidad de la fuente.

### 16. Datos declarativos frente a comportamiento

Especies, objetos, hechizos, clases, armas, estados, profesiones y misiones deben describirse con datos declarativos versionados. La lógica general resuelve su conducta. No crear un script exclusivo para cada NPC o monstruo cuando una misma regla puede operar sobre parámetros y capacidades legítimas.

Los datos declarativos deben tener validadores de integridad: IDs únicos, requisitos, tipos, rangos, referencias existentes, condiciones de uso y compatibilidad de versión.

## PARTE V — AGENTES AUTÓNOMOS E INTELIGENCIA

### 17. Arquitectura cognitiva

La inteligencia de un agente no se reduce a dos estadísticas ni a un árbol rígido de frases. El proceso mínimo es:

1. percibir señales disponibles;
2. filtrar y atender información;
3. actualizar creencias y recuerdos;
4. evaluar necesidades, motivaciones y compromisos;
5. generar objetivos candidatos;
6. valorar opciones según capacidades, conocimiento, riesgo, tiempo y recursos;
7. construir un plan;
8. solicitar acciones al dominio correspondiente;
9. observar resultados;
10. aprender de éxitos, fallos y consecuencias.

Los sistemas pueden usar Utility AI, GOAP, planificación jerárquica, máquinas de estado, árboles de comportamiento o combinaciones. Ninguna técnica concreta puede contradecir el contrato de agencia, percepción limitada, memoria o causalidad.

### 18. Diferencias individuales

Los agentes deben diferir por personalidad, aptitudes, experiencia, educación, cultura, objetivos, recuerdos, relaciones, recursos, percepción, anatomía y capacidad de aprendizaje. Los perfiles no deben ser copias que cambian solo el nombre.

### 19. Aprendizaje

El aprendizaje utiliza exposición, atención, comprensión, instrucción, práctica, retroalimentación, errores, retención y transferencia. La capacidad de aprendizaje es un modificador, no un sustituto de la práctica ni una garantía de éxito. Las clases predisponen pero no bloquean otras trayectorias. El crecimiento debe dejar trazabilidad de origen y actividad.

### 20. Adaptación táctica

Los combatientes recuerdan patrones y pueden construir hipótesis sobre hábitos de sus rivales. El motor de combate no concede contramedidas telepáticas. La adaptación exige observación repetida o evidencia clara, capacidad de interpretar el patrón y oportunidad de ejecutar una respuesta. Los umbrales de evidencia iniciales de SR-09 son parámetros de referencia calibrables.

### 21. IA generativa y modelos externos

- Ningún LLM es autoridad de dominio.
- Ningún LLM puede confirmar muertes, transacciones, heridas, descubrimientos, posesiones, cambios de ubicación o efectos arcanos.
- La IA generativa puede sugerir diálogo, hipótesis, variantes de misión, explicaciones, planes o contenido estructurado, pero los validadores deterministas aceptan, rechazan o corrigen la propuesta.
- La aplicación principal no dependerá de API remota pagada.
- Los procesos rutinarios deben funcionar con lógica local y datos.
- Los conectores de modelos serán opcionales, intercambiables y aislados; la ausencia de proveedor no detiene el mundo.
- El modelo recibe solo contexto autorizado, necesario y limitado; no se le entrega estado omnisciente para que responda como una entidad.

## PARTE VI — SCHEDULER, NIVELES DE SIMULACIÓN Y TIEMPO

### 22. Principio de simulación multiescala

El mundo no necesita ejecutar cada movimiento de cada entidad en cada fotograma. Debe conservar sus procesos y consecuencias usando distintos niveles de resolución. La reducción de detalle no autoriza desaparición, teleport narrativo, invulnerabilidad, congelación global o creación arbitraria de resultados.

### 23. Niveles de resolución

| Nivel | Dominio típico | Tratamiento |
|---|---|---|
| L0 — Interacción directa | entidades en cámara o combate inmediato | movimiento, percepción, física, combate y eventos detallados |
| L1 — Actividad local | barrio, grupo, vivienda, taller, ruta cercana | acciones frecuentes resumidas, necesidades, horarios y relaciones |
| L2 — Actividad regional | viajes, expediciones, población, comercio y ecosistema | resolución por hitos, trayectos, consumos y encuentros posibles |
| L3 — Procesos de larga duración | generaciones, stocks, migraciones, tendencias y organizaciones | agregación causal por intervalos, con individuos importantes preservados |
| L4 — Historia/estado agregado | procesos que no requieren detalle individual continuo | cálculo agregado y eventos significativos con procedencia y límites de fidelidad |

La transición entre niveles debe conservar estado, recursos, tiempo, causalidad, inventarios, lesiones, objetivos y compromisos. Si un agente entra en una situación que requiere precisión —por ejemplo, combate, lesión crítica o evento narrativamente importante— debe elevarse el nivel de resolución antes de resolver el efecto.

### 24. Priorización del scheduler

La prioridad de simulación considera:

- peligro inmediato para una entidad;
- riesgo de muerte, lesión permanente o pérdida;
- acción que afecta a varias entidades;
- consecuencias económicas o ecológicas irreversibles;
- compromisos con tiempo límite;
- interacción directa con jugador;
- causalidad pendiente de resolver;
- evento de alto impacto narrativo/social;
- costo computacional y presupuesto disponible.

La proximidad visual no es el único criterio. Una expedición distante puede merecer mayor resolución que un NPC visible esperando sin actividad relevante.

### 25. Tiempo global

El tiempo del mundo es persistente. El personaje jugador no lo controla ni lo detiene. El tiempo puede avanzar mientras la aplicación está cerrada.

Deben distinguirse:

- tiempo del mundo;
- reloj de pared del dispositivo;
- tiempo monotónico disponible durante la ejecución;
- tiempo de evento y secuencia de resolución.

Mientras la aplicación está activa, el runtime utiliza un reloj monotónico para medir intervalos y evitar saltos causados por correcciones del reloj del sistema. Al cerrar, persiste el punto de control temporal. Al reabrir, calcula el intervalo de ausencia con el reloj de pared del dispositivo, registra la fuente y aplica controles de anomalía.

### 26. Catch-up al reabrir

El catch-up no reproduce millones de fotogramas ni simula cada movimiento perdido. Debe:

1. validar y recuperar el último snapshot y diario consistente;
2. calcular el intervalo de ausencia aceptable;
3. detectar un salto temporal sospechoso;
4. procesar primero procesos críticos y eventos con plazos;
5. avanzar agendas, necesidades, viajes, producción, comercio, ecología y estados por sus modelos de resolución;
6. resolver encuentros con reglas y semillas reproducibles;
7. aplicar transiciones entre niveles de simulación;
8. registrar resumen, eventos significativos y anomalías;
9. guardar un nuevo punto de control antes de permitir interacción plena.

No se puede prometer protección absoluta frente a manipulación del reloj local en un dispositivo offline. El sistema debe limitar saltos anormales, registrar anomalías y evitar duplicar recompensas o eventos por repetición del proceso.

### 27. Frecuencias

El mundo puede usar frecuencias de actualización distintas por dominio. No se fija todavía una tasa universal de ticks ni una velocidad final de tiempo. Combate visible y física activa requieren actualización continua a la tasa del runtime; ecología, economía, agendas y simulación lejana pueden ser event-driven o por intervalos. La frecuencia concreta es CALIBRACIÓN y debe medirse en Android.

## PARTE VII — PERSISTENCIA, RECUPERACIÓN Y CONTINUIDAD OFFLINE

### 28. Autoridad local del mundo

En la primera versión offline, una instalación local mantiene un mundo individual y constituye la autoridad de ese mundo. No se presume continuidad compartida con otra instalación, teléfono o jugador. La aplicación no requiere servidor remoto, cuenta ni base de datos externa para simular y guardar el mundo.

Si en el futuro se añade mundo compartido, deberá existir una autoridad común, reconciliación de operaciones, control de concurrencia y resolución de conflictos. No se simula un mundo global compartido si cada teléfono tiene estados contradictorios y permanece desconectado.

### 29. Modelo de persistencia

La persistencia debe permitir recuperar estado objetivo, no solo la apariencia de la última escena. El diseño recomendado es:

- **Diario de eventos append-only:** eventos confirmados, secuencia, versión, instante, participantes, ubicación y datos necesarios para recuperar.
- **Snapshots:** estado materializado por mundo/región y versión de esquema.
- **Datos estáticos versionados:** plantillas, catálogos, reglas, assets, hechizos y contenido aprobado.
- **Índices derivados:** búsquedas y vistas reconstruibles que no sean autoridad.
- **Registro de migraciones:** transformación explícita y comprobable entre versiones.

Para la primera compilación se admite un backend local de archivos versionados (JSON/JSONL o formato local equivalente) detrás de una interfaz de persistencia, siempre que soporte escritura atómica, verificación, journal, checkpoint y recuperación. Un motor SQLite u otra base embebida puede adoptarse después de pruebas de escala, sin cambiar los contratos de dominio. No incluir una extensión nativa sin comprobar compatibilidad y exportación Android.

### 30. Transacciones e idempotencia

Una transferencia, muerte, recompensa, nacimiento, cambio de propietario o consumo de recurso debe evitar duplicación tras cierre inesperado. Las operaciones con efectos múltiples se aplican como transacciones lógicas: todas se confirman o ninguna. Cada comando con riesgo de repetición tendrá clave/idempotency ID. Un evento confirmado no se vuelve a aplicar si el proceso de catch-up se ejecuta otra vez.

### 31. Guardado y cierre

El runtime debe guardar en momentos de riesgo y antes de suspender la aplicación, además de mantener checkpoints periódicos. Los archivos se escriben primero en temporales, se verifican y luego se sustituyen atómicamente cuando el sistema operativo lo permite. Si el cierre ocurre a mitad de una escritura, el siguiente arranque recupera el último conjunto consistente.

### 32. Desinstalación y nueva partida

El guardado local pertenece a la instalación y sus datos de aplicación. Desinstalar puede eliminar el mundo local. No se promete restauración sin backup/exportación explícita. Una instalación nueva puede generar un mundo nuevo con semilla nueva y asignar un hogar inicial diferente según las reglas de inicio. Si el usuario restaura un backup, recupera el mundo respaldado y no debe generarse una nueva identidad por error.

### 33. Integridad y migraciones

Toda partida debe registrar versión del juego, versión normativa, versión de contenido, versión de esquema, semilla de generación y punto de control. Las migraciones deben ser verificables, respaldar el estado anterior y no inventar eventos históricos. Ante datos corruptos, el sistema debe recuperar hasta el último checkpoint seguro y explicar qué datos no pudieron recuperarse.

## PARTE VIII — ESPACIO, GEOGRAFÍA, NAVEGACIÓN Y MAZMORRA

### 34. Un mundo continuo

La ficción del mundo es un único territorio continuo: reino, ciudad, caminos, bosque amurallado, entrada de la torre y Mazmorra. La fragmentación en sectores es una decisión de carga, memoria y simulación; no debe presentarse como instancias independientes ni exigir pantallas de transición arbitrarias.

Los sectores se pueden cargar/descargar en memoria, pero sus entidades, datos, rutas, estado ecológico, eventos y coordenadas lógicas permanecen persistentes.

### 35. Escala de coordenadas

La convención técnica es X = este/oeste, Y = altura, Z = norte/sur. Una unidad de mundo puede corresponder a un metro como escala de trabajo, salvo contenido que declare otra convención. Las dimensiones del reino, la ciudad, los sectores, calles y pisos quedan sujetas a la calibración aprobada en SR-11; SR-15 no convierte dimensiones preliminares en medidas canónicas.

### 36. Streaming interno

El mundo se divide en sectores técnicos para:

- cargar geometría y colisiones cercanas;
- mantener activos modelos visibles;
- limitar navegación local;
- gestionar LOD y oclusión;
- elevar o reducir la resolución de simulación.

El streaming debe ocultar su implementación al jugador tanto como sea posible. No se permite que descargar un sector destruya o reinicialice su estado.

### 37. Torre y espacio interior ampliado

El interior de la torre/mazmorra puede tener una extensión desproporcionada frente a su volumen exterior, incluso con pisos de escala comparable al reino. El runtime debe modelarlo como una topología espacial arcana con dominios internos conectados por umbrales/portales; no necesita fingir que el espacio interior cabe euclidianamente en la malla exterior. La transición conserva identidad, tiempo, continuidad y navegación; puede usar streaming o carga asíncrona técnica, pero no debe alterar la realidad ni generar una copia narrativa del personaje.

### 38. Navegación jerárquica

La navegación separa:

1. **Ruta estratégica:** origen, destino y región/piso.
2. **Ruta regional:** caminos, puertas, puentes, entradas y conexiones entre zonas.
3. **Ruta local:** geometría navegable alrededor del agente.
4. **Locomoción:** aceleración, velocidad, giro, equilibrio, salto y postura según capacidades reales.

En Godot puede utilizarse NavigationRegion3D y NavigationAgent3D para mallas locales, junto con un grafo regional persistente. La elección exacta del algoritmo se valida con prototipos. Los agentes no deben calcular rutas masivas cada fotograma.

### 39. Geometría de combate

Las rutas deben admitir corredores estrechos y anchos, escaleras, cámaras, desniveles, pilares, minerales, puertas, puentes, zonas seguras y zonas de peligro. No hay salas especiales que sean las únicas donde se permita luchar. Colisiones, línea de visión, alcance, cobertura, obstáculos, terreno y espacio de maniobra afectan al combate.

### 40. Zona segura de la Mazmorra

La pequeña zona segura de cada piso tiene baja o nula generación espontánea ordinaria de monstruos, pero no es una barrera inviolable. Un monstruo puede entrar si una razón, motivación, persecución, desplazamiento, error o circunstancia lo lleva allí. El sistema no debe imponer inmunidad a la zona si SR-11 no la define.

## PARTE IX — MOVIMIENTO, COMBATE Y REPRESENTACIÓN

### 41. Movimiento continuo

El personaje y las entidades activas deben desplazarse mediante locomoción continua con velocidad, aceleración, frenado, orientación y colisiones. No se acepta el salto entre posiciones como sustituto de desplazamiento. El nivel de detalle visual puede reducirse lejos del observador, pero la posición lógica y la ruta siguen siendo coherentes.

### 42. Animación

El controlador de animación puede usar state machines, blend spaces, retargeting, in-place animation o root motion según el asset. Debe sincronizarse con la locomoción lógica. La animación no decide si un golpe conectó, si una herida ocurrió, si una puerta se abrió o si un hechizo impactó. Las transiciones de caminar, correr, detenerse, girar, atacar, defender, recibir daño, incapacitar y descansar deben ser suaves y compatibles con el rig.

### 43. Combate en tiempo real

El combate visible es continuo. Las entradas del usuario y decisiones de IA generan comandos de ataque, defensa, movimiento, evasión, bloqueo, uso de objetos, formulación arcana y retirada. El dominio de combate resuelve tiempo, alcance, geometría, anatomía, protección, material, capacidades, velocidad, fatiga y estado emocional. HP no reemplaza la evaluación anatómica. MP es interfaz numérica cuando aplica, no una fisiología universal.

### 44. Estados y consecuencias

Heridas, sangrado, daño interno, amputación, shock, pánico, agotamiento, efectos arcanos, buffs y debuffs deben persistir con su causa, duración, intensidad, tratamiento y consecuencias. La muerte ordinaria no produce respawn; los modos alternativos deben estar separados y declarados como perfil de reglas.

### 45. Adaptación durante el combate

La IA táctica observa acciones reales y conserva evidencia. No puede contrarrestar una maniobra que no conoce o no tuvo oportunidad de observar. Su conducta debe diferenciar especies, inteligencia, capacidad de aprendizaje y experiencia. Un enemigo puede ser engañado, distraído, desinformado o repetir un error.

## PARTE X — ARCANA, VEYRATH Y SISTEMA MÁGICO

### 46. Autoridad arcana

SR-07 es la autoridad sobre Trama, flujo, Resonancias, fuentes, límites, costes, resistencias, interacción natural y fenómenos arcanos. SR-09 y el Anexo A definen el combate mágico y el catálogo de referencia. SR-13 define el papel de la Arcana en la civilización. SR-15 solo implementa esos contratos.

### 47. Veyrath

Veyrath es la lengua arcana original aprobada. Las fórmulas se expresan como oraciones de palabras independientes, con orden y función gramatical; no como sílabas sueltas. El catálogo inicial de pisos 1–5 contiene 72 hechizos de referencia, cada fórmula inicial con nueve palabras completas, conforme al Anexo A de SR-09.

### 48. Interfaz de magia

La interfaz del jugador debe:

1. mostrar únicamente palabras conocidas por el personaje;
2. permitir selección y orden consciente de palabras;
3. mostrar traducción de comprensión cuando proceda, sin sustituir la formulación Veyrath;
4. validar gramática, semántica, dominio, recursos, postura, entorno y prerrequisitos;
5. mostrar progreso del cántico y tiempo de casteo;
6. permitir cancelación/interrupción con consecuencias según fase;
7. ofrecer autocompletado solo cuando el personaje ya domine esa oración y cumpla el umbral aprobado;
8. conservar el tiempo, coste, requisitos y vulnerabilidad del cántico aun con autocompletado.

### 49. Balance y aprendizaje mágico

El mago intercambia tiempo de ejecución y vulnerabilidad por alcance, control, defensa, utilidad, percepción y curación. Un guerrero puede reaccionar físicamente con mayor inmediatez. Un sanador puede evitar que una lesión tratable sea mortal, pero no resucitar gratuitamente ni eliminar consecuencias. La capacidad de aprendizaje facilita comprender palabras, gramática y hechizos; no concede automáticamente conocimientos ni dominio.

### 50. Catálogo y descubrimiento

Los 72 hechizos aprobados son el repertorio de referencia inicial para pisos 1–5. No significa que todos los personajes los conozcan, que aparezcan todos en el primer piso o que no puedan descubrirse variantes. Nuevos hechizos requieren fórmulas, gramática, costes y validación conforme a SR-07 y SR-09; no se inventan como botones sin mecanismo.

## PARTE XI — ECONOMÍA, SOCIEDAD Y NARRATIVA

### 51. Economía

Toda moneda, transacción, propiedad, material, cristal, inventario, contrato, fabricación y recompensa debe pasar por Economy Domain conforme a SR-10. Los inventarios no son infinitos. Los precios son contextuales. El gremio puede mediar, ofrecer servicios y gestionar contratos, pero no crea fondos de la nada.

Los cristales y materiales de monstruos constituyen la fuente principal de botín de la Mazmorra. No se debe incorporar cofres rompibles como sistema básico de recompensa. Los nombres de moneda MC/MP/MO permanecen provisionales y no canónicos hasta una futura revisión.

### 52. Biología y ecología

Cada especie y población utiliza mecanismos de SR-08: alimentación, necesidades, metabolismo, reproducción, compatibilidad, enfermedad, adaptación y relación con el hábitat. La Mazmorra genera monstruos; esa es la explicación general conocida, pero no se afirma que sea el único mecanismo posible. Los monstruos no envejecen por senescencia y su fuerza puede aumentar con el tiempo que sobreviven conforme a las reglas de SR-08. La simulación agregada debe respetar poblaciones y recursos.

### 53. Sociedad y Arcana

La Arcana es un fundamento importante de la civilización: infraestructura, oficio, investigación, cultura, filosofía y creencias. No es una deidad ni tiene voluntad propia. Las religiones pueden venerarla o interpretarla, pero la fe no concede poder automáticamente. Los dioses permanecen sin definición ontológica o mecánica; SR-15 no debe crear dioses, bendiciones ni sistemas de favor divino no aprobados.

### 54. Narrativa fundacional y emergente

La campaña **El Eco de Vhaloren** proporciona historia previa, misterio y dirección inicial. Incluye el Triple Eco, una expedición desaparecida, tres Anclas y un mecanismo en las profundidades. Los nombres y detalles declarados como de trabajo en SR-14 deben conservar su estado de nomenclatura allí indicado. La campaña ofrece misiones y objetivos, pero los resultados son reales y abiertos: NPC o monstruos pueden actuar, morir, desaparecer, resolver objetivos o alterar la situación antes del jugador.

### 55. Misiones manuales y emergentes

El gremio y el diseño autoral pueden crear tutoriales y misiones manuales. Las misiones emergentes se originan en necesidades, riesgos, relaciones, eventos, recursos, promesas, conflictos o descubrimientos. Ambas clases deben usar el mismo contrato de misión y trazabilidad. Un marcador de misión no fuerza al mundo a conservar el objetivo si la causalidad lo cambió.

## PARTE XII — PRESENTACIÓN VISUAL Y ASSETS

### 56. Dirección visual

- Estilo: semi-realista estilizado.
- Mundo: geometría 3D real con presentación 2.5D.
- Cámara: isométrica ortográfica.
- Personajes: modelos 3D completos con anatomía y rigs adecuados.
- Entornos: arquitectura fantástica medieval, bosque, muro, reino y torre/mazmorra.
- Animación: locomoción continua, giros naturales, transiciones, combate y acciones contextuales.

No se adopta como arte final el blockout experimental de cubos, cápsulas o figuras geométricas. El blockout sirve únicamente para validar escala, distribución, navegación, visibilidad y conectividad. Las referencias DanMachi/Sword Art Online describen aspiraciones de tono y estructura, no autorización para copiar personajes, mapas, nombres, diseños o material protegido.

### 57. Pipeline de assets

El pipeline debe contemplar:

1. modelo fuente;
2. revisión de malla, escala, topología y materiales;
3. rigging y jerarquía de huesos;
4. skinning y pesos;
5. animaciones y pruebas de transición;
6. exportación glTF/GLB u otro formato compatible aprobado;
7. importación a Godot;
8. LOD, colisiones, impostores y variantes cuando corresponda;
9. validación de rendimiento y licencia;
10. registro de asset, versión y entidad/especie para la que es válido.

No se decide aún un proveedor de generación 3D concreto. No generar modelos complejos en el teléfono durante el juego. Utilizar assets preparados, variantes controladas y plantillas verificadas.

### 58. Cámara y movimiento

La cámara isométrica ortográfica presenta el mundo y puede admitir zoom limitado de observación. La cámara no cambia coordenadas de simulación, escalas reales, distancias o resultados físicos. La rotación de cámara no está fijada como requisito; no debe agregarse sin decisión de dirección de juego o prueba de usabilidad.

## PARTE XIII — OBSERVATORIO Y HERRAMIENTAS DE DESARROLLO

### 59. Observatorio pasivo

El Observatorio consulta el mismo estado objetivo del juego. Debe permitir:

- ver mapa y regiones;
- seguir entidades, grupos y organizaciones;
- buscar y filtrar cronología;
- abrir eventos y consultar causas, participantes y consecuencias;
- inspeccionar identidad, capacidades, relaciones, memoria accesible, inventario, salud, objetivos e historia;
- distinguir estado objetivo de creencias de los agentes;
- consultar métricas ecológicas, demográficas, económicas, narrativas y de rendimiento;
- observar localización con cámara aérea o de seguimiento;
- reproducir una crónica con nivel de fidelidad declarado.

### 60. Reproducción histórica

La reproducción no puede inventar animaciones y presentarlas como grabaciones exactas. Debe declarar si la reconstrucción es exacta, detallada, resumida, inferida o no reconstruible. Solo se reproduce el nivel de detalle que los registros permiten.

### 61. Intervención y ramas experimentales

La observación es pasiva por defecto. Las herramientas de intervención requieren modo explícito, confirmación, motivo, usuario/actor de administración, datos anteriores y posteriores, y registro de auditoría. Las ramas de experimento no contaminan el mundo canónico. Una prueba puede explorar consecuencias sin alterar la partida principal.

## PARTE XIV — ANDROID, GODOT Y COMPILACIÓN

### 62. Decisiones de tecnología aprobadas

La primera implementación se construirá con:

- Godot 4.7.2 Standard;
- GDScript;
- proyecto Android como aplicación local;
- GitHub Actions para validación y compilación reproducible;
- exportación inicial APK Debug para pruebas;
- almacenamiento local, sin base de datos remota ni servidor obligatorio.

La versión del motor se fija para una entrega repetible. Actualizar Godot requiere una decisión de ingeniería documentada, pruebas de regresión y validación de exportación; no se actualiza por accidente a una beta.

### 63. Arquitectura de escenas

La escena Godot contiene la capa de presentación y la composición visual; los dominios de simulación se mantienen en módulos lógicos desacoplados. No se debe anclar la identidad o existencia de un NPC a un Node3D. Al descargar un sector visual, el agente sigue existiendo y el scheduler continúa su proceso según su nivel de resolución.

### 64. Android y presupuesto de recursos

El dispositivo de referencia preliminar comunicado es un Xiaomi Note 12 con memoria física reportada de 6 GB más expansión virtual. Esta referencia debe medirse y no se interpreta como límite oficial de población. Las pruebas deben medir RAM real, CPU, GPU, almacenamiento, temperatura, batería, tiempo de catch-up y estabilidad. No se fijan máximos definitivos de agentes, modelos, polígonos, texturas o sectores antes de medir.

### 65. Renderizado y rendimiento

El renderizador Compatibility es una base de prueba para compatibilidad Android; la elección final entre Compatibility y Mobile se valida en el dispositivo. La aplicación debe utilizar culling, LOD, occlusion, streaming de sectores, pooling de objetos visuales, atlas y compresión adecuada. No se ejecuta lógica de miles de entidades en `_process` de cada Node.

### 66. Ciclo de vida de Android

La aplicación debe reaccionar a suspensión, reanudación, pérdida de foco, cierre del proceso y baja memoria. Antes de suspenderse debe intentar persistir checkpoint. Al recuperar, valida journal y snapshot. No presupone que Android mantendrá el proceso vivo mientras la aplicación está en segundo plano.

### 67. GitHub Actions

El flujo de build debe:

1. fijar versiones de Godot, Java y Android SDK;
2. instalar únicamente paquetes Android requeridos;
3. aceptar licencias de forma no interactiva y con booleanos YAML válidos;
4. importar proyecto en modo headless;
5. ejecutar pruebas automáticas;
6. verificar export preset Android;
7. exportar APK Debug;
8. comprobar que el archivo existe y no está vacío;
9. publicar artefacto con número de commit y logs;
10. fallar claramente si un paso no se cumple.

Un build exitoso confirma que el paquete se generó, no que el juego se ve o se juega correctamente. La prueba en dispositivo sigue siendo obligatoria.

## PARTE XV — PRUEBAS, VALIDACIÓN Y ACEPTACIÓN

### 68. Estrategia de pruebas

Las pruebas se organizan en:

- unitarias: fórmulas, validadores, conversión, identidad y contratos;
- integración: transacciones entre dominios;
- deterministas: misma semilla, reglas y secuencia de comandos producen el mismo resultado declarado;
- persistencia: cerrar, matar proceso, restaurar y migrar;
- causalidad: ningún cambio sin comando/evento autorizado;
- autonomía: mundo sin jugador;
- simulación temporal: catch-up y límites de anomalía;
- rendimiento: perfiles Android medidos;
- visuales: navegabilidad, modelos y animaciones en dispositivo;
- aceptación del usuario: criterios explícitos de cada etapa.

### 69. Pruebas obligatorias del núcleo

1. Crear mundo sin jugador.
2. Crear agentes con IDs estables.
3. Ejecutar agentes con percepción limitada.
4. Confirmar que un agente no conoce un evento que no observó ni recibió.
5. Registrar comando, validación y evento.
6. Rechazar un comando inválido sin cambios laterales.
7. Repetir una operación idempotente sin duplicar recompensa.
8. Cerrar y reabrir preservando identidad y estado.
9. Recuperar de cierre abrupto usando último snapshot y journal consistente.
10. Avanzar tiempo offline sin reproducir fotogramas.
11. Detectar salto de reloj y registrar anomalía.
12. Elevar resolución de una expedición cuando se aproxima combate o evento crítico.
13. Simular un agente lejos sin renderizar su modelo.
14. Cargar el modelo de una entidad sin cambiar su identidad ni atributos.
15. Abrir Observatorio y comprobar que no altera probabilidades o estados.

### 70. Pruebas obligatorias de dominio

- biología: recursos, necesidades, reproducción, enfermedad, adaptación y población;
- monstruos: generación de Mazmorra, supervivencia prolongada, aprendizaje y cambios de rasgo;
- combate: golpes en tiempo real, lesiones localizadas, sangrado, cura, amputación, incapacitación y muerte;
- magia: vocabulario conocido, oraciones Veyrath válidas, errores, casteo, interrupción, costes y autocompletado;
- economía: propiedad única, transacciones, escasez, stock, cristales y fabricación;
- geografía: ruta continua, muro, bosque, torre, piso interior ampliado y carga/descarga de sectores;
- sociedad: familia, institución, rumor, ley, conflicto y cambios organizacionales;
- narrativa: misión manual, misión emergente, fracaso, ausencia del jugador y final alternativo.

### 71. Pruebas de autonomía prolongada

El mundo debe superar ejecuciones sin jugador a duraciones progresivas —por ejemplo, un día, siete días, treinta días y cien días simulados— con informes de población, economía, recursos, expediciones, lesiones, muertes, nacimientos, conflictos, cambios sociales, eventos y errores. Los intervalos concretos son pruebas de calibración; no constituyen una promesa de rendimiento antes de la implementación.

### 72. Criterio de autonomía real

La autonomía no se demuestra con personajes caminando. Debe observarse una cadena de decisiones basada en estado y conocimiento: necesidad/motivación → percepción → intención → plan → comando → validación → resultado → aprendizaje/memoria → consecuencia. Las historias pueden ocurrir sin misiones autorales activas y sin intervención del jugador.

### 73. Criterios de cierre Android

No se considera una versión jugable aceptada hasta que:

- instala y abre en dispositivo objetivo;
- muestra una escena jugable coherente, no pantalla vacía;
- permite navegar y mover entidades con continuidad;
- el combate se resuelve en tiempo real de forma consistente;
- los agentes conservan estado lógico cuando no están visibles;
- guardado, cierre, reapertura y catch-up funcionan;
- los assets se cargan y animan sin saltos evidentes;
- el rendimiento está medido;
- las pruebas de causalidad y persistencia pasan;
- los fallos conocidos están documentados.

## PARTE XVI — PLAN DE IMPLEMENTACIÓN

### 74. Regla de ejecución por puertas

Cada etapa tiene que producir un artefacto verificable y superar sus criterios de aceptación antes de aumentar su alcance. Un ZIP no es un resultado funcional por sí solo. Un APK generado no es un juego aceptado. Una escena visual no demuestra autonomía.

### 75. WLA-0A — Núcleo y persistencia

**Objetivo:** una aplicación Android que inicia un mundo local y conserva eventos/estado.

Entregables:
- proyecto Godot 4.7.2 Standard;
- Application Shell;
- SystemCore mínimo;
- Entity Registry;
- World Clock;
- comando/evento/validación;
- persistencia local journal + snapshot;
- pantalla de estado/diagnóstico;
- pruebas unitarias e integración;
- APK Debug instalable.

Aceptación: crear mundo, cerrar, matar proceso, reabrir y demostrar que la identidad y los eventos no se duplican ni se pierden.

### 76. WLA-0B — Scheduler y laboratorio sin jugador

**Objetivo:** mundo simple que avanza sin usuario.

Entregables: scheduler, tiempo, niveles de resolución iniciales, pocos agentes con necesidades y objetivos, registro de eventos, catch-up básico y Observatorio de lectura.

Aceptación: el mundo produce una secuencia causal verificable sin jugador y conserva resultados después del catch-up.

### 77. WLA-1A — Cognición y memoria

**Objetivo:** agentes que toman decisiones a partir de información limitada y trayectoria individual.

Entregables: percepción, creencias, motivaciones, memoria episódica/semántica/procedimental, objetivos, planes, aprendizaje y explicaciones trazables.

Aceptación: dos agentes con información y experiencias diferentes reaccionan de forma distinta a una misma situación; ninguna entidad accede a conocimientos no adquiridos.

### 78. WLA-1B — Biología, economía y ecología

**Objetivo:** demostrar que organismos, recursos y población mantienen procesos autónomos.

Entregables: necesidades, alimentación, producción, consumo, reproducción, enfermedades, migración, propiedad, mercado y contratos.

Aceptación: balances y transacciones coherentes, sin inventarios infinitos ni población sin mecanismo.

### 79. WLA-2A — Geografía y representación

**Objetivo:** construir una región continua y navegación real.

Entregables: terreno, ciudad, bosque, muro, caminos, torre, primer piso, streaming interno, navegación regional/local y cámara isométrica.

Aceptación: recorrido continuo, sectores cargables sin pérdida de estado, colisiones y rutas verificadas.

### 80. WLA-2B — Entidades visuales y animación

**Objetivo:** reemplazar proxies por modelos reales probados.

Entregables: personaje humanoide maestro, al menos una criatura, rigs, animaciones, colisiones, locomoción y LOD.

Aceptación: caminar, correr, detenerse, girar y ejecutar acciones sin teletransportes visuales ni divergencia de posición lógica.

### 81. WLA-3A — Combate y Arcana

**Objetivo:** combate continuo con daño anatómico y magia Veyrath.

Entregables: ataque, defensa, evasión, lesiones, estados, tratamiento, muerte, hechizos, formularios/cánticos, costes e interrupción.

Aceptación: escenarios reproducibles de combate, curación y ejecución arcana, con resultados coincidentes con SR-07 y SR-09.

### 82. WLA-3B — Sociedad, narrativa y campaña

**Objetivo:** introducir instituciones, tutoriales, misiones y El Eco de Vhaloren en el mundo autónomo.

Entregables: hogares, gremio, tabernas, barrios, organizaciones, misiones authored y emergentes, personajes y pistas.

Aceptación: el jugador puede aceptar o ignorar objetivos; NPC siguen actuando y los resultados no son garantizados por guion.

### 83. WLA-4 — Estabilidad, calibración y expansión

Pruebas de larga duración, rendimiento, memoria, batería, migración de partidas, balance, densidad ecológica, economía, clases, magia y expansión de pisos. No escalar contenido masivo antes de que los sistemas fundamentales superen sus pruebas.

## PARTE XVII — CONTROL DE VERSIONES Y CAMBIOS

### 84. Versionado

Cada release del runtime registra:
- versión de la aplicación;
- versión de SR-01 a SR-15 usada;
- versión de contenido/catálogos;
- versión de esquema de persistencia;
- versión de assets;
- commit de código;
- semilla de mundo;
- resultado de pruebas.

### 85. Cambio de una normativa

Un cambio de una regla aprobada requiere:
1. identificar la norma y sección afectada;
2. explicar motivo, riesgo y compatibilidad;
3. preparar propuesta/versionado;
4. obtener aprobación del autor cuando altere una regla canónica;
5. actualizar documentos dependientes y pruebas;
6. mantener historial de cambios.

Un arreglo interno de código que implementa correctamente una regla no exige nueva aprobación de lore, pero sí pruebas. Una decisión de diseño que cambie la regla sí requiere revisión normativa.

### 86. Decisiones de ingeniería abiertas

Permanecen sujetas a pruebas: elección final del renderizador Android, frecuencia de ticks, cantidad máxima de agentes, presupuesto de memoria, tamaño definitivo de sector, política de compresión, backend local de persistencia final, algoritmo concreto de planificación, frecuencia de catch-up, profundidad de historial de replay, optimizaciones de navegación y pipeline de assets/proveedor 3D.

Estas decisiones no autorizan a cambiar Godot 4.7.2/GDScript como punto de partida ni las reglas de offline-first, autoridad local y separación lógica/visual. Toda sustitución de una decisión técnica aprobada debe documentarse y justificarse.

## PARTE XVIII — ESTADO Y DECLARACIÓN FINAL

### 87. Estado real del proyecto al aprobar SR-15

La aprobación de SR-15 cierra el marco técnico de referencia, no el producto. Existió un scaffold de Godot y un flujo de GitHub Actions que alcanzó exportación; una prueba visual posterior no alcanzó el estándar y el blockout experimental fue rechazado como representación de calidad. Dichos artefactos pueden aportar aprendizaje de build y exportación, pero no se consideran el juego definitivo ni demuestran autonomía, navegación o combate aceptados.

Los próximos entregables deben empezar por WLA-0A y WLA-0B con pruebas. No debe añadirse contenido visual masivo antes de demostrar el núcleo, persistencia y ciclo de vida de la aplicación.

### 88. Declaración normativa

El Sistema Reactor debe ejecutar una única realidad persistente, causal y auditable. El World Laboratory y el RPG Android comparten esa realidad. Los agentes perciben, recuerdan, aprenden y actúan sin omnisciencia. Los dominios validan los cambios. El tiempo continúa con catch-up controlado. Los datos sobreviven al cierre. La representación visual explica el estado, pero no lo gobierna. El Observatorio observa por defecto. La historia ofrece dirección sin dictar resultados. La simulación debe demostrar autonomía mediante trazas, pruebas y consecuencias verificables.

**SR-15 v1.0 — NORMATIVA TÉCNICA OFICIAL APROBADA POR AUTORIZACIÓN EXPRESA DEL AUTOR EL 2026-11-20.**
